# Offline-first PWA integration

Implemented in core **2.2.0**. The PWA work began as the unpublished 2.1 milestone
and is included in 2.2.0; version 2.0.0 does not contain these APIs.

The integration adds an install manifest, an executable service worker, a public
offline shell, background synchronization and foreground fallback. It reuses the
existing IndexedDB records/outbox, HTTP transport and authority protocol. D1 and
the application's server policy continue to decide acceptance, transformation
and rejection. See [ADR-0007](adr/0007-offline-first-pwa-and-worker-execution.md)
and [W01-W16](requirements/pwa.md).

After online bootstrap and verified offline readiness, the application can
reopen an allowlisted URL, read locally available records and commit edits
without a network. Delivery is attempted when execution and authorized
connectivity are available. Installation does not guarantee that a browser will
grant background execution or preserve storage indefinitely.

## Package boundaries and application files

| Entry point | Environment and responsibility |
| --- | --- |
| `@mintcd/sync-engine/pwa/client` | Page coordinator: local-first facade, worker messages, reconnect triggers and foreground fallback. |
| `@mintcd/sync-engine/pwa/worker` | Service-worker host: bounded complete synchronization runs and owned-session cleanup. |
| `@mintcd/sync-engine/pwa/cache` | Explicit public shell/assets, fetch routing and cache readiness. |
| `@mintcd/sync-engine/pwa/registry` | Durable public bootstrap descriptors and cooperative account-session leases. |
| `@mintcd/sync-engine/integrations/vinext/pwa` | Node/Vite build plugin; keep it out of browser and worker imports. |

Importing these runtime modules opens no database, registers no worker and
installs no event listeners. Applications call their factories explicitly.

A typical application owns:

```text
sync.config.json                 public generator/PWA configuration
vite.config.ts                   vinext() and syncEnginePwa() plugins
sync/model.ts                    shared browser/worker-safe domain model
sync/replica.ts                  durable bootstrap, replica sessions and cleanup
sync/client.ts                   page engine composition
sync/worker.ts                   exports syncWorkerOptions
offline/entry.ts                 browser-only offline UI entry
public/icon-192.png              public install icons
public/icon-512.png
```

Generation also produces the existing HTTP route/client configuration and:

```text
sync/worker.generated.ts         event wiring around the application composition
sync/register.generated.ts       registration function used by the build plugin
.sync-engine/vinext.manifest.json source ownership and content hashes
```

The generated worker imports `/pwa/worker`, `/pwa/cache`, a build-provided cache
manifest and the application `sync/worker.ts`. That application module imports
the shared replica factory and model, then uses the existing `/client`,
`/records`, `/adapters/indexeddb` and `/transport/http-client` exports. It must not
import page registration, server authentication modules, D1 bindings or policy.
Worker-usable authentication belongs in a separate browser/worker-safe module.

## Configure and build a Vinext PWA

Add an explicit `pwa` object to the existing strict JSON generator configuration:

```json
{
  "version": 1,
  "contractVersion": "notes/1",
  "endpoint": "/api/sync",
  "pwa": {
    "appId": "my-notes",
    "workerModule": "sync/worker.ts",
    "offlineEntry": "offline/entry.ts",
    "scope": "/",
    "navigationPaths": ["/", "/notes"],
    "publicAssets": ["/fonts/app.woff2"],
    "manifest": {
      "id": "/",
      "name": "My Notes",
      "shortName": "Notes",
      "startUrl": "/notes",
      "scope": "/",
      "display": "standalone",
      "themeColor": "#1f5b3f",
      "backgroundColor": "#ffffff",
      "icons": [
        { "src": "/icon-192.png", "sizes": "192x192", "type": "image/png" },
        { "src": "/icon-512.png", "sizes": "512x512", "type": "image/png" }
      ]
    }
  }
}
```

Supply the referenced files in the application's public directory. Remove the
optional font entry if the application does not use it. The build validates the
required public 192×192 and 512×512 PNG icons, including their dimensions; their
purpose must be `any` or omitted.

Use one opt-in plugin in the existing Vite configuration:

```ts
import { defineConfig } from "vite";
import vinext from "vinext";
import { syncEnginePwa } from "@mintcd/sync-engine/integrations/vinext/pwa";

export default defineConfig({
  plugins: [
    vinext(),
    syncEnginePwa({ config: "./sync.config.json", register: "auto" }),
  ],
});
```

The plugin's `config` accepts the JSON path relative to Vite's root or the
already-authored `VinextGeneratorConfig` object. `register` defaults to `auto`.
Using this build plugin requires Vite `>=8.3.4 <9`; its runtime version check is
separate from the optional peer dependency, so ordinary SDK users do not need
that Vite version merely to install the package.
Automatic mode injects registration into the production Vinext browser entry
and the offline browser entry. Application code does not need a manual
registration call. Registration failures dispatch the page event
`sync-engine:pwa-registration-error` with the error in `event.detail`.

Generate the source files before building:

```sh
npx sync-engine generate vinext --config ./sync.config.json --dry-run
npx sync-engine generate vinext --config ./sync.config.json
npx sync-engine generate vinext --config ./sync.config.json --check
npx vite build
npx vinext start
```

Use `--scaffold-server` on the generation command if an initial server
composition stub is needed. Follow the [Vinext generator guide](vinext-generation.md)
to implement its authentication, authorization and authority. The plugin checks
that the generated worker/registration sources match the current configuration;
it does not replace the CLI's ownership or drift checks.

Registration is disabled during ordinary Vite development. Verify worker and
cache behavior using the production build on HTTPS or a browser-recognized local
secure context. The generated registration code rejects a different worker
already occupying the same exact scope.

| PWA configuration | Meaning/default |
| --- | --- |
| `appId` | Required application/cache identifier; at most 64 portable characters. |
| `workerModule` | Required app-relative `.ts` module exporting `syncWorkerOptions`. |
| `offlineEntry` | Required app-relative `.ts` or `.tsx` browser program. |
| `scope` | Same-origin directory path, default `/`. |
| `workerPath` | Default `<scope>sync-worker.js`. |
| `shellPath` | Default `<scope>sync-offline.html`. |
| `manifestPath` | Default `<scope>manifest.webmanifest`. |
| `navigationPaths` | Required exact document pathnames, including `manifest.startUrl`; no wildcards or query strings. |
| `publicAssets` | Optional explicit public URLs; manifest icons are included automatically. |
| `manifest` | Required identity, name, start URL, scope, display mode and icons; optional short name and six-digit hexadecimal colors. |

The worker, shell, manifest and offline navigation paths must fit the configured
scope. The generated worker's directory must permit that scope without a
broader `Service-Worker-Allowed` header. Broader custom registrations require
application-owned integration. The manifest scope/start URL must agree with the
worker and navigation allowlist. Vite's base must be an unencoded same-origin
absolute path; place configured public paths under that base. Cross-origin
asset prefixes and runtime-generated client asset URLs are unsupported.

The production build emits the executable worker, neutral shell HTML, manifest,
offline entry/chunks/CSS and declared assets into the actual client output. It
also includes the reachable public Vinext client graph, excluding SSR/RSC output,
source maps and private runtime responses. Build inspection metadata lives at
`.sync-engine-pwa/<appId>/build.json` and `precache-<buildId>.json` inside that
output. These are separate from the CLI's source ownership manifest.

## Bootstrap identity before enabling a replica

`openPwaReplicaRegistry({ name })` opens a separate IndexedDB bootstrap database.
Its descriptors contain public identifiers only:

```ts
const descriptor = {
  replicaKey: "main",
  accountId: authorizedAccountId,
  databaseName: "my-notes-account-alice",
  streamId: authorizedStreamId,
  clientId: persistedDeviceClientId,
  contractVersion: model.contractVersion,
  modelKey: "notes",
  // Optional public app-release marker used by deployment bootstrap.
  deploymentVersion: "release-2026-10-18",
};
```

`authorizedAccountId`, `authorizedStreamId`, `persistedDeviceClientId` and `model`
are application values. Descriptor account/stream identifiers do not grant
server access. Never put credentials in the descriptor or generator JSON.

On first authorized bootstrap, serialize initialization across tabs, persist a
recoverable descriptor with its stable client ID in application storage, create
the local record database and replica metadata, and then call
`registry.enable(descriptor)`. Close/drain initialization handles before enabling
the descriptor. If initialization is interrupted, reuse that descriptor rather
than generating a different client ID for an already-bound database. The registry
does not atomically initialize a separate replica database for the application.

This ordering concerns enabling the **replica descriptor**, not registering the
service-worker script. Automatic script registration may happen earlier; a cold
worker must refuse to open a missing or disabled replica bootstrap.

Normal page/worker recovery should require existing storage at both levels:

```ts
const database = await openIndexedDbRecordDatabase({
  name: descriptor.databaseName,
  streamId: descriptor.streamId,
  schema: model.schema,
  requireExisting: true,
});
const replica = await openRecordReplica({
  database, clientId: descriptor.clientId, model, requireExisting: true,
});
```

These factories come from `/adapters/indexeddb` and `/records`. A missing database,
stream or replica metadata fails with `corrupt-state` instead of silently creating
genesis or allocating client sequence 1. Report explicit bootstrap/recovery
required. Neither this option nor increasing an IndexedDB version migrates a
schema, restores evicted unsent edits or resets a retained history safely.

## Share an application-owned session factory

An app-owned `sync/replica.ts` should resolve a configured key to a statically
imported model and acquire its registry lease before opening storage. The core
sequence is:

```ts
const registry = await openPwaReplicaRegistry({ name: "my-notes-bootstrap" });
const lease = await registry.acquire(replicaKey, { signal });
await lease.assertEnabled();
const descriptor = lease.descriptor;
// Validate contractVersion/modelKey, then open the existing database/replica above.
// Recheck enablement after asynchronous opening, before returning the session.
await lease.assertEnabled();
```

The factory also composes `createHttpSyncTransport` with the authorized endpoint,
stream and shared model. Its `headers` callback can call `lease.assertEnabled()`
and resolve fresh worker-usable authentication for every exchange. Same-origin
cookie credentials are supported by the existing HTTP transport. Page-memory
bearer tokens and `localStorage` are not a cold-worker authentication strategy.
Refresh/reauthentication and origin/CSRF policies remain application-owned.

Give the session an idempotent cleanup function. It closes the replica, awaits
`database.closeAndDrain()`, releases the lease and closes its registry handle, in
that order. Partial opening failures need the same cleanup. Keep the lease until
storage drain finishes, including after a worker factory's signal is aborted.
If cleanup cannot establish a safe drain, retain the lease/fail cleanup rather
than claiming that destructive logout is safe.

`engine.close()` and `database.close()` prevent new work but can return before
already-started native transactions settle. `database.closeAndDrain()` closes
this connection and waits for its active native transactions; it does not drain
another page or worker's connection. The registry's cross-context barrier depends
on every participating owner following the same lease/drain contract.

The following examples assume the application factory
`openReplicaSession(replicaKey, { signal? })` returns
`{ replica, database, transport, lease, close }` with that ownership contract.
This helper is application code, not a package export.

## Compose the worker and page

The configured application `sync/worker.ts` exports options; it does not eagerly
open an engine:

```ts
import { createSyncEngine } from "@mintcd/sync-engine/client";
import type { CreateSyncWorkerHostOptions } from "@mintcd/sync-engine/pwa/worker";
import { model } from "./model";
import { openReplicaSession } from "./replica";

export const syncWorkerOptions = {
  contractVersion: model.contractVersion,
  replicaKeys: ["main"],
  async openSession(replicaKey, { signal }) {
    const session = await openReplicaSession(replicaKey, { signal });
    try {
      const engine = await createSyncEngine({
        replica: session.replica,
        transport: session.transport,
        autoSync: false,
      });
      return {
        engine,
        signal: session.lease.signal,
        assertEnabled: () => session.lease.assertEnabled(),
        close: () => session.close(),
      };
    } catch (error) {
      await session.close();
      throw error;
    }
  },
} satisfies CreateSyncWorkerHostOptions;
```

The generated worker creates the cache/host and attaches their event handlers.
Each accepted extendable event owns a bounded complete
`prepare -> exchange -> reconcile` run through `event.waitUntil()`. Closing a
page, losing a reply port or cancelling a page observer cannot cancel that
event-owned run. The worker reconciles responses directly into IndexedDB.

Compose the page with the same application session factory:

```ts
import { createPwaSyncEngine } from "@mintcd/sync-engine/pwa/client";
import { model } from "./model";
import { openReplicaSession } from "./replica";

const session = await openReplicaSession("main");
const engine = await createPwaSyncEngine({
  replica: session.replica,
  transport: session.transport,
  worker: { replicaKey: "main", contractVersion: model.contractVersion },
  lifecycle: {
    signal: session.lease.signal,
    assertEnabled: () => session.lease.assertEnabled(),
  },
  subscribeChanges: listener => session.database.subscribe(listener),
}).catch(async error => {
  await session.close();
  throw error;
});

let closing: Promise<void> | undefined;
const close = (): Promise<void> => closing ??= (async () => {
  try { await engine.close(); }
  finally { await session.close(); }
})();
session.lease.signal.addEventListener("abort", () => {
  void close().catch(error => console.error("Session cleanup failed", error));
}, { once: true });
if (session.lease.signal.aborted) await close();

const receipt = await engine.mutate(intent);
const progress = await engine.sync();
// Call close() during application teardown as well as on account invalidation.
```

Here `intent` is application domain input. Its lifecycle signal closes the
engine; the application abort handler above performs database drain
and lease release. Do not release a shared lease merely because a caller stopped
waiting for `sync()`.

The app-owned `offline/entry.ts` mounts the offline UI and uses this local client.
It is an executable browser entry, not an SSR/RSC route. It may reuse shared UI
components, but its cold launch, navigation and required lazy screens must work
without server components, server actions or network-only router behavior.

## Page and host API behavior

`createPwaSyncEngine` accepts the existing [client options](client-api.md), plus
`worker`, optional `lifecycle` and optional `subscribeReconnect` hooks. It returns
the existing mutation/query/resolution/sync/status/close facade and adds
`getWorkerSnapshot()` and `subscribeWorker(listener)`.

| Option | Behavior/default |
| --- | --- |
| `autoSync` | Defaults to **true** for the PWA facade; the underlying foreground engine is constructed with automatic scheduling disabled. |
| `worker.replicaKey` / `contractVersion` | Required configured key and public contract version. |
| `worker.getRegistration` | Defaults to the current page's service-worker registration; an app can return `{ active, sync? }` or `undefined`. No registration is created by the coordinator. |
| `worker.handshakeTimeoutMs` | 1,000 ms per registration lookup, handshake and best-effort Background Sync registration. |
| `worker.responseTimeoutMs` | 45,000 ms for the worker run reply. |
| `subscribeReconnect` | Defaults to browser `online` events; return an unsubscribe function. |
| `lifecycle.assertEnabled` / `signal` | Application account-generation check and invalidation signal. Hooks must settle; provide a signal when initialization may need cancellation. |

Automatic startup, new durable local work and reconnect triggers schedule bounded
runs. A failed run stops automatic follow-ups until a later new write,
reconnect or explicit sync. There is no perpetual polling. `autoSync: false`
leaves scheduling to explicit calls. Failed registration, wake-up or connectivity
cannot reject an already-persisted local mutation receipt.

Worker unavailability, incompatible messages and bounded reply/handshake failures
select foreground fallback against the same replica. A worker that finishes
after fallback starts can safely overlap it: native transactions and authority
idempotency protect identities and canonical history. Actual worker transport or
protocol failures retain their structural classification; authorization failures
do not immediately retry in the foreground.

Overlapping page `sync()` calls share a run and its first caller's settings.
An individual `AbortSignal` cancels that caller's wait. Engine close stops page
scheduling and closes its replica; it does not revoke an already accepted worker
event. The page rereads durable status after a worker reply rather than trusting
message status as authoritative.

Worker observations contain `availability` (`unknown`, `available`, `unavailable`,
`closed`), `phase` (`idle`, `syncing`, `error`), `shellReady`, optional `mode`
(`worker` or `foreground`) and `lastError`. They are separate from persisted
replica/decision status. `shellReady` is a recent worker cache observation, not a
complete offline-ready or installation promise. Readiness also needs compatible
worker control of intended URLs and a usable enabled local bootstrap. Neither
`navigator.serviceWorker.ready` nor registration success establishes that alone.

`createSyncWorkerHost(options)` accepts `contractVersion`, bounded configured
`replicaKeys`, `openSession`, optional engine `syncOptions`, `isOfflineReady`
(cache readiness hook), `onError`, and these limits:

| Host limit | Default |
| --- | --- |
| `maximumDurationMs` | 45,000 ms, covering session opening and synchronization. |
| `cleanupTimeoutMs` | 10,000 ms for owned-session cleanup. |
| `maximumConcurrentRuns` | 4 configured keys. |

The host coalesces active runs per key, passes its cancellation signal into the
factory, checks session enablement and closes the returned engine before calling
the session's optional `close`. Timed-out factories are disposed if they return
late. Unresolved factories/cleanup remain counted against capacity. Application
factories must still release partial resources on failure and honor cancellation.

The host exposes `handleMessage(event)`, `handleSync(event)` and `close()`.
Handlers synchronously return whether they claimed the event and attach work
using its `waitUntil()`. Messages contain bounded version/contract/correlation/key
fields, never arbitrary executable models, database names or endpoints. Error
replies contain stable classifications, without application stacks or prose.
`syncWorkerTag(replicaKey)` is exported by `/pwa/client` and `/pwa/worker` for
application Background Sync registration.

Only classified transient sync failures reject a handled Background Sync event
for possible browser retry. Access/non-transient failures preserve the outbox and
wait for a later application trigger. Background Sync is optional; runtime
delivery remains usable through explicit worker messages or foreground sync.

## Logout, account changes and registry lifecycle

The registry exposes:

| Method | Contract |
| --- | --- |
| `get(key)` / `listEnabled()` | Read a descriptor or enabled descriptors; registrations add `enabled` and `generation`. |
| `enable(descriptor, { signal? })` | Enable/replace under an exclusive lease barrier; returns the durable registration. Identical already-enabled descriptors are reused. |
| `acquire(key, { signal?, timeoutMs? })` | Acquire a shared lease, default wait budget 30 seconds. The lease exposes frozen `descriptor`, `signal`, `assertEnabled()` and idempotent `release()`. |
| `replace(key, prepare, { timeoutMs? })` | Invalidate/drain current owners, call `prepare(retained)` under an exclusive lease barrier, publish its replacement descriptor on success and restore the retained descriptor on failure. Invalid options fail before disablement; default wait budget 30 seconds. |
| `disable(key, { timeoutMs?, cleanup? })` | Disable and advance generation first, then await exclusive quiescence before cleanup; default wait budget 30 seconds. |
| `close()` | Abort this registry handle's lease signals and close its connection. Owners must still drain storage and release leases. |

Web Locks are required for the built-in registry's coordinated sessions and
destructive cleanup. They are independent of Background Sync support. When Web
Locks are unavailable, use the existing foreground client or supply an
application-owned durable coordination design; the package does not pretend an
in-process lock establishes cross-context safety. Registry construction also
accepts injected `indexedDB`, `locks` and `broadcastChannel` implementations.

For logout, use a **separate controller registry handle** to call `disable`.
Disabling invalidates participating session signals; those owners close/drain
their resources and release their leases. The controller then obtains its
exclusive barrier and invokes `cleanup(descriptor)`, where the application may
delete the old replica database. Close the controller after `disable` finishes.
Reusing an owner's registry handle for this control flow can cancel cleanup when
the owner closes that handle.

If an owner holds its lease too long, ignores invalidation, or misses the advisory
BroadcastChannel hint, disabling may time out. The descriptor stays disabled and
cleanup does not run. Report/retry cleanup after owners quiesce; never bypass the
barrier. A server decision committed before logout remains committed. Account
switches must use explicitly initialized, separate storage/client identity and
complete this lifecycle before enabling the next descriptor.

## Cache routing, existing workers and updates

`createPwaCache({ cacheName, assets, shellUrl, navigationPaths, scope?, origin?,
cacheStorage?, fetch? })` returns `install()`, `handleFetch(request)` and
`isReady()`. Assets must be explicit same-origin public URLs; the shell is
neutral HTML. Installation fetches with credentials omitted and rejects invalid
status, redirects, private/no-store policy and unsuitable MIME types. Readiness
requires the final completion marker and every declared asset.

Fetch routing serves declared build assets and uses a network-first document
navigation with offline-shell fallback for exact allowlisted paths. It does not
cache arbitrary runtime responses. API/auth/session/sync/action requests,
non-GET methods, RSC payloads and sensitive headers/queries bypass generic
routing. Domain records and pending delivery remain in IndexedDB.

For an existing application worker, use the composable host/cache handlers and
`register: "manual"`; preserve its registration/build composition. That mode
disables automatic registration injection. Do not replace its routing with an
unconditional `respondWith`: call `cache.handleFetch(request)` and handle only a
non-`undefined` result. Generated source still follows ownership/conflict rules;
application-owned worker, manifest and Vite configuration are not overwritten.

Build caches use immutable app/build identities. Failed candidates cannot
replace the active usable shell. Generated activation claims clients only after
normal browser activation; it does not call `skipWaiting()`. A new worker waits
while an old controlled page is open, and old caches/lazy chunks remain available.
The application owns any more aggressive activation/handoff policy.

**Old build caches are retained automatically.** Automatic cleanup is deferred;
their storage grows across releases. Establish an explicit safe cleanup policy
that accounts for old controlled pages and lazy chunks before production use.
Cache eviction, denied storage or quota failures can remove readiness, and
browser storage is not a permanent backup. History compaction, schema migration
and legacy migration remain separate capabilities.

## Verification and current platform limits

In the repository, `npm run check` includes protocol/worker/page/cache/registry,
consumer-type and existing sync tests. `npm run test:pwa` separately builds and
runs the generated Vinext production fixture in native Chromium against local
workerd D1. These repository scripts are not shipped as application tooling.

Verified behavior includes controlling-worker registration and manifest delivery,
deep-link cold offline launch with every tab closed, lazy JavaScript/CSS,
durable edits across reopen, D1 transformation/rejection, expired/renewed cookie
authentication, response persistence after the last page closes, native worker
termination after authority commit without duplicate history, foreground
fallback, failed candidate installation, waiting updates and logout/account
cleanup, concurrent tabs and queued edits surviving ordinary worker activation.
The current native PWA runner passes 16 checks.

The verified environment is Chromium 155, Vinext 1.2.1 and Vite 8.3.4, using the
Vinext Node production server and a credentialed bridge to native local workerd
D1. Other browser engines, a remote Cloudflare deployment and an automated
installation UI are not claimed. Native Background Sync registration is reported
separately from execution timing: the fixture does not prove guaranteed
browser-granted dispatch or delivery while the browser/device is closed.
