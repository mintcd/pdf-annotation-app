# Client coordination and IndexedDB

Implemented: `createSyncEngine`, bounded synchronization and subscriptions, and
an IndexedDB record database, [HTTP transport](http-api.md), and [D1 authority](d1-api.md).
The [vinext generator](vinext-generation.md) emits endpoint/client config files.
The [record API](records-api.md) defines the shared domain and query
contracts; the [architecture](architecture.md) explains the roles.

Service-worker execution, page fallback coordination and offline application
shell integration are implemented in 2.2 under
[ADR-0007](adr/0007-offline-first-pwa-and-worker-execution.md). See the
[PWA API](pwa-api.md) for that opt-in composition. The APIs below describe the
foreground client, also used inside the worker host.

Version 2.2 adds a typed collection facade. Supply `collections:
crudCollections(model)` when composing a schema-driven CRUD model:

```ts
const engine = await createSyncEngine({
  replica, transport, collections: crudCollections(model),
});
const page = await engine.from("notes")
  .select("id", "title")
  .where("folderId", "eq", "inbox")
  .limit(50)
  .execute();
await engine.from("notes").update(["note-1"], { title: "Updated" });
```

Import `crudCollections` from `/records`. The CRUD model derives row, key and
patch types; custom models may supply their own collection metadata and intent
builders. Without mutation builders, `from()` exposes reads. Supported methods
include `get`, `select`, `where`, `index`, `prefix`, `lower`, `upper`, `order`,
`limit`, `cursor` and `execute`. Field predicates support `eq`, `gt`, `gte`, `lt`
and `lte` on string/number values and must match one declared index interval.
Ranges on compound indexes require equality prefixes and a final ranged
component. Unsupported plans fail; no filtering scan is substituted. Selection
projects decoded rows and does not reduce storage-level column reads. Pages
retain `rows`, `nextCursor`, `revision` and replica `status`.

Collection writes enqueue through the public engine's `mutate()`, preserving
PWA lifecycle checks and worker scheduling. Receipts indicate durable local
work; inspect synchronization/resolution APIs for server decisions. The
[dedicated Vinext package](vinext-package.md) generates this typed composition.

## Compose a browser client

The application supplies its shared `model`, stable `clientId`, stream, and
transport. A transport implements `exchange(request, { signal })`; it returns a
typed protocol response. Use the built-in [HTTP transport](http-api.md) for a
network endpoint, or provide an in-process transport for local composition.

```ts
import { createSyncEngine } from "@mintcd/sync-engine/client";
import { openRecordReplica } from "@mintcd/sync-engine/records";
import { openIndexedDbRecordDatabase } from "@mintcd/sync-engine/adapters/indexeddb";

const database = await openIndexedDbRecordDatabase({
  name: "my-app-sync", streamId, schema: model.schema,
});
const replica = await openRecordReplica({ database, clientId, model });
const engine = await createSyncEngine({
  replica, transport, autoSync: true,
  subscribeChanges: listener => database.subscribe(listener),
});

const unsubscribe = engine.subscribe(snapshot => renderStatus(snapshot));
const receipt = await engine.mutate(intent); // local commit, before remote acceptance
const progress = await engine.sync({ maximumRounds: 8 });
const outcomes = await engine.readResolutions({ limit: 20 });
await engine.acknowledgeResolutions(outcomes.decisions.map(item => item.operationId));

unsubscribe();
await engine.close();
database.close();
```

`mutate(intent, { operationId? })` returns the persisted operation identity. The
default ID generator uses `crypto.randomUUID()`; supply `createOperationId` if
the application needs another generator. Client sequence allocation remains in
the durable transaction. A local storage failure sends nothing. A subsequent
network failure does not turn an already committed local mutation into a failed
save or discard its outbox entry.

`clientId` is explicit. Reopening the same stream with a different client ID
fails; multiple tabs sharing that stream use the same durable client identity.
Use another storage namespace when replacing a replica. The package does not
silently reset identity, cursor, or history.

`get`, `query`, `readResolutions`, and `acknowledgeResolutions` delegate to the
record replica and preserve its inferred collection, row, intent and index types.
Queries return rows and sync status from one storage transaction. Resolution
acknowledgement removes application notices while retaining retry protection.
The [memory record example](../examples/memory-records.mjs) runs the same client
coordinator against an in-process authority.

## Bounded runs, retries, and cancellation

`sync()` prepares a bounded snapshot from the durable outbox, exchanges it, and
reconciles the response atomically. It repeats while making progress, up to its
round/time budget. Overlapping calls share the first call's run settings. A
mutation committed during exchange is included in a subsequent request; an
automatic engine also schedules a later bounded run if that new work arrived
during the last permitted round.

| Setting | Default |
| --- | --- |
| `maximumRounds` | 16 |
| `maximumDurationMs` | 30,000 |
| `requestTimeoutMs` | 10,000 |
| `retry.maximumRetries` | 3 across the entire run |
| `retry.initialDelayMs` / `maximumDelayMs` | 100 / 2,000 |
| `retry.jitterRatio` | 0.2 |

Set defaults with `syncOptions` at construction and override them per call.
`maximumProposals` and `maximumEntries` control request sizes within the
replica's protocol limits; `maximumProposals: 0` requests pull-only work.

The result contains the last observed `status`, `rounds`, transport `attempts`,
`retries`, and a `reason`: `settled`, `round-budget`, `time-budget`, or
`no-progress`. Settled means this replica has no observed remaining work. It
does not promise that another writer cannot commit immediately afterward.
Budget exhaustion leaves all unfinished work durable. A time budget stops waiting
for storage already in progress; that transaction may finish afterward. The
result status is an observation, not a barrier against later commits. Storage
notifications or a later `status()` refresh reveal that progress.

Transports classify failures with `SyncTransportError`. `network`, `timeout`
and `rate-limit` can retry; `access`, `aborted` and `invalid-response` cannot.
Rate limiting may carry `retryAfterMs`. The engine also retries typed storage
`commit-conflict` errors. Unknown errors are reported without an automatic retry;
classification never parses message text. Permanent domain rejections are
successful exchanges with durable resolution notices.

`autoSync` defaults to false. When enabled, startup, a local mutation, or a
storage notification revealing unfinished new work schedules a bounded run.
It does not poll indefinitely or repeatedly restart a failed run on unchanged
notifications. A failed run stops automatic follow-ups, including work queued
during that failed exchange. The application can call `sync()` on a reconnect/user
retry, or a later new mutation can schedule a run. The application owns any
browser connectivity event listeners.

An `AbortSignal` cancels that caller's wait. Other callers may continue sharing
the run; when its last waiter leaves, the transport is aborted. Requests race
their timeout even if a transport ignores cancellation. Closing aborts requests,
stops scheduling, unsubscribes storage notifications and closes the supplied
replica handle. Close is idempotent. A native transaction already running may
finish; committed data remains available on reopen. The supplied database is
application-owned and must be closed separately when its other users finish.

Version 2.2 adds `database.closeAndDrain()`: close the connection to new
transactions and wait for its already-started native transactions to complete
or abort. It does not wait for arbitrary application callbacks or other
connections. PWA account cleanup additionally needs the cross-context registry
lease barrier described in the [PWA API](pwa-api.md).

For recovery, set `requireExisting: true` on both
`openIndexedDbRecordDatabase` and `openRecordReplica`. A missing database,
stream or replica metadata then fails with `corrupt-state` and an explicit
bootstrap-required message, instead of reseeding state or reusing sequence 1.
Initial bootstrap remains explicit and uses ordinary opens.

## Status and notifications

`status()` refreshes from storage. `getSnapshot()` returns a cached frozen object
with `{ replica, phase, lastError? }`; `subscribe(listener)` reports later changes.
Phases are `idle`, `syncing`, `retrying`, `error`, and `closed`. Subscriber errors
cannot undo a successful commit. Storage errors retain their cause; native
IndexedDB failures retain their `DOMException.name`, such as
`QuotaExceededError`.

`database.subscribe(listener)` emits a committed revision locally and uses
`BroadcastChannel` for other connections when available. Those messages are
invalidation hints, never trusted state. The coordinator rereads storage and
ignores older revisions. Without cross-context messaging, explicit `status()`
and `sync()` still work; there is no hidden polling fallback. Set
`broadcastChannel: false` to disable the channel, or inject a channel factory.
Listener and notification-channel failures cannot turn a committed write into a
failed local receipt.

## Native storage and upgrades

The adapter creates separate `row:confirmed:<collection>` and
`row:visible:<collection>` object stores. Each row uses the compound primary key
`[streamId, primaryKeyTuple]`. Declared secondary indexes use
`[streamId, indexKeyTuple, primaryKeyTuple]` for direct native range seeks and
deterministic ties. Both areas have the declared indexes so domain reads and
application queries use the same contract.

Separate `internal:<table>` stores hold canonical entries, identities, client
positions, decisions, accepted-sequence bindings, outbox, pending-request index,
resolution notices and replica metadata. `__sync_metadata` holds format/schema
binding and per-stream storage revisions. No object contains all tables or all
history. Ordinary queries visit their native index range; point edits flush only
changed records. Unchanged domain rows and absent deletes are skipped.

Transactions include all declared stores, currently serializing writes across
streams in the same physical database. Pure callback writes are staged per key,
then flushed with a single revision increment in the native transaction. The
promise resolves only on transaction completion. Request errors or callback
errors roll back rows, indexes, protocol data and revision together. Only storage
requests may be awaited inside a transaction callback. Unrelated asynchronous
work can let the browser end the transaction and causes the staged work to fail.

`initialRows` defines shared genesis at sequence zero and is installed once per
stream. Reopening never reapplies it. This is not snapshot import or legacy data
migration. Protocol v1 retains all canonical history and decision receipts.

The numeric IndexedDB `version` defaults to 1. Opening checks the adapter format
and declared schema identity. A higher numeric version is accepted only with the
same declared schema. Changed schema/version/collection/index bindings fail
without altering existing data. Automatic data/index migrations are deferred;
increasing the numeric version alone cannot migrate a changed domain schema.
Key/index/codec semantics require a schema version change even when their
function names stay the same.

Connections close on `versionchange` so they do not hold up upgrades. `onBlocked`
reports another connection holding an upgrade open. If that callback throws, the
open fails and a later upgrade is aborted. After closure, reopen a new database
and replica handle. `indexedDB` and `keyRange` can be injected outside browsers.

The optional `durability` setting passes the browser's `default`, `strict`, or
`relaxed` hint through. Transaction completion is the engine's local commit
boundary; persistence remains subject to browser storage/eviction behavior. See
the [IndexedDB transaction specification](https://w3c.github.io/IndexedDB/#transaction-concept).

## Verification

`npm run check` runs consumer type checks, coordinator failure/scheduling tests,
and fake IndexedDB contract, recovery, concurrency and memory-parity tests.
`npm run test:browser` separately runs native IndexedDB checks in headless
Chromium. Install a Playwright Chromium build with
`npx playwright install chromium`, or set `SYNC_ENGINE_BROWSER_PATH` to an installed compatible browser.
The runner also detects an installed Chrome on Windows.

Native checks cover reopen before send, lost authority response, durable notices,
two-connection allocator/reconcile races, abort rollback, compound-index pages,
cross-connection and separate-tab invalidation, and expiration after an unsupported async wait.
This establishes Chromium behavior; other browser engines remain unverified.
