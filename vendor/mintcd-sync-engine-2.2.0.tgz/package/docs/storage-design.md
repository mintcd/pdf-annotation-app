# Storage for queries, edits, and synchronization

Status: Accepted. Date: 2026-10-16.

This defines the physical storage and performance design. Record contracts, an
indexed memory reference and native IndexedDB storage are implemented; see the
[record API](records-api.md) and [client API](client-api.md). The original aggregate
reference remains unchanged. D1 authority storage is also implemented; GitHub
remains planned. See
[ADR-0004](adr/0004-materialized-records-and-sync-history.md) and the
[storage requirements](requirements/storage.md).

## Store current records and changes for different purposes

Yes: keep **materialized current data plus an ordered change log** for the chosen
operation-log protocol. Query current data directly. Append accepted canonical
operations to the log for synchronization/recovery, and incrementally update the
affected materialized records in the same commit. Do not serialize every table
into one replica record or store a full database snapshot after every operation.

| Data | Purpose | Typical access |
| --- | --- | --- |
| Current domain records | Lookup, filtering, sorting, edits, current merge-policy state | Primary key and declared secondary indexes |
| Canonical operations | Ordered sync pages, replay, delivery to projections | `(streamId, sequence)` range |
| Decisions/identity bindings | Return the original accept/reject decision on retry and detect identity reuse | Operation ID and client-position lookups |
| Pending outbox | Survive interruption and retry unresolved local intent | Ordered client-sequence range |
| Resolution notices | Let the application acknowledge accepted/rejected outcomes | Per-stream notice page |
| Stream metadata | Identity allocator, revisions, cursors, model/schema versions | Small keyed record |
| Checkpoints, later | Restore a consistent materialization at a known sequence | Checkpoint manifest plus state chunks |

These are logical responsibilities, not a requirement to duplicate every payload.
For example, an accepted decision can reference the corresponding retained log
payload internally. The store must still reconstruct the complete protocol
decision when responding to a retry. A rejection needs its original reason.

If history has one million operations but only ten thousand current notes,
ordinary note queries should visit the relevant current records/index range.
They should not read a million entries or replay that history. A local edit writes
its outbox/protocol records and affected view records; it does not rewrite all
ten thousand notes. Rebase work can still depend on unresolved pending work.

```mermaid
flowchart LR
    A[Local intent] --> T[Atomic local commit]
    T --> O[Ordered outbox]
    T --> V[Indexed visible records]
    Q[Application queries] --> V
    C[Canonical page and decisions] --> R[Stage canonical changes and replay pending previews]
    O --> R
    R --> W[One atomic response commit]
    W --> L[Log, decisions, outbox, notices and cursors]
    W --> B[Confirmed records]
    W --> V
```

Canonical changes, preview replay, and visible index updates belong to the same
response transaction; cursor advancement cannot commit ahead of the view.

## IndexedDB layout

Use one IndexedDB database per application/storage namespace with multiple object
stores. Each domain row/document is its own record. Select synchronized collections
explicitly in the shared stream/domain contract. Participants in that stream use
the same contract and receive its complete canonical sequence. This avoids
automatically syncing unrelated D1 tables; it does not introduce per-client table
filtering or selective replication into protocol v1.

The table below describes logical protocol stores. The implemented adapter
uses separate keyed `internal:<table>` stores and explicit identity, position,
accepted-sequence and pending-request indexes; see the
[native layout](client-api.md#native-storage-and-upgrades).

| Store | Primary key | Additional lookup |
| --- | --- | --- |
| `syncMeta` | `streamId` | None initially |
| `canonical` | `[streamId, sequence]` | Unique `[streamId, operationId]` |
| `decisions` | `[streamId, operationId]` | Unique `[streamId, clientId, clientSequence]` |
| `outbox` | `[streamId, clientSequence]` | Unique `[streamId, operationId]`; `[streamId, status, clientSequence]` for pending work |
| `resolutions` | `[streamId, operationId]` | Stream range for unacknowledged notices |

`syncMeta` contains storage/model/projection versions, local revision, client ID,
next client sequence, confirmed sequence, and observed authority head. It contains
no table contents or ever-growing operation arrays. Acknowledging a notice deletes
the notice, leaving its decision/identity binding intact.

For a declared `notes` collection, use:

```text
confirmed:notes   key [streamId, id]    canonical row plus last canonical sequence
visible:notes     key [streamId, id]    current row including optimistic previews
```

Add equivalent stores for each declared collection, such as `tasks`. The confirmed
stores need only primary-key indexes initially; declare additional policy/rebase
lookups when needed. The visible stores get the indexes used by the application.
This baseline stores two current row representations locally, plus history and
pending work. It spends space to make both rollback/rebase and indexed UI queries
straightforward; it does not save two entire databases for every operation.

An overlay containing only changed rows can save space later. It also requires
merging base and overlay query results correctly when pending changes alter filter
membership, ordering, pagination, or deletion. Simply reading a base index then
patching its returned rows can omit newly matching rows and retain deleted rows.
Start with a fully materialized visible view and verify it against the reference.

A generic `records[streamId, collection, encodedKey]` store is a fallback for
dynamic document collections or confirmed records. A JSON payload in that store
does not by itself offer indexed queries over arbitrary fields. Per-collection
stores with declared native indexes are the first query-optimized design.

IndexedDB supports transactions scoped to several object stores, so consistency
does not require a single giant value. Store/index creation is performed during
a database version upgrade. The adapter must handle blocked upgrades and close
older connections on `versionchange`. See the
[IndexedDB specification](https://w3c.github.io/IndexedDB/#transaction-concept).

### Query contract and indexes

First support point lookup and declared-index equality/range scans, stable sort,
and bounded keyset pagination. A notes screen filtering by project and status,
then sorting by update time, can declare:

```text
visible:notes.byProjectStatusUpdated
  [streamId, projectId, status, updatedAt, id]
```

The query fixes the stream/project/status prefix and scans the remaining ordered
range. The cursor includes the full ordering key and ID tie-breaker, plus the
query/schema identity. Each page has a consistent local revision. Later mutations
can change subsequent pages; callers either accept live pagination or restart on
revision change. Do not promise a frozen multi-request snapshot by default.

The collection contract declares keys, payload codecs, indexed fields, and index
normalization. Preserve type distinctions in composite primary keys; do not join
components with an ambiguous delimiter. Sort timestamps/numbers as normalized
numeric keys rather than lexically sorting JSON-encoded numbers. Specify handling
for booleans, missing/null values, case normalization, and collation instead of
assuming SQL and IndexedDB compare every value identically. IndexedDB's allowed
key types are defined in its [key specification](https://w3c.github.io/IndexedDB/#key-construct).

Add indexes for actual query shapes. Each extra index adds maintenance and storage.
Search by word/body content is a separate capability: IndexedDB would need an
explicit token/postings projection or an optional local search implementation.
The first API does not translate arbitrary SQL predicates or promise identical
full-text ranking across adapters. A scan fallback must be explicit and bounded.

### Local edit and reconciliation boundaries

A local edit transaction reads current metadata/required records, allocates client
order, inserts the outbox proposal, stages its preview changes, updates affected
visible records, and commits them together. Native indexes follow those record
writes. Hashing and protocol payload validation occur before the transaction;
there are no network calls or unrelated asynchronous waits inside it.

A response transaction validates retained identities/overlapping entries through
keyed lookups, appends new canonical entries, records decisions, applies canonical
changes to confirmed rows, and advances the confirmed cursor. It then reconciles
outbox/notice records and rebuilds the affected visible view from confirmed data
plus remaining previews in client order, before the same commit completes.

Before replay, reset the union of newly changed canonical keys and **all previously
optimistic touched keys** to the confirmed base. This includes rows touched only
by a preview being rejected or removed: delete a former optimistic insert when
the base is absent, and restore a former optimistic deletion when the base exists.
Record each preview's touched keys with its outbox metadata and capture them
before removing resolved work. Replaying only remaining previews without clearing
the old effects would leave ghost rows or stale index entries. If reliable touched
keys are unavailable, explicitly rebuild the complete visible view conservatively.

An accepted decision beyond the downloaded prefix remains a canonical preview.
A rejected or transformed operation can invalidate other pending work, including
work on another collection. Initially replay **all remaining pending previews**
conservatively, retaining unavailable outcomes. A preview that fails after staging
several row changes must discard its complete staged change set. It must not leave
half an optimistic multi-row operation applied or block canonical progress.

Optimizing rebase to only some pending entries requires trustworthy read/write
dependencies, including predicate/range reads. Declaring only an operation's
target row is insufficient. Until those dependencies are implemented, do not
claim that every edit touches only one row regardless of the pending overlay.

All touched stores are in the same transaction scope. A multi-collection intent
remains one atomic domain action. Read a query result and its cursor/revision/status
in one read transaction. Notifications are sent only after commit; another tab
must reload data for the committed revision rather than treating a notification
as the data itself.

## D1 layout

The following logical design is implemented by the
[D1 adapter](d1-api.md), with explicit per-collection SQL mappings and separately
keyed internal tables. See [ADR-0005](adr/0005-d1-guarded-record-plans.md) for its
primary read-plan, revision assertion and migration decisions.

Use ordinary domain tables with typed columns and application-selected indexes.
For the same notes screen, the domain table can have primary key
`(stream_id, id)` and an index on
`(stream_id, project_id, status, updated_at, id)`. Keep flexible fields as JSON
where appropriate, but do not bury every searchable field in one stream JSON
value. Reads of synchronized data always use the resolved internal stream scope.

Keep protocol state separately:

| Table | Required keys/content |
| --- | --- |
| `sync_streams` | Primary key `stream_id`; revision, head sequence, contract/storage/projection versions |
| `sync_entries` | Primary key `(stream_id, sequence)`; unique `(stream_id, operation_id)`; canonical identity and payload |
| `sync_decisions` | Primary key `(stream_id, operation_id)`; unique `(stream_id, client_id, client_sequence)`; fingerprint and original decision |
| `sync_delivery` (later, optional) | Delivery obligations or a per-target canonical cursor and retry/version metadata |

Domain rows are the authority's current materialization. Stream head and domain
rows represent the same committed history. Domain writes enter through authority
decisions so direct SQL edits cannot silently diverge from the sync log.

Read relevant rows/decisions at a consistent revision, calculate the operation
and row change set, then commit rows, canonical log, decisions, and revision/head
atomically with a revision guard. Rejected-only plans still bind decisions and
advance revision. Every statement must be protected: a conditional update that
matches zero rows must not allow subsequent writes to succeed. D1 documents
transactional `batch()` rollback on statement failure; zero matched rows is not
such a failure. See [D1 batch semantics](https://developers.cloudflare.com/d1/worker-api/d1-database/#batch).

Use `EXPLAIN QUERY PLAN` to verify declared query paths, and create schema/indexes
through explicit migrations. D1 documents compound-index use and the tradeoff
between query improvements and index maintenance in its
[index guide](https://developers.cloudflare.com/d1/best-practices/use-indexes/).
Optional full-text search can use its supported
[FTS5 extension](https://developers.cloudflare.com/d1/sql-api/sql-statements/#supported-sqlite-extensions).
Search projections need a defined update transaction/version before being exposed
as current results; FTS capability does not imply a portable cross-backend query.

## GitHub layout

For the initial D1-authoritative topology, project current domain data into useful
files: for example, one Markdown note with metadata or one JSON document per
entity, grouped under an application-selected directory. Use bounded chunks only
when many small files would be unsuitable. Store enough manifest/version metadata
to identify the source stream and delivered canonical position/range.

The projection worker keeps durable progress on the authority side. It writes a
complete intended file/tree change, verifies the target commit, then advances
delivery progress. Git's blob/tree/commit APIs provide the building blocks for
file changes followed by a branch-reference update; see the
[GitHub Git database guide](https://docs.github.com/en/rest/guides/using-the-rest-api-to-interact-with-your-git-database).
Use non-forced updates and explicit source/target identities to detect concurrent
changes and lost-response retries. A fast-forward check alone is not an arbitrary
compare-and-swap guarantee; reconciliation of the target commit is still required.

GitHub files/Git history do not substitute for the engine's indexed local rows,
ordered canonical sequence, and rejection/idempotency ledger. Search locally or
in D1 for the application's database query API. Independent GitHub edits need an
import adapter producing proposals with loop prevention. GitHub as the deciding
authority remains a separate capability design.

## Live materialization, checkpoints, and retention

The live materialization already records the result of applying canonical history
through a known sequence. Persist it incrementally so ordinary startup can open
current records and pending work. Index rebuilding or integrity repair can replay
history when explicitly needed; normal reads/startup do not need full replay.

A separate checkpoint is an immutable recovery/export snapshot at sequence `K`:

```text
stream identity + contract/storage/projection versions + canonical sequence K
consistent confirmed domain records at K + manifest/integrity metadata
```

Create it periodically or for bootstrap/backup, not after every operation. Capture
a consistent revision; chunked export must not mix records from different heads.
Publish a completed manifest atomically before treating its chunks as a usable
checkpoint. Local pending work is separate and must not disappear when restoring
confirmed state.

**No history deletion is enabled by this storage proposal.** Current protocol v1
has no checkpoint/reset exchange or state codec; current replica transitions
require the full retained prefix. Normalization changes placement/access cost,
not those guarantees. Local checkpoint mechanics and wire bootstrap are different
features and both need explicit contracts before pruning.

Future compaction must settle all of the following:

- A retention floor and consistent snapshot bootstrap for clients older than it,
  including what happens to their pending intents.
- Contract/state codecs, schema/projection versions, checkpoint integrity, and
  atomic installation/activation of a snapshot plus its cursor.
- Downstream projection delivery progress, offline/retry lifetime, and any epoch
  fencing before old client identities or history are retired.
- Separate receipt retention. Accepted retries currently return the original
  canonical operation, rejected retries the original reason. A hash alone cannot
  reconstruct either; deleting canonical payloads may require retaining them in
  receipts or changing the protocol. Rejections have no canonical sequence, so
  a client's confirmed cursor cannot justify expiring them.
- Deletion/tombstone semantics that prevent stale clients/importers resurrecting
  removed records. UI acknowledgement is never a receipt-GC signal.

Log, receipts, current records, pending work, and checkpoints have different
lifetimes. Do not apply one TTL to all of them.

## Required evolution of the current contracts

The original aggregate core is a correctness reference with an arbitrary `State`. Its
canonical reducer already applies newly received operations incrementally.
However, `ReplicaState` embeds complete confirmed/visible state, history,
decisions, and outbox; the current transitions scan and clone those structures.
Authority planning similarly receives and replaces complete `State`.
Changing the physical object stores alone cannot remove that work.

Keep that aggregate path for small custom domains such as the counter example.
The implemented record-oriented capability now provides the following contracts
and memory references ahead of native adapters:

1. **Collection contract:** logical collections, stable primary keys, payload
   codecs, declared indexes and query semantics, schema/projection versions.
2. **Transactional domain view:** start with typed key-directed row operations,
   including multi-row proposals, and declared read requirements derived from
   intent. The adapter/planner loads those records/declared query results at a
   consistent revision, then pure policy/interpretation works on a detached view
   and stages writes/deletes. Undeclared reads fail explicitly. Supporting dynamic
   read discovery requires a separate bounded planning protocol, not hidden I/O
   inside a pure policy. Read sets include predicates/ranges and their invalidation
   rules for any future selective replay; current replay conservatively visits all
   pending work. A transaction/revision guard protects the complete plan. No automatic translation
   of arbitrary whole-object reducers into native database operations is implied.
3. **Incremental protocol transitions:** operate on metadata, exact identity/entry
   lookups, bounded incoming pages and the current pending set; commit a validated write set.
   No normal mutation/query hydrates the complete log or decision ledger.
4. **Narrow APIs:** status/metadata, bounded request preparation, paged domain
   queries, paged resolutions, and commit summaries. A complete `ReplicaState`
   dump is an explicit diagnostic/reference operation, not the UI read path.

The memory reference and paired equivalence tests against the aggregate path are
implemented. Generic opaque reducers remain supported without promising record-level
performance. See [Record API](records-api.md) for current exports and limits;
IndexedDB and D1 persistence are implemented.

## Delivery and verification

Implement collection/key/index contracts and the memory record reference first,
then the normalized IndexedDB adapter and client query facade. Adapt D1 planning
to the same record semantics before its native commit implementation. Keep GitHub
projection, full-text modules, and compaction separate later work.

Verify point/index queries and cursor semantics, row-level write counts, preserved
untouched records, consistency of confirmed/visible views after rejection and
transformation, failed multi-row previews, transaction abort/reopen, two-tab races,
and equivalence under the existing loss/duplicate/delay scenarios. Seed many
historical entries while measuring normal edit/query work to prove that protocol
lookups do not scan history. Track pending-overlay work separately rather than
claiming constant work regardless of domain dependencies.
