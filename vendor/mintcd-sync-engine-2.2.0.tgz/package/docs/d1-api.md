# D1 authority storage

Implemented: explicit initial migration generation and a record database for
`createRecordSyncAuthority`. D1 owns durable storage; the application policy owns
acceptance and merging. The [HTTP API](http-api.md) connects that authority to
the [client coordinator](client-api.md). The [vinext generator](vinext-generation.md)
adds route files without importing database bindings into browser output.

## Declare tables and searchable columns

Every declared collection maps to its own SQL table. The shared record schema
still defines codecs, primary keys and portable query indexes. Add typed SQL
columns for application searches and reporting:

```ts
import {
  createD1RecordMigration, openD1RecordDatabase,
} from "@mintcd/sync-engine/adapters/d1";
import type { D1CollectionMappings } from "@mintcd/sync-engine/adapters/d1";
import { createRecordSyncAuthority } from "@mintcd/sync-engine/server";

const collections = {
  notes: {
    table: "notes",
    columns: {
      title: { type: "TEXT", value: note => note.title, indexed: true },
      updatedAt: { type: "REAL", value: note => note.updatedAt },
    },
  },
} satisfies D1CollectionMappings<typeof notesModel.schema>;

// Development/deployment step: review and apply this SQL before runtime use.
const initialMigration = createD1RecordMigration({
  schema: notesModel.schema, collections,
});

// Request-scoped server composition, after authorization has resolved streamId.
const database = await openD1RecordDatabase({
  database: env.DB, streamId, model: notesModel, collections,
});
const authority = createRecordSyncAuthority({
  database, model: notesModel, policy: notesPolicy,
});
```

Use the same mapping configuration in migration generation and runtime opening.
`TEXT`, `REAL`, `INTEGER` and `BLOB` columns accept their matching value type or
`null`; integer values must be safe integers and numbers must be finite. Binary
values use `ArrayBuffer`. `indexed: true` creates an index on stream plus that
column. Column extractors are deterministic, synchronous and clone-safe, like
the shared collection extractors.

The table contains `__sync_stream`, `__sync_key`, `__sync_data`, declared portable
index columns, and the application columns above. Each domain row is independent.
`__sync_data` is the row's codec-encoded JSON, not all tables or history. Typed
columns and native indexes support SQL searches without unpacking every row.
Names must be safe SQL identifiers; `__sync_` columns and internal table names
are reserved. All mapped collections must be present exactly once.

Raw SQL reads must constrain `__sync_stream` to an authorized internal stream.
Writes to synchronized rows enter through the authority. Raw writes bypassing
its revision/log discipline invalidate the synchronization contract. Application
columns do not create an alternative write path.

## Explicit migration boundary

`createD1RecordMigration` generates an initial schema as a SQL string. It does
not execute it. Review and apply it using the application's deployment/migration
tooling before accepting requests; Cloudflare describes that workflow in its
[D1 migration documentation](https://developers.cloudflare.com/d1/reference/migrations/).

The default internal table prefix is `sync_`; `tablePrefix` changes it. Collection
table names are used exactly as configured. Storage records its format, schema
identity, declared collections/indexes, and mapped column types/index options.
The same initial migration is idempotent. A different layout fails its binding
check before later schema statements, and runtime opening rejects it. Runtime
opening issues no DDL and never silently repairs or recreates tables.

The generator does not plan schema/data upgrades or import legacy data. A future
upgrade must preserve history, receipts, row projections and version binding
consistently. Bump schema versions when codec/key/index/column extraction
semantics change; the package cannot detect a changed callback implementation
from its name. Neither increasing a version string nor rerunning the initial
migration is a data migration.

Optional `initialRows` installs shared genesis at canonical sequence zero, once
per stream. Racing first openers cannot overwrite each other's committed rows.
Reopening never reapplies genesis. This is not checkpoint bootstrap.

## Record and history layout

| Storage | Purpose |
| --- | --- |
| One configured SQL table per collection | Current confirmed rows, typed search columns and native query indexes |
| `sync_streams` | Per-stream storage revision, model contract and layout binding |
| `sync_meta` | Authority head and protocol metadata |
| `sync_canonical` | Canonical entries ordered by sequence |
| `sync_identities`, `sync_positions` | Operation-ID and client-position identity bindings |
| `sync_decisions`, `sync_accepted` | Original accepted/rejected outcomes and accepted-sequence bindings |
| `sync_layout`, `sync_guards` | Database layout binding and atomic commit assertion |

All history and receipts remain retained in protocol v1. Acknowledging a local
notice does not delete a server receipt. Payloads use the model's operation and
rejection codecs, preserving supported domain representations such as dates.

Portable record queries use ordered internal keys with SQL `BINARY` collation.
Numeric keys preserve numerical order; strings preserve UTF-16 order, including
tuple prefixes and primary-key tie breaks. Each declared secondary index has a
native `(stream, indexKey, primaryKey)` index. The adapter seeks that range and
fetches a bounded page, merging staged writes before returning it. These keys
are separate from application SQL column indexes, whose SQL semantics remain
explicit. Ordinary edits never hydrate canonical history.

This adapter implements the authority role: confirmed records and authority
protocol tables. It rejects optimistic visible rows and local replica queues;
use IndexedDB or the memory replica for that role. A failed attempt to open it
as a replica leaves no replica binding behind.

## Primary reads and guarded atomic commits

Pass the primary `D1Database` binding, not a `D1DatabaseSession`. Session objects
are excluded by the public type and rejected at runtime. Cloudflare documents
that queries made without the Sessions API use the primary; sessions can route
later reads to replicas. See the
[D1 binding documentation](https://developers.cloudflare.com/d1/worker-api/d1-database/).

D1 does not expose the package's interactive transaction callback. The adapter
reads a revision, performs keyed/range reads and stages changes, then checks that
revision again. If another authority changed it, the callback result is discarded
with `commit-conflict`. Successful read-only calls return a consistent revision;
callers of this low-level API must handle conflicts. `createRecordSyncAuthority`
retries the complete pure plan within its configured attempt budget.

A write batch begins with a revision assertion protected by a SQL `CHECK`
constraint. A stale revision makes that statement fail. Row changes, protocol
bindings, decisions, canonical entries and the revision increment follow in the
same batch. Rejection-only commits also advance revision. A failed statement
rolls back the entire sequence under
[D1's batch contract](https://developers.cloudflare.com/d1/worker-api/d1-database/#batch).
There is no sequential-write fallback. Error classification checks the primary
revision after failure rather than parsing database error prose.

The transaction callback can execute again after a conflict, so domain policy
and extractors must be pure. Keep hashing, external I/O and side effects outside
it. Unchanged row payloads and absent deletes produce no row write. Independent
streams share a database but keep separate revisions and protocol keys.

## Work budgets and operational scope

`limits` on the D1 factory defaults to:

| Setting | Default |
| --- | --- |
| `maximumStatements` | 1,000 per atomic batch |
| `maximumBytes` | 1 MiB of SQL plus bound data per batch |
| `maximumReadRows` | 4,096 per individual read |

The adapter also checks per-statement parameter/SQL-size and table-column bounds.
Oversized work fails before issuing a mutation batch. Reads plus staged overlays
remain bounded; batching a large number of domain changes is not guaranteed to
fit just because the wire envelope fits.

Set client, HTTP and authority proposal/page limits for the workload and Workers
plan. Database operations per proposal and conflict retries also consume the
platform's per-invocation query budget. Adapter limits are local safeguards, not
a replacement for the current [D1 platform limits](https://developers.cloudflare.com/d1/platform/limits/).
External delivery, schema upgrades, compaction and legacy migration remain
separate work. The adapter owns no connection lifecycle beyond the supplied
platform binding.

## Verification

`npm run check` runs the SQL storage and authority tests on Cloudflare's local
workerd D1 implementation through Miniflare. Tests cover indexed plans, portable
query parity, unchanged writes, mixed-read conflicts, simultaneous genesis,
stale guarded batches, rejection-only races, permanent receipts, and rollback
after an actual failing SQL statement partway through a batch. A local Worker
fixture also exercises IndexedDB → HTTP → D1 transformation, rejection, lost
responses, authorization isolation and precommit response byte limits.

The fixture pins a compatibility date supported by its installed local runtime.
No remote Cloudflare database is created or modified. This verifies local API
behavior; production quotas and geographic latency require separate measurement.
