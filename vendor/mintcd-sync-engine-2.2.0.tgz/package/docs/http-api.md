# HTTP transport and Fetch endpoint

Implemented: a browser-compatible Fetch transport and a framework-neutral Fetch
handler over protocol v1. They carry the same requests, canonical pages, and
decisions used by the [core](core-api.md) and [record API](records-api.md).
Legacy endpoint payloads are not accepted by this boundary.

The [client coordinator](client-api.md) owns scheduling and retries. The
[D1 adapter](d1-api.md) owns durable server records; the authority owns policy,
canonical decisions, and atomic commits. HTTP authenticates and transports each
exchange without allocating a second operation identity or maintaining an outbox.

## Compose a browser client

```ts
import { createSyncEngine } from "@mintcd/sync-engine/client";
import { openRecordReplica } from "@mintcd/sync-engine/records";
import { openIndexedDbRecordDatabase } from "@mintcd/sync-engine/adapters/indexeddb";
import { createHttpSyncTransport } from "@mintcd/sync-engine/transport/http-client";
import { model } from "./sync-model";

const database = await openIndexedDbRecordDatabase({
  name: "my-app-sync", streamId, schema: model.schema,
});
const replica = await openRecordReplica({ database, clientId, model });
const transport = createHttpSyncTransport({
  url: "/api/sync", streamId, model,
  credentials: "same-origin",
  headers: async () => ({
    authorization: `Bearer ${await getAccessToken()}`,
    "x-csrf-token": await getCsrfToken(),
  }),
});
const engine = await createSyncEngine({
  replica, transport, autoSync: true,
  subscribeChanges: listener => database.subscribe(listener),
});

const receipt = await engine.mutate(intent);
const progress = await engine.sync();
```

The application supplies the shared model, stream/client identities, and token
helpers. Configure the headers required by its authentication scheme. A header
supplier runs for every exchange, including retries, so refreshed tokens do not
require a new engine. A static `HeadersInit` is also accepted. The transport sets
the JSON content type, JSON accept header, and `cache-control: no-store` itself.

`credentials` defaults to `same-origin`; opt into `include` only when the
application needs cross-origin cookies and has configured its server policy.
Relative HTTP(S) URLs are accepted. URL credentials and fragments are rejected.
Fetch uses `redirect: "error"` so credentials are not forwarded through endpoint
redirects. A supplied `fetch` implementation must honor those Fetch options.

`receipt` confirms the local storage commit. The remote exchange can later accept,
transform, or reject that operation. A network failure leaves the durable outbox
available for retry. Read and acknowledge domain outcomes through the engine's
resolution methods.

## Bind a server route

`createSyncHandler` requires both `resolveContext` and `getAuthority`. The first
authenticates the caller, authorizes the requested stream, and enforces the
application's origin/CSRF policy. Only a successful resolution can reach
`getAuthority`. Its returned `streamId` must exactly match the protocol request;
a mismatch returns 403 without opening an authority.

```ts
import { createSyncHandler, SyncHttpError } from "@mintcd/sync-engine/transport/http-server";
import type { SyncHandlerOptions } from "@mintcd/sync-engine/transport/http-server";
import { model } from "./sync-model";
import type { Intent, Operation, Rejection } from "./sync-model";
import { authenticate, canAccessStream, verifyCsrfToken } from "./auth";
import { applicationOrigin, getNotesAuthority } from "./sync-server";

interface RequestContext {
  readonly userId: string;
}

const options: SyncHandlerOptions<Intent, Operation, Rejection, RequestContext> = {
  model,
  async resolveContext(request, scope) {
    // This example expects same-origin browser requests and the app's CSRF token.
    if (request.headers.get("origin") !== applicationOrigin) {
      throw new SyncHttpError(403, "origin-denied", "Origin is not allowed.");
    }
    const user = await authenticate(request);
    if (!user) throw new SyncHttpError(401, "authentication-required", "Sign in to synchronize.");
    if (!await verifyCsrfToken(request, user)
      || !await canAccessStream(user.id, scope.streamId)) {
      throw new SyncHttpError(403, "access-denied", "Stream access is not allowed.");
    }
    return { streamId: scope.streamId, context: { userId: user.id } };
  },
  getAuthority(context, streamId) {
    // Returns SyncAuthority<Intent, Operation, Rejection, RequestContext>.
    return getNotesAuthority(streamId, context);
  },
};

export const POST = createSyncHandler(options);
```

The application helpers are deliberately explicit: binding a stream requires an
access decision, and trusted policy context comes from authentication rather
than proposal fields. The scope contains only `protocolVersion`, `contractVersion`,
and `streamId`; it is frozen. `getAuthority` can return its authority synchronously
or asynchronously. The same resolved context is passed to `synchronize`.

A handwritten vinext `route.ts` can export `POST` as above. The
[vinext generator](vinext-generation.md) creates a thin route delegating to this
application-owned composition. Other frameworks can pass their
standard `Request` to the returned function and return its `Response`.

The handler accepts only POST with uncompressed `application/json`, optionally
declaring UTF-8 charset. Method/media checks, bounded body reading, and protocol
validation happen before context resolution. There is no default CORS response
or preflight handler; OPTIONS receives 405. Cross-origin applications must add
their own deliberate CORS handling and authorization policy.

## Limits and the commit boundary

Both factories accept these options:

| Option | Default | Meaning |
| --- | --- | --- |
| `maximumRequestBytes` | 1 MiB | Encoded UTF-8 request body cap |
| `maximumResponseBytes` | 4 MiB | Encoded UTF-8 response body cap |
| `limits.maximumProposals` | 64 | Maximum proposals or returned decisions |
| `limits.maximumEntries` | 256 | Maximum canonical page entries |

Configure compatible count limits on replicas, transports, handlers, and
authorities. A request also carries its chosen `maximumEntries`; responses must
respect that smaller page size. Use smaller proposal/page batches when needed
to keep D1 work within the adapter's configured transaction budget. Count limits
alone do not bound the size of individual domain payloads.

Outgoing bodies are measured after codec encoding. Incoming bodies are read
incrementally with actual byte counts, including multibyte UTF-8. Content-Length
is checked before reading when present; a missing or dishonest small value cannot
bypass the streaming cap. The bounded body is then decoded as UTF-8 JSON.
Oversized or invalid streams are canceled. Client response limits also apply to
error bodies. Server errors obey the response cap; an unusually tiny cap can
produce an empty error body, with its status still available to the client.

Before committing, the handler supplies the authority's optional third argument:

```ts
await authority.synchronize(request, context, {
  validateResponse(response) {
    // Synchronous encoding, identity/page checks, and response-byte validation.
  },
});
```

The built-in authorities invoke this hook with an isolated validated response
before any durable commit. An exception aborts the proposed transaction or CAS.
The hook must be synchronous and can run again after a commit conflict. The HTTP
handler uses it to reject an oversized or mismatched response before committing
the submitted decisions. Response decisions must match the submitted identity
set; their order may differ.

Custom authorities must honor this hook to provide the same precommit guarantee.
The handler also validates the returned response, but that later check cannot
undo a custom authority's earlier commit. A connection can still fail after a
successful commit; retrying the unchanged durable proposals returns the retained
decisions rather than applying them twice.

## Errors and cancellation

Every handler response sets `cache-control: no-store` and
`x-content-type-options: nosniff`. Errors normally use this envelope:

```json
{"protocolVersion":1,"error":{"code":"access-denied","message":"Stream access is not allowed.","retryable":false}}
```

Throw `SyncHttpError(status, code, publicMessage, { retryAfterMs? })` from trusted
application hooks for a deliberate public response. Its message is sent to the
caller. Unknown exceptions become a generic 500; core errors use fixed public
messages, and causes/storage details are not serialized. `retryAfterMs` also sets
the HTTP Retry-After header, rounded up to whole seconds.

| Status | Typical handler meaning | Client classification |
| --- | --- | --- |
| 400 | Invalid JSON/protocol or unsupported protocol version | Protocol error when recognized; otherwise `invalid-response` |
| 401 / 403 | Authentication, authorization, or origin/CSRF failure | `access`, no automatic retry |
| 405 / 415 | Wrong method or media type/encoding | `invalid-response`, no automatic retry |
| 409 | Contract/stream/cursor mismatch, identity conflict, or divergence | Corresponding core protocol error |
| 413 | Request count/bytes or response byte limit | `limit-exceeded` protocol error when recognized; otherwise `invalid-response` |
| 429 | Application rate limit | `rate-limit`, retryable |
| 503 | Commit contention or unavailable authority | `commit-conflict`/`closed` when recognized; otherwise retryable `network` |
| 500 | Unexpected server failure or corrupt retained state | `corrupt-state` when recognized; otherwise `invalid-response` |

`HttpSyncProtocolError` extends `SyncError`, adds `httpStatus`, and preserves the
recognized core code. Only core `commit-conflict` is retryable. Recognition uses
a fixed code/status mapping, so a mismatched status does not acquire a code's
retry behavior. Other failures use `HttpSyncTransportError`, extending
`SyncTransportError` with optional `httpStatus` and `serverCode`. Network failures,
408/504 timeouts, 429, and 502/503 infrastructure errors can retry. Classification
does not trust the wire `retryable` flag or parse message text. For transport
errors, Retry-After or an envelope delay can guide the coordinator's bounded
retry wait.

`exchange(request, { signal })` cancels Fetch, response reading, and waits for an
asynchronous header supplier. An ordinary abort is nonretryable `aborted`;
timeout signals produce retryable `timeout`. The coordinator provides request
timeouts, a total run budget, and cancellation for shared runs. The transport
performs one exchange per call and has no retry timer of its own.

The server stops waiting for canceled body/context work and checks cancellation
before authority access and in its precommit hook. An already running lookup or
transaction may finish after disconnection; durable identities make its later
retry safe. Local receipts, canonical sequence, engine rounds, transport attempts,
and retry counts remain separate observations.

## Verification

`npm run check` covers handler authorization isolation, byte limits with chunked
and multibyte bodies, cancellation, error redaction/classification, precommit
response rollback, refreshed headers, and a lost committed HTTP response retried
through `createSyncEngine`. The D1 API documents the native database checks and
the complete IndexedDB-to-HTTP-to-D1 path.
