# Vinext package setup and API

`@mintcd/sync-engine-vinext` composes the portable engine for a Vinext application
using IndexedDB locally and a D1-backed authority on the server. A logical schema
and Wrangler configuration generate the sync route and one typed hook module.
Package helpers compose the model, D1 authority and optional PWA wiring.

API versions: core 2.2.0 and Vinext package 1.0.0. See
[requirements](requirements/vinext-package.md)
and [ADR-0008](adr/0008-vinext-package-and-schema-driven-client.md).
Deployment-triggered rebuilds are defined by [V13-V18](requirements/vinext-package.md)
and [ADR-0010](adr/0010-deployment-replica-rebootstrap.md).

## Install and platform setup

Install the dedicated integration; its dependency includes the core engine:

```sh
npm install @mintcd/sync-engine-vinext
npm install --save-dev wrangler
```

The application needs its normal working Vinext/Cloudflare Vite setup. This
package reads `wrangler.jsonc`; it does not initialize or replace that platform
setup. Current Vinext also offers `cloudflare.config.ts`; this package's binding
validation targets Wrangler JSON/JSONC explicitly. Generated server modules use
`env` from `cloudflare:workers`, so run the server environment in workerd through
the application's Cloudflare integration. The tested PWA build range is Vite
`>=8.3.4 <9` with Vinext 1.2.1. Vinext tooling requires Node
`^20.19.0 || >=22.12.0`; the portable core keeps its Node 20+ baseline.

Wrangler remains application-owned. Its D1 configuration might include:

```jsonc
{
  // Preserve the application's existing worker, assets and compatibility options.
  "d1_databases": [{
    "binding": "DB",
    "database_name": "notes",
    "database_id": "YOUR_EXISTING_DATABASE_ID",
    "migrations_dir": "migrations"
  }]
}
```

For a named environment, declare its own `d1_databases` and set the matching
`wrangler.environment` in the sync configuration. A missing staging binding
fails; it cannot silently select the top-level database. Generation validates
configuration without connecting to a remote database.

## Declare the logical model

Create `sync-engine.config.ts` in the application root for configuration
completion and literal schema inference:

```ts
import { defineSyncConfig } from "@mintcd/sync-engine-vinext/config";

export default defineSyncConfig({
  version: 1,
  appId: "notes",
  contractVersion: "notes/1",
  wrangler: { config: "wrangler.jsonc", binding: "DB" },
  replicaKeys: ["main"],
  collections: {
    notes: {
      fields: {
        id: { type: "string" },
        title: { type: "string" },
        folderId: { type: "string" },
        archived: { type: "boolean" },
        priority: { type: "number", optional: true },
        color: { type: "string", nullable: true, enum: ["red", "blue"] }
      },
      primaryKey: ["id"],
      indexes: { byFolder: ["folderId"] }
    }
  }
});
```

`defineSyncConfig` validates the object and preserves literal collection, field
and index names, including IDE suggestions for keys and index field tuples.
The generated client retains those types without handwritten generic
arguments. Trusted local helper modules may be imported from the TS config.

The same object is supported in `sync-engine.config.json` as JSON/JSONC, without
import/export statements. JSON is parsed as data and never evaluated. The CLI
and plugin discover one default TS or JSON configuration automatically. If both
files exist, select one explicitly with `--config sync-engine.config.ts` or the
plugin's `config` option. Loading a TS configuration uses the application's Vite
installation and executes the module and its imports as trusted build-time code;
configuration modules are never loaded by browser or service-worker code.
JSON-only generation does not load Vite.

Supported field types are `string`, `number` and `boolean`; numeric values must
be finite. `optional` permits an absent field, `nullable` permits `null`, and
`enum` restricts scalar values. Primary keys are tuples of required nonnullable
string/number fields. Secondary indexes declare ordered string/number field
tuples; optional/null indexed values omit that row from the index. Boolean keys,
joins, relations and nested JSON fields are not part of this first CRUD schema.

Optional top-level settings include `schemaVersion`, `appDirectory` (`app` or
`src/app`), `endpoint` (default `/api/sync`) and `serverModule` (default
`sync/server.ts`). `appId` selects storage/table namespaces; keep it stable for
an existing installation. Contract/schema changes require an explicit migration
plan rather than an automatic reset.

## Generate and type-check

Add the plugin before `vinext()` in the existing Vite configuration:

```ts
import { syncEngineVinext } from "@mintcd/sync-engine-vinext/vite";

// Keep the platform plugins and options already configured by the application.
plugins: [syncEngineVinext(), vinext(), /* existing platform plugins */]
```

Generation runs before route discovery. During development, changing the sync
or Wrangler configuration, or a tracked local TS-config dependency, restarts
Vite and regenerates sources. The CLI uses
the same generation path:

```sh
npx sync-engine-vinext generate
npx sync-engine-vinext generate --dry-run
npx sync-engine-vinext generate --check
npx sync-engine-vinext types --wrangler wrangler.jsonc
```

`--root` selects the application root; `--config` selects its relative sync
configuration file. TypeScript may default-export the configured object or a
config function returning it; call `defineSyncConfig` on the returned object.
The plugin supplies Vite's actual command/mode; the standalone CLI defaults to
`build`/`production`. Dry-run reports proposed changes, and check exits nonzero on
drift or conflicts. The `types` command delegates to the project's installed
Wrangler; add `--env staging` when needed. Include Wrangler's generated runtime
declarations in the application's TypeScript configuration. They type `Env` and
`env.DB`; the generated literal model types tables and rows.

Generation creates the initial migration under the binding's `migrations_dir`.
Apply that migration through the application's normal local/remote deployment
workflow. Neither generation nor the Vite plugin applies migrations. A later
configuration that would change the initial migration is rejected; review a
separate schema-evolution migration instead of rewriting applied SQL.

## Generated modules and ownership

| File | Imports and responsibility |
| --- | --- |
| `sync/generated.ts` | Exports only the typed `useSyncEngine` hook; embeds the public schema/runtime values |
| `app/api/sync/route.ts` | POST incremental sync and GET snapshot handlers, literal model and package server composition; path follows app/endpoint configuration |
| `sync/server.ts` | Application-owned identity/authorization and policy hooks, created once |
| `migrations/0001_sync_notes.sql` | Application-owned initial SQL migration; actual name follows app ID |

Generated sources use the existing ownership marker and manifest. Modified
generated files cause a conflict before any partial update. Server hooks and
migrations become application-owned immediately and are never overwritten or
deleted by regeneration. The same executor supplies lock, journal, rollback and
safe-path protections as the [core generator](vinext-generation.md).

Optional PWA worker and registration entries are virtual build modules; they do
not add generated source files. The ownership manifest remains internal.

Client, route and worker embed the same validated schema without importing the
authored build configuration. A common package session helper opens the same
IndexedDB replica and transport for the page and worker, acquires the durable
registry lease, and drains native writes before releasing it. Server hooks and D1 mappings are
absent from the browser and service-worker import graph.

## Authenticate and customize authority decisions

The initial `sync/server.ts` deliberately returns an error until configured.
Implement identity, stream authorization and Origin/CSRF handling with the
application's existing session system. For the schema above, an example is:

```ts
import { SyncHttpError } from "@mintcd/sync-engine/transport/http-server";
import type { ResolvedSyncContext, SyncRequestScope } from "@mintcd/sync-engine/transport/http-server";
import { createCrudPolicy } from "@mintcd/sync-engine/records";
import type { SyncModel } from "../app/api/sync/route";
import { authenticateSession } from "../auth/server"; // Application-owned.

type Context = { readonly accountId: string };

export async function resolveContext(
  request: Request,
  scope: SyncRequestScope,
): Promise<ResolvedSyncContext<Context>> {
  const session = await authenticateSession(request);
  if (!session) throw new SyncHttpError(401, "unauthenticated", "Sign in.");
  const origin = request.headers.get("origin");
  const sameOriginGet = request.method === "GET" && origin === null
    && request.headers.get("sec-fetch-site") === "same-origin";
  if (!sameOriginGet && origin !== new URL(request.url).origin) {
    throw new SyncHttpError(403, "origin-denied", "Origin denied.");
  }
  if (scope.streamId !== `${session.accountId}/notes`) {
    throw new SyncHttpError(403, "stream-denied", "Stream denied.");
  }
  return { streamId: scope.streamId, context: { accountId: session.accountId } };
}

export function createPolicy(model: SyncModel) {
  return createCrudPolicy(model);
}
```

The browser's `accountId` only selects local state. The server establishes its
own trusted identity. The generated transport sends same-origin cookies; no
bearer token is generated or stored automatically. Cookie expiration preserves
queued work and reports an access failure until a later authorized sync.

The default CRUD policy rejects duplicate inserts and updates to missing rows,
and merges field patches against the current confirmed record. Different-field
changes survive; same-field changes follow authority order. To normalize the
canonical title in this example, replace its `createPolicy` export with:

```ts
export function createPolicy(model: SyncModel) {
  const decide = createCrudPolicy(model);
  const policy: typeof decide = (view, proposal, context) => {
    const result = decide(view, proposal, context);
    if (result.status !== "accepted" || result.operation.type !== "put") return result;
    const title = result.operation.row.title.trim();
    if (!title) {
      return { status: "rejected", reason: { code: "invalid-title", message: "A title is required." } };
    }
    return {
      ...result,
      operation: {
        ...result.operation,
        row: { ...result.operation.row, title },
      },
    };
  };
  return policy;
}
```

The authority validates and commits that result to D1. The client reconciles its
optimistic title with the canonical value, or exposes the application's rejection
through resolution notices. Policies can return application-defined bounded
rejection codes/messages. Custom domain workflows can use the portable core's
explicit model/policy APIs; the CRUD helper does not infer business rules or
authorization.

## Use the typed client

Client Components import `createSyncConfig` from the package and `useSyncEngine`
from the generated module. Create a stable configuration after the application
has authenticated the account:

```tsx
"use client";
import { createSyncConfig } from "@mintcd/sync-engine-vinext";
import { useSyncEngine } from "./sync/generated";

// Example for an already authenticated account; initialize only at bootstrap.
const config = createSyncConfig({
  accountId: "alice", streamId: "alice/notes", initialize: true,
});

export function Notes() {
  const { engine, error, logoutSync } = useSyncEngine(config);
  if (error) return <p>{String(error)}</p>;
  if (!engine) return <p>Opening local notes...</p>;
  return <>
    <button onClick={() => void engine.sync()}>Sync notes</button>
    <button onClick={() => void logoutSync()}>Disconnect sync</button>
  </>;
}
```

`createSyncConfig` validates runtime client options such as account, stream and
bootstrap settings. The generated hook supplies the schema inference for the
engine's collections, fields, queries and mutations. `defineSyncConfig` from
`/config` describes the authored build configuration.

The hook opens the engine after hydration, subscribes to its status and shares
one engine between consumers of the same hook and configuration. It returns
`{ engine, status, error, phase, logoutSync }` and closes the engine after the
last consumer leaves. Pass `null` while no authenticated configuration is
available. Keep configurations stable with a module constant or `useMemo` for account-dependent
values; do not create a new one on every render.

Once the hook has returned an engine, UI handlers use its typed collection API:

```ts
await engine.from("notes").insert({
  id: "note-1", title: "Draft", folderId: "inbox", archived: false, color: null,
});
await engine.from("notes").update(["note-1"], { title: "Revised draft" });

const query = engine.from("notes")
  .select("id", "title")
  .where("folderId", "eq", "inbox")
  .limit(50);

const page = await query.execute();
if (page.nextCursor) {
  const nextPage = await query.cursor(page.nextCursor).execute();
}

await engine.sync();
const status = await engine.status();
```

The hook subscribes to engine status and handles cleanup. Table names, fields,
predicate values, CRUD inputs and selected result fields retain IDE inference. Primary-key tuples
are inferred for CRUD mutations; primary keys cannot be patched. Builders are
immutable. `.get(key)` reads a local row and `.delete(key)` enqueues deletion.

Queries require `.execute()`. `.where()` accepts `eq`, `gt`, `gte`, `lt` and `lte`
with string/number values only when the predicates describe a supported primary
or declared secondary-index interval. `.index(name)` selects an index explicitly;
raw `.prefix()`, `.lower()` and `.upper()` use portable key tuples. Unsupported
filters fail rather than scanning unbounded data. `.select()` projects decoded
rows; it does not reduce physical storage reads. See the [client API](client-api.md).

Reads include pending optimistic changes. Mutation completion means the intent
was saved durably; inspect sync status and resolution notices for canonical
acceptance/rejection. Automatic startup, mutation and reconnect scheduling
defaults to enabled. Set `autoSync: false` to control explicit runs; pass
`syncOptions` to bound run/retry behavior.

## Bootstrap, recovery and logout

Use `initialize: true` after a trusted application sign-in/bootstrap. Ordinary
page and offline recovery should omit it. Existing replicas retain their client
identity; missing storage fails explicitly rather than resetting sequence state.
The hook's `logoutSync(options?: { deleteData?: boolean })` acts on its configured
replica.
After awaiting logout, create a fresh configuration to sign in again, even for
the same account; previously observed configurations remain revoked.

```ts
// In a component event handler, use logoutSync returned by useSyncEngine.
await logoutSync(); // Disable, drain active sessions and retain local data.

// After signing back into the same account/stream, pass this config to the hook:
const resumed = createSyncConfig({
  accountId: "alice", streamId: "alice/notes", initialize: true,
});
// The retained identity, pending edits and resolutions are reused.
```

To intentionally remove local data:

```ts
await logoutSync({ deleteData: true });
// After authenticating again, pass a fresh replica configuration to the hook:
const fresh = createSyncConfig({
  accountId: "alice", streamId: "alice/notes", initialize: true, freshStart: true,
});
```

`freshStart` selects a new identity and store; use it only after deciding to
discard or replace retained state. It does not recover pending edits from the
old store. Account/stream switching first requires logout. If the retained slot still has
pending or accepted-awaiting edits, switching also blocks so its outbox remains
reachable. Sign back into the previous account/stream to finish syncing and then
switch, or authorize an explicit fresh start. Each configured
replica key represents one active account/stream slot; this is not an account
catalog. Generated sessions require IndexedDB and Web Locks even without PWA
configuration. Applications needing another lifecycle can compose the portable
core directly.

## Rebuild the local replica after every app deployment

Supply `deploymentVersion` in the runtime client configuration. Your build or
release pipeline must create one unique value for each deployed app asset set,
and keep that value identical across every page in that deployment. Repeated
page loads must reuse it; generating a value in a component render would trigger
an unnecessary rebuild every time.

```ts
declare const __SYNC_DEPLOYMENT_VERSION__: string; // Injected once by the app build.
const config = createSyncConfig({
  accountId: "alice", streamId: "alice/notes", initialize: true,
  deploymentVersion: __SYNC_DEPLOYMENT_VERSION__,
});
```

A version is 1-128 characters from letters, digits, `_`, `.`, `:`, `/` and `-`.
It is public build metadata, never a credential or authorization claim. A fixed
`deploymentVersion` in `defineSyncConfig`/the runtime config is an optional
fallback; the runtime client option takes precedence. Supplying it through
`createSyncConfig` keeps source generation and `generate --check` deterministic.
Omitting both options keeps deployment rebuilds disabled; all retained-slot
replacements still protect pending work, including account switches.

On the first versioned initialization, or when the retained marker differs, the
page requests `GET /api/sync?bootstrap=1&protocolVersion=1&contractVersion=...&streamId=...`.
The generated endpoint validates this request and invokes the same application
`resolveContext` hook as POST before obtaining a D1 binding. Authentication,
exact stream authorization and the application's Origin/CSRF policy therefore
apply to snapshots too. Same-origin browser GET requests may omit `Origin`;
account for `Sec-Fetch-Site: same-origin` in that GET policy while keeping POST
origin validation. Successful and error responses use `Cache-Control: no-store`.

The server exports confirmed materialized rows and their canonical watermark at
one consistent D1 revision. It retries concurrent revision conflicts. The core
snapshot codec binds stream, contract, schema identity, row count and checksum;
see the [bootstrap API](records-api.md#materialized-authority-bootstrap).
Default export/import bounds are 10,000 rows and 8 MiB; the page additionally
caps response bytes at 8 MiB and its fetch at 30 seconds. Custom server
composition can set lower `bootstrapLimits` on `createVinextSyncHandler`.

The page creates a separate candidate database with a fresh client identity,
validates and installs the complete snapshot, then coordinates replacement of
the existing registry slot. Existing page/worker owners are invalidated and
must close/drain their databases before the final pending-work check. Pending
or accepted-but-not-yet-applied local edits block every retained-slot replacement,
including account/stream switches after logout, with an explicit error. The old database, client identity and queue remain retained; sign into their
previous account/stream and app version, finish syncing, and retry. The barrier inspects only the old adapter metadata without opening it through
the new schema. A settled old schema can therefore be replaced by a validated
new-schema snapshot after the server's separately managed migration. Automatic
pending-edit translation across schema changes is not supplied. An explicit `freshStart`
continues to mean intentional discard of retained work and should be reserved
for a separately authorized reset.

Only successful preparation publishes the new descriptor. Offline/auth/invalid
snapshots never change the active descriptor; a failed pending-work or lease
barrier restores its retained descriptor. A process interruption while owners
are quiescing can leave the old descriptor disabled; a later trusted
`initialize: true` retries against the retained database. Old replica databases
are retained after successful replacement; automatic historical-store cleanup
is not implemented.

The new replica starts at the snapshot's actual sequence and then pulls only
later canonical operations through ordinary POST sync. The same deployment
resumes its existing local identity and works offline without another snapshot.
Keep `appId`, D1 table mappings, contract/schema versions and server history
stable across ordinary deployments. A deployment marker changes only the local
replica selection; it does not create another D1 namespace, migrate legacy data,
change schemas or reset server history. A service worker may open an already
enabled compatible replica; deployment bootstrap itself is initiated by the
page after authentication.

## Migrate existing generated imports

Regenerate, then replace `sync/client.generated` imports with `sync/generated`.
Import `createSyncConfig` from `@mintcd/sync-engine-vinext` and only
`useSyncEngine` from `sync/generated`; the generated module has no other exports.
Use the hook's returned `logoutSync` method for account cleanup. A browser-only
offline entry can mount components using the same hook with React DOM.
Regeneration removes unchanged obsolete generated modules through the existing
ownership checks; edited generated files require conflict resolution.

The application-owned `sync/server.ts` is preserved. Remove its runtime import
of `model.generated` and change `export const policy = ...` into
`export function createPolicy(model: SyncModel) { ... }`, as shown above. Import
`SyncModel` only as a type from the generated route, adjusting the path for a
custom `appDirectory` or endpoint. The route also exports the `Schema` type.
PWA worker and registration entries are virtual build modules and do not need
application imports.

## Enable the PWA

Add this `pwa` property to the sync configuration:

```json
{
  "pwa": {
    "offlineEntry": "offline/entry.tsx",
    "scope": "/",
    "navigationPaths": ["/notes"],
    "manifest": {
      "id": "/notes",
      "name": "Notes",
      "shortName": "Notes",
      "startUrl": "/notes",
      "scope": "/",
      "display": "standalone",
      "icons": [
        { "src": "/icons/notes-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any" },
        { "src": "/icons/notes-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any" }
      ]
    }
  }
}
```

Create real icons under `public/icons` and a browser-only `offline/entry.tsx`
that mounts the application's local UI. It can reuse Client Components and
the generated hook:

```tsx
import { createRoot } from "react-dom/client";
import { Notes } from "../components/Notes";

createRoot(document.getElementById("root")!).render(<Notes />);
```

The offline UI must not require SSR/RSC responses or server actions
for an offline cold launch. The application supplies its account-selection UI
and durable account/bootstrap information. PWA entries do not need a separate
handwritten worker model or replica/session factory.

The plugin bundles the generated worker, public offline shell, reachable lazy
chunks/CSS and declared assets. It injects registration into the production
Vinext browser entry. No import registers a worker and development does not
install one automatically. Pages query/write IndexedDB, wake the worker after
commits, and fall back to foreground sync when needed. The worker opens the
same enabled replica and performs prepare, HTTP exchange and reconciliation
under `waitUntil()`.

Only public shell/build assets are cached. Domain records stay in IndexedDB;
API/auth/session/private SSR/RSC responses do not enter the shell cache.
Offline readiness requires a completed shell cache, compatible controlling
worker and initialized local replica. Background execution remains best effort,
and browser storage can be evicted. See the [PWA setup/API](pwa-api.md) for scope,
update, existing-worker and capability boundaries.

## Discover an existing D1 schema explicitly

To reduce initial declaration work, inspect only named application tables:

```sh
npx sync-engine-vinext discover --wrangler wrangler.jsonc --binding DB --table notes --local --out sync-schema.draft.json
```

Repeat `--table` to allowlist additional tables. Add `--env staging` to select
that environment. Inspect a remote database only by replacing `--local` with
an explicit `--remote`; there is no implicit location selection. The command
uses Wrangler already installed in the application and its existing local
authentication. Credentials stay in Wrangler's normal local configuration.
No remote discovery is claimed as executed by this implementation's local
checks.

The output includes `sourceTables`, draft `collections`, `warnings`,
`unresolved` entries and metadata declaring `reviewRequired: true`,
`rowsRead: false` and `writesPerformed: false`. It is a draft, not a complete
sync configuration. Review the metadata, resolve unsupported fields and merge
the logical declarations into the authored configuration. Normal generate,
dev and build commands never perform discovery.

Discovery reads metadata PRAGMAs, not application rows. It excludes system and
sync-storage tables, preserves column/key order, and imports only supported
ordinary nonunique ascending BINARY indexes. It reports ambiguous declared
types, numeric precision, generated columns, defaults, nullable keys, unique or
partial/expression/collated indexes and foreign keys for review. SQL defaults
and constraints do not automatically become offline behavior. SQLite TEXT can
still represent dates, UUIDs or JSON, and INTEGER can encode a boolean; logical
overrides remain necessary even when the affinity has a basic scalar mapping.

Programmatic discovery has two levels:

```ts
import { discoverD1Schema } from "@mintcd/sync-engine-vinext/discovery";
import { discoverConfiguredD1 } from "@mintcd/sync-engine-vinext/node";

const draft = await discoverD1Schema({
  tables: ["notes"],
  query: sql => applicationMetadataConnection.query(sql),
});

const configuredDraft = await discoverConfiguredD1({
  root: process.cwd(), wrangler: "wrangler.jsonc", binding: "DB",
  location: "local", tables: ["notes"],
});
```

The first query port is application-owned and returns metadata row objects.
The second validates the configured binding/environment and invokes the local
Wrangler binary. Discovery does not infer authentication, stream/tenant
boundaries or merge policy.

Adopting existing data is separate and remains proposed. The current D1 adapter
uses sync-managed collection tables with `__sync_*` columns and history/decision
metadata. Discovery does not attach arbitrary existing SQL tables or copy their
rows. A future adoption flow needs explicit mappings plus canonical import or a
supported snapshot/bootstrap protocol so fresh clients receive existing data.
Authority-only sequence-zero rows are not a substitute for that delivery path.

## Package boundaries

| Export | Intended environment |
| --- | --- |
| `@mintcd/sync-engine-vinext` and `/client` | Browser configuration, engine factory and local lifecycle; no React import |
| `/react` | Shared React engine lifecycle and status subscription |
| `/worker` | Service-worker session/options composition |
| `/server` | D1 authority and HTTP composition |
| `/discovery` | Explicit metadata discovery through a caller-owned query port |
| `/config` | Typed `defineSyncConfig` helper; no file loading or database access |
| `/node` | File generation, configured discovery and Wrangler type generation |
| `/vite` | Vinext generation and optional PWA build integration |

Import `createSyncConfig` from the package and `useSyncEngine` from the generated
module. The hook's literal schema supplies complete IDE inference without
handwritten generic arguments. Custom browser composition can use
`createVinextSyncEngine(model, runtime, options)` and
`logoutVinextSync(runtime, options)` from `/client` with an application-owned
model and runtime.

## Local verification evidence

Checks of this implementation include generated-client positive/negative type
tests, safe generation and environment selection, native workerd/D1 execution
of the generated route and server composition, authority transformations,
concurrent field merges, rejection recovery and fresh-client canonical pull.

`npm run check` passes 569 tests and strict browser, WebWorker and Workers type
consumers. Production browser checks pass 16 PWA cases and 10 dedicated-package
cases in Chromium 155.0.8059.80. The dedicated cases load the typed TS config and
cover generated worker-owned CRUD, indexed projection, cold offline launches,
retained edits, reconnection, account isolation and shared React hook lifecycle. Run
`npm run test:vinext-package` for that production fixture. Clean tarball consumers
from earlier verification also checked public imports, declaration/source maps
and browser dependency boundaries. Earlier native fixture runs covered 9
IndexedDB cases and 15 existing Vinext cases. These counts describe local
evidence, not cross-browser guarantees.

An isolated local project also exercised the actual installed Wrangler CLI
(4.151.1): discovery produced a metadata draft without changing the source row,
`types` emitted official Worker binding declarations, and the generated route
and client compiled against those declarations. No remote D1 database was
contacted for these checks. These checks verify the local package artifacts;
a deployed Cloudflare application requires separate validation.


Deployment-bootstrap regression coverage additionally exercises repeated distinct
deployments, same-deployment identity reuse, offline/401/truncated/wrong-stream/
oversized snapshots, pending-edit retention, cross-context lease invalidation,
failed/invalid registry replacement and native D1 GET authentication/stream/Origin
checks. These local checks do not establish physical-device or remote deployment
behavior.
