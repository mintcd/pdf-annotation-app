# Rewrite implementation plan

Status: Accepted. Date: 2026-10-16.

These stages follow the [requirements](requirements/sync-engine.md) and
[architecture](architecture.md). **Stages 1–6 are implemented.** The
accepted [storage refinement](storage-design.md) adds a record/query contract step
before the native adapters. That contract step and the memory record reference
are implemented, together with `createSyncEngine` and IndexedDB. Each stage keeps
lower layers usable without later adapters. Current contracts are documented in
the [core API](core-api.md), [record API](records-api.md) and [client API](client-api.md).

Stage 5 implements the offline-first PWA milestone: both Vinext shell/build
generation and service-worker synchronization, with a framework-independent
runtime. It is included in core 2.2; version 2.0.0 lacks these APIs. See the
[PWA API](pwa-api.md),
[W01-W16](requirements/pwa.md) and
[ADR-0007](adr/0007-offline-first-pwa-and-worker-execution.md).

## 1. Portable contracts and executable reference (implemented)

Implemented protocol version/stream scope, identity and canonical intent fingerprinting,
typed errors, domain codecs, proposal/decision/page types, replica transitions,
and the `ReplicaStore`/`AuthorityStore` contracts, with a consistent authority
read and revision-guarded commit plan, including rejected-only commits. Added
memory stores and authority coordination with a small note-edit domain fixture
and a [runnable counter example](../examples/memory-counter.mjs).

Tests cover accept/transform/reject behavior against current state, duplicate retries,
changed-identity errors, concurrent stale plans, bounded contiguous pages,
accepted receipts beyond a page, and deterministic overlay/rejection recovery.
They include accepted previews with missing canonical prerequisites and pending
previews invalidated by remote changes: neither can block valid reconciliation.
Retained client validation metadata keeps duplicate/divergent
responses distinguishable after application notices are acknowledged. Twelve
seeded interleavings of dropped, duplicated, and delayed exchanges converge once
communication succeeds. Protocol checks include strict runtime payload validation,
count/depth limits, stable codec normalization, and full-envelope sendability
before local or authority commit. Consumer type checks exercise published subpaths.

Requirements: R04-R10, R13; ADR-0001 and ADR-0002.

## 2. Client coordinator and IndexedDB durability (implemented)

Implemented the [record API](records-api.md): typed collection/key/index contracts,
transaction/query capabilities, incremental replica/authority coordination and an
indexed memory reference. Normal status/query/request APIs are separate from full
diagnostic state dumps. The aggregate path remains for small domains. Tests verify
that ordinary edits do not hydrate history and that record mode matches the
aggregate oracle under loss/duplicate/delay schedules.

Implemented `createSyncEngine`, local receipts, status/subscription APIs, durable
resolution access/acknowledgement, bounded explicit sync, coalesced automatic
scheduling, retry classification/backoff, cancellation, and close semantics.
Implemented IndexedDB atomic enqueue/reconcile over separate metadata, canonical
entry, receipt, outbox, and notice stores, with per-collection confirmed/visible
records and declared query indexes, preserving explicit client identity handling.
The coordinator composes record replicas and transport without adapter imports.
The aggregate reference remains independent; React facades remain deferred.
See [client API](client-api.md) for lifecycle, defaults and schema-upgrade policy.

Checks cover IndexedDB reopen/transaction-abort tests,
two-connection mutation/merge races, commit-before-send checks, and crash-boundary
scenarios. Native Chromium checks verify transaction behavior in addition to
fake IndexedDB contract checks; other browser engines remain unverified.

Checks also cover keyed/indexed query paths, unchanged-row writes, multi-record
preview failures, optimistic filter/sort/delete correctness, and equivalence with
the memory reference. Native cursor instrumentation verifies bounded range
visits rather than unrelated row/history traversal; conservative
pending-overlay replay remains explicit until dependency tracking is proven.

Requirements: R01-R03, R08-R12, R15, P01, P08.

Additional requirements: S01-S12; ADR-0004. Native IndexedDB verification is
implemented. D1 native acceptance is covered by stage 3.

## 3. HTTP boundary and D1 authority store (implemented)

Implemented the HTTP transport and `createSyncHandler` with versioned codecs,
stream authorization/context resolution, byte/count bounds, no-cache responses,
and structured error mapping. Synchronous final-response validation runs before
authority commit, so byte/page/identity failures roll back new decisions.
Implemented D1 guarded atomic commits of decisions, log, affected records and
revision. Primary read-plan validation and a failing SQL assertion protect the
whole write batch, including rejection-only changes. Read-replica sessions are
excluded. Explicit initial migration generation and layout binding are
implemented; automatic schema/data upgrades remain deferred. See
[HTTP API](http-api.md), [D1 API](d1-api.md), and
[ADR-0005](adr/0005-d1-guarded-record-plans.md).

Record mode plans against required current rows at a consistent revision.
Per-collection SQL tables provide typed application columns and native portable
query indexes alongside keyed history tables. Ordinary work does not hydrate
whole state/history. Work budgets fail before issuing a mutation batch.

Local workerd D1 tests cover simultaneous stream creation, rejected-only races,
identity preservation, stale guards, SQL failure partway through a batch, and
lost-response retries. Query-plan checks verify indexed paths. A Worker fixture
executes IndexedDB → HTTP → D1 exchanges with transformation, rejection,
reopen/retry, authorization isolation and response-byte rollback. No remote
database mutation is needed. Consumer type checks cover browser and official
Workers/D1 types; browser entrypoints retain no server or platform dependency.

Requirements: R04-R08, R11, P02, P07-P08.

## 4. Vinext generation and package boundary checks (implemented)

Implemented strict JSON configuration, pure deterministic planning, Node file
generation and a CLI binary. Generated POST routes delegate to an app-owned
handler; browser config exposes only endpoint and public protocol/contract data.
Optional server scaffolds remain application-owned and return 503 until configured.
Explicit app/root selection, dry-run/check, ownership hashes and conflict checks
protect existing files. Locks, staged backups and an interrupted-write journal
keep failed writes from publishing misleading ownership. No D1 discovery or
server-module execution is needed. See [generator API](vinext-generation.md) and
[ADR-0006](adr/0006-safe-vinext-generation.md).

The fixture pins vinext 1.2.1, Vite 8.3.4 and React 19.3.1. Native Chromium checks
load the generated route in development and production builds and exercise
IndexedDB → HTTP → local workerd D1 with transformation, rejection, offline
reopen/reload and lost-response recovery. Browser module responses and production
chunks are checked for server-only code/credentials. This validates vinext's Node
server with a private local-D1 test bridge; Cloudflare deployment is not claimed.
Consumer/package checks keep Node generation and vendor code out of browser
entrypoints. Framework test dependencies remain development-only.

Requirements: P01-P09; ADR-0003.

## 5. Offline-first PWA (implemented)

Implemented an additive PWA extension, originally developed as the unpublished
2.1 milestone and included in core 2.2. The [PWA API](pwa-api.md) documents
exports and strict JSON configuration. The 2.0 generator accepts no PWA options.

### 5a. Worker execution and recovery

Implemented `createSyncWorkerHost` with an app-owned engine factory,
durable bootstrap of configured replicas, static model imports, versioned
bounded messages and explicit event handlers. It runs the existing complete
prepare/exchange/reconcile cycle under `waitUntil()`, with bounded sync and
owned resource cleanup over the existing replica layout and semantic outbox.

Checks cover cold reconstruction, duplicate concurrent sends, lost responses,
termination boundaries, unsupported messages, factory/cleanup failure and
event-owned run lifetime independent of cancelled page observers. Both consumer
types and a real bundled native service worker are verified.

Requirements: W03-W06, W08-W09, W15-W16.

### 5b. Page coordination and foreground fallback

Implemented `createPwaSyncEngine`, keeping local mutation/query APIs usable,
wakes the worker only after durable commits, and requests Background Sync when
available. It provides startup/reconnect/explicit-retry rescan, bounded capability
handshake, separate worker/run observations and foreground fallback. The existing
foreground API remains usable and runtime imports have no startup side effects.

Checks cover failed wake-up after a successful receipt, lost wake-up recovery, denied
background API, missing worker/timeout/version mismatch, page closure,
concurrent fallback and account logout/auth renewal. Worker reconstruction uses
durable app bootstrap. `openPwaReplicaRegistry` disables descriptors before an
exclusive Web Lock cleanup barrier; cooperating owners retain their shared
leases until `database.closeAndDrain()` finishes. Tests cover delayed factory
opens and native reconciliation after logout. The engine close operation alone
is not a drain barrier. `requireExisting` recovery opens reject missing state.

Requirements: W02, W04-W09, W15-W16.

### 5c. Vinext executable shell and installable app generation

Extended strict JSON generation with explicit opt-in PWA configuration and source
ownership. `syncEnginePwa` builds manifest/registration wiring around app-owned
offline UI and worker composition. Automatic registration preserves an existing
different worker and offers manual mode. Vite configuration is app-owned.

Added isolated builds for executable worker code, neutral shell HTML
and a final public client asset manifest, including dynamic chunks/CSS/declared
assets. Output/base/scope settings and required public icons are validated, along with
start URL and navigation allowlist against effective worker/manifest scope.
The initial implementation requires a same-origin worker/shell/precache graph and rejects
unsupported cross-origin asset prefixes and undeclared scope-broadening header
requirements. Public resources enter the actual Vite client bundle so Vinext
serves them; client chunks/lazy CSS are included in the precache graph. Server
output is excluded. The optional peer does not constrain non-PWA consumers;
the build plugin checks Vite 8.3.4–8.x when configured.

Implemented `createPwaCache`, offline navigation and versioned readiness, with
API/auth/private/RSC/action exclusions. Checks cover failed
installs, old open tabs/lazy chunks, wrong MIME/scope, unrelated cache preservation
and existing-worker preservation. Ordinary development does not register the
worker. Old caches remain retained until the app defines cleanup policy.

Requirements: W01, W10-W14, W16; P04-P06, P09.

### 5d. Offline-first production fixture and package release gate

The generated Vinext production fixture now has a manifest, real bundled worker,
IndexedDB UI and a lazy offline screen. Its tested acceptance sequence is:

1. Visit online, initialize the replica and wait for explicit offline readiness.
2. Close every page; disable the network; reopen a deep link in the same profile.
3. Read/query existing records, edit locally and use the lazy screen offline.
4. Close/reopen again and confirm the receipt and visible records survived.
5. Reconnect; verify accepted/transformed/rejected outcomes against local D1.
6. Exercise worker termination and response loss with no page-side reconciliation.
7. Upgrade the shell with pending edits and an older tab, including a failed
   asset installation; preserve the usable version, data and old lazy chunks.
8. Expire/renew authentication, switch accounts and disable worker/background
   capabilities; verify local usability, isolation and foreground recovery.

`npm run test:pwa` passes 16 native production checks in Chromium 155.0.8059.80,
with Vinext 1.2.1, Vite 8.3.4 and local workerd D1. This includes two-tab identity
allocation, a delayed response after every page closes, native worker termination
after authority commit, failed asset installation, older lazy chunks and pending
edits across ordinary activation. Native Background Sync registration is verified;
browser-chosen execution timing and automated installation UI are not claimed.
The existing 9 native IndexedDB and 15 development/production Vinext checks pass.
Source, browser, WebWorker and official Workers consumer types are checked.
Packed-package consumer/build verification is part of each release review.

Requirements: W01-W16. A remote Cloudflare deployment remains separate from the
local Vinext/Chromium/workerd fixture and must not be claimed by that fixture.

## 6. Schema-driven client and dedicated Vinext package (implemented)

Implemented for core 2.2.0 and `@mintcd/sync-engine-vinext` 1.0.0.
The portable engine adds typed collection queries and optional CRUD intent
builders; a shared declarative CRUD model supplies codecs, optimistic previews,
canonical application and a field-patch policy. Vinext generation composes the
client, D1 authority, endpoint and optional worker/PWA objects from that model
and a validated Wrangler binding. Authentication remains application-owned.

Explicit schema discovery produces a local draft from allowlisted D1 metadata;
normal builds use the reviewed configuration. Existing-table/data adoption and
schema evolution remain separate. See [ADR-0008](adr/0008-vinext-package-and-schema-driven-client.md),
[V01-V12](requirements/vinext-package.md), and the
[package guide](vinext-package.md). Native checks exercise generated endpoints
in workerd and generated offline clients in Chromium, including retained local
work and account isolation. TypeScript configuration uses a trusted build-time
module with `defineSyncConfig`; plain JSON remains supported without evaluation.

## 7. Other extensions after the Vinext package milestone

Use the working client -> IndexedDB -> HTTP -> D1 path to validate extension ports.
Then prioritize React subscriptions, existing-data adoption, or a GitHub
projection based on application needs. A GitHub delivery design must settle target
representation, idempotency/version guards, durable progress, and import-loop
prevention before implementation. Authority switching is a separate decision.

Before adopting the rewrite for existing data, define protocol/storage versioning,
legacy export/bootstrap, rollback expectations, and a retention/workload envelope.
Do not copy legacy API names or storage tables as an implicit compatibility promise.

## Defaults to confirm through the first slice

- The first authority is D1 and there is one authority per stream.
- Domain intents and canonical operations are generic; no full-row overwrite
  policy is assumed.
- The app owns authentication, access rules, and merge policy; package handlers
  require those hooks and handle protocol validation.
- Endpoint/source generation is an explicit development command. The PWA
  milestone adds a separate opt-in build integration because executable worker
  bundles and final public asset names are required; see ADR-0007.
- GitHub initially fits the downstream projection boundary; implementing it as
  an authority or import source is separate work.

Change a default in the requirements and corresponding ADR before depending on
a different behavior. Stages 1-6 are implemented in core 2.2.0 and the Vinext
package 1.0.0. Stage 7 extensions remain separate decisions.
