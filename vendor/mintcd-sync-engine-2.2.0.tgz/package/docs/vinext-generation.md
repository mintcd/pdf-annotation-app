# Vinext endpoint generation

Implemented: a build-time CLI, a pure planner, and a Node filesystem writer.
The generator emits a thin App Router POST route and public client configuration.
It does not execute synchronization, choose policy, discover D1 tables, or
configure a deployment. Runtime composition remains in the
[client](client-api.md), [HTTP](http-api.md), and [D1](d1-api.md) APIs.

The [PWA API](pwa-api.md) documents the opt-in 2.2 extension: offline shell/build
integration, manifest/automatic registration and worker execution. Existing
endpoint-only configuration and commands below retain their behavior. The
[dedicated Vinext package](vinext-package.md) adds schema-driven generation with
a typed TypeScript configuration or plain JSON.

## Generate into an existing application

Create `sync.config.json` at the application root:

```json
{
  "version": 1,
  "contractVersion": "notes/1",
  "appDirectory": "app",
  "endpoint": "/api/sync",
  "serverModule": "sync/server.ts",
  "serverExport": "handleSync",
  "clientModule": "sync/client.generated.ts"
}
```

With the package installed in that application, run its binary from an npm
script or through `npx`:

```sh
npx sync-engine generate vinext --config ./sync.config.json --scaffold-server --dry-run
npx sync-engine generate vinext --config ./sync.config.json --scaffold-server
npx sync-engine generate vinext --config ./sync.config.json --check
```

In this repository, build first and replace `npx sync-engine` with
`node dist/cli/bin.js`. The root defaults to the configuration file's containing
directory. `--root <directory>` selects another existing application root and
resolves relative to the invoking working directory. Output paths are relative
to that root.

The initial command creates:

```text
app/api/sync/route.ts                 generated, owned
sync/client.generated.ts             generated, owned
sync/server.ts                       scaffolded once, application-owned
.sync-engine/vinext.manifest.json     generated ownership manifest
```

The route delegates to the configured server export:

```ts
import { handleSync as applicationSyncHandler } from "../../../sync/server";

export async function POST(request: Request): Promise<Response> {
  return applicationSyncHandler(request);
}
```

The scaffold returns 503 with `Cache-Control: no-store` until the application
replaces it. Compose `createSyncHandler` with authentication, stream authorization,
origin/CSRF rules and an authority in this module. The [HTTP example](http-api.md#bind-a-server-route)
shows those hooks; the [D1 example](d1-api.md#declare-tables-and-searchable-columns)
shows persistent authority composition. The generator preserves the server module
after creation, including application edits. Without scaffolding, that module
must already exist.

The client module exports only:

```ts
export const syncConfig = Object.freeze({
  protocolVersion: 1,
  contractVersion: "notes/1",
  endpoint: "/api/sync",
} as const);
```

Import `syncConfig` in browser composition and pass its endpoint to
`createHttpSyncTransport`. Match its public contract version with the authored
domain model before creating the engine. Client code supplies its runtime stream
and client identity separately. No server module, database binding, authentication
configuration or policy is imported into generated browser code.

## Configuration and commands

The configuration is strict JSON, never an executable TypeScript/JavaScript
module. Unsupported fields are rejected rather than copied into public output.
Authored shared models are sufficient; there is no database connection or schema
discovery step during generation.

| Field | Default / supported value |
| --- | --- |
| `version` | Required literal `1`, the generator configuration format |
| `contractVersion` | Required public domain contract identifier |
| `appDirectory` | `app` or `src/app`; default `app` |
| `endpoint` | Static path below `/api/`; default `/api/sync` |
| `serverModule` | Application-relative `.ts` path; default `sync/server.ts` |
| `serverExport` | Named handler export; default `handleSync` |
| `clientModule` | Application-relative `.ts` path; default `sync/client.generated.ts` |
| `scaffoldServer` | Create a missing server scaffold once; default `false` |

For `src/app`, set `appDirectory` or pass `--app-dir src/app`. The server and
client paths are independently configurable, such as `src/sync/server.ts` and
`src/sync/client.generated.ts`. Generated imports are relative to the route's
actual location. Dynamic route segments, route groups, URL queries/fragments,
path traversal and platform-specific file names are rejected in this version.
There is no app-directory auto-detection or implicit preference between layouts.

| Flag | Effect |
| --- | --- |
| `--config <file>` | Required JSON configuration path |
| `--root <directory>` | Override the application root |
| `--app-dir app\|src/app` | Override the configured App Router directory |
| `--scaffold-server` | Create an absent application-owned server module |
| `--dry-run` | Report planned changes without writing, including directories |
| `--check` | Write nothing; fail on drift or conflicts |
| `--json` | Emit a structured result for tooling |
| `--help` | Print usage |

Exit status is 0 for success, 1 for drift/conflicts or filesystem failure, and 2
for invalid arguments/configuration. Dry-run can succeed with proposed changes;
check mode succeeds only when output is current. Both refuse an active generator
lock. There is no force-overwrite flag.

## Ownership and failed writes

The deterministic manifest records generated paths and SHA-256 content hashes,
without timestamps or absolute paths. Commit it alongside the generated files.
An unchanged invocation produces identical output. Owned files missing from disk
can be recreated. Old generated paths can be removed after configuration changes
only while their content still matches the ownership record and generated marker.

Untracked existing files and edited generated files are conflicts, even if an
untracked file happens to contain the expected output. A conflict prevents the
entire write plan. The application-owned server scaffold is excluded from
ownership and cleanup. A generated file cannot silently become the server module;
case-only path changes also require an explicit application change.

The writer checks paths stay inside a real application directory and refuses
symbolic links/junctions in output paths. A write lock serializes generator runs.
Files are staged with backups, checked again before replacement, and committed
with the manifest last. Ordinary failure rolls back completed replacements. This
uses separate file renames, so run builds after generation has completed.

An interrupted or unsuccessful rollback retains
`.sync-engine/vinext.journal.json` and transaction backups. Later invocations fail
with `incomplete-generation` instead of trusting the manifest. Review the journal,
paths and backups, restore a consistent reviewed file set, and clear recovery
state only after confirming the original process stopped. A stale lock is not
automatically stolen. There is no automatic recovery or upgrade/adoption of
handwritten routes.

## Programmatic use

The pure entrypoint performs no filesystem or environment access:

```ts
import { planVinextGeneration } from "@mintcd/sync-engine/integrations/vinext";

const plan = planVinextGeneration({ version: 1, contractVersion: "notes/1" });
// plan.files contains deterministic paths, content and ownership classifications.
```

The Node entrypoint applies the same plan:

```ts
import { generateVinext } from "@mintcd/sync-engine/integrations/vinext/node";

const result = await generateVinext({
  root: applicationRoot,
  config: { version: 1, contractVersion: "notes/1", scaffoldServer: true },
  mode: "dry-run", // write | dry-run | check
});
if (!result.ok) reportConflicts(result.files);
```

Results include `ok`, `drift`, `mode` and per-path `create`, `update`, `delete`,
`unchanged` or `conflict` statuses. `VinextGenerationError` distinguishes unsafe
paths, invalid manifests, locks, incomplete generation and I/O failures. Config
validation uses the portable `SyncError` codes. No filesystem or CLI code is
re-exported by the browser/client entrypoints.

## Verified framework scope

The fixture pins **vinext 1.2.1**, Vite 8.3.4 and React 19.3.1. It runs the actual
generated route in Vite development and a production build served by
`vinext start`. Framework dependencies are development-only for this package;
the integration fixture requires Node 22+ as required by the pinned vinext
release. The package's portable runtime and generator retain their Node 20+
baseline. Vinext's setup and routing conventions are described in its
[official documentation](https://github.com/cloudflare/vinext).

Run `npm run check` for generator, filesystem, CLI and consumer type checks.
Run `npm run test:vinext` for the headless Chromium integration fixture, using
the [browser setup](client-api.md#verification) if needed. It verifies native
IndexedDB → generated HTTP route → local workerd D1, transformation, rejection,
offline database reopen/page reload, and retry after a committed lost response.
Development module responses and production browser chunks are checked for
server policy, adapter and credential leakage.

This fixture uses vinext's Node server with a credential-protected, test-only
loopback bridge to native local D1. It does not establish a Cloudflare deployment
claim. Worker binding resolution remains application-owned; the generator emits
no deployment config, provisions no resources and performs no deployment.
