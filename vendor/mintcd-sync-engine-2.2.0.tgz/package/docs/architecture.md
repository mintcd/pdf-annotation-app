# Sync engine architecture

Status: Accepted. Date: 2026-10-16.

Stages 1–6 are implemented in core 2.2 and Vinext package 1.0. This document describes the target architecture
across all stages; see the [core API](core-api.md), [record API](records-api.md),
and [client API](client-api.md), plus the [HTTP](http-api.md) and [D1](d1-api.md)
APIs and [vinext generation](vinext-generation.md) for current exports.

The offline-first PWA extension includes Vinext shell generation/build support
and service-worker execution, implemented in 2.2. See the
[PWA API](pwa-api.md), [requirements](requirements/pwa.md) and
[ADR-0007](adr/0007-offline-first-pwa-and-worker-execution.md).

Core 2.2 adds the portable schema-driven CRUD model and typed collection API.
The separate `@mintcd/sync-engine-vinext` package generates page, worker and
server composition from an explicit logical contract and Wrangler binding.
Optional schema discovery produces a reviewed local draft; existing data
adoption remains separate. See [ADR-0008](adr/0008-vinext-package-and-schema-driven-client.md)
and the [package guide](vinext-package.md).

The [storage design](storage-design.md) defines native indexed materialized
records alongside separate sync history. The [record contracts](records-api.md),
memory reference, IndexedDB and D1 adapters are implemented; the whole-`State` path
remains a reference/small-aggregate implementation. See
[ADR-0004](adr/0004-materialized-records-and-sync-history.md).

## Responsibility boundaries

The client **coordinates** local persistence and remote exchange. The authority
**coordinates** canonical decisions and their durable commit. Application policy
**decides** how to merge. Adapters implement storage, transport, or delivery.

These are roles, not an inheritance tree. Prefer TypeScript interfaces and
composition with factory functions. A stateful implementation can use a class
internally without requiring every extension to subclass it.

| Component | Owns | Does not own |
| --- | --- | --- |
| `SyncEngine` | Client lifecycle, local mutation workflow, sync scheduling, retry budgets, snapshots/subscriptions | SQL, IndexedDB transactions, server acceptance policy, route generation |
| `ReplicaStore` | Atomic local enqueue and reconciliation, client identity/order, confirmed state/cursor and validation history, outbox, resolution inbox | Network calls or authority decisions |
| `SyncTransport` | Sending a protocol exchange, cancellation and typed transport failures | Local persistence, canonical decisions or scheduling retries |
| `SyncAuthority` | Idempotency checks, policy invocation, canonical ordering, commit conflict retries, bounded pages | HTTP routing, credentials, vendor SQL |
| `DecisionPolicy` | Accept, transform/merge, or reject intent using current authority state and validated context | Storage, networking, clocks/randomness or external side effects |
| `DomainModel` | Payload codecs, deterministic committed-operation reduction, total optimistic previews for intents and accepted operations | Server-only policy and authorization |
| `AuthorityStore` | Consistent authority reads and atomic compare-and-commit of decisions/state/log | Domain merge logic and HTTP responses |
| `createSyncHandler` | Fetch protocol boundary: limits, codecs, app authorization/stream resolution, error mapping | Merge algorithms and physical storage |
| `VinextGenerator` | Build-time file planning/rendering, safe regeneration and checks | Runtime sync or accepting requests |
| `createPwaSyncEngine` | Durable local engine facade, worker wake-up, reconnect and foreground fallback | Server decisions, a second delivery queue or permanent background-execution promises |
| `createSyncWorkerHost` | Event lifetime, reopening app-composed engines, bounded sync and owned-resource cleanup | Merge policy, a new protocol, application credentials or page-only bootstrap |
| `createPwaCache` / `syncEnginePwa` | Explicit public asset graph, executable shell/worker output, cache readiness and scoped navigation fallback | Generic caching of private HTML/RSC/API responses or application UI/identity decisions |
| `ProjectionWorker` / `ProjectionSink` (later) | Durable delivery of committed changes to external systems | Changing an already committed authority decision |

`DomainModel` can be shared with the browser; `DecisionPolicy` remains server-only
when the authority is on the server. Optimistic validity in the browser is useful
feedback, not trusted server validation.

## Storage is independent of authority

An authority is a configured role for a stream, not a flag on a database adapter.
For example, `createSyncAuthority({ store: d1Store, policy: mergeNotes, model })`
makes a D1-backed service authoritative. Replacing D1 with another conforming
`AuthorityStore` leaves the merge policy and coordinator intact.

| Backend | Initial role | Possible additional role |
| --- | --- | --- |
| Memory | Reference `ReplicaStore` and `AuthorityStore` | Tests and executable specification |
| IndexedDB | Browser `ReplicaStore` | A local-only authority if a separate `AuthorityStore` implementation meets the same contract |
| D1 | Server `AuthorityStore` | A separate replica or projection implementation if needed |
| GitHub | Future `ProjectionSink` for committed data | Import source or alternate authority, each requiring its own explicit contract |

There is no universal `Adapter.push()` pipeline or `isDecider` property. A product
can implement several ports, but capabilities such as atomic local enqueue and
atomic authority commit are different promises. Unsupported roles fail at
configuration/type boundaries rather than falling back to weaker writes.

The first topology has **one logical authority per stream**. Many server requests
or instances can share that authority's durable store. Different streams may use
different stores/policies. Independent authorities accepting conflicting writes
to the same stream require a separate consensus/replication design.

## Local write through canonical confirmation

```mermaid
sequenceDiagram
    participant App
    participant Engine as SyncEngine
    participant Local as ReplicaStore (IndexedDB)
    participant HTTP as SyncTransport / handler
    participant Authority as SyncAuthority + DecisionPolicy
    participant D1 as AuthorityStore (D1)
    App->>Engine: mutate(intent)
    Engine->>Local: atomically enqueue + optimistic state
    Local-->>Engine: transaction committed
    Engine-->>App: locally persisted receipt
    Engine->>Local: read bounded pending snapshot + cursor
    Engine->>HTTP: synchronize(snapshot)
    HTTP->>Authority: authorized exchange
    Authority->>D1: read state, revision, decisions
    Authority->>Authority: replay known decision or decide(current state, intent)
    Authority->>D1: compare-and-commit plan
    D1-->>Authority: committed or conflict
    Authority-->>HTTP: durable decisions + canonical page
    HTTP-->>Engine: response
    Engine->>Local: atomically reconcile page + decisions
    Local-->>Engine: committed snapshot + resolutions
    Engine-->>App: notify updated state/status
```

1. `mutate()` creates a stable operation identity; the store allocates durable
   client order and atomically records the intent, outbox entry, and visible local
   state. Failure here means no send. Success resolves the local receipt.
2. The engine schedules synchronization only after that commit. An optional
   automatic scheduler and explicit `sync()` use the same workflow. Reopening or
   reconnecting can drain persisted pending work.
3. The transport sends a snapshot, leaving the durable outbox in place. There is
   no semantic in-flight queue to lose when a request disappears.
4. The handler validates and authorizes the requested stream, then resolves its
   authority. The policy sees the current committed state and can accept intent
   unchanged, produce a transformed canonical operation, or reject it.
5. The authority returns decisions only after persistence succeeds. A concurrent
   commit conflict causes a bounded read/decide/commit retry against fresh state.
6. The replica atomically merges decisions, the contiguous canonical page, its
   cursor, and resolution notices. It rebuilds the visible view from confirmed
   state plus the remaining optimistic overlay and notifies subscribers.

For IndexedDB, successful individual requests are insufficient: the local
boundary waits for transaction completion. Durability settings must be documented
by the adapter; the specification defines durability as a browser hint, so this
does not promise immunity to device loss or storage eviction. See the
[IndexedDB transaction specification](https://w3c.github.io/IndexedDB/#transaction-concept).

## State, decisions, and merge policy

A stream is an isolated synchronization history/access boundary. A proposal has
`operationId`, `clientId`, `clientSequence`, `intentHash`, and `intent`. Identity is
chosen before network communication; authority sequence is assigned only on
acceptance. The hash binds one identity to one canonical encoding of its intent.
Exact encoding and wire fields are specified in the first implementation stage.

The authority retains an append-only canonical operation log plus an idempotency
ledger for accepted **and rejected** proposals. Client and operation identities
are scoped to a stream. Reusing an operation ID with a changed intent or client
position, or reusing a client position for another ID, is a protocol violation.
An identical retry returns the original stored decision, even if policy changes.

Authority state is the reduction of its canonical log. Persisted state and any
application tables are materializations kept consistent with that log. Writes to
synchronized state, including external imports, enter through authority proposals;
out-of-band table edits are outside this consistency contract.

The first replica implementation retains enough canonical entries/fingerprints
and identity/decision bindings to validate old duplicate responses for divergence.
Acknowledging a resolution removes its application notice, not that validation
history. The first implementation stage specifies the exact representation.

The policy is conceptually:

```ts
decide(currentState, proposal, context)
  -> { status: "accepted", operation: canonicalOperation }
   | { status: "rejected", reason: domainReason }
```

The authority, not the policy, assigns sequence and commits. `applyCommitted`
deterministically reduces canonical operations on both sides. `applyOptimistic`
interprets pending intent locally and may report a local conflict if a newer
canonical state invalidates it. Those conflicts are exposed without discarding
the original pending intent or inventing an authority rejection.

For example, changing a title may carry `{ baseTitle, newTitle }`. The server can
compare that base with the current title, reject a conflicting edit, or emit a
merged operation. A full-row overwrite is one explicit policy; choosing D1 as a
store does not itself provide field merging or CRDT semantics.

Visible state is the confirmed canonical state with the ordered outbox overlay:

- Pending entries apply their optimistic intent.
- Accepted entries awaiting their canonical page apply the returned canonical
  operation as a preview instead of the original intent when its prerequisites
  are available. They leave the overlay when that entry joins the confirmed
  prefix, preventing double application.
- Rejected entries leave the overlay. The remaining pending work is replayed,
  and durable resolution notices let the UI explain rejection or transformation.

Overlay replay must be total for both pending intents and accepted operations:
it returns a preview or an explicit conflicted/unavailable-preview outcome rather
than throwing. An accepted operation can depend on an entity introduced by an
earlier canonical entry the client has not received yet. Such work stays durable
with accepted status, even if its preview cannot currently be shown. Preview
failure never prevents committing an otherwise valid contiguous canonical page.
Only reduction of the canonical prefix assumes canonical predecessor state.

This overlay is provisional; only the contiguous canonical prefix is confirmed.
An accepted receipt for sequence 500 cannot advance a cursor currently at 100.
Wire pages distinguish `throughSequence` from the observed `headSequence` and
contain exactly the contiguous entries covered by the page. Delayed responses
must merge monotonically and validate overlapping entries/decisions for divergence.

## Transaction and failure contracts

`ReplicaStore` provides atomic operations such as enqueue, reconcile, and
acknowledge-resolutions, rather than a generic async transaction callback. It
executes pure transition functions within its native transaction. Hashing,
network access, and unrelated awaits happen outside IndexedDB transactions.
Reads used to prepare requests are consistent snapshots; reconciliation reads
the latest durable state so it preserves mutations made while a request ran.

`AuthorityStore` exposes a consistent read and a compare-and-commit operation.
The commit plan binds an expected **store revision**, decision records, accepted
log entries, new state/head, and any configured durable delivery obligations.
Revision advances for rejected-only commits too; log head alone cannot guard
the decision ledger. A stale revision commits nothing. No partial sequential
fallback is allowed. Proposals are considered in submitted order against state
updated by preceding accepted proposals; a transport batch is not a domain
transaction. If a client write must be indivisible, represent it as one proposal.

D1's documented `batch()` supports transactional rollback on statement failure.
A successful conditional SQL update affecting zero rows is not such a failure:
the D1 adapter must ensure its revision guard protects **every** write and prove
that a stale plan cannot partly commit. A JavaScript read followed by independent
SQL writes is insufficient. See [D1's batch contract](https://developers.cloudflare.com/d1/worker-api/d1-database/#batch).

The implemented record path uses `RecordDatabase` rather than the aggregate
`AuthorityStore`. D1 stages a keyed plan, validates a primary revision, then uses
a `CHECK`-protected assertion at the start of one atomic batch. A stale guard
fails the batch, including every domain/protocol write. Rejection-only commits
advance the revision. The SQL layout is created by an explicit migration, and
runtime opening checks its binding. See [ADR-0005](adr/0005-d1-guarded-record-plans.md).

| Failure | Required result |
| --- | --- |
| Local transaction fails | No local receipt or remote send; report persistence error. |
| Local commit succeeds, app closes before send | Outbox survives; next engine instance resumes it. |
| Server commits, response is lost | Same proposal retries and retrieves its stored decision. |
| Response arrives, local reconciliation fails | Keep old durable cursor/outbox; retry safely. |
| Authority revision changes during decision | Commit nothing, reload, and re-run pure policy within retry budget. |
| Request is unauthorized or rate limited | Transport/access failure, not a permanent domain rejection. |
| Two tabs synchronize or mutate concurrently | Transactions/identity checks preserve writes; duplicate sends remain safe. |

Policy must be pure because it can run more than once. Any required timestamp,
identifier, or validated principal is explicit input. External API calls do not
belong in `decide()`; capture their results as separately validated input or use
post-commit delivery.

Within one engine, overlapping sync requests are coalesced and a mutation during
sync schedules another pass. Store transactions and authority CAS provide safety
across engines/tabs. Retry uses typed codes, bounded backoff/jitter, cancellation,
and a round/time budget. A sync result reports observed progress and remaining
work, not a promise that all writers everywhere have stopped.

## Optional downstream GitHub delivery

For `IndexedDB -> D1 authority -> GitHub`, the last edge is a separate durable
workflow. D1 commits a projection delivery obligation with canonical acceptance,
or the retained canonical log is the delivery source with a durable sink cursor.
A projection worker retries the sink and advances its cursor only over
contiguously delivered work. D1 acceptance never waits for GitHub availability.

A crash after a GitHub write but before cursor advancement can repeat delivery.
The sink must identify already-applied work using operation/range identity and
target version checks, or explicitly expose at-least-once behavior. D1 and GitHub
do not share an atomic transaction. GitHub's Git API supports commit/tree writes
and non-forced reference updates; its behavior needs a dedicated adapter design,
not an assumed SQL-like transaction. See [GitHub reference updates](https://docs.github.com/en/rest/git/refs#update-a-reference).

If GitHub edits should flow back, an import adapter translates them into new
proposals with stable source identities and loop prevention. If GitHub should
instead decide canonical history, it needs a conforming authority store with
decision durability, concurrency control, and bounded reads; that remains future
work. Neither feature creates a second independent decider for an existing stream.

## Public factories and generated app code

The following examples explain ownership. Client factories, HTTP composition
and record D1 authority are implemented. See the [client API](client-api.md),
[HTTP API](http-api.md) and [D1 API](d1-api.md) for complete composition.

```ts
// Browser: application-owned composition, using browser-safe dependencies.
const engine = await createSyncEngine({
  replica: recordReplica,
  transport,
});
const localReceipt = await engine.mutate(intent); // resolves after local commit
const progress = await engine.sync();             // bounded remote progress
```

```ts
// Server: application-owned composition, with request-scoped authorized context.
const handleSync = createSyncHandler({
  model: notesModel,
  resolveContext: authenticateAuthorizeAndResolveStream,
  async getAuthority(context, streamId) {
    const database = await openD1RecordDatabase({
      database: context.database, streamId, model: notesModel, collections: notesTables,
    });
    return createRecordSyncAuthority({ database, policy: notesDecisionPolicy, model: notesModel });
  },
});
```

`resolveContext` validates identity/access and maps a public stream to its internal
store scope before `getAuthority` runs. Credentials, database bindings, and policy
are selected in server composition. A server factory never returns a client
instance or causes the browser to import its dependencies.

`planVinextGeneration` is the pure development-time renderer; the Node writer and
CLI apply its output with ownership checks. Invoke
`sync-engine generate vinext --config ./sync.config.json`. Strict JSON avoids
executing application/server configuration during generation. It writes a thin
`app/api/sync/route.ts` (or `src/app/...`) and browser-safe `sync/client.generated.ts`.
The route exports `POST` delegating to the app-owned `sync/server.ts`. A one-time
server composition stub can be scaffolded separately; regeneration does not own
or replace it. Missing authorization/configuration fails clearly.

Vinext documents App Router `route.ts` handlers with named HTTP methods and
server-side binding access through `cloudflare:workers` for its Cloudflare
integration. Ordinary endpoint source generation uses the binding import in the
app's server composition and needs neither runtime route registration nor a Vite
plugin. PWA asset/worker building is a separate integration below. The
[integration fixture](vinext-generation.md#verified-framework-scope)
pins vinext 1.2.1 and tests the generated route in Node development/production
with local D1. It makes no Cloudflare deployment claim. See
[vinext's routing and binding documentation](https://github.com/cloudflare/vinext).

Shared authored contracts, optional schema discovery, client config generation,
and server scaffolding are separate operations. The generator never imports a
server module to derive client config. Client output is allowlisted (endpoint and
public contract/protocol identifiers), with no credentials or server imports.
The 2.0.0 generator does not emit a service worker. Version 2.2 adds opt-in PWA
source and build integration under ADR-0007; automatic schema discovery remains
separate. The production Vite plugin injects browser registration into Vinext's
client entry and the offline shell. Manual mode supports app-owned integration.

## Offline-first PWA execution

The accepted scope includes installable Vinext app-shell support and background
synchronization, while keeping the runtime independent of Vinext. After an
online bootstrap and verified offline readiness, the application must reopen
without a network, read locally available records, and accept durable edits.
Background delivery is opportunistic; a usable local application and later
foreground retry do not depend on background API support.

```mermaid
flowchart LR
  Page[Page: local reads and edits] -->|atomic commit| DB[(IndexedDB records and outbox)]
  Page -. wake after commit .-> Host[Service-worker sync host]
  Host -->|prepare from durable state| DB
  Host <-->|existing HTTP transport| Authority[D1 authority and app policy]
  Host -->|atomic reconciliation| DB
  DB -. invalidation hint .-> Page
  Page -. bounded foreground fallback .-> Authority
  Cache[(Public shell and build assets)] -->|offline navigation| Page
```

The worker hosts the entire existing engine run, including response
reconciliation. Its app-owned factory reconstructs configured replicas using
the same account/database/stream/client identity and statically imported model.
The durable outbox is the only delivery queue. Cross-context transactional
correctness and server idempotency remain necessary even when execution is
coalesced. A worker restart, lost message, denied background event, or late
foreground response cannot lose committed work.

The page coordinator handles worker handshakes/messages and reconnect triggers,
with bounded foreground fallback. Events use `waitUntil()` and existing run
budgets. Durable record/outcome status is separate from observed worker phase,
capability and shell readiness. Authentication and logout/account isolation are
application composition, and must work without a live page.

Offline launch also needs a real browser-only UI entry. The initial Vinext
integration builds an app-owned entry and neutral shell HTML, bundles the worker,
collects static/dynamic chunks and declared assets from final client output, and
installs a complete versioned public shell. An arbitrary SSR/RSC route is not
implicitly an offline shell. Generic caching excludes private/API/auth/session,
sync, RSC, action and non-GET traffic; synchronized data remains in IndexedDB.

Worker registration, manifest/build integration and caching are opt-in and
compose with an existing PWA. Source generation keeps the current ownership
rules; final asset collection justifies a separate build integration. Cache
installation/activation must preserve the previous usable shell, old open
pages and queued edits. See ADR-0007 for decisions and
[W01-W16](requirements/pwa.md) for observable acceptance criteria.

The implementation exports `/pwa/client`, `/pwa/worker`, `/pwa/cache` and
`/pwa/registry`. The separately imported `/integrations/vinext/pwa` Vite plugin
requires Vite 8.3.4–8.x when configured; ordinary runtime imports do not require
Vite. The registry uses a separate IndexedDB bootstrap database and shared Web
Lock leases; disablement precedes exclusive cleanup. Each owner drains its
native writes using `database.closeAndDrain()` before releasing its lease.
Recovery uses `requireExisting` opens to avoid resetting an evicted replica's
identity sequence. Cache updates retain older caches; cleanup is explicit app
policy. See the PWA API for capability limits and the verified browser scope.

## Proposed source and package layout

```text
src/
  core/                 protocol, codecs, identities, pure transitions, ports
  client/               SyncEngine and createSyncEngine
  pwa/                  page coordinator, worker host, messages, cache and registry
  server/               SyncAuthority and createSyncAuthority
  adapters/
    memory/             reference replica and authority stores
    indexeddb/          ReplicaStore implementation
    d1/                 AuthorityStore implementation
    github/             future projection/import/authority implementation
  transport/
    http-client/        SyncTransport implementation
    http-server/        createSyncHandler
  integrations/vinext/  generator renderer and app-specific conventions
  cli/                  configuration loading, generation planning, file writes
test/                   contracts, protocol scenarios, adapter/framework fixtures
```

Proposed public subpaths: root for the portable core; `/client`, `/server`,
`/adapters/memory`, `/adapters/indexeddb`, `/adapters/d1`, `/transport/http-client`,
and `/transport/http-server` as they are implemented. CLI tooling is exposed as
a binary, with pure `/integrations/vinext` and Node
`/integrations/vinext/node` entrypoints. Add further exports only when implemented; the root does not re-export
all integrations and accidentally pull server code into browser bundles.

Core imports no adapter. Coordinators import core ports. Adapters implement those
ports. HTTP and framework layers depend inward. Application composition selects
implementations. Generic contracts never import vendor-specific result types.

## Lessons from the legacy implementation

The rewrite keeps the valuable protocol ideas already present in
`sync-engine-legacy/src/replica.ts`, `server.ts`, and `indexeddb/store.ts`: stable
identities, pure transitions, durable outbox/resolutions, idempotent decisions,
and pagination with accepted overlays. It is not a clean break from those safety
properties.

The boundaries change: D1 moves out of `src/next/`; generic client ports stop
depending on `IndexedDb*` types; a single explicit atomic store contract replaces
corrective SQL wrappers/fallbacks. State-dependent merge always receives current
authority state, unlike the legacy specialized row path's initial-state shortcut.
Framework templates delegate runtime logic, schema discovery becomes optional,
and retry classification uses structured codes. Legacy data/API compatibility
requires a separate migration decision.
