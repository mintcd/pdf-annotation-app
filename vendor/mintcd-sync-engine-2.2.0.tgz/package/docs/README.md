# Documentation

The rewrite follows the accepted architecture below. Stages 1-6 are
implemented: portable contracts, replica/authority coordination, memory
references, the client coordinator, IndexedDB, HTTP, D1 storage and vinext
generation and opt-in PWA execution/build integration. The
[implemented core API](core-api.md) and [client API](client-api.md) distinguish
current exports from the remaining architecture sketches. The [HTTP API](http-api.md)
and [D1 API](d1-api.md) document the server boundary and persistent authority.

The [record-oriented API](records-api.md) now adds collection/query contracts,
incremental replica/authority coordination, an indexed memory backend and native
IndexedDB and D1 storage. The [vinext generator](vinext-generation.md) completes
the first client-to-authority path with thin route files and explicit ownership.

Materialized authority bootstrap is implemented in the local core source.
A fresh replica can install a consistent current-record checkpoint at its real
canonical watermark, then continue incremental synchronization. See the
[bootstrap API](records-api.md#materialized-authority-bootstrap),
[requirements](requirements/bootstrap.md) and
[ADR-0009](adr/0009-materialized-authority-bootstrap.md).

The **offline-first PWA** milestone is implemented in core 2.2,
including Vinext app-shell/manifest/build integration and service-worker
synchronization with foreground fallback. See the [PWA setup/API](pwa-api.md),
[PWA requirements](requirements/pwa.md),
[ADR-0007](adr/0007-offline-first-pwa-and-worker-execution.md), and
[stage 5](implementation-plan.md#5-offline-first-pwa-implemented).

The dedicated `@mintcd/sync-engine-vinext` 1.0 package and core 2.2 schema-driven
typed client are implemented. See the [Vinext package requirements](requirements/vinext-package.md)
and [ADR-0008](adr/0008-vinext-package-and-schema-driven-client.md), with the
[setup and API guide](vinext-package.md). Explicit D1 discovery produces a draft
for review; existing-data adoption remains proposed. Normal generation uses the
reviewed declarative contract.

Applications can opt into rebuilding their local replica after every deployment
with a runtime deployment marker and an authenticated materialized D1 snapshot.
See the [deployment setup](vinext-package.md#rebuild-the-local-replica-after-every-app-deployment),
[V13-V18](requirements/vinext-package.md) and
[ADR-0010](adr/0010-deployment-replica-rebootstrap.md).

Read in this order:

1. [Architecture](architecture.md): responsibilities, adapter roles, write flow,
   and target package API.
2. [Requirements](requirements/sync-engine.md): behavior and observable acceptance
   criteria.
3. [Implementation plan](implementation-plan.md): incremental delivery and checks.
4. [Storage design](storage-design.md) and [storage requirements](requirements/storage.md):
   normalized records, indexes, and history/checkpoint boundaries before
   the native adapters.
5. Architecture decision records:
   - [ADR-0001: Separate orchestration, policy, and adapters](adr/0001-role-based-composition.md)
   - [ADR-0002: One authority and durable local-first synchronization](adr/0002-authority-and-consistency.md)
   - [ADR-0003: Runtime factories and vinext generation](adr/0003-runtime-factories-and-vinext-generation.md)
   - [ADR-0004: Materialized records and sync history](adr/0004-materialized-records-and-sync-history.md)
   - [ADR-0005: Guarded D1 record plans](adr/0005-d1-guarded-record-plans.md)
   - [ADR-0006: Safe vinext generation](adr/0006-safe-vinext-generation.md)
   - [ADR-0007: Offline-first PWA and worker execution](adr/0007-offline-first-pwa-and-worker-execution.md)
   - [ADR-0008: Vinext package and schema-driven client](adr/0008-vinext-package-and-schema-driven-client.md)
   - [ADR-0009: Materialized authority bootstrap](adr/0009-materialized-authority-bootstrap.md)
   - [ADR-0010: Rebuild local replicas for each app deployment](adr/0010-deployment-replica-rebootstrap.md)

Requirements describe **what must hold**. The architecture describes **how the
parts fit**. ADRs preserve **why a consequential choice was made**, including
alternatives and tradeoffs. The implementation plan describes delivery order.

All ADRs start as **Proposed** for discussion. Mark a decision **Accepted** when
agreed; supersede an accepted ADR with a new record when the decision changes.
Update the requirements and architecture to reflect that change. This avoids
turning historical decisions into contradictory current documentation.

