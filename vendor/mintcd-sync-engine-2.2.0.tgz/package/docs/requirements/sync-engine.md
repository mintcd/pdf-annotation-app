# Sync engine requirements

Status: Accepted. Date: 2026-10-16. Delivery is tracked in the [implementation plan](../implementation-plan.md).

Accepted [storage/query requirements](storage.md) refine the physical layout and
record-oriented capabilities before the native adapters, without changing the
implemented protocol or weakening retention/identity guarantees.

## Purpose and scope

Provide a TypeScript package for offline local writes, durable synchronization,
and application-defined merge decisions. Support adding IndexedDB, D1, GitHub,
and other backends without making the core depend on their APIs or a framework.

The first topology is a browser replica backed by IndexedDB synchronizing with
one server authority backed by D1. Vinext is the first generated app integration.
An adapter implements a specific role; supporting one role does not imply it can
implement every role. See the [architecture](../architecture.md).

The extended scope is an offline-first PWA: Vinext app-shell/manifest/build
integration plus service-worker synchronization and foreground fallback. The
[PWA requirements](pwa.md) define that milestone, implemented in 2.2.
Version 2.0.0 does not implement it; see the [PWA API](../pwa-api.md).

## Behavioral requirements

| ID | Requirement | Observable acceptance criterion |
| --- | --- | --- |
| R01 | Persist local writes before sending them. | Local mutation, stable identity/order, and outbox entry commit atomically. An aborted local transaction sends nothing and reports failure. |
| R02 | Distinguish local persistence from canonical acceptance. | A mutation returns a local receipt without waiting for connectivity; callers can later observe acceptance, rejection, and confirmation. |
| R03 | Recover from interruption. | Reopening a replica resumes pending work with its original identities, including after a crash between local commit and send. |
| R04 | Support application-defined decisions. | A policy can accept unchanged intent, accept a transformed/merged operation, or reject against the actual current authority state. |
| R05 | Keep acceptance atomic. | The decision ledger, accepted log entry, authoritative state/head, and configured delivery obligations commit together, or none do. Rejection persists its decision without adding a log entry. |
| R06 | Make retries safe. | A lost response followed by retry returns the stored decision without a second canonical operation. Reusing an identity with different content or client position fails. |
| R07 | Serialize concurrent authority writes durably. | Racing requests, including rejected-only commits, cannot overwrite state or bind one identity to different decisions. Stale commits retry from current state within a bounded budget. |
| R08 | Reconcile through a contiguous canonical prefix. | Duplicate/delayed pages cannot move the cursor backward or apply an entry twice. A gap or divergent entry produces a typed error. |
| R09 | Retain accepted work during catch-up. | An acceptance beyond the returned page remains a durable canonical overlay/status until confirmed; transformed intent is no longer applied as the original intent. If canonical prerequisites are missing, preview reports unavailable without losing the acceptance. |
| R10 | Recover visibly from rejection and invalid previews. | Rejected intent leaves the overlay; its durable resolution remains until acknowledged. Replay of remaining pending/accepted work returns explicit preview outcomes, including conflicts; it cannot block valid canonical reconciliation. |
| R11 | Bound synchronization work. | Requests/pages have count and byte limits. A sync call has a round/time budget and reports remaining work; ongoing writes elsewhere cannot make it wait forever. |
| R12 | Preserve concurrent local changes. | Multiple tabs sharing a store cannot reuse a client sequence or lose an enqueue during response merge. In-process scheduling alone is insufficient. |
| R13 | Use roles independently of products. | An in-memory store can replace IndexedDB or D1 in a contract test without changing coordination or policy. Core contracts expose no IndexedDB, D1, HTTP, or framework types. |
| R14 | Separate external delivery from acceptance. | If a GitHub projection is enabled later, delivery obligations survive crashes and have independent retry/status tracking; its failure does not undo a committed authority decision. |
| R15 | Define lifecycle and status. | Client code can read a snapshot, subscribe, request sync, inspect/acknowledge resolutions, and close. Close prevents new scheduling and releases owned resources; already committed work survives. |

## Package and integration requirements

| ID | Requirement | Observable acceptance criterion |
| --- | --- | --- |
| P01 | Expose a framework-independent client factory. | `createSyncEngine` composes explicit dependencies; importing the core does not open storage, start timers, register workers, or contact a service. |
| P02 | Expose reusable server composition. | `createSyncAuthority` and a Fetch handler can be used without vinext. A handwritten route and a generated route delegate to the same runtime behavior. |
| P03 | Generate vinext endpoints. | A CLI emits a thin App Router POST route and browser-safe config into an explicitly selected app root (`app/` or `src/app/`). It does not implement sync logic in templates. |
| P04 | Make generation repeatable and reviewable. | Dry-run shows planned changes; identical input produces identical output; check mode detects drift. Regeneration refuses to overwrite handwritten or edited generated files. |
| P05 | Separate browser and server modules. | A browser entry/config cannot reach D1 bindings, server policies/auth, secrets, Node filesystem code, or generator dependencies in its import graph. |
| P06 | Keep schema discovery optional. | An authored shared domain contract is sufficient. Generating an endpoint never requires connecting to D1 or introspecting a database. |
| P07 | Validate and authorize the transport boundary. | Malformed/unsupported envelopes and excessive bodies are rejected; an application must supply authorization and stream resolution before authority access. Responses are not shared-cacheable. |
| P08 | Classify failures structurally. | Offline, timeout, rate limit, authorization failure, malformed request, and temporary store conflict remain distinguishable from permanent domain rejections. No retry decision depends on parsing error prose. |
| P09 | Keep extension dependencies optional. | Browser users do not need a framework, Wrangler, React, or GitHub SDK installed to use the client/core. Adapter subpaths publish their own supported environments. |

Cookie-based routes must integrate the app's CSRF/origin policy; authentication
alone does not authorize an arbitrary requested stream. The package supplies
hooks and enforces their presence; the application supplies identity and access
rules. Failed authentication/access checks do not create permanent domain
decisions or expose another user's decision ledger.

Replicas retain enough canonical/identity/decision validation metadata to check
old duplicate responses for divergence (R08). Acknowledging a resolution removes
only its application notice. Out-of-band writes to synchronized authority state
are unsupported: application writes and external imports enter through authority
proposals and the same guarded commit contract (R04-R07).

## First implementation defaults

- One configured authority per stream, with a retained append-only canonical log
  and retained accepted/rejected decisions. Sequence values are never reset or
  reused; replacing a history requires a new stream identity.
- Generic intent and canonical-operation model. A shared domain contract defines
  codecs, deterministic committed reduction, and optimistic intent application.
  Server merge policy is separate. A row facade can be added over this model.
- One logical proposal is the unit of domain atomicity. A network batch is ordered
  transport work and does not imply all-or-nothing acceptance of all proposals.
- One combined `POST /api/sync` exchange; a request without proposals is pull-only.
- Memory reference adapters, IndexedDB replica, HTTP transport, D1 authority, and
  vinext scaffolding delivered in stages.

## Deferred capabilities

Multi-authority consensus, peer-to-peer merge, automatic authority failover,
GitHub implementation, React bindings, existing-table/data adoption,
protocol snapshots/compaction, schema migrations, and legacy data migration are
separate work. The architecture reserves their boundaries without promising
their implementation now.

Service-worker execution and Vinext PWA support have moved from this deferred
list into the implemented 2.2 APIs under [ADR-0007](../adr/0007-offline-first-pwa-and-worker-execution.md).
Explicit D1 schema discovery is implemented in the dedicated Vinext package;
it produces a reviewable draft and does not adopt existing data.

Full retention is a deliberate initial correctness baseline, not a growth
strategy. Establish a supported workload/storage envelope before production use;
compaction must define cursor recovery and idempotency retention before deleting
history. Existing legacy data is not automatically compatible with the rewrite.
