# Vinext package requirements

Status: Accepted. Date: 2026-10-16. Updated: 2026-10-18.

Delivery status: V01-V11 are implemented in core 2.2.0 and the Vinext package
1.0.0. V13-V18 deployment bootstrap is implemented in local source. V12 is proposed data-adoption work and is
not implemented. See [ADR-0008](../adr/0008-vinext-package-and-schema-driven-client.md)
and the [setup and API guide](../vinext-package.md).

## Scope

An application using Vinext and a D1 binding should provide its Wrangler file,
one TypeScript or JSON declarative sync configuration, authentication/policy hooks and its UI.
Generation supplies one typed hook module and the server authority route;
package helpers compose the model and optional PWA wiring. Portable CRUD/query behavior belongs to the core
package. Vinext integration belongs to `@mintcd/sync-engine-vinext`.

## Implementation requirements

| ID | Requirement | Observable acceptance criterion |
| --- | --- | --- |
| V01 | Keep the dedicated package layered on core. | Public browser imports load without Node, Vite or Cloudflare server modules. Core CRUD and collection APIs work independently of Vinext. Node build/generator and server composition have explicit exports. |
| V02 | Use a shared declarative logical contract. | One validated TypeScript or JSON/JSONC configuration supplies collection fields, scalar types, optional/null/enum constraints, primary keys and named indexes. `defineSyncConfig` preserves literal types and gives configuration suggestions. Client, worker and authority derive compatible codecs and operations from the same generated literal definition. Invalid references and unsupported declarations fail before writes. TS modules/imports execute only as trusted build configuration; JSON is never evaluated. Automatic selection rejects ambiguous TS/JSON defaults; explicit selection remains available. |
| V03 | Preserve IDE inference through the generated hook. | The package exports typed runtime `createSyncConfig`; `sync/generated.ts` exports only `useSyncEngine`, which specializes the engine to the application's schema. Type checks accept known table/field names, compatible predicate values and correct CRUD data; reject unknown names, wrong values and primary-key patches. Selected result rows expose the requested fields. Existing engine status, synchronization, subscriptions and resolution methods remain available. |
| V04 | Preserve offline and authority semantics. | Queries read local visible records, including pending optimistic changes. Supported predicates use declared bounded index intervals. Unsupported predicates fail explicitly. CRUD methods return durable local operation identities and flow through authority policy and reconciliation. No raw database mutation bypass is introduced. |
| V05 | Generate the required runtime compositions with a small public surface. | Generation produces only `sync/generated.ts` and the App Router endpoint as generated source files, plus the create-once server hook scaffold, initial SQL and internal ownership manifest. The hook module embeds a validated public schema/runtime literal and has no helper/type exports; the route composes its model and D1 authority through package helpers. Optional PWA worker/registration entries are virtual build modules. Page/worker sessions share the package's registry and IndexedDB lifecycle helper. `useSyncEngine(config \| null)` opens after hydration, shares an engine across consumers of a stable config, subscribes to status and cleans up after the last consumer. Hook state exposes `logoutSync({ deleteData? })` bound to the configured replica. |
| V06 | Keep authentication and merge decisions explicit. | An application-owned hook resolves trusted identity, authorizes the requested stream and exports `createPolicy(model)`. The route exports type-only `SyncModel`/`Schema` for policy typing. The initial hook scaffold rejects requests until configured. Client-provided account IDs do not authorize access. Server-only hooks, bindings and mappings never enter browser/worker output. |
| V07 | Validate Wrangler bindings without changing infrastructure. | The selected file and environment contain exactly one matching D1 binding. A missing environment binding cannot use a top-level database silently. The binding's migration directory is respected; no remote queries, database creation, Wrangler rewrite or migration application occurs during normal generation/build. |
| V08 | Preserve safe source generation and initial migrations. | Write/dry-run/check modes reuse ownership, lock, journal and rollback protections. Handwritten or edited generated files cause conflicts without partial output. Server scaffolds and initial migrations are create-once. A changed initial migration fails clearly and is never overwritten or applied automatically. |
| V09 | Preserve replica identity and account isolation. | Explicit bootstrap persists a stable client identity and enables the replica after initialization. Recovery requires existing state. Page/worker sessions hold registry leases until native writes drain. Logout disables the replica and establishes quiescence before optional deletion; account/stream switching cannot reuse another enabled replica. |
| V10 | Verify generated consumer behavior and packaging. | Tests compile the generated hook/route with runtime binding types, exercise local CRUD and authority decisions, and check generator conflicts and environment selection. Hook checks cover shared lifecycle, asynchronous cleanup and server rendering. PWA claims use the existing native browser integration evidence plus checks of the new composition. Clean package consumers resolve browser, React, worker, server, Node and Vite entry points; importing `createSyncConfig` from the package does not require React. Published status is reported only after registry verification. |
| V11 | Discover an explicitly selected D1 schema into a reviewed local draft. | A separate command uses the project's installed Wrangler, explicitly selected local/remote location, binding/environment and allowlisted tables. Metadata-reading PRAGMAs produce draft fields, keys and indexes with source table names, unresolved logical types and unsupported-feature diagnostics. A query-port API supports caller-owned connections. Normal generation/dev/build never introspect remote databases. Discovery reads no application rows and performs no database writes. |

## Proposed data-adoption requirement

The following requirement describes future work. Schema discovery is available
as a draft-generation step; attaching existing tables and importing their data
are not implemented.

| ID | Requirement | Proposed acceptance criterion |
| --- | --- | --- |
| V12 | Separate schema discovery from data adoption. | Discovery does not subscribe every table or modify existing SQL layouts. Adoption explicitly maps existing tables into a supported sync representation and imports data through canonical history or a supported snapshot/bootstrap protocol. Fresh clients can receive those records. Identity, authorization, tenant boundaries and merge policy remain application-authored; authority-only genesis data is not treated as a substitute for canonical delivery. |

## Deployment bootstrap requirements

These requirements extend V09 through an explicit runtime deployment marker.
[ADR-0010](../adr/0010-deployment-replica-rebootstrap.md) records the lifecycle
choice; [B01-B08](bootstrap.md) define the core checkpoint protocol.

| ID | Requirement | Observable acceptance criterion |
| --- | --- | --- |
| V13 | Identify every deployed app independently of the sync schema. | `createSyncConfig({ deploymentVersion })` validates and snapshots an optional portable public version string. The app changes it for every deployment. A matching version reuses the same database/client identity offline; a different version or previously unversioned registration triggers one rebuild. `appId`, contract/schema and D1 namespaces remain stable. Omitting it preserves existing behavior. |
| V14 | Seed from current authenticated materialized D1 data. | Generated GET validates protocol/contract/stream query fields, calls the same trusted auth/stream/Origin resolver as POST before obtaining the binding, rejects a resolver stream mismatch, and returns no-store on success/errors. A fresh deployment imports all confirmed rows with a consistent canonical watermark before any new descriptor is enabled. |
| V15 | Preserve incremental continuity after bootstrap. | The imported replica has a fresh client ID, sequence allocation starts at 1, its confirmed/head cursor equals the real snapshot watermark, and subsequent POST pulls start there. Authority history and data are never reset or put in another deployment namespace. |
| V16 | Preserve old local data on every failed rebuild. | Offline, denied, oversized, truncated, checksum-invalid, schema/contract/stream-invalid or storage-failed snapshots do not publish a new registration. The previous database/client remain retained. Failed quiescence or preparation restores the retained descriptor; aborted candidates are closed and removed when possible. |
| V17 | Do not silently lose pending work during deployment. | Cooperating page/worker owners receive invalidation and release leases only after writes drain. A final old-store check blocks every retained-slot replacement, including account/stream switching after logout, when pending or accepted-awaiting local intents remain; the error explains signing into the previous account/session to finish sync and retry. The old descriptor remains reachable for that sign-in. The barrier validates old adapter metadata without applying the new model codec, permitting a settled old schema to be replaced after a separate server migration while pending old-schema work remains blocked. Explicit fresh-start remains an intentional-reset option, not an automatic deployment setting. |
| V18 | Bound and document bootstrap lifecycle behavior. | Snapshot rows/bytes and fetch time are bounded, every retained/current session and candidate closes/drains on success/failure, and malformed registry options cannot alter active registrations. Tests cover repeated deployments, same-build recovery, pending barriers, lease coordination, failures and native D1 security. Deployment IDs are supplied once per build/release so generation/check stay deterministic; historical local-store garbage collection is explicitly outside this feature. |

## Validation boundaries

Generated schema types are separate from Wrangler's environment/binding types.
IDE inference cannot prove runtime input validity, authentication or deployed
migration state; runtime codecs and server authorization remain required.

Queries initially support the core collection facade's declared index intervals
and result projection. They do not promise arbitrary JavaScript filters,
unbounded scans, joins, full-text search or storage-level column projection.
PWA background scheduling remains best effort under
[W01-W16](pwa.md); missing storage and unsupported browser capabilities are
reported explicitly.

Automatic schema evolution, legacy migration, direct SQL-export parsing and
existing-data adoption require separate implementations before these documents
can mark them as delivered. No remote discovery is claimed as executed during
local implementation checks.
