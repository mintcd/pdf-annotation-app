# Storage and query requirements

Status: Accepted. Date: 2026-10-16.

These extend the [accepted sync requirements](sync-engine.md) for record-oriented
adapters. Collection/query contracts, the memory record reference and native
IndexedDB persistence are implemented; see the [record API](../records-api.md)
and [client API](../client-api.md). The [D1 adapter](../d1-api.md) now implements
native authority storage with explicit initial migrations. Data/index upgrades
remain deferred. See the
[storage design](../storage-design.md) and
[ADR-0004](../adr/0004-materialized-records-and-sync-history.md).

| ID | Requirement | Acceptance criterion |
| --- | --- | --- |
| S01 | Persist current records separately from protocol history. | Reading/modifying one domain record does not deserialize every table or the retained canonical prefix. Each domain row/document and protocol entry is independently keyed. |
| S02 | Declare synchronized collections and query indexes. | Applications supply typed keys, codecs, schema/projection versions, and index definitions in the shared stream contract. No automatic inclusion of all D1 tables is required; per-client filtering of a stream is not introduced. |
| S03 | Provide bounded native query paths. | Point lookup, declared-index equality/range scans, ordering, and keyset pagination expose defined comparison semantics. An indexed page reads the matching range without loading all collection rows; fallback scans/full-text capabilities are explicit. |
| S04 | Separate confirmed and visible state locally. | Queries see optimistic inserts/updates/deletes and correct index membership/order. Rebase resets all old optimistic touched keys, including effects of removed previews, before replay. Rejection/transformation leaves no ghost rows and never writes unaccepted intent to the confirmed base. |
| S05 | Keep data and protocol commits atomic. | Aborting any local edit/reconcile or authority commit leaves rows/indexes, metadata, outbox, entries, receipts, and notices at the prior committed revision. Multi-collection intent is indivisible. |
| S06 | Preserve preview dependency correctness. | Initial rebase conservatively replays pending work. Skipping replay requires verified dependencies including range/predicate reads. A failed multi-row preview exposes unavailable status and leaves no partial row writes. |
| S07 | Replace full-history mutation scans with keyed validation. | Enqueue/request preparation/reconcile use metadata, exact identity/sequence lookups, bounded pages, and the current pending set. Tests with growing retained history show no full-prefix hydration in ordinary operations. Pending replay cost is reported separately. |
| S08 | Preserve identity and outcome guarantees. | Unique operation-ID and client-position bindings cover accepted/rejected work. Acknowledging UI notices never removes retry/divergence protection. Accepted work beyond a canonical page remains retained. |
| S09 | Version schema and projections explicitly. | IndexedDB store/index upgrades handle blocked/versionchange connections; D1 changes use migrations. Queries cannot silently use indexes/materializations built for a different projection version. |
| S10 | Distinguish materialization from checkpoint and retention. | Normal startup opens current data without replaying all history. No log/receipt deletion is introduced before snapshot bootstrap, stale-client recovery, and separate receipt-retention rules are specified. |
| S11 | Expose consistent query/status snapshots. | A page's records, local revision, and relevant sync status come from one consistent read. Cursor ordering has a deterministic key tie-breaker and documented behavior under intervening mutations. |
| S12 | Preserve generic-domain support honestly. | Small arbitrary `State` domains keep the current aggregate API. Record mode has an explicit interpreter/query capability and a memory reference; it does not claim to optimize every opaque reducer automatically. |

The first index API targets primary-key and declared equality/range/order queries.
Arbitrary SQL translation, portable full-text relevance, distributed transactions,
and automatic compaction are outside this requirement set. These remain optional
capabilities with their own semantics and validation.
