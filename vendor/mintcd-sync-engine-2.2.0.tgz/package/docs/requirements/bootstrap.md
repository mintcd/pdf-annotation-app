# Materialized authority bootstrap requirements

Status: Accepted. Date: 2026-10-18.

These extend [storage requirements S05, S09-S11](storage.md) with an explicit
checkpoint for initializing a fresh record replica. The portable API is
implemented in [`/records`](../records-api.md#materialized-authority-bootstrap).
[ADR-0009](../adr/0009-materialized-authority-bootstrap.md) records the decision.
Deployment detection, session replacement and pending-work handling belong to
the [Vinext package](../vinext-package.md); the core does not observe deployments.

| ID | Requirement | Acceptance criterion |
| --- | --- | --- |
| B01 | Export confirmed materialized rows and their real canonical watermark consistently. | One successful readonly transaction reads initialized authority metadata and every declared collection. A concurrent D1 revision change invalidates the complete attempt and retries within a configured budget. Returned rows and watermark never come from different committed revisions. |
| B02 | Bind each bootstrap to its stream, schema and contract. | The envelope declares format version, stream ID, contract version, schema version and schema identity. Export checks the authority binding; install rejects an unsupported format or mismatched stream/schema/contract before writing. |
| B03 | Bound the complete transfer. | Export traverses pages of at most 256 rows; both export and install enforce total row and canonical UTF-8 byte limits, defaulting to 10,000 rows and 8 MiB. Exceeding a limit fails explicitly rather than returning a partial snapshot. |
| B04 | Validate completeness and rows before storage mutation. | Declared row count and SHA-256 checksum cover the full envelope. Truncated/changed data, undeclared collections, malformed codec values and duplicate collection/primary-key addresses fail before opening the install write transaction. Key and index extractors are validated through normal record normalization. |
| B05 | Install only into a fresh empty replica. | Any existing confirmed/visible row, replica/authority metadata, retained receipt, pending work or other protocol record rejects installation. The caller supplies a fresh client identity; the core never reuses or resets a retired identity. |
| B06 | Commit checkpoint, confirmed rows and visible rows atomically. | Installation writes both row areas and replica metadata in one readwrite transaction. Injected row or metadata failures leave all areas empty. Successful recovery retains the installed rows, watermark and identity after closing and reopening IndexedDB. |
| B07 | Continue from the checkpoint without inventing history. | Confirmed and head sequence equal the exported watermark; next client sequence is 1 and pending/accepted/resolution counts are 0. No canonical operations or receipts are synthesized. The first request starts at the watermark, later canonical edits/deletes reconcile normally, and pages preceding the installed checkpoint reject. |
| B08 | Preserve authority retention and application boundaries. | Export does not delete history/receipts or admit arbitrary SQL tables. A checksum detects corruption but does not authenticate a sender. The application authenticates and authorizes the snapshot endpoint and transports it securely. |

## Verification

`test/record-bootstrap.test.ts` covers snapshot installation followed by remote
deletions and local sequence-1 writes, consistent D1 reads under a concurrent
commit, row/byte budgets and multipage traversal, identity/codec/completeness
failures, refusal of nonempty replicas, atomic write failures, and IndexedDB
close/recovery. The existing record replica and authority suites remain
regression coverage for normal incremental synchronization.

These requirements do not add log compaction, receipt expiry, arbitrary
existing-table adoption, automatic schema migration, or preservation/replay of
pending work from the retired replica.
