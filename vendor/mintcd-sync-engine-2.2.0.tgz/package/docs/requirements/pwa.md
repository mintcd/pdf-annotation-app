# Offline-first PWA requirements

Status: Accepted. Date: 2026-10-16.

Delivery status: implemented in core 2.2; see the [PWA API](../pwa-api.md).
These capabilities are not exported by version 2.0.0.
See [ADR-0007](../adr/0007-offline-first-pwa-and-worker-execution.md) and the
[implementation plan](../implementation-plan.md#5-offline-first-pwa-implemented).

## Scope and guarantees

The client must be usable as an installable, offline-first PWA. The first
integration includes both Vinext app-shell generation/build support and
service-worker synchronization. The runtime remains usable without Vinext or an
installed PWA, and the existing foreground client remains supported.

After a successful online bootstrap and an explicit offline-ready state, users
can close every tab, reopen an allowlisted application URL without a network,
read locally available records, and make durable edits. Synchronization is
attempted when an execution opportunity and authorized connectivity are
available. Background execution is best effort; continued usability and data
durability do not depend on the browser granting background execution.

Offline access covers data already replicated to this device and the declared
offline UI. It does not imply that an unseen remote record is available, that a
first-ever visit works offline, or that browser storage survives eviction or a
user clearing site data. Missing bootstrap/storage must be reported explicitly.

## Acceptance criteria

These extend R01-R15, P01-P09 and S01-S12 without changing authority or storage
semantics. A passing synthetic worker-event test alone is insufficient evidence
of native background scheduling or installability.

| ID | Requirement | Observable acceptance criterion |
| --- | --- | --- |
| W01 | Start and navigate offline. | After offline readiness, close all tabs, disable the network, and reopen an allowlisted deep link. The interactive UI starts, reads IndexedDB and navigates to a declared lazy-loaded screen without requiring an SSR/RSC response or other successful network access. |
| W02 | Keep local operations independent of delivery. | Offline mutations return a durable local receipt and update indexed visible records. Failed worker messaging, registration, Background Sync, or connectivity cannot turn a committed edit into a reported failure or erase its outbox entry. |
| W03 | Host the entire sync cycle in a worker. | With every page closed, a granted worker event can open the replica, prepare its durable requests, exchange them, reconcile results into IndexedDB and close owned resources. A page is not required to prepare requests or save responses. |
| W04 | Reconstruct worker state durably. | A new worker global discovers only configured/enabled replicas through application-owned durable bootstrap. It uses the same database namespace, account, stream, persisted client ID and statically imported model as the page; no page-memory function, credential, or localStorage read is required. |
| W05 | Preserve retry and reconciliation guarantees across contexts. | Concurrent tabs, a worker and foreground fallback can send overlapping requests without duplicate canonical operations, reused identities, lost local edits or duplicate resolution notices. A late response cannot rewind the confirmed cursor. |
| W06 | Bound execution and recover from termination. | Worker events extend their lifetime with `waitUntil()` and run within time/round/request budgets. Termination before send, after authority commit, or during local reconciliation leaves recoverable work with original identities. Budget exhaustion and a lost wake-up are recovered by a later page start, explicit retry or granted background event. |
| W07 | Provide a foreground fallback. | Missing/denied Background Sync, absent/failed worker registration, handshake timeout and incompatible worker messages do not disable local use. Page startup, explicit sync and reconnect attempt bounded foreground synchronization when the worker cannot run it. No perpetual polling or unconditional retry loop is introduced. |
| W08 | Define message and cancellation ownership. | Messages have a version, bounded payload, correlation ID and configured replica key. Unknown commands/targets/versions fail structurally. Messages cannot select arbitrary endpoints, databases or executable models. An accepted extendable event owns its bounded run independently of page reply observers. Cancelling/closing/timing out a page detaches that observer without aborting event-owned work or another caller. |
| W09 | Preserve authorization and account isolation. | Background authentication is provided by the application and works without a page. Access failures preserve the outbox and pause retries until a later authorized trigger. Logout first disables durable bootstrap and invalidates stale factory/auth generations, then establishes cross-context write quiescence or a proven durable generation fence before cleanup/account switching. Delayed opens/reconciliation cannot resurrect deleted data or enter the next account's replica. Awaiting engine.close() alone is insufficient; native writes may still finish. The package does not persist bearer credentials automatically. |
| W10 | Separate shell caches from synchronized data. | Only explicitly declared public shell/build assets are precached. Sync/API/auth/session responses, private HTML, RSC payloads, server actions and non-GET requests are excluded from generic cache routing. Domain records and delivery state remain in the existing IndexedDB replica/outbox. |
| W11 | Build a complete, executable offline shell. | Build wiring emits browser-executable worker code and neutral shell HTML around an app-owned browser entry, including reachable static/dynamic chunks, CSS and declared fonts/images. It honors the actual client output directory and URL base, and excludes SSR/RSC outputs and server-only imports. The first milestone requires same-origin shell/precache assets and rejects an unsupported cross-origin assetPrefix. Missing assets fail readiness. |
| W12 | Integrate installability and scope explicitly. | Generated manifest/registration wiring uses app-supplied identity, names, icons, display mode, start URL and scope. The worker script is same-origin; the start URL and offline navigation allowlist are inside its effective registration scope and the manifest scope. Broader-than-script-directory scope requires an explicit Service-Worker-Allowed header contract; unsupported configurations fail clearly. No import registers a worker. Development registration is opt-in; the production fixture verifies manifest delivery, MIME types, compatible worker control and scoped navigation on a secure context. |
| W13 | Compose with an existing service worker. | An application can attach synchronization and shell handlers to its existing worker. Generation preserves application-owned worker/build/manifest files and unrelated fetch handlers/caches. Conflicts are reported through existing ownership/dry-run/check protections. |
| W14 | Update without losing a usable shell or pending edits. | A failed asset installation leaves the previous worker/shell usable. Successful updates use versioned, package-owned cache namespaces and an explicit activation policy. Old open pages and lazy chunks remain usable until a compatible handoff; no unconditional `skipWaiting()`, broad cache deletion or implicit IndexedDB migration discards queued work. |
| W15 | Report durable state and execution capability separately. | The UI can distinguish local persistence, pending/accepted/rejected/confirmed records, offline readiness, worker availability and an observed run error. Worker phase/status messages are hints; durable replica status is reread from IndexedDB. Offline readiness requires a compatible active worker controlling the intended URLs, a complete shell and usable local bootstrap; registration.ready alone is insufficient. |
| W16 | Handle storage and platform limits honestly. | Quota/denied-storage failures do not report local success. A missing/evicted store reports bootstrap required. Persistence requests are an optional application policy. Test reports name the browsers and distinguish native worker execution/background scheduling from manually triggered events; unsupported engines are not claimed as verified. |

## Deferred beyond this milestone

Push notifications, periodic polling/sync, background fetch for large uploads,
automatic schema/legacy migration, history compaction, and multi-authority
behavior remain separate work. Install prompts, branding and business UI are
application-owned; package scaffolding supplies integration points and a working
reference, rather than inventing an application's interface.

## Platform references

- [Service Worker lifetime and registration](https://w3c.github.io/ServiceWorker/#service-worker-lifetime)
- [Background Sync events and scheduling](https://wicg.github.io/background-sync/spec/)
- [Offline application resources and background operation](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Offline_and_background_operation)
- [PWA installability](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable)
