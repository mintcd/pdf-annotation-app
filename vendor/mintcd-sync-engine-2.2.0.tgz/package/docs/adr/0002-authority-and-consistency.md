# ADR-0002: One authority and durable local-first synchronization

Status: Accepted

Date: 2026-10-16

Requirements: R01-R12, R14, P07-P08.

## Context

An offline write must survive until a server can decide it. A network response can
disappear after the authority commits. Multiple server instances and browser tabs
can race. A server may merge intent into a different operation, and its decision
may arrive before the client catches up to that operation's canonical position.

## Decision

Use one logical authority per stream with a totally ordered append-only canonical
log. Retain decision receipts for accepted and rejected proposals. Stable
operation identity, client order, intent fingerprint, and canonical sequence are
different fields. A stream's sequence is never reset/reused; a replacement history
gets a new stream identity. Multi-authority consensus is deferred.

The replica atomically persists local intent, identity/order, outbox, and optimistic
state before any send. A local receipt means local persistence, not authority
acceptance. Outgoing requests are immutable snapshots of durable state; a lost
request needs no recovery of a separate in-flight queue.

The authority reads current state/decisions, invokes a pure policy, then commits
the plan through `AuthorityStore.compareAndCommit`. This atomically guards and
persists the decision ledger, accepted log/state/head, and any enabled delivery
obligations. A distinct store revision covers all commits, including rejection
without log growth. A stale plan changes nothing and is retried against fresh
state within a bounded budget. No sequential write fallback satisfies this port.

Proposal retries return the stored decision after identity/fingerprint validation.
Authentication/access failures and temporary infrastructure errors are not stored
as permanent domain rejections. Policies may run repeatedly and cannot perform
external side effects.

Clients advance only through contiguous canonical pages. They atomically persist
reconciliation, cursor, outbox transitions, and durable resolution notices. An
accepted operation outside the page remains a canonical optimistic overlay until
confirmed; its preview may be unavailable until prerequisite entries arrive.
Rejection removes its intent and causes the remaining overlay to be re-evaluated.
All overlay replay returns explicit preview outcomes and cannot block committing
a valid canonical page. Confirmed state never includes entries beyond a gap.
Replicas retain validation metadata independently of acknowledged UI notices so
old duplicate responses can still be checked for divergence.

Downstream delivery, such as GitHub, follows canonical commit through durable
delivery obligations or a retained-log cursor. It has its own progress and retry
contract. It does not participate in a distributed transaction with D1.

## Alternatives

**Send first, save locally on success:** prevents offline operation and loses
intent across interruption.

**Let every adapter decide independently:** creates conflicting canonical
histories without a consensus or merge protocol.

**Delete pending work on send or any accepted receipt:** loses retries or makes
accepted edits disappear during paginated catch-up.

**Require exactly-once network delivery:** cannot resolve the ambiguous case where
the server committed but its response was lost. Use at-least-once delivery and
idempotent durable decisions instead.

## Consequences

The first model has strong, testable failure boundaries and retains useful legacy
safety guarantees. It does not automatically supply CRDT/field merging; the domain
policy defines that behavior. Full history and decision retention consume storage.
Compaction, offline-client expiry, history replacement, and authority migration
must be designed explicitly before changing retention behavior.

The store adapters bear the atomicity proof. D1 transactional batches are a useful
primitive, but all statements must be protected by the revision guard, including
when a conditional update matches zero rows. See the [D1 batch documentation](https://developers.cloudflare.com/d1/worker-api/d1-database/#batch)
and the [architecture's failure contracts](../architecture.md#transaction-and-failure-contracts).
