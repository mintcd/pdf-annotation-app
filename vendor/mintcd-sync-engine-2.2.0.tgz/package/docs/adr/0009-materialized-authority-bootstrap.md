# ADR-0009: Bootstrap fresh replicas from materialized authority checkpoints

Status: Accepted

Date: 2026-10-18.

Delivery status: implemented in the local core source. See the
[record API](../records-api.md#materialized-authority-bootstrap) and
[bootstrap requirements B01-B08](../requirements/bootstrap.md). Extends
[ADR-0004](0004-materialized-records-and-sync-history.md) and
[ADR-0005](0005-d1-guarded-record-plans.md).

## Context

Applications need to rebuild their browser replica when a deployed application
version changes, using current materialized D1 records. Replaying all canonical
operations makes startup cost depend on retained history. Treating current
authority records as replica `initialRows` loses their canonical position and
can replay already-applied operations. Existing `initialRows` represent shared
genesis at sequence zero; they are not a checkpoint import API.

An independent read of current rows followed by a read of the authority head can
produce a mismatched checkpoint if a commit races the export. Reusing a retired
client identity with sequence 1 can also collide with permanent authority
receipts. A checkpoint therefore needs consistent capture, explicit identity
bindings and an atomic fresh-replica install.

## Decision

Add `exportRecordBootstrap` and `installRecordBootstrap` to the portable
`@mintcd/sync-engine/records` entrypoint.

Export reads initialized authority metadata and all confirmed materialized rows
within one readonly database transaction. The D1 adapter's revision checks make
an interleaving authority commit fail with `commit-conflict`; export retries the
complete capture, up to eight attempts by default. Hashing runs after the
transaction against the captured envelope. All declared collections are included;
this does not introduce selective replication or arbitrary SQL-table discovery.

The version-1 envelope carries stream ID, contract/schema versions, schema
identity, canonical watermark, row count, encoded rows and a SHA-256 checksum of
the canonical envelope excluding the checksum field. Collection codecs and key
and index extractors validate every imported row. A duplicate address, malformed
row, count/checksum mismatch or wrong identity rejects before storage mutation.
The checksum detects corruption; endpoint authentication and authorization remain
application responsibilities.

Bound the operation to 10,000 rows and 8 MiB by default, configurable on both
sides. Export reads pages of at most 256 rows within the same transaction.
Hitting a total budget fails instead of returning a partial snapshot. This
initial design transfers a complete bounded envelope; it is not a resumable
snapshot stream.

Install requires a fresh, completely empty database and a fresh caller-supplied
client identity. One readwrite transaction verifies emptiness, writes confirmed
and visible rows and stores replica metadata at the exported watermark. The
next local client sequence is 1, all work counters are zero and no canonical
history or decisions are synthesized. A stored bootstrap floor rejects canonical
pages preceding the checkpoint. Incremental synchronization starts at the real
watermark and applies later canonical edits and deletions normally.

The core does not detect application deployments or replace live sessions.
The integration chooses when to fetch/install a checkpoint and how to drain or
preserve existing pending work before retiring a replica. The
[Vinext package guide](../vinext-package.md) describes that lifecycle.

## Alternatives and consequences

Full replay preserves the existing empty-replica path but makes bootstrap
proportional to log history. Authority-only sequence-zero seeding does not
communicate either imported rows or their real position to a fresh client.
Synthesizing canonical operations from materialized records invents history and
cannot represent the actual accepted/rejected decision ledger.

The explicit checkpoint keeps routine synchronization incremental and lets a
fresh client obtain current state without old operations. It consumes bounded
memory and transfer bandwidth; larger datasets need a separate resumable
snapshot design. Live or nonempty replicas cannot import checkpoints in place.
Applications must open a fresh replica identity and coordinate session changes.

Authority canonical history and permanent decision/identity receipts remain
retained. Snapshot bootstrap alone does not make compaction, stale-client
recovery, receipt expiration, schema migration, or arbitrary existing-table
adoption safe. Those need separate contracts.

## Verification

`test/record-bootstrap.test.ts` checks actual D1 revision races, bounded
multicollection exports, validation failures, fresh-replica enforcement,
transaction rollback, IndexedDB close/recovery and checkpoint-to-incremental
synchronization including deletions. Existing replica and authority suites
cover continued operation outside the bootstrap path.
