# ADR-0001: Separate orchestration, policy, and adapters

Status: Accepted

Date: 2026-10-16

Requirements: R01, R04, R13, R14, P01, P05, P09.

## Context

The rewrite must accommodate IndexedDB, D1, GitHub, and other backends. A client
must save locally before sending, while a server may transform or reject the
intent. Calling every participant an adapter with a `push()` method hides which
component owns ordering, durable state, and merge decisions.

The legacy implementation already has pure replica/server transitions, but some
generic client interfaces use IndexedDB result types and D1 authority storage is
nested under the Next integration. Those dependencies make extensions harder to
reason about.

## Decision

Use explicit ports composed through factories:

- `SyncEngine` coordinates client mutation, synchronization, and lifecycle.
- `ReplicaStore` provides atomic local persistence and reconciliation.
- `SyncTransport` carries exchanges without owning the sync loop.
- `SyncAuthority` coordinates idempotency, policy, canonical order, and commits.
- `DecisionPolicy` chooses accept/transform/reject using current authority state.
- `AuthorityStore` provides durable consistent reads and atomic guarded commits.
- A shared `DomainModel` defines deterministic application and payload codecs.
- Future `ProjectionWorker`/`ProjectionSink` roles deliver committed changes.

An adapter implements one or more ports explicitly. Authority is a composition
of a store, policy, and coordinator; there is no `isDecider` flag. Storage choice
does not imply a merge algorithm. Local persistence does not confer canonical
authority when a remote authority owns the stream.

Factories return interfaces; implementations can use classes internally. The
core depends only on portable types and pure functions. Vendor and framework
layers depend on core contracts, never the other way around.

## Alternatives

**A common adapter base class with ordered `push()` calls:** simple to draw, but
it conflates local commit, remote acceptance, and external delivery. Restart and
partial failure need durable state between the calls, so an array order is not
enough to define correctness.

**A single engine handling storage, policy, HTTP, and code generation:** offers
one entry point but couples browser dependencies, authority lifetime, credentials,
and build-time filesystem access.

**An arbitrary adapter graph:** may be useful later, but needs explicit consensus,
cycle prevention, delivery, and failure semantics. It is outside the first design.

## Consequences

Policies can change independently of D1. Stores can change independently of
framework handlers. New integrations must prove the capability contract for each
role they implement. There are more named interfaces, but no mandatory class
hierarchy or plugin registry to configure before using the first topology.

See the [architecture](../architecture.md) for ownership and adapter-role tables.
