# ADR-0007: Offline-first PWA and worker execution

Status: Accepted

Date: 2026-10-16

Delivery status: implemented in core 2.2; not available in version 2.0.0.
The original 2.1 milestone was not published separately.
See the [PWA API](../pwa-api.md) for actual exports and configuration.

Requirements: [W01-W16](../requirements/pwa.md), R01-R03, R06-R12, R15, P01, P04-P09.
Extends [ADR-0003](0003-runtime-factories-and-vinext-generation.md) beyond its
initial service-worker deferral; its runtime/generator separation still applies.

## Context

The goal is an offline-first PWA, including Vinext PWA generation and background
synchronization. Version 2.0.0 already persists local mutations, indexed visible
records, identities, decisions and pending delivery in IndexedDB. Its engine
schedules work in the current JavaScript context, and its generator emits only
an HTTP route, public configuration and an optional server scaffold.

Durable records alone do not let an application reopen offline. Its HTML,
JavaScript, styles and other required assets must also be available. Conversely,
caching an application shell does not deliver pending data or persist server
responses after the page closes. These concerns need separate responsibilities
within one application-owned service worker.

## Decision

### 1. Preserve the existing protocol and durable outbox

Keep IndexedDB as the client's query/write store and the existing semantic
outbox as the delivery source. Pages can commit local edits and query visible
records without a worker, network or canonical acceptance. D1 remains the first
authority and application server policy still decides accept/transform/reject.

Do not introduce a second queue of serialized Fetch requests. Requests are
prepared from durable protocol state at execution time, and responses must pass
the existing validation and atomic reconciliation path.

### 2. Add a worker execution host around the existing engine

The worker host opens an application-composed replica/engine and executes the
whole `prepare -> exchange -> reconcile` cycle. It uses the existing HTTP
transport; a worker is an execution location, not a transport or authority role.
The host exposes composable message/background-event handlers so an application
can use its existing service worker. Merely importing it has no side effects.

An app-owned factory resolves an opaque configured replica key to the model,
database, account namespace, stream, persisted client identity and current
authentication. Models are static imports, not functions sent in messages.
Bootstrap/enablement metadata must be worker-readable and durable. It can live
in application storage or a separately versioned integration store; this
milestone does not silently upgrade the 2.0 replica layout. Worker messages may
select configured keys, never arbitrary URLs, schemas, code or database names.

Each extendable event holds its work through `event.waitUntil()`. Engines use
explicit bounded sync with automatic engine scheduling disabled in the worker.
The host coalesces compatible active runs in its own context. An accepted
extendable event owns its bounded run independently of page reply observers;
observer cancellation/page closure cannot accidentally abort event-owned work.
Close only owned resources after event-owned runs finish. A cold worker
reconstructs state rather than relying on previous globals or timers. Native termination
can still happen; durable retry identities and atomic commits provide recovery.

Cross-context correctness continues to depend on the existing transactional
replica and authority idempotency. Optional cross-context single-flight can
reduce duplicate traffic, but a lock/lease is not the only protection against
data loss. Foreground fallback and a late worker run must remain safe together.

### 3. Add a page coordinator with bounded fallback

The page keeps local reads/mutations in IndexedDB. After a successful local
commit it wakes the worker and, where available, requests Background Sync.
Wake-up failure cannot change the result of the completed local transaction.
Startup/reconnect/explicit retry rescan durable pending work, including edits
whose original wake-up was lost.

Use a versioned, bounded request/reply protocol with correlation IDs, explicit
errors and per-caller cancellation. A caller can stop waiting without deleting
queued work or cancelling a background event/another tab. Worker execution
phase is ephemeral; local replica status is reread from storage. Unexpected
worker versions or unavailable registrations select foreground fallback after a
bounded handshake, rather than blocking local operations.

Background Sync is an optional execution opportunity. It is not a guarantee of
continuous execution or delivery while the browser/device is shut down.
Ordinary foreground synchronization remains a supported path in every browser
where the existing client can run. Access failures retain work and stop retry
loops until another authorized trigger.

### 4. Build a real offline browser shell for Vinext

Vinext's normal App Router page bootstraps through server-rendered HTML/RSC.
Our inference from that architecture is that caching its JavaScript alone is
insufficient for a reliable cold offline launch. The first integration therefore
uses an explicit app-owned browser-only entry that mounts the offline UI and
reads IndexedDB without server components, server actions or a network-dependent
router. It may reuse domain models and UI components from the online app.

Generation supplies neutral shell HTML and opt-in build/registration wiring.
The production build bundles the offline browser entry and worker into executable
public artifacts, collects the complete declared asset graph, and injects a
versioned precache manifest. Follow reachable imports/dynamic imports, CSS and
assets; include explicitly declared public icons/fonts/images. Honor the actual
client output directory and URL base. The first milestone requires same-origin
shell/precache assets and rejects unsupported cross-origin asset prefixes.
Filter build work to the client/worker outputs; do not expose server output by
directory globbing.

An explicit Vite/Vinext build integration is now justified by final asset names
and worker bundling. Keep it outside the portable runtime and pure file planner.
Select the smallest integration proven against the pinned production fixture;
do not couple the core to Vite or rely on undocumented Vinext manifest details
without a compatibility test. Build-generated cache manifests are separate from
the CLI's source-file ownership manifest.

A complete explicitly public prerender could become another shell input later.
Arbitrary runtime SSR/RSC responses are not treated as public offline shells.

### 5. Define cache, identity and update boundaries

- Cache only explicit public build assets and neutral shell HTML. Serve the
  shell for an app-declared allowlist of document navigations when offline.
  API/auth/session/sync/RSC/action requests and non-GET traffic bypass generic
  caching. Synchronized domain data stays in IndexedDB.
- App-supplied manifest identity, branding, icons, start URL and scope are
  validated. The worker script must be same-origin. Start URL and allowlisted
  offline navigations must be inside its effective registration scope and the
  manifest scope; broader-than-script-directory scope needs an explicit
  `Service-Worker-Allowed` header contract. Installation UI belongs to the app.
  Offline readiness requires a compatible active worker controlling those URLs,
  a complete shell/asset install and local bootstrap; `registration.ready` or
  registration success alone is insufficient.
- Existing worker/manifest/build files remain application-owned. Supply
  composable handlers and opt-in scaffolds; preserve unrelated routing/caches.
  Generated source continues to obey ADR-0006 ownership and recovery rules.
- Version package-owned caches by app/build. A failed install cannot replace
  the usable shell. Activation and old-cache cleanup are explicit so open
  pages retain their lazy chunks. Do not force activation or clear databases as
  a shortcut to a worker/contract mismatch.
- The application owns worker-usable authentication and account partitioning.
  Do not copy page-memory bearer tokens into generated files or persist them
  automatically. Logout first disables durable bootstrap and invalidates stale
  factory/auth generations, then stops cross-context owners. Optional cleanup
  or account switching requires write quiescence across worker/foreground
  owners and pending native transactions, or a proven durable generation fence.
  The existing `engine.close()` is not a write-drain barrier: native transactions
  may still finish. Delayed opens/reconciliation must not resurrect cleared
  data or enter the next account's replica. A request already committed by the
  authority is not undone by client logout.
- Browser storage may be denied, full, cleared or evicted. Preserve typed local
  errors and report missing bootstrap; persistence requests are optional app
  policy, not a promise of permanent device storage.

## Responsibility map

| Boundary | Owns |
| --- | --- |
| Page PWA coordinator | Local engine facade, worker wake/handshake, reconnect triggers, foreground fallback and observed capabilities |
| Worker host | Event lifetime, app factory invocation, bounded engine runs, run waiters and owned resource cleanup |
| Existing engine/replica/transport | Prepare/exchange/reconcile, durable receipts and queries, retry classification and protocol validation |
| Shell/cache helper | Explicit public asset install, navigation fallback, versioned owned-cache lifecycle and readiness |
| Vinext generator/build integration | Reviewable source wiring, install manifest, executable worker/shell assets and final asset graph |
| Application | Model, persistent identity/account bootstrap, authentication/logout, offline UI, branding, routes and update policy |
| Authority | Canonical decisions and atomic server commits, unchanged from the existing design |

Implemented subpaths are `/pwa/client`, `/pwa/worker`, `/pwa/cache`, `/pwa/registry`
and build-only `/integrations/vinext/pwa`. Strict JSON now accepts opt-in `pwa`
configuration; `syncEnginePwa` injects browser registration by default, while
manual mode leaves registration app-owned. Ordinary development does not register
the worker. Existing registrations using a different script at the same scope
cause a clear error rather than replacement. The implementation collects the
actual public client chunks/CSS/assets as well as the separate offline UI graph,
so older online tabs retain their lazy assets after deployment.

The first build integration rejects broader-than-worker-directory scopes and
cross-origin asset prefixes. Registry cleanup uses Web Locks and cooperating
owners; a lost notification or frozen owner can cause a bounded timeout, leaving
bootstrap disabled without deleting active data. `closeAndDrain()` waits for
native transactions on the owned connection. The app must retain the registry
lease until that wait finishes. Old build caches remain retained until the app
defines a safe cleanup policy.

## Alternatives considered

- **Worker transport proxy only:** leaves request preparation or response
  reconciliation dependent on a surviving page; does not satisfy W03.
- **Generic HTTP replay queue:** creates another durable delivery source and
  bypasses current protocol preparation/reconciliation semantics.
- **Worker-only client:** makes unsupported/failed worker startup block local
  use and foreground delivery; weakens existing guarantees.
- **Cache every response:** risks private/session data and stale protocol/RSC
  responses, and does not prove a complete offline asset graph.
- **Replace any existing worker:** takes ownership of application routing and
  cache/update policies; compose handlers instead.

## Consequences and verification

This is additive and opt-in. Existing 2.0 imports and foreground composition
keep working. No automatic data migration or protocol change is required by the
decision. Installation, offline startup and background synchronization have
separate capability/readiness states and separate browser evidence.

Delivery evidence is in the [implementation plan](../implementation-plan.md#5-offline-first-pwa-implemented).
The decisive fixture visits online, waits for offline readiness, closes all
tabs, disables the network, reopens a deep link, reads/edits local records,
loads a lazy screen, restarts again, and reconnects to reconcile with D1. Native
worker termination/lost-response tests and failed-install/old-tab update tests
exercise durability beyond a happy-path message exchange. Test reports must
distinguish actual browser-granted scheduling from synthetic event dispatch.

## Sources

- [Service Worker lifetime and registration](https://w3c.github.io/ServiceWorker/#service-worker-lifetime)
- [Background Sync specification](https://wicg.github.io/background-sync/spec/)
- [Offline resources and background operation](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Offline_and_background_operation)
- [PWA installability](https://developer.mozilla.org/en-US/docs/Web/Progressive_web_apps/Guides/Making_PWAs_installable)
- [Vinext rendering architecture](https://github.com/cloudflare/vinext#how-it-works)
- [Vite build manifests](https://vite.dev/guide/backend-integration.html)
- [Vite environment-specific plugin hooks](https://vite.dev/guide/api-environment-plugins.html)
