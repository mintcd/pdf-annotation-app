# ADR-0003: Runtime factories and Vinext endpoint generation

Status: Accepted

The initial exclusion of service workers/background synchronization is extended
by [ADR-0007](0007-offline-first-pwa-and-worker-execution.md), implemented in 2.2.
The runtime, application-composition and source-generation boundaries
in this decision remain in force; 2.0.0 still implements only the initial scope.

Date: 2026-10-16

Requirements: P01-P09, R01-R02, R04, R11, R15.

## Context

The package needs a simple client entrypoint and generated Vinext endpoints while
remaining usable with other frameworks and storage systems. Browser composition,
server composition, HTTP handling, and source generation have different lifetimes
and responsibilities. Their proposed names below describe an intended design;
their delivery status is tracked in the [implementation plan](../implementation-plan.md).

The legacy package demonstrates useful boundaries in
`sync-engine-legacy/src/client/client.ts`, `src/next/server.ts`, and
`src/cli/next/generate.ts`. Its generator also requires D1 schema discovery and
mixes framework configuration with storage selection. The rewrite should retain
thin generated routes while removing that dependency.

## Decision

### Runtime composition

`createSyncEngine` composes a `ReplicaStore`, a `SyncTransport`, and domain
reducers into the client facade. The resulting engine owns local-first write
ordering, synchronization scheduling, retries, subscriptions, and lifecycle.
It sends a proposal only after the local store durably commits it. Its local
success result means queued locally; authoritative acceptance arrives later.

`createSyncAuthority` composes an `AuthorityStore`, a `DecisionPolicy`, and the
shared `DomainModel` committed-operation reducer on the server. The policy decides
acceptance, rejection, or a canonical merged operation
against authoritative state. The authority coordinates the atomic commit of the
decision, canonical operation, and updated state. Neither the client factory nor
the generated endpoint chooses a merge policy.

`createSyncHandler` adapts an authority to a standard Fetch
`Request -> Promise<Response>` boundary. It enforces authentication and stream
authorization through application-supplied hooks, protocol and contract versions,
payload validation, and byte/count limits before invoking the authority. It maps
typed retryable operational failures separately from permanent proposal decisions
and returns responses with `Cache-Control: no-store`. An authentication failure must
not become a permanent domain rejection.

The application owns request-scoped identity, authorization, and binding
resolution. The handler passes trusted context into authority construction;
browser-supplied stream IDs never confer access. On Vinext Workers deployments,
the application server module can resolve bindings using `cloudflare:workers`,
as recommended by the [Vinext project](https://github.com/cloudflare/vinext).
Core modules do not import a framework or environment singleton.

### Build-time generation

A CLI `VinextGenerator` renders files at build or development setup time. It
does not run inside `createSyncEngine`, provision storage, or execute decisions.
The implemented interface uses strict JSON configuration, a pure planner and a
separate Node writer; [ADR-0006](0006-safe-vinext-generation.md) records its
ownership and recovery decisions. See the [generator API](../vinext-generation.md).
The default is one combined synchronization endpoint:

```text
app/api/sync/route.ts     generated POST wrapper
sync/server.ts          application-owned server composition
sync/client.generated.ts generated public configuration
```

The route imports the application server module and delegates `POST(request)` to
its handler. Vinext supports App Router `route.ts` files with named HTTP method
exports; see the [Vinext documentation](https://github.com/cloudflare/vinext).
Split push/pull endpoints remain an optional later integration.

The generated client module contains an explicit allowlist of browser-safe data:
the endpoint and public contract version. It contains no server imports, binding
identifiers, credentials, or secrets. The schema/domain contract is authored
explicitly; optional adapter-specific discovery is a separate tool. D1 is never
a prerequisite for generating routes or creating a client.

Generation is deterministic. A manifest records owned paths and content hashes.
Generation refuses to overwrite handwritten files or generated files edited
since the previous manifest. Dry-run reports planned changes; check mode fails
on drift without writing. Updating generated output and its manifest must not
leave a misleading ownership record after a failed run.

## Consequences and validation

Client, authority, transport, and framework dependencies stay independently
replaceable. Consumers provide a small server composition module and retain
control of authentication and deployment bindings. The first milestone excludes
service workers and background synchronization.

Validation covers browser/server import separation, authorization and protocol
failure paths, bounded bodies, deterministic generation, ownership protection,
and drift detection. A fixture pinned to a specific Vinext version must verify
the generated route in local development and a production build; generic Fetch
handler tests alone do not establish framework compatibility.
