# ADR-0008: Vinext package and schema-driven client

Status: Accepted

Date: 2026-10-16. Updated: 2026-10-18.

Delivery status: implemented in core 2.2.0 and `@mintcd/sync-engine-vinext` 1.0.0.
Explicit D1 schema discovery is included; existing-data adoption remains
proposed. See the [setup and API guide](../vinext-package.md).

Requirements: [V01-V12](../requirements/vinext-package.md). Extends
[ADR-0003](0003-runtime-factories-and-vinext-generation.md),
[ADR-0006](0006-safe-vinext-generation.md) and
[ADR-0007](0007-offline-first-pwa-and-worker-execution.md).

## Context

The existing Vinext generator emits a thin route, public endpoint configuration,
and optional PWA entry points. Applications still compose their domain model,
IndexedDB replica, HTTP transport, worker sessions and D1 authority themselves.
Ordinary collection CRUD repeats codecs, intent declarations, previews and
canonical application code. The user wants Wrangler configuration and one sync
TypeScript or JSON configuration to produce this wiring, with IDE suggestions for collections,
selected fields, predicates and mutations.

Wrangler declares infrastructure bindings. It does not describe the complete
logical data model, security rules or conflict policy. These remain separate
inputs even when generation reduces the amount of application code.

## Decision

### 1. Add a dedicated Vinext package around the portable engine

Create `@mintcd/sync-engine-vinext`, depending on `@mintcd/sync-engine`.
The core owns the schema-driven CRUD model and typed collection facade, so they
remain usable by clients outside Vinext. The dedicated package owns Vinext
generation, a Vite plugin and page/worker/server composition helpers.

Separate browser, service-worker, server and Node build exports. Browser imports
must not pull in Node, Vite, Wrangler configuration, D1 bindings or server hooks.
The Vite plugin generates source before route discovery and composes the
existing PWA build/registration plugin when PWA configuration is present.

### 2. Generate from an explicit logical contract

The sync configuration declares application identity, contract/schema
versions, collections, field types, primary keys, secondary indexes, endpoint,
Wrangler file/binding/environment and optional PWA configuration. The initial
CRUD declarations support string, number and boolean fields, optional/null
values and scalar enums. Index and primary-key fields follow the portable
record-key constraints. Recommend `sync-engine.config.ts` with a default-exported
`defineSyncConfig({...})` from the package's `/config` entry for configuration
completion and literal type inference. Plain JSON/JSONC remains supported.

TypeScript configuration and imported helper modules execute as trusted
build-time code through Vite's config loader; they are never loaded in the
browser or worker. JSON remains unevaluated data. Default discovery accepts a
single TS or JSON config; when both exist, require an explicit selection.
The Vite plugin tracks the resolved configuration and imported dependencies;
the CLI defaults to build/production mode. Generated output retains the literal
schema independently of the authored format.

The generator embeds the validated definition as a TypeScript `as const`
literal. `defineCrudModel()` derives runtime validation, CRUD intents, previews,
canonical application and collection metadata from that definition. The
generated hook retains this literal type through its returned engine;
it must not widen collection names, fields or selected results to generic
string-keyed records.

The engine exposes local reads such as
`engine.from("notes").select("id", "title").where("folderId", "eq", id)`.
Queries execute against the local visible materialization, including optimistic
changes, with declared index intervals and bounded pages. Column selection
projects decoded results; it does not promise storage-level column reads.
Unsupported predicates fail explicitly rather than starting an unbounded scan.
Collection CRUD methods enqueue durable intents through the existing protocol.
Their receipts describe local persistence, with authority decisions observed
through synchronization and resolution APIs.

### 3. Generate composition while preserving application decisions

The generated source set includes:

| Output | Responsibility |
| --- | --- |
| `sync/generated.ts` | Literal public schema/runtime and a single named export, typed `useSyncEngine` |
| App Router `route.ts` | Literal model, binding lookup, HTTP handler and package D1 authority composition |
| Initial SQL migration | Sync metadata, collection tables and indexes |
| Application-owned server hook scaffold | Authentication, stream authorization and policy customization |

Keep engine creation, subscriptions and cleanup in the package's `/react`
helper. The hook accepts a stable generated config or `null`, opens after
hydration, shares an engine between consumers and closes it after the last
consumer leaves. It returns `{ engine, status, error, phase, logoutSync }`, with
logout bound to the configured replica. Browser-only offline entries can mount
the same components through React DOM. `createSyncConfig` is imported from the
package root or `/client` without loading React and supplies runtime session
options. Schema inference belongs to the generated hook. The separate
`defineSyncConfig` helper continues to describe the authored build-time schema.

Optional worker and registration entries are virtual build modules managed by
the PWA integration, so enabling PWA does not add generated source files. The
ownership manifest remains internal. Each execution target derives its model
from the same validated literal; browser and worker modules never import the
authored configuration. Runtime D1 mapping belongs to the server package.

The package's common session helper owns IndexedDB opening, stable replica
identity, registry leases and draining cleanup for page and worker sessions.
Only an explicit authenticated bootstrap may initialize a replica. Recovery
opens existing state and reports missing storage rather than silently allocating
a replacement identity. Account/stream switches require logout first.

The generated route imports `env` from `cloudflare:workers` and composes an
authority backed by the configured D1 binding. A service worker remains a
client execution host; it does not become the authority. The server policy
accepts, rejects or transforms intents. The default CRUD policy applies field
patches to confirmed records, with conflicting same-field changes following
authority order. Applications can replace or wrap that policy.

The application-owned server hook exports `createPolicy(model)` and can import
the route's `SyncModel` and `Schema` types without a runtime route dependency.
It must authenticate the request, authorize its
stream and enforce the application's Origin/CSRF requirements. Its initial
scaffold fails closed until configured. An account identifier provided by a
browser is not proof of server identity. The generated transport uses same-origin
cookies; the package does not invent authentication or persist bearer tokens.

### 4. Keep infrastructure and migration changes explicit

Read `wrangler.jsonc` as configuration data without evaluating code. Select the
requested environment and require its own matching D1 binding. Never fall back
from an absent environment binding to a top-level database. Keep the Wrangler
file application-owned. Generate the initial SQL under that binding's migration
directory; do not apply it automatically.

Use the existing guarded plan executor for ownership, dry-run/check modes,
conflict handling, locks, interrupted-generation journals and rollback. Generated
sources use the existing ownership marker. Authentication scaffolds and initial
SQL migrations are create-once, application-owned files. A differing initial
migration blocks regeneration and requires an explicit schema-evolution plan;
generation must not rewrite potentially applied SQL or migrate browser state.

Cloudflare's generated runtime types describe `Env` and the D1 binding. The
literal sync contract supplies collection/row types. These are distinct type
generation responsibilities.

### 5. Keep explicit schema discovery separate from generation

The optional `discover` command inspects explicitly selected D1 tables using
supported metadata-reading SQLite PRAGMAs. It produces a local draft contract
with source table names, warnings and unresolved decisions for review. The
`discoverConfiguredD1()` Node API invokes the application's installed Wrangler
with an explicit binding, local/remote selection and optional environment. The
portable `discoverD1Schema()` API accepts an application-owned read-only query
port. Normal generation, development and production builds use the saved
contract; they do not silently contact remote D1. A direct SQL-export parser is
not implemented.

Require a table allowlist and an explicit local/remote environment selection.
System, authentication, migration and unrelated tables must not become browser
replicas merely because they were discovered. SQLite column affinity does not
identify logical UUIDs, dates, JSON, enums or boolean representations reliably;
logical overrides and unsupported-feature diagnostics are necessary.
Authorization, tenant boundaries, optimistic behavior and merge rules cannot be
inferred from database structure.

Schema discovery is separate from adopting existing data. The current D1
adapter requires its own `__sync_*` record representation, encoded indexes and
stream/history/decision metadata. Arbitrary existing SQL tables do not satisfy
that layout. Adoption needs a deliberate mapping and migration into a supported
sync layout, plus canonical import or a supported snapshot/bootstrap protocol
that makes existing records available to new clients. Seeding authority-only
sequence-zero rows does not deliver them to otherwise empty replicas.

## Consequences

Most CRUD applications author one logical contract, their authentication/policy
hooks, and their UI. The two generated source files expose the application's
route and typed client without exposing every composition step as a separate
module. Existing applications update old `client.generated` imports and convert
their preserved `policy` export into `createPolicy(model)` when regenerating.
Custom domain models and non-Vinext composition remain supported
by the portable core.

This milestone does not add automatic schema evolution, schema discovery during
build/runtime, arbitrary existing-table attachment, data import, joins,
full-text search or SQL predicate translation. Each requires its own explicit
contract.

## References

- [D1 schema inspection and supported PRAGMAs](https://developers.cloudflare.com/d1/sql-api/sql-statements/)
- [D1 SQL import and schema-only export](https://developers.cloudflare.com/d1/best-practices/import-export-data/)
- [Vinext Cloudflare bindings](https://vinext.dev/docs/deploying/cloudflare)
