# ADR-0010: Rebuild local replicas for each app deployment

Status: Accepted

Date: 2026-10-18.

Delivery status: implemented in the local Vinext package and registry source.

Requirements: [V13-V18](../requirements/vinext-package.md). Extends
[ADR-0008](0008-vinext-package-and-schema-driven-client.md) using the checkpoint
protocol in [ADR-0009](0009-materialized-authority-bootstrap.md).

## Context

An application may deploy new behavior without changing its declared sync
schema. Rebuilding only on schema/contract changes therefore does not implement
the requested policy: every app deployment should seed its local replica from
current D1 materialized data. The server's data and canonical history must stay
continuous, and an offline queue must not disappear when the frontend changes.

## Decision

Applications pass a unique public `deploymentVersion` through runtime
`createSyncConfig` options, fixed for one deployed asset set. An optional
build/runtime-config value is a fallback. Existing callers omitting the marker
retain their previous session behavior. Runtime injection avoids source
regeneration drift and separates app release identity from `appId`, database
namespaces and schema/contract versions.

A matching marker resumes the retained database/client identity with no network
bootstrap. The first versioned session or a changed marker fetches the generated
authenticated GET snapshot on the existing sync endpoint. Request validation and
the exact POST authentication/stream/Origin resolver precede D1 access. GET
responses and requests use no-store. A snapshot is a complete validated current
materialization at its real canonical sequence, bounded by rows and bytes.

The page builds a candidate replica in a separate database with a new client ID.
Only after install succeeds does the controller registry invalidate current
owners and wait for all cooperating page/worker leases to drain. Under the
exclusive barrier it reads retained local metadata and refuses automatic
replacement while pending or accepted-awaiting work exists. This check applies
to every retained-slot replacement, including a different account/stream after
logout; overwriting the only descriptor would otherwise orphan its offline
outbox. Sign back into the previous account/session to finish syncing before
switching. It then publishes
the candidate descriptor. New local client sequence allocation starts at 1;
ordinary incremental pulls begin at the imported watermark.

The pending barrier reads the retained adapter's versioned bookkeeping in a
readonly native IndexedDB transaction and validates its format, stream/schema
binding, old contract/client identity and queue counts. It never decodes old
rows through the new model. A settled old schema can be replaced after the
server's separately managed schema migration; a pending old schema stays blocked.

The registry's `replace` operation preserves the retained descriptor while it
is temporarily disabled. Failed preparation or lease acquisition restores that
descriptor with a new generation; invalid wait options fail before changing it.
Snapshot failures before replacement leave it untouched. A crash during
quiescence can leave the old descriptor disabled, and trusted initialization
retries using the retained store. The old database is never deleted by a
successful deployment rebuild. A failed candidate is removed after its owned
connections have drained. Explicit `freshStart` continues to express an
intentional reset; deployment code must not enable it automatically.

## Alternatives considered

- Rebuild only on schema/contract changes: does not meet the requested release policy.
- Change `appId` or D1 tables for every release: separates or hides authority data and history rather than rebuilding local state from them.
- Reset the current database/client sequence in place: can lose offline edits and reuse identities already known by the authority.
- Fetch rows without a consistent canonical watermark: can skip or duplicate later changes.
- Replay canonical history from zero on each release: adds release startup cost and ignores the existing materialized representation.
- Replace immediately and discard old queues: conflicts with durable local-first behavior.

## Consequences

A new deployment needs online authenticated bootstrap once per local replica;
repeat loads of that deployment retain offline access. Pending edits require
finishing the previous session's sync and retrying, or a separately authorized
reset. Automatic cross-schema pending-intent translation is deferred. Old stores
are retained for recovery and can accumulate until a separate explicit cleanup
policy is implemented. Server data/schema adoption, migrations and history
compaction remain independent capabilities.

Validation covers repeated rebuilds, matching-marker identity reuse, incremental
continuation, missing/untrusted snapshots, pending retention, lease invalidation,
registry rollback/options and native local D1 authentication/stream/Origin checks.
No remote deployment or physical-device behavior is claimed by these checks.
