# ADR-0006: Non-executing configuration and recoverable generation

Status: Accepted

Date: 2026-10-16

Requirements: P03-P06, P09; refines [ADR-0003](0003-runtime-factories-and-vinext-generation.md).

## Context

Generating a route needs a public contract identifier, output paths and a server
export name. It does not need an executing domain model, authentication module
or D1 schema connection. Loading TypeScript configuration would add a runtime
loader or depend on a newer Node version, and could execute server-only code
while deriving browser output.

Route and client output must also be updated together with truthful ownership
metadata. A failed multi-file write cannot safely pretend all new files were
committed, and an edited route must remain under application control.

## Decision

Use strict versioned JSON configuration, a pure deterministic planner, and a
separate Node filesystem writer/CLI. Explicitly choose `app` or `src/app`; emit
one static POST route and an allowlisted public configuration object. The route
delegates to an application-owned server handler. Optional scaffolding creates
that module once and returns 503 until the application composes authorization
and an authority. Scaffolds never become generated ownership.

Record only generated paths and content hashes in a deterministic manifest.
Refuse untracked or edited outputs, unsafe paths, and implicit changes between
generated and application-owned roles. Remove old generated paths only when
their original content is intact. Dry-run/check write nothing.

Serialize writers with a lock, stage backups and output, recheck observed files,
then rename outputs with the manifest last. Roll back ordinary failures. Preserve
a journal/backups and fail closed after interruption or failed restoration.
There is no force mode or automatic lock stealing/recovery.

Validate a pinned framework version using actual development and production
routes. Keep the test deployment scope explicit: the first fixture uses the
vinext Node server and real local D1 through a private test bridge. Browser module
and chunk checks enforce server/client separation. Cloudflare deployment remains
a separate application validation step.

## Consequences

Generation is independent of framework/database runtime packages. Public contract
metadata is authored explicitly and should be checked against the shared model.
JSON configuration cannot compute metadata from application code; that deliberate
boundary keeps server imports and credentials out of code generation.

Recoverable file replacement adds manifest, lock and journal state. It does not
provide one atomic filesystem snapshot to a concurrently running build; complete
generation before building. Interrupted recovery requires inspection rather than
guessing whether application edits may be overwritten.

The [generator API](../vinext-generation.md) documents commands, ownership,
recovery and the tested framework/toolchain versions.
