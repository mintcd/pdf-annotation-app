# ADR-0004: Materialized records and separate synchronization history

Status: Accepted

Date: 2026-10-16

Requirements: [Storage requirements](../requirements/storage.md).

## Context

The legacy IndexedDB adapter stores an entire stream, including all domain
tables, in one `replicas` record. A small edit reads and rewrites that record,
and application searches cannot use native indexes over individual rows.

The new core already applies new canonical operations to confirmed state
incrementally. However, its arbitrary `State` contract, complete snapshots,
history validation scans, and cloning still assume data fits in memory.
Splitting that snapshot across physical stores alone would preserve these costs.

## Decision

Add an explicit record/collection mode that persists current materialized rows
alongside separate normalized synchronization records: canonical entries,
accepted and rejected decision receipts, pending outbox entries, resolution
notices, and small stream metadata. Current rows serve searches and modifications;
the canonical log serves synchronization, validation, and replay. Ordinary queries
must not reconstruct the log or read a complete `ReplicaState`.

Use backend-native layouts:

- **IndexedDB:** per-collection confirmed and visible object stores, with one
  record per domain row and declared native indexes for visible queries. Confirmed
  rows contain canonical state; visible rows include pending previews. Commit
  metadata, protocol records, affected rows, and index changes in one transaction
  spanning the required stores.
- **D1:** ordinary relational application tables with explicit SQL indexes,
  alongside synchronization tables. Guard every part of an authority commit,
  including application changes and decision receipts, atomically with the store
  revision. Native tables do not permit writes outside the authority contract.
- **GitHub:** a future projection writes domain files and tracks a durable
  delivery cursor. GitHub does not become a query database or a participant in
  D1's transaction.

Declare collections, keys, and query indexes explicitly in the shared stream
contract; this does not add per-client selective replication. A generic JSON row store
can remain a fallback, but does not promise arbitrary indexed-query parity with
SQL or per-collection IndexedDB stores. Physical schema changes require explicit
migrations.

Preserve arbitrary `State` mode for small aggregates and the memory reference.
Before claiming record-scale performance, evolve the complete-snapshot ports and
algorithms into incremental transaction and query capabilities. These must account
for domain reads, row changes, and query read sets, rather than infer dependencies
from an operation's apparent target row. Record mode uses its own explicit ports;
it is not inferred from the aggregate `State` API. The record contracts and memory
reference are implemented in the [record API](../records-api.md). The
[IndexedDB adapter](../client-api.md) and [D1 adapter](../d1-api.md) implement the
native layouts. [ADR-0005](0005-d1-guarded-record-plans.md) defines the guarded SQL
plan and migration boundary.

Start with correctness: reconciliation updates confirmed rows and replays all
remaining pending work in client order to rebuild the visible result atomically.
Reset previous optimistic touched keys first, including effects of removed previews,
so rejected inserts/deletes cannot leave ghost state.
One intent may affect multiple rows or collections. Optimize replay only after
dependency and invalidation rules cover those reads and writes honestly.

A live materialization is maintained after each commit; a checkpoint is a
versioned recovery image at a known canonical sequence. Neither replaces the
decision ledger. Protocol v1 retains complete history and receipts. Compaction
requires a later snapshot-bootstrap and receipt-retention protocol, including
recovery for stale clients and outstanding downstream deliveries.

## Alternatives and consequences

Keeping only a log makes routine searches expensive. Keeping only current rows
loses incremental synchronization and durable retry outcomes. One giant snapshot
is useful for compact aggregates but unsuitable as the default record layout.

Maintained projections and indexes consume storage and increase atomic write
work. They provide direct native queries and bounded record changes without
replaying canonical history. Confirmed and visible rows remain distinct to support
rejection, transformed acceptance, and pending-overlay reconstruction.

This decision extends [ADR-0001](0001-role-based-composition.md) and
[ADR-0002](0002-authority-and-consistency.md); it does not replace their authority
or consistency contracts. See the [storage design](../storage-design.md) for the
physical layouts and delivery sequence.
