# ADR-0005: Guarded D1 record plans and explicit SQL mappings

Status: Accepted

Date: 2026-10-16

Requirements: R05-R08, R11, R13; S01-S03, S05, S07-S12.

## Context

The record coordinator uses asynchronous storage callbacks, but D1's binding
provides prepared statements and atomic batches. A JavaScript read followed by
independent writes cannot preserve that callback's revision. A conditional
update affecting zero rows does not itself abort later batch statements.

SQL queries also need a physical representation of portable typed tuple keys
and declared indexes. Storing all domain tables in one JSON value would restore
the legacy query/write costs.

## Decision

Use an authority-only D1 record database with explicit collection-to-table
mappings, codec-encoded individual rows, application-selected typed SQL columns,
and native indexes for declared portable queries. Ordered internal keys preserve
numeric, UTF-16 and tuple comparison rather than relying on JSON text ordering.

Read from the primary D1 binding and reject Sessions API objects. Read a storage
revision before planning and again after the callback. A changed revision rejects
the complete plan. For writes, begin one atomic batch with a `CHECK`-protected
revision assertion that fails on a stale plan, then apply all staged rows,
protocol records and a revision increment. Genesis uses an absent-stream
assertion. Rejection-only writes participate in the same revision protocol.

An authority retries a conflict by rerunning its pure policy against new data.
No branch falls back to sequential writes. Batch failure classification compares
the current primary revision instead of matching error message text. Preserve
unknown storage errors and their causes when the revision did not change.

Generate initial SQL for review and explicit deployment. Runtime opening validates
the layout binding and performs no DDL. Changed schemas require a separate
migration design; automatic upgrades, legacy import and compaction remain deferred.

The HTTP handler supplies a synchronous final-response validator to authority
coordination. Built-in authorities validate the exact bounded response before
commit, allowing byte/correlation failures to abort rather than retain an
unsendable decision. Custom authorities must honor that hook too.

## Alternatives and consequences

Guarding only the head would miss rejected-only races. Guarding only one SQL
update would let a zero-row match leave later writes unprotected. Replacing
the entire state/history would avoid neither query cost nor retry concerns.

Optimistic read plans may repeat work under contention, and separate reads
consume query budget. Staged changes and checked batch/read limits bound local
work. Protocol and application batch sizes must also fit the deployment's
platform limits. Raw domain writes outside the authority would bypass revision
validation and are outside the contract.

Typed application columns and portable sort indexes use additional storage but
provide native searches with defined ordering. This implements the D1 portion
of [ADR-0004](0004-materialized-records-and-sync-history.md); it does not change
the single-authority or retained-receipt decisions.
