# Record-oriented API

Implemented: collection/query contracts, transactional record storage, incremental
replica and authority coordination, an indexed memory reference, IndexedDB
persistence and `createSyncEngine`. See the [client API](client-api.md) for native
storage and lifecycle details. The [D1 API](d1-api.md) implements persistent
authority storage and the [HTTP API](http-api.md) connects the roles.

This API follows [ADR-0004](adr/0004-materialized-records-and-sync-history.md).
The existing [aggregate API](core-api.md) remains available for compact custom
state. Both use protocol v1 and the same identity/decision semantics.

Version 2.2 adds `defineCrudModel`, `createCrudPolicy` and `crudCollections` from
`/records`. Declare runtime fields, a primary-key tuple and named field indexes
once. String, finite number and boolean fields support enums, optional values
and nullability; primary keys require nonnullable required string/number fields.
Indexes use string/number fields and omit rows with missing/null indexed values.
The model derives codecs, typed insert/update/delete intents, optimistic
previews and canonical put/delete operations. Updates cannot change primary
keys and apply field patches against confirmed records. Duplicate inserts and
missing updates reject; deletes are idempotent. Same-field concurrent patches
follow authority order. Server policy can return validated custom rejection
codes/messages or transform canonical operations. Application authorization
remains required. See the [schema example and generated API](vinext-package.md).

## Public entrypoints

| Import | Exports |
| --- | --- |
| `@mintcd/sync-engine/records` | `defineRecordSchema`, key/schema helpers, `loadDeclaredRecordView`, `openRecordReplica`, `exportRecordBootstrap`, `installRecordBootstrap`, and record types |
| `@mintcd/sync-engine/server` | `createRecordSyncAuthority`, alongside the aggregate authority |
| `@mintcd/sync-engine/adapters/memory` | `createMemoryRecordDatabase`, `createMemoryRecordReplica`, alongside aggregate stores |
| `@mintcd/sync-engine/adapters/indexeddb` | `openIndexedDbRecordDatabase` |
| `@mintcd/sync-engine/client` | `createSyncEngine`, `SyncTransportError`, and client types |
| `@mintcd/sync-engine/adapters/d1` | `createD1RecordMigration`, `openD1RecordDatabase`, and typed SQL mappings |

Record mode does not return a complete `ReplicaState` for ordinary operations.
Status, domain records, indexed pages, resolution pages, and commit summaries
are separate reads. Protocol history is retained in independently keyed records.

## Collections, keys, and queries

Declare collections with row codecs, primary-key extractors, and named indexes:

```ts
const schema = defineRecordSchema({
  version: "notes/1",
  collections: {
    notes: {
      codec: noteCodec,
      key: (note: Note) => [note.id],
      indexes: {
        byStatusUpdated: { key: (note: Note) => [note.status, note.updatedAt] },
      },
    },
  },
});
```

Collection names, row types, and query index names are inferred in TypeScript.
Codecs follow the stable-normalization and clone-safe requirements of the core.
Definitions and callbacks must remain deterministic for the database lifetime.
Bump the schema version when key/index/codec semantics change. Stored binding
checks include version and collection/index names; function source is not hashed
and semantic changes cannot be inferred automatically.

Keys are nonempty tuples of at most 32 finite numbers/strings. Numbers sort before
strings; tuples compare lexicographically, then by length. Strings use JavaScript
UTF-16 order. Encode booleans/null/date or application-specific collation explicitly
in the extractor when needed. Identity encoding preserves number/string and tuple
boundaries; numerical ordering does not use serialized JSON strings.

Indexes are nonunique in this increment. An extractor returning `undefined` omits
that row from that index. Index order automatically uses the primary key as a
deterministic tie-breaker. Secondary uniqueness, full-text search, multi-entry
indexes, and arbitrary predicates are not silently emulated.

```ts
const page = await replica.query({
  collection: "notes",
  index: "byStatusUpdated",
  prefix: ["open"],
  direction: "desc",
  limit: 20,
});
const next = page.nextCursor
  ? await replica.query({
      collection: "notes", index: "byStatusUpdated", prefix: ["open"],
      direction: "desc", limit: 20, cursor: page.nextCursor,
    })
  : undefined;
```

Omit `index` to traverse primary keys. Prefixes match complete tuple components;
`["open"]` is a status equality prefix, not text substring search. `lower`/`upper`
accept `{ key, inclusive? }` over index tuples; inclusive defaults to true. Each
page is bounded to 1–256 rows and carries its revision plus consistent sync status.

Cursors bind stream, schema, area, collection, index, direction, prefix and bounds,
and contain the last full index key/primary key. Page size may change on resume.
Pagination is live across revisions; edits may change later membership. Restart
on revision change when a caller needs a stable traversal. A cursor does not
promise an immutable cross-request snapshot.

## Declared domain reads and staged writes

`RecordDomainModel` supplies schema, payload codecs, `intentReads`,
`operationReads`, `applyCommitted`, `previewIntent`, and `previewOperation`.
Read declarations are synchronous arrays of:

```ts
{ type: "get", collection: "notes", key: [id] }
{ type: "query", name: "openNotes", query: {
  collection: "notes", index: "byStatusUpdated", prefix: ["open"], limit: 20,
} }
```

The coordinator prefetches only those keys/pages at one transaction revision.
A pure policy reads `view.get(collection, key)` or
`view.query(name, collection)`. The policy view has no mutation methods.
Canonical/preview interpreters additionally stage `view.put(collection, row)` and
`view.delete(collection, key)`. A write target must have been declared as a key,
including an explicitly missing key, or returned in a declared query page.
Undeclared access fails rather than fetching more data implicitly.

Key reads see an interpreter's own staged writes. Named query results stay fixed
to the prefetched page for that operation; they are not recomputed after staged
writes. They authorize only returned records, not every possible match outside
the page. A later operation receives a fresh declared view, including preceding
staged canonical operations in the same transaction.

Callbacks perform no I/O, return synchronously, and retain no live storage handle.
An async policy/canonical interpreter aborts its transaction. Async or failing
domain previews are unavailable and their staged rows are discarded. Storage read
or write failures abort the complete transaction rather than being treated as
domain preview conflicts. A multi-row operation therefore cannot partially apply.

## Composition and lifecycle

### Materialized authority bootstrap

`exportRecordBootstrap({ database, model, limits?, maximumReadAttempts? })`
captures every confirmed materialized row and the real canonical head in one
consistent readonly transaction. The authority metadata must already be
initialized, normally by its first synchronization request. Optimistic adapter
conflicts retry the entire read up to eight times by default. The result is a
version-1 `RecordBootstrapSnapshot` containing stream ID, contract/schema
versions, schema identity, `watermark`, `rowCount`, encoded `rows` and `checksum`.

`installRecordBootstrap({ database, clientId, model, snapshot, limits? })`
validates the full envelope, checksum and collection codecs before installing
it into a fresh empty replica database. It atomically writes confirmed and
visible rows plus metadata with confirmed/head sequence equal to the watermark,
next client sequence 1, and zero work counters. The supplied client ID must be
fresh. Any existing row, metadata or protocol record rejects installation.

```ts
// Server: authenticate/authorize this stream before exporting its current state.
const snapshot = await exportRecordBootstrap({ database: authorityDatabase, model });

// Client: create an empty database, without initialRows or existing replica metadata.
await installRecordBootstrap({ database: freshDatabase, clientId: freshClientId, model, snapshot });
const replica = await openRecordReplica({
  database: freshDatabase, clientId: freshClientId, model, requireExisting: true,
});
// The next request starts at snapshot.watermark, without replaying prior history.
```

Both helpers accept `{ maximumRows, maximumBytes }` limits, defaulting to 10,000
rows and 8 MiB of canonical UTF-8 JSON for the complete envelope. Export traverses
pages of at most 256 rows within the transaction; exceeding a total budget
rejects. Install rejects wrong stream/schema/contract, incomplete or changed
contents, invalid rows, undeclared collections and duplicate primary keys.

No canonical operations or receipts are synthesized, and authority history is
retained. The replica rejects canonical pages preceding its bootstrap watermark.
The checksum detects corruption and does not authenticate the sender. The
application owns secure transport, authorization, deployment detection, pending
work handling and replacement of live replicas. Existing `initialRows` remain
shared sequence-zero genesis data. This API does not migrate arbitrary SQL
tables, compact history, or import over a live replica. See
[bootstrap requirements](requirements/bootstrap.md),
[ADR-0009](adr/0009-materialized-authority-bootstrap.md) and the
[Vinext package guide](vinext-package.md).

Version 2.2 supports `requireExisting: true` in `openRecordReplica` recovery
options. Missing replica metadata then fails instead of creating a fresh client
sequence. Use it with the IndexedDB adapter's corresponding recovery option
after explicit initial bootstrap; see the [PWA API](pwa-api.md).

```ts
const clientDatabase = createMemoryRecordDatabase({ streamId, schema, initialRows });
const replica = await openRecordReplica({ database: clientDatabase, clientId, model });
const serverDatabase = createMemoryRecordDatabase({ streamId, schema, initialRows });
const authority = createRecordSyncAuthority({ database: serverDatabase, model, policy });

await replica.enqueue({ operationId, intent });
const response = await authority.synchronize(await replica.prepareSyncRequest(), context);
const commit = await replica.reconcile(response);
const note = await replica.get("notes", [id]);
```

`createMemoryRecordReplica` is a convenience factory that creates its own memory
database and opens a replica. The explicit database form is useful for shared
handles, metrics, and adapter substitution. See the runnable
[record example](../examples/memory-records.mjs): `npm run build`, then
`node examples/memory-records.mjs`.

A database instance is scoped to one stream and one role. Replicas and authorities
need separate instances; attempting to bind both roles fails. Multiple handles
for the same replica/client may share one database. Opening binds client identity,
model contract, and schema. Shared `initialRows` define genesis at sequence zero;
they are not a snapshot/bootstrap or migration facility.

Replica methods are `status`, `get`, `query`, `enqueue`, `prepareSyncRequest`,
`reconcile`, `readResolutions`, `acknowledgeResolutions`, and `close`.
Status reports revision/cursors, allocation, pending/accepted-awaiting counts and
notice count. Reconcile returns status, conservative affected record keys, and
remaining preview outcomes. It does not dump history or all domain records.

Resolution pages use `{ after?, limit? }`, bounded by the configured proposal
limit, and return `nextAfter` when more notices remain. Ordering is lexical by
operation ID. Like domain pages, these are live reads. Acknowledgement deletes
only UI notices, leaving decisions/identity protection intact. Close prevents new
operations and a hashing enqueue from committing after closure; it does not
destroy the shared database. An already-running storage transaction can finish.

## Atomic storage boundary

`RecordDatabase.transaction(mode, callback, { expectedRevision? })` provides a
consistent revision and atomic staged row/internal changes, returning
`{ revision, value }`. A stale expected revision raises typed `commit-conflict`.
The memory implementation serializes transactions, including storage awaits;
native adapters must provide the same guarantees through native transactions or
guarded plans. Coordinators await only storage requests inside a transaction.
Network access, hashing, unrelated waits and nested transactions are outside this
contract. Do not call the database recursively from its transaction callback.

`tx.get`, `tx.query`, and `tx.apply` address confirmed/visible collection records.
Each `apply` validates its entire write set before staging any of it. Aborting
the outer transaction rolls back rows, indexes and protocol records together.
Internal keyed tables hold metadata, canonical entries, identity/client-position
bindings, decisions, accepted-sequence bindings, outbox/pending indexes and notices.
This low-level interface belongs to adapters/coordinators; application edits go
through replica/authority composition to preserve sync invariants.

The memory adapter uses ordered tree indexes and per-key write overlays. It
does not clone all rows or history at transaction start. Point writes maintain
only affected index entries; bounded scans seek their range. Row values are
normalized before staging, and unchanged rows/missing deletes are not rewritten.
`metrics()`/`resetMetrics()` expose row reads/writes and visited domain/protocol
index entries for regression checks. They are counters, not a native-database
benchmark or a measurement of payload bytes.

Canonical history is never scanned to make a normal edit. Reconciliation checks
exact identity/sequence bindings, applies the bounded incoming page, then resets
old optimistic touched keys and replays all remaining pending work in client
order. That pending work remains an explicit cost; selective dependency-based
replay is not implemented. Metadata and all changes commit once; accepted and
rejected receipts retain the original outcome across retries.

Authority initialization binds its model/schema on the first successful exchange;
replica binding happens on open. That initial metadata write advances revision.
Later known-only/pull authority exchanges do not advance revision. A temporary
typed storage conflict retries the full pure authority plan, defaulting to eight
attempts. Full-envelope validation happens before retaining new work.

The memory adapter retains data for the database object's lifetime. The
[IndexedDB adapter](client-api.md) adds browser persistence, native indexes and
cross-connection invalidation. Browser data/index migrations, checkpoint
bootstrap and history compaction remain deferred.

## Verification

Storage tests cover key/index ordering, staged queries, pagination under edits,
atomic aborts, stale revisions, isolated values and undeclared access. Seeded
index schedules compare against independently filtered/sorted row data.
Replica/authority tests cover ghost inserts/deletes, future transformed acceptance,
failed multi-collection previews, receipt divergence, concurrency and failure
boundaries. A 1,200-operation replica history test shows a normal edit writes one
materialized row with no history scan.

Eight paired loss/duplicate/delay schedules compare record requests/responses,
confirmed/visible rows, preview outcomes, counts and receipts against the existing
aggregate reference. Successful exchanges converge, and late responses do not
recreate acknowledged notices. Consumer type checks exercise the new public
subpath, inferred row/index types and policy context.
