# Implemented portable API

Stage 1, implemented on 2026-10-16. The full target remains in the
[architecture](architecture.md). The reference runs without a browser or
framework; [client coordination and IndexedDB](client-api.md) are now implemented
as a separate record-based capability.

The [record API](records-api.md) implements a separate record/query capability and
indexed memory reference. The aggregate snapshot APIs below still scan/clone
whole state/history; large collections use the record path. The
[storage design](storage-design.md) describes native layouts and remaining work.

## Entrypoints

| Import | Runtime exports |
| --- | --- |
| `@mintcd/sync-engine` | `SyncError`, `canonicalizeJson`, `createIntentHash`, request/response codecs, protocol limits, and pure replica transitions |
| `@mintcd/sync-engine/server` | `createSyncAuthority` |
| `@mintcd/sync-engine/adapters/memory` | `createMemoryReplicaStore`, `createMemoryAuthorityStore` |

Core exports the types for domain models, policies, proposals, decisions, replica
state, store ports, and transports. It does not re-export adapter or server
implementations. Imports have no initialization side effects.

## Domain contract

`DomainModel<State, Intent, Operation, Rejection>` supplies a `contractVersion`,
three payload codecs (`intent`, `operation`, `rejection`), deterministic
`applyCommitted`, and total `previewIntent`/`previewOperation` functions. Preview
returns `{ status: "applied", state }` or `{ status: "unavailable", reason }`.
Unavailable or throwing previews retain the work and do not stop canonical
reconciliation. An invalid committed reducer can still fail the transition;
reducers must handle valid canonical operations against canonical predecessor state.

Each codec exposes `encode(domainValue): JsonValue` and `decode(unknown): Value`.
One normalization is allowed, such as trimming a string. Once decoded, repeated
encode/decode roundtrips must preserve the canonical JSON encoding. The runtime
rejects detectable drift before committing: a decoder that increments a number
on every invocation is not a valid codec. Functions must be deterministic and
must not mutate inputs or perform external side effects.

State and domain values must retain their meaning under `structuredClone`.
Use clone-safe data; custom class prototypes/functions are unsuitable snapshot
values. A codec can still expose a supported richer representation such as `Date`
while encoding it as JSON. The app must configure compatible models, codecs, and
initial state for every participant in a stream.

`DecisionPolicy(state, proposal, context)` returns either
`{ status: "accepted", operation }` or `{ status: "rejected", reason }`.
It sees current authority state, including preceding accepted operations in the
same request. A commit conflict can invoke it again. Context is trusted explicit
application input; this layer does not authenticate it.

## Reference composition

```ts
import { createMemoryAuthorityStore, createMemoryReplicaStore } from "@mintcd/sync-engine/adapters/memory";
import { createSyncAuthority } from "@mintcd/sync-engine/server";

// model, policy, and initialState are application-owned.
const store = createMemoryAuthorityStore({
  streamId, initialState, operation: model.operation, rejection: model.rejection,
});
const authority = createSyncAuthority({ store, model, policy });
const replica = createMemoryReplicaStore({ streamId, clientId, initialState, model });

const localReceipt = await replica.enqueue({ operationId, intent });
const request = await replica.prepareSyncRequest({ maximumProposals: 32, maximumEntries: 128 });
const response = await authority.synchronize(request, undefined);
await replica.reconcile(response);
const snapshot = await replica.read();
```

Pass policy context instead of `undefined` when the policy requires it. This
explicit exchange is the aggregate executable reference. The [client API](client-api.md)
adds `createSyncEngine` and automatic scheduling over record replicas. Run the self-contained
[counter example](../examples/memory-counter.mjs) with
`node examples/memory-counter.mjs` after `npm run build`.

Both authority factories also accept an optional third synchronization argument:

```ts
await authority.synchronize(request, context, {
  validateResponse(response) { /* synchronous, pure precommit validation */ },
});
```

The hook receives an isolated, validated final response before any new decision
commits. Throwing aborts the plan; returning a promise is an error. Conflict
retries can invoke it again. Pull-only and known-decision responses also run the
hook. The [HTTP handler](http-api.md) uses it to enforce response-byte and
request/response correlation limits before retaining work. The returned response
is the same coherent bounded page validated before commit; concurrent later
commits are downloaded on another exchange.

The replica methods are `read`, `enqueue`, `prepareSyncRequest`, `reconcile`,
`readResolutions`, `acknowledgeResolutions`, and `close`. Enqueue returns a local
identity receipt and allocates monotonically increasing client order. An ID is
single-use for enqueue; network retries reuse prepared proposals, rather than
enqueueing again. Concurrent enqueue/hash/reconcile calls preserve the latest
store state. Close stops further operations and prevents an awaiting enqueue
from committing.

Snapshots contain confirmed state/sequence, observed head, visible state, outbox,
per-operation preview outcomes, retained log/decisions, and resolution notices.
Acknowledgement removes UI notices only. Accepted decisions beyond the current
canonical page remain in the outbox with their canonical preview; missing preview
prerequisites produce an unavailable outcome until history catches up.

Memory stores return detached values and atomically stage changes within one
JavaScript process. They retain everything for their lifetime; closing or replacing
one does not provide restart persistence. Do not treat them as the durable adapter.

## Store and pure-transition contracts

The memory implementations are a reference for later native stores:

- `ReplicaStore` atomically enqueues and reconciles against the latest state.
  Hashing and full request validation happen before the local commit. It keeps
  accepted/rejected resolutions separately from retained validation history.
- `AuthorityStore` is scoped to `streamId`. `read` returns a consistent state,
  revision, head, bounded canonical page, and decisions matching requested
  operation IDs **or** client positions. Both lookups are necessary to detect
  identity reuse. `compareAndCommit` validates the complete plan before replacing
  state and binding decisions/log entries. A stale revision changes nothing.
  Rejected-only commits advance revision; log head is not the revision.

`createSyncAuthority` defaults to eight guarded commit attempts. It checks payload
fingerprints, reuses permanent decisions, calls policy for new proposals, validates
response sendability before commit, and returns one consistent canonical page.
Reads may return shorter pages, but must make progress when entries remain.
No-op/pull or known-only requests do not advance the store revision.

The pure exports are `createReplicaState`, `enqueueReplicaOperation`,
`prepareSyncRequest`, `reconcileSyncResponse`, and `acknowledgeResolutions`.
Pure enqueue accepts a precomputed `intentHash`; callers must hash the normalized
intent codec representation before entering their native transaction. Pure request
preparation permits `maximumProposals: 0` for pull-only work. Pure functions return
detached next state without mutating prior state. Durable implementations must
persist that state atomically before reporting success.

## Protocol v1 representation

Both messages use a flat envelope. A request contains exactly:

```ts
{
  protocolVersion: 1,
  contractVersion: "notes/v1",
  streamId: "account/example",
  baseSequence: 0,
  maximumEntries: 128,
  proposals: [/* operationId, clientId, clientSequence, intentHash, intent */],
}
```

A response contains exactly:

```ts
{
  protocolVersion: 1,
  contractVersion: "notes/v1",
  streamId: "account/example",
  requestedBaseSequence: 0,
  throughSequence: 1,
  headSequence: 4,
  entries: [/* identity fields, sequence, operation */],
  decisions: [/* identity fields plus accepted(sequence, operation) or rejected(reason) */],
}
```

`entries` covers exactly `requestedBaseSequence + 1` through `throughSequence`.
An accepted decision can refer to a sequence beyond that page, but never beyond
`headSequence`. Rejected decisions carry neither canonical sequence nor operation.
Unknown fields, duplicate identities/client positions within either array, unsafe
numbers, gaps, unsupported versions, and invalid payloads fail validation. Replica
reconciliation also checks cross-array contradictions and retained history.

`encodeSyncRequest`/`encodeSyncResponse` return JSON text. Decoders accept JSON text
or a parsed wire object. All receive the domain model and optional
`{ streamId, limits }`. Typed in-process requests/responses pass the same boundary.
The default count limits are 64 proposals/decisions and 256 entries; page size is
positive and bounded by the configured entry limit. Storage history is retained;
these limits bound exchange work, not total history size.

`createIntentHash(model.intent.encode(normalizedIntent))` produces
`sha256:<64 lowercase hexadecimal digits>` using Web Crypto and UTF-8. The hash
input is a package-defined canonical JSON encoding with lexically sorted keys,
JSON scalar spelling, and array order preserved. Objects must be plain/null
prototype records with enumerable data properties. Arrays must be ordinary and
dense. Cycles, accessors, extra array properties, symbols, hidden properties,
classes, non-finite numbers, and non-JSON values are rejected.

Canonical traversal has a protective nesting ceiling of 256. Envelope wrappers
also count toward it; a standalone hash fitting that ceiling does not guarantee
sendability. Store/authority preflight verifies complete message representability
before committing new work. The [HTTP API](http-api.md) adds streaming body byte limits.

## Errors and validation

`SyncError` exposes `code` and `retryable`; only `commit-conflict` is retryable in
this increment. Other codes distinguish invalid input, limits, unsupported
protocol, contract/stream mismatch, invalid cursor, identity conflict, divergence,
corrupt state, and closed stores. Application callback bugs can still throw their
own errors. The [HTTP transport](http-api.md) adds structured network, timeout,
access, rate-limit and malformed-response classification.

`npm run check` covers source typing, a consumer fixture importing package subpaths,
runtime codec/fingerprint cases, authority CAS and identity cases, replica overlays
and concurrency, and 12 seeded loss/duplicate/delay schedules. The note fixture
demonstrates current-state conflicts and transformed acceptance. Persistent crash
recovery and real browser transaction behavior remain stage-2 validation work.
