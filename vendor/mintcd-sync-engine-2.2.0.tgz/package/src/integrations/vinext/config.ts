import { SyncError } from "../../core/errors.js";
import { assertIdentifier } from "../../core/validation.js";
import type { VinextGeneratorConfig, VinextPwaConfig, VinextPwaIcon, VinextPwaManifest } from "./types.js";

const fields = new Set([
  "version", "contractVersion", "appDirectory", "endpoint", "serverModule", "serverExport", "clientModule", "scaffoldServer", "pwa",
]);

const reservedIdentifiers = new Set([
  "arguments", "await", "break", "case", "catch", "class", "const", "continue", "debugger", "default", "delete", "do", "else",
  "enum", "eval", "export", "extends", "false", "finally", "for", "function", "if", "implements", "import", "in", "instanceof",
  "interface", "let", "new", "null", "package", "private", "protected", "public", "return", "static", "super", "switch", "this",
  "throw", "true", "try", "typeof", "var", "void", "while", "with", "yield",
]);

/** No environment lookup, module execution, or filesystem access occurs here. */
export function parseVinextGeneratorConfig(value: unknown): VinextGeneratorConfig {
  if (value === null || typeof value !== "object" || Array.isArray(value)) invalid("Expected a Vinext generator configuration object.");
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) invalid("The Vinext generator configuration must be a plain object.");
  const config: Record<string, unknown> = {};
  for (const key of Reflect.ownKeys(value)) {
    if (typeof key !== "string" || !fields.has(key)) invalid("The Vinext generator configuration contains an unsupported field.");
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (descriptor === undefined || !descriptor.enumerable || !("value" in descriptor)) invalid("The Vinext generator configuration must contain ordinary JSON fields.");
    config[key] = descriptor.value;
  }
  if (config.version !== 1) throw new SyncError("unsupported-version", "The Vinext generator configuration version must be 1.");
  assertIdentifier(config.contractVersion, "contractVersion");
  const appDirectory = "appDirectory" in config ? config.appDirectory : "app";
  if (appDirectory !== "app" && appDirectory !== "src/app") invalid("appDirectory must be app or src/app.");
  const endpoint = "endpoint" in config ? config.endpoint : "/api/sync";
  validateEndpoint(endpoint);
  const serverModule = "serverModule" in config ? config.serverModule : "sync/server.ts";
  validateModulePath(serverModule, "serverModule");
  const clientModule = "clientModule" in config ? config.clientModule : "sync/client.generated.ts";
  validateModulePath(clientModule, "clientModule");
  const serverExport = "serverExport" in config ? config.serverExport : "handleSync";
  if (typeof serverExport !== "string" || serverExport.length > 128 || !/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(serverExport) || reservedIdentifiers.has(serverExport)) {
    invalid("serverExport must be a non-reserved JavaScript identifier.");
  }
  const scaffoldServer = "scaffoldServer" in config ? config.scaffoldServer : false;
  if (typeof scaffoldServer !== "boolean") invalid("scaffoldServer must be a boolean.");
  const pwa = "pwa" in config ? parsePwa(config.pwa) : undefined;

  // Case folding also protects applications generated on case-insensitive filesystems.
  const paths = [`${appDirectory}${endpoint}/route.ts`, serverModule, clientModule,
    ...(pwa ? [pwa.workerModule, pwa.offlineEntry, "sync/worker.generated.ts", "sync/register.generated.ts"] : []),
  ].map(path => path.toLowerCase());
  if (new Set(paths).size !== paths.length) invalid("The route, server module, and client module must have different paths.");

  return Object.freeze({
    version: 1,
    contractVersion: config.contractVersion,
    appDirectory,
    endpoint,
    serverModule,
    serverExport,
    clientModule,
    scaffoldServer,
    ...(pwa === undefined ? {} : { pwa }),
  });
}

function jsonObject(value: unknown, allowed: readonly string[], label: string): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)
    || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) invalid(`${label} must be a plain JSON object.`);
  const result: Record<string, unknown> = {};
  for (const key of Reflect.ownKeys(value)) {
    if (typeof key !== "string" || !allowed.includes(key)) invalid(`${label} contains an unsupported field.`);
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor?.enumerable || !("value" in descriptor)) invalid(`${label} must contain ordinary JSON fields.`);
    result[key] = descriptor.value;
  }
  return result;
}

function parsePwa(value: unknown): VinextPwaConfig {
  const input = jsonObject(value, ["appId", "workerModule", "offlineEntry", "workerPath", "shellPath", "manifestPath", "scope", "navigationPaths", "publicAssets", "manifest"], "pwa");
  if (typeof input.appId !== "string" || !/^[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}$/.test(input.appId)) invalid("pwa.appId must be a portable identifier of at most 64 characters.");
  validateModulePath(input.workerModule, "pwa.workerModule");
  if (typeof input.offlineEntry !== "string") invalid("pwa.offlineEntry must be an application-relative .ts or .tsx path.");
  validateModulePath(input.offlineEntry.endsWith(".tsx") ? input.offlineEntry.slice(0, -1) : input.offlineEntry, "pwa.offlineEntry");
  const scope = "scope" in input ? input.scope : "/";
  publicPath(scope, "pwa.scope", true);
  const workerPath = "workerPath" in input ? input.workerPath : `${scope}sync-worker.js`;
  const shellPath = "shellPath" in input ? input.shellPath : `${scope}sync-offline.html`;
  const manifestPath = "manifestPath" in input ? input.manifestPath : `${scope}manifest.webmanifest`;
  publicPath(workerPath, "pwa.workerPath");
  publicPath(shellPath, "pwa.shellPath");
  publicPath(manifestPath, "pwa.manifestPath");
  if (!workerPath.endsWith(".js") || !shellPath.endsWith(".html") || !manifestPath.endsWith(".webmanifest")) invalid("PWA output paths must end with .js, .html, and .webmanifest respectively.");
  if (!scope.startsWith(workerPath.slice(0, workerPath.lastIndexOf("/") + 1))) invalid("pwa.scope cannot exceed the worker script directory; broader scopes require application-owned registration and Service-Worker-Allowed headers.");
  if (!workerPath.startsWith(scope) || !shellPath.startsWith(scope) || !manifestPath.startsWith(scope)) invalid("PWA output paths must be inside pwa.scope.");
  if (new Set([workerPath, shellPath, manifestPath].map(path => path.toLowerCase())).size !== 3) invalid("PWA output paths must be distinct.");
  const navigationPaths = pathArray(input.navigationPaths, "pwa.navigationPaths", 128);
  if (navigationPaths.length === 0 || navigationPaths.some(path => !path.startsWith(scope))) invalid("pwa.navigationPaths must contain exact paths inside pwa.scope.");
  const manifest = parseManifest(input.manifest);
  if (!manifest.scope.startsWith(scope) || !manifest.startUrl.startsWith(manifest.scope)
    || !manifest.startUrl.startsWith(scope) || !navigationPaths.includes(manifest.startUrl)
    || navigationPaths.some(path => !path.startsWith(manifest.scope))) invalid("Manifest scope, startUrl, and navigationPaths must agree with the worker scope.");
  const publicAssets = "publicAssets" in input ? pathArray(input.publicAssets, "pwa.publicAssets", 1024) : [];
  const assets = [...new Set([...publicAssets, ...manifest.icons.map(icon => icon.src)])].sort();
  if (assets.some(path => [workerPath, shellPath, manifestPath].includes(path))) invalid("Public input assets cannot collide with PWA build outputs.");
  return Object.freeze({ appId: input.appId, workerModule: input.workerModule, offlineEntry: input.offlineEntry,
    workerPath, shellPath, manifestPath, scope, navigationPaths: Object.freeze(navigationPaths),
    publicAssets: Object.freeze(assets), manifest });
}

function parseManifest(value: unknown): VinextPwaManifest {
  const input = jsonObject(value, ["id", "name", "shortName", "startUrl", "scope", "display", "themeColor", "backgroundColor", "icons"], "pwa.manifest");
  publicPath(input.id, "pwa.manifest.id");
  publicPath(input.startUrl, "pwa.manifest.startUrl");
  publicPath(input.scope, "pwa.manifest.scope", true);
  for (const label of ["name", "shortName"] as const) {
    if (label === "shortName" && !(label in input)) continue;
    if (typeof input[label] !== "string" || !input[label].trim() || input[label].length > 128 || /[\u0000-\u001f\u007f]/.test(input[label])) invalid(`pwa.manifest.${label} must be nonempty plain text of at most 128 characters.`);
  }
  if (input.display !== "standalone" && input.display !== "minimal-ui" && input.display !== "fullscreen") invalid("pwa.manifest.display must be standalone, minimal-ui, or fullscreen.");
  for (const color of ["themeColor", "backgroundColor"] as const) {
    if (color in input && (typeof input[color] !== "string" || !/^#[a-fA-F0-9]{6}$/.test(input[color]))) invalid(`pwa.manifest.${color} must be a six-digit hexadecimal color.`);
  }
  const iconInputs = jsonArray(input.icons, "pwa.manifest.icons", 32);
  if (iconInputs.length === 0) invalid("pwa.manifest.icons must declare public install icons.");
  const icons: VinextPwaIcon[] = iconInputs.map((value: unknown) => {
    const icon = jsonObject(value, ["src", "sizes", "type", "purpose"], "pwa.manifest.icons[]");
    publicPath(icon.src, "pwa.manifest.icons[].src");
    if (typeof icon.sizes !== "string" || !/^(?:any|[1-9][0-9]{0,3}x[1-9][0-9]{0,3})(?: (?:[1-9][0-9]{0,3}x[1-9][0-9]{0,3}))*$/.test(icon.sizes)) invalid("Manifest icon sizes must use dimensions or any.");
    if (icon.type !== "image/png" && icon.type !== "image/svg+xml" && icon.type !== "image/webp") invalid("Manifest icons must declare PNG, SVG, or WebP MIME types.");
    if ("purpose" in icon && icon.purpose !== "any" && icon.purpose !== "maskable" && icon.purpose !== "monochrome") invalid("Manifest icon purpose is unsupported.");
    return Object.freeze(icon) as unknown as VinextPwaIcon;
  });
  for (const size of ["192x192", "512x512"]) {
    if (!icons.some(icon => icon.type === "image/png" && icon.sizes.split(" ").includes(size) && (icon.purpose === undefined || icon.purpose === "any"))) invalid(`Manifest icons must include a public ${size} PNG with purpose any.`);
  }
  return Object.freeze({ ...input, icons: Object.freeze(icons) }) as unknown as VinextPwaManifest;
}

function pathArray(value: unknown, label: string, maximum: number): string[] {
  const paths = jsonArray(value, label, maximum).map(path => { publicPath(path, label); return path; });
  if (new Set(paths).size !== paths.length) invalid(`${label} cannot contain duplicate paths.`);
  return paths;
}

function jsonArray(value: unknown, label: string, maximum: number): unknown[] {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || value.length > maximum) invalid(`${label} must be a bounded JSON array.`);
  const keys = Reflect.ownKeys(value);
  if (keys.length !== value.length + 1) invalid(`${label} must contain ordinary contiguous JSON array entries.`);
  const result: unknown[] = [];
  for (let index = 0; index < value.length; index++) {
    const entry = Object.getOwnPropertyDescriptor(value, String(index));
    if (!entry?.enumerable || !("value" in entry)) invalid(`${label} must contain ordinary JSON values.`);
    result.push(entry.value);
  }
  return result;
}

function publicPath(value: unknown, label: string, directory = false): asserts value is string {
  if (typeof value !== "string" || value.length > 1024 || !/^\/(?:[A-Za-z0-9_~.-]+\/)*[A-Za-z0-9_~.-]*$/.test(value)
    || value.includes("//") || value.split("/").some(part => part === "." || part === ".." || reservedPathSegment(part))
    || /(?:^|\/)(?:api|auth|session|sessions|sync|login|logout|signin|signout|_actions|_next|_rsc|__vinext|\.sync-engine-pwa)(?:\/|$)/i.test(value)
    || /\.rsc\/?$/i.test(value)
    || directory && !value.endsWith("/")) invalid(`${label} must be an unencoded same-origin public ${directory ? "directory ending in /" : "URL path"}.`);
}

function validateEndpoint(value: unknown): asserts value is string {
  if (typeof value !== "string" || value.length > 1024 || !value.startsWith("/api/")) invalid("endpoint must be a static path below /api/.");
  const segments = value.slice(1).split("/");
  if (segments.length > 32 || segments.some(segment => !/^[A-Za-z0-9][A-Za-z0-9_-]*$/.test(segment) || reservedPathSegment(segment))) {
    invalid("endpoint must contain only static, portable route segments.");
  }
}

function validateModulePath(value: unknown, label: string): asserts value is string {
  if (typeof value !== "string" || value.length > 1024) invalid(`${label} must be an application-relative TypeScript path.`);
  const segments = value.split("/");
  const filename = segments.pop();
  if (segments.length > 31 || segments.some(segment => !/^[A-Za-z0-9_-]+$/.test(segment) || reservedPathSegment(segment))
    || filename === undefined || !/^[A-Za-z0-9_-][A-Za-z0-9_.-]*\.ts$/.test(filename)
    || filename.includes("..") || filename.toLowerCase().endsWith(".d.ts") || reservedPathSegment(filename)) {
    invalid(`${label} must be a portable application-relative .ts path without traversal.`);
  }
}

function reservedPathSegment(segment: string): boolean {
  return segment.toLowerCase() === "node_modules" || /^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(segment);
}

function invalid(message: string): never {
  throw new SyncError("invalid-input", message);
}
