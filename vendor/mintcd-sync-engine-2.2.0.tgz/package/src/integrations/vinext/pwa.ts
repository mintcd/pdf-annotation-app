import { readFile } from "node:fs/promises";
import { resolve } from "node:path";
import type { Plugin, ResolvedConfig } from "vite";
import { parseVinextGeneratorConfig } from "./config.js";
import { buildVinextPwa } from "./pwa-build.js";
import { registrationSource } from "./pwa-registration.js";
import type { VinextGeneratorConfig } from "./types.js";

export interface SyncEnginePwaOptions {
  /** A strict JSON path relative to Vite's root, or the already-authored configuration. */
  readonly config: string | VinextGeneratorConfig;
  readonly register?: "auto" | "manual";
  /** Trusted integration-generated entries. Omit to use the legacy on-disk entries. */
  readonly sources?: { readonly worker: string; readonly registration: string };
}

const automaticRegistration = "virtual:sync-engine-pwa-register";
const resolvedAutomaticRegistration = `\0${automaticRegistration}`;
const registrationEntry = "virtual:sync-engine-pwa-registration-entry.ts";

/** Opt-in build integration. Importing or constructing the plugin does not register a worker. */
export function syncEnginePwa(options: SyncEnginePwaOptions): Plugin {
  if (!options || !["auto", "manual", undefined].includes(options.register)) throw new TypeError("register must be auto or manual.");
  let vite: ResolvedConfig;
  let config: VinextGeneratorConfig;
  let injected = false;
  let built = false;
  return {
    name: "sync-engine:vinext-pwa",
    enforce: "post",
    async configResolved(resolved) {
      // The peer stays optional/unconstrained for ordinary SDK consumers. Only
      // executing this build integration opts into its tested Vite API version.
      const { version } = await import("vite");
      const parts = /^(\d+)\.(\d+)\.(\d+)(?:\+.*)?$/.exec(version);
      if (!parts || Number(parts[1]) !== 8 || Number(parts[2]) < 3
        || Number(parts[2]) === 3 && Number(parts[3]) < 4) {
        throw new TypeError(`syncEnginePwa build integration requires its tested Vite range >=8.3.4 <9; found ${version}. Ordinary SDK clients do not require Vite.`);
      }
      vite = resolved;
      let input: unknown = options.config;
      if (typeof input === "string") input = JSON.parse(await readFile(resolve(vite.root, input), "utf8"));
      config = parseVinextGeneratorConfig(input);
      if (!config.pwa) throw new TypeError("syncEnginePwa requires an explicit pwa configuration.");
      if (!vite.base.startsWith("/") || vite.base.startsWith("//") || /[?#%\\]/.test(vite.base)) throw new TypeError("PWA builds require an unencoded same-origin absolute Vite base.");
      if (!config.pwa.scope!.startsWith(vite.base)) throw new TypeError("PWA scope must be inside Vite's URL base.");
      const renderUrl = vite.experimental?.renderBuiltUrl;
      if (renderUrl) {
        for (const hostType of ["js", "css", "html"] as const) {
          const result = renderUrl("_next/static/sync-engine-pwa-probe.js", { type: "asset", hostId: "virtual:vinext-app-browser-entry", hostType, ssr: false });
          if (typeof result === "string" && /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i.test(result)
            || typeof result === "object" && result.runtime !== undefined) throw new TypeError("PWA builds do not support cross-origin assetPrefix or runtime-generated asset URLs.");
        }
      }
    },
    resolveId(id) {
      if (id === automaticRegistration) return resolvedAutomaticRegistration;
      if (options.sources && id === registrationEntry) return `\0${registrationEntry}`;
    },
    load(id) {
      if (options.sources && id === `\0${registrationEntry}`) return options.sources.registration;
      if (id !== resolvedAutomaticRegistration) return;
      return registrationSource(options.sources ? registrationEntry : resolve(vite.root, "sync/register.generated.ts"), vite.command === "build");
    },
    transform(code, id) {
      // Vinext bypasses transformIndexHtml for its framework browser bootstrap.
      // These identifiers are compatibility-tested against the pinned Vinext fixture.
      if (vite.command !== "build" || options.register === "manual" || this.environment.name !== "client") return;
      const entry = id.replace(/^\0/, "").split("?")[0];
      if (entry !== "virtual:vinext-app-browser-entry" && entry !== "virtual:vinext-client-entry") return;
      injected = true;
      return { code: `import ${JSON.stringify(automaticRegistration)};\n${code}`, map: null };
    },
    generateBundle: {
      order: "pre",
      async handler(_output, bundle) {
        if (this.environment.name !== "client" || vite.command !== "build" || built) return;
        if (options.register !== "manual" && !injected) throw new TypeError("The Vinext browser entry was not recognized. Use register: manual or a supported Vinext version.");
        built = true;
        const files = await buildVinextPwa({ vite, config, register: options.register ?? "auto", clientFiles: Object.values(bundle), ...(options.sources ? { sources: options.sources } : {}) });
        for (const [fileName, source] of files) {
          if (bundle[fileName] !== undefined) throw new TypeError(`PWA output ${fileName} conflicts with an existing client bundle output.`);
          // Vinext derives its production asset allowlist from the client bundle.
          // Emitting before writeBundle keeps the server, Vite, and worker graph aligned.
          this.emitFile({ type: "asset", fileName, source });
        }
      },
    },
  };
}

export type { VinextPwaConfig, VinextPwaIcon, VinextPwaManifest } from "./types.js";
