/** Authored JSON configuration for build-time Vinext source generation. */
export interface VinextGeneratorConfig {
  readonly version: 1;
  readonly contractVersion: string;
  readonly appDirectory?: "app" | "src/app";
  readonly endpoint?: string;
  readonly serverModule?: string;
  readonly serverExport?: string;
  readonly clientModule?: string;
  readonly scaffoldServer?: boolean;
  readonly pwa?: VinextPwaConfig;
}

/** Public, application-authored PWA inputs. No credentials or server bindings belong here. */
export interface VinextPwaConfig {
  readonly appId: string;
  readonly workerModule: string;
  readonly offlineEntry: string;
  readonly workerPath?: string;
  readonly shellPath?: string;
  readonly manifestPath?: string;
  readonly scope?: string;
  /** Exact document pathnames, including startUrl. API and RSC routes are excluded. */
  readonly navigationPaths: readonly string[];
  readonly publicAssets?: readonly string[];
  readonly manifest: VinextPwaManifest;
}

export interface VinextPwaManifest {
  readonly id: string;
  readonly name: string;
  readonly shortName?: string;
  readonly startUrl: string;
  readonly scope: string;
  readonly display: "standalone" | "minimal-ui" | "fullscreen";
  readonly themeColor?: string;
  readonly backgroundColor?: string;
  readonly icons: readonly VinextPwaIcon[];
}

export interface VinextPwaIcon {
  readonly src: string;
  readonly sizes: string;
  readonly type: "image/png" | "image/svg+xml" | "image/webp";
  readonly purpose?: "any" | "maskable" | "monochrome";
}

export interface VinextGeneratedFile {
  /** A POSIX path relative to the application root. */
  readonly path: string;
  readonly content: string;
  /** Scaffolds become application-owned immediately after their first creation. */
  readonly ownership: "generated" | "scaffold";
}

export interface VinextGenerationPlan {
  readonly version: 1;
  readonly manifestPath: ".sync-engine/vinext.manifest.json";
  readonly files: readonly VinextGeneratedFile[];
}
