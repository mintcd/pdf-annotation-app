/** Source injected only into an explicit browser entry by the build integration. */
export function registrationSource(modulePath: string, enabled = true): string {
  if (!enabled) return "// PWA registration is disabled during development.\n";
  return `import { registerSyncServiceWorker } from ${JSON.stringify(modulePath.replace(/\\/g, "/"))};\nvoid registerSyncServiceWorker().catch(error => {\n  window.dispatchEvent(new CustomEvent("sync-engine:pwa-registration-error", { detail: error }));\n});\n`;
}
