import { createHash } from "node:crypto";
import { builtinModules } from "node:module";
import { readFile, realpath, stat } from "node:fs/promises";
import { isAbsolute, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import type { InlineConfig, Plugin, ResolvedConfig } from "vite";
import { planVinextGeneration } from "./plan.js";
import { registrationSource } from "./pwa-registration.js";
import type { VinextGeneratorConfig, VinextPwaConfig } from "./types.js";

interface BuildFile {
  readonly type: "chunk" | "asset";
  readonly fileName: string;
  readonly code?: string;
  readonly source?: string | Uint8Array;
  readonly isEntry?: boolean;
  readonly imports?: readonly string[];
  readonly dynamicImports?: readonly string[];
  readonly referencedFiles?: readonly string[];
  readonly viteMetadata?: { readonly importedCss?: Set<string>; readonly importedAssets?: Set<string> };
}

interface BuildPwaOptions {
  readonly vite: ResolvedConfig;
  readonly config: VinextGeneratorConfig;
  readonly register: "auto" | "manual";
  readonly clientFiles: readonly BuildFile[];
  readonly sources?: { readonly worker: string; readonly registration: string };
}

const buildToken = "__SYNC_ENGINE_PWA_BUILD_ID__";
const cacheModule = "virtual:sync-engine-pwa-cache";
const offlineModule = "virtual:sync-engine-pwa-offline";
const registrationEntry = "virtual:sync-engine-pwa-registration-entry.ts";
const workerEntry = "virtual:sync-engine-pwa-worker-entry.ts";
const nodeBuiltins = new Set(builtinModules.map(name => name.replace(/^node:/, "")));

/** Build only explicitly reachable browser/worker graphs; never glob the SSR output. */
export async function buildVinextPwa({ vite, config, register, clientFiles, sources }: BuildPwaOptions): Promise<ReadonlyMap<string, Uint8Array>> {
  const pwa = config.pwa!;
  const { build } = await import("vite");
  const prefix = `sync-engine-pwa/${pwa.appId}`;
  const metadataPrefix = `.sync-engine-pwa/${pwa.appId}`;
  if (!sources) {
    const plan = planVinextGeneration(config);
    for (const generatedPath of ["sync/worker.generated.ts", "sync/register.generated.ts"]) {
      const expected = plan.files.find(file => file.path === generatedPath)!.content;
      let actual: string;
      try { actual = await readFile(resolve(vite.root, generatedPath), "utf8"); }
      catch { throw new TypeError(`Missing ${generatedPath}. Run sync-engine generate vinext before building.`); }
      if (actual !== expected) throw new TypeError(`${generatedPath} differs from the generation plan. Run sync-engine generate vinext --check.`);
    }
    await assertSource(vite.root, pwa.workerModule);
  }
  await assertSource(vite.root, pwa.offlineEntry);
  const outputs = new Map<string, Uint8Array>();
  const publicRoot = vite.publicDir;
  const finalPaths = [pwa.workerPath!, pwa.shellPath!, pwa.manifestPath!];
  for (const path of finalPaths) {
    if (!publicRoot) continue;
    try { await stat(resolve(publicRoot, fromBase(path, vite.base))); }
    catch (error) { if (isMissing(error)) continue; throw error; }
    throw new TypeError(`PWA output ${path} conflicts with an application-owned public file.`);
  }
  for (const path of pwa.publicAssets!) {
    const source = fromBase(path, vite.base);
    if (!publicRoot) throw new TypeError("PWA public assets require Vite's publicDir.");
    const absolute = await assertSource(publicRoot, source);
    outputs.set(source, await readFile(absolute));
  }
  validatePngIcons(pwa, outputs, vite.base);
  const common: InlineConfig = {
    configFile: false,
    envDir: false,
    root: vite.root,
    base: vite.base,
    mode: vite.mode,
    oxc: { jsx: { runtime: "automatic" } },
    publicDir: false,
    logLevel: "warn",
    resolve: { alias: vite.resolve.alias, conditions: ["browser", "module", "production"], dedupe: ["react", "react-dom"] },
    build: { write: false, emptyOutDir: false, sourcemap: false, minify: true, target: "es2022", assetsInlineLimit: 0, cssCodeSplit: true },
  };
  const offlineEntry = resolve(vite.root, pwa.offlineEntry).replace(/\\/g, "/");
  const offlineResult = await build({
    ...common,
    plugins: [browserBoundary(), {
      name: "sync-engine:pwa-offline-entry",
      enforce: "pre",
      resolveId(id) {
        if (id === offlineModule) return `\0${offlineModule}`;
        if (sources && id === registrationEntry) return `\0${registrationEntry}`;
        // The app's entry is an executable program, even when its package has sideEffects:false.
        if (id === offlineEntry) return { id, moduleSideEffects: true };
      },
      load(id) {
        if (sources && id === `\0${registrationEntry}`) return sources.registration;
        if (id !== `\0${offlineModule}`) return;
        const registration = register === "auto" ? registrationSource(sources ? registrationEntry : resolve(vite.root, "sync/register.generated.ts")) : "";
        return `${registration}\nimport ${JSON.stringify(offlineEntry)};\n`;
      },
    }],
    build: { ...common.build, rolldownOptions: {
      input: offlineModule,
      output: { format: "es", entryFileNames: `${prefix}/offline-[hash].js`, chunkFileNames: `${prefix}/[name]-[hash].js`, assetFileNames: `${prefix}/[name]-[hash][extname]` },
    } },
  });
  const offlineFiles = buildFiles(offlineResult);
  for (const output of offlineFiles) outputs.set(output.fileName, bytes(output));
  validateCssGraph(offlineFiles, outputs, vite.base);
  const entry = offlineFiles.find(file => file.type === "chunk" && file.isEntry);
  if (!entry) throw new TypeError("The offline browser build did not emit an entry.");
  for (const file of offlineFiles) {
    for (const imported of [...file.imports ?? [], ...file.dynamicImports ?? []]) {
      if (!outputs.has(imported)) throw new TypeError("The offline asset graph contains an external import.");
    }
  }
  const stylesheetPaths = initialStyles(entry.fileName, offlineFiles);
  const shell = renderShell(pwa, `${vite.base}${entry.fileName}`, stylesheetPaths.map(path => `${vite.base}${path}`));
  outputs.set(fromBase(pwa.shellPath!, vite.base), new TextEncoder().encode(shell));
  const manifest = {
    id: pwa.manifest.id, name: pwa.manifest.name,
    ...(pwa.manifest.shortName === undefined ? {} : { short_name: pwa.manifest.shortName }),
    start_url: pwa.manifest.startUrl, scope: pwa.manifest.scope, display: pwa.manifest.display,
    ...(pwa.manifest.themeColor === undefined ? {} : { theme_color: pwa.manifest.themeColor }),
    ...(pwa.manifest.backgroundColor === undefined ? {} : { background_color: pwa.manifest.backgroundColor }),
    icons: pwa.manifest.icons,
  };
  outputs.set(fromBase(pwa.manifestPath!, vite.base), new TextEncoder().encode(`${JSON.stringify(manifest, null, 2)}\n`));
  const resourceBytes = new Map([...outputs].map(([path, bytes]) => [`${vite.base}${path}`, bytes]));
  collectClientGraph(clientFiles, vite, resourceBytes);
  const assets = [...resourceBytes.keys()].sort();
  if (assets.length > 4096) throw new TypeError("The complete offline asset graph exceeds the supported 4096 assets.");
  const cacheOptions = { cacheName: `sync-engine:${pwa.appId}:${buildToken}`, assets, shellUrl: pwa.shellPath!, scope: pwa.scope!, navigationPaths: pwa.navigationPaths };
  const workerResult = await build({
    ...common,
    plugins: [browserBoundary(), {
      name: "sync-engine:pwa-cache-manifest",
      resolveId(id) {
        if (id === cacheModule || sources && id === workerEntry) return `\0${id}`;
      },
      load(id) {
        if (id === `\0${cacheModule}`) return `export default ${safeJson(cacheOptions)};`;
        if (sources && id === `\0${workerEntry}`) return sources.worker;
      },
    }],
    build: { ...common.build, cssCodeSplit: false, rolldownOptions: {
      input: sources ? workerEntry : resolve(vite.root, "sync/worker.generated.ts"),
      output: { format: "iife", codeSplitting: false, entryFileNames: fromBase(pwa.workerPath!, vite.base), assetFileNames: `${prefix}/worker-[name]-[hash][extname]` },
    } },
  });
  const workerFiles = buildFiles(workerResult);
  if (workerFiles.length !== 1 || workerFiles[0]?.type !== "chunk" || workerFiles[0].imports?.length || workerFiles[0].dynamicImports?.length) throw new TypeError("The worker must bundle into one executable script with no external or dynamic imports/assets.");
  const workerCode = workerFiles[0].code!;
  if (!workerCode.includes(buildToken)) throw new TypeError("The worker cache manifest was removed by its application composition.");
  const digest = createHash("sha256");
  for (const [path, content] of [...resourceBytes].sort(([left], [right]) => left < right ? -1 : left > right ? 1 : 0)) digest.update(path).update("\0").update(content).update("\0");
  digest.update(workerCode);
  const buildId = digest.digest("hex").slice(0, 24);
  outputs.set(fromBase(pwa.workerPath!, vite.base), new TextEncoder().encode(workerCode.replaceAll(buildToken, buildId)));
  const buildManifest = { version: 1, appId: pwa.appId, buildId, cacheName: cacheOptions.cacheName.replace(buildToken, buildId), assets,
    shellUrl: pwa.shellPath!, workerUrl: pwa.workerPath!, scope: pwa.scope!, navigationPaths: pwa.navigationPaths };
  outputs.set(`${metadataPrefix}/precache-${buildId}.json`, new TextEncoder().encode(`${JSON.stringify(buildManifest, null, 2)}\n`));
  // A stable inspection pointer is build metadata, not an input to the immutable cache.
  outputs.set(`${metadataPrefix}/build.json`, new TextEncoder().encode(`${JSON.stringify(buildManifest, null, 2)}\n`));
  for (const path of outputs.keys()) {
    if (publicRoot && !pwa.publicAssets!.includes(`${vite.base}${path}`)) {
      if (await exists(resolve(publicRoot, path))) throw new TypeError(`PWA output ${vite.base}${path} conflicts with an application-owned public file.`);
    }
  }
  return outputs;
}

function browserBoundary(): Plugin {
  const forbidden = ["server", "adapters/d1", "transport/http-server", "integrations/vinext/pwa", "integrations/vinext/node"].map(subpath => {
    const entry = fileURLToPath(import.meta.resolve(`@mintcd/sync-engine/${subpath}`)).replace(/\\/g, "/");
    return entry.endsWith("/index.js") ? entry.slice(0, -"index.js".length) : entry;
  });
  return {
    name: "sync-engine:pwa-browser-boundary",
    enforce: "pre",
    resolveId(id) {
      if (id.startsWith("node:") || nodeBuiltins.has(id) || id === "server-only"
        || /^@mintcd\/sync-engine\/(?:server|adapters\/d1|transport\/http-server|integrations\/vinext(?:\/|$))/.test(id)) throw new TypeError(`Server-only import is unavailable in a PWA browser/worker entry: ${id}`);
    },
    transform(_code, id) {
      const path = id.replace(/\\/g, "/").split("?")[0]!;
      if (forbidden.some(entry => entry.endsWith("/") ? path.startsWith(entry) : path === entry)) throw new TypeError(`Server-only module is unavailable in a PWA browser/worker entry: ${path}`);
    },
  };
}

function buildFiles(value: unknown): BuildFile[] {
  const results = Array.isArray(value) ? value : [value];
  return results.flatMap(result => {
    if (!result || typeof result !== "object" || !("output" in result) || !Array.isArray(result.output)) throw new TypeError("Unexpected Vite build result.");
    return result.output as BuildFile[];
  });
}

function bytes(file: BuildFile): Uint8Array {
  const content = file.type === "chunk" ? file.code : file.source;
  if (typeof content === "string") return new TextEncoder().encode(content);
  if (content instanceof Uint8Array) return content;
  throw new TypeError("The PWA build emitted an unsupported asset.");
}

function initialStyles(entry: string, outputs: readonly BuildFile[]): string[] {
  const files = new Map(outputs.map(file => [file.fileName, file]));
  const visited = new Set<string>();
  const styles = new Set<string>();
  function visit(path: string): void {
    if (visited.has(path)) return;
    visited.add(path);
    const file = files.get(path);
    if (!file) return;
    for (const imported of file.imports ?? []) visit(imported);
    for (const css of file.viteMetadata?.importedCss ?? []) styles.add(css);
  }
  visit(entry);
  return [...styles];
}

function renderShell(pwa: VinextPwaConfig, script: string, styles: readonly string[]): string {
  return `<!doctype html>\n<html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>${html(pwa.manifest.name)}</title><link rel="manifest" href="${html(pwa.manifestPath!)}">${styles.map(path => `<link rel="stylesheet" href="${html(path)}">`).join("")}</head><body><div id="root"></div><script type="module" src="${html(script)}"></script></body></html>\n`;
}

function html(value: string): string { return value.replace(/[&<>"']/g, char => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[char]!); }
function safeJson(value: unknown): string { return JSON.stringify(value).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029"); }

function fromBase(path: string, base: string): string {
  if (!path.startsWith(base)) throw new TypeError(`Public PWA path ${path} is outside Vite base ${base}.`);
  const relativePath = path.slice(base.length);
  if (!relativePath || relativePath.startsWith("/") || relativePath.split("/").some(part => part === ".." || part === ".")) throw new TypeError("Invalid PWA output path.");
  return relativePath;
}

async function assertSource(root: string, path: string): Promise<string> {
  const absolute = resolve(root, path);
  assertInside(root, absolute);
  const canonicalRoot = await realpath(root);
  const canonical = await realpath(absolute);
  assertInside(canonicalRoot, canonical);
  if (!(await stat(canonical)).isFile()) throw new TypeError(`PWA input is not a regular file: ${path}`);
  return canonical;
}

function assertInside(root: string, target: string): void {
  const path = relative(resolve(root), target);
  if (!path || path === ".." || path.startsWith(`..${sep}`) || isAbsolute(path)) throw new TypeError("PWA paths must stay inside their application directory.");
}

function isMissing(error: unknown): boolean { return error instanceof Error && "code" in error && error.code === "ENOENT"; }

function validatePngIcons(pwa: VinextPwaConfig, files: ReadonlyMap<string, Uint8Array>, base: string): void {
  for (const icon of pwa.manifest.icons) {
    if (icon.type !== "image/png") continue;
    const bytes = files.get(fromBase(icon.src, base))!;
    if (bytes.length < 24 || ![137, 80, 78, 71, 13, 10, 26, 10].every((value, index) => bytes[index] === value)
      || new TextDecoder().decode(bytes.slice(12, 16)) !== "IHDR") throw new TypeError(`Manifest PNG icon is not a PNG: ${icon.src}`);
    const dimensions = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    if (icon.sizes.split(" ").some(size => size !== `${dimensions.getUint32(16)}x${dimensions.getUint32(20)}`)) throw new TypeError(`Manifest PNG icon dimensions disagree with sizes: ${icon.src}`);
  }
}

async function exists(path: string): Promise<boolean> {
  try { await stat(path); return true; } catch (error) { if (isMissing(error)) return false; throw error; }
}

function validateCssGraph(files: readonly BuildFile[], outputs: ReadonlyMap<string, Uint8Array>, base: string): void {
  for (const file of files) {
    if (!file.fileName.endsWith(".css")) continue;
    const css = new TextDecoder().decode(bytes(file)).replace(/\/\*[\s\S]*?\*\//g, "");
    const urls = css.matchAll(/\burl\(\s*(?:"([^"]*)"|'([^']*)'|([^\s)]*))\s*\)|@import\s+(?:"([^"]*)"|'([^']*)')/gi);
    for (const match of urls) {
      const value = match.slice(1).find(value => value !== undefined)!;
      if (value.startsWith("#") || /^data:/i.test(value)) continue;
      if (value.includes("\\")) throw new TypeError("Escaped CSS resource URLs are unsupported in the offline asset graph.");
      const url = new URL(value, `https://sync-engine.invalid${base}${file.fileName}`);
      if (url.origin !== "https://sync-engine.invalid" || url.search || !url.pathname.startsWith(base)
        || !outputs.has(url.pathname.slice(base.length))) throw new TypeError(`Offline CSS references an undeclared or cross-origin asset: ${value}`);
    }
  }
}

/** Only the current client bundle is a source of online UI assets, never server directories. */
function collectClientGraph(files: readonly BuildFile[], vite: ResolvedConfig, resources: Map<string, Uint8Array>): void {
  const byName = new Map(files.map(file => [file.fileName, file]));
  const byUrl = new Map<string, BuildFile>();
  for (const file of files) {
    if (excludedClientAsset(file.fileName)) continue;
    for (const url of publicClientUrls(file.fileName, vite)) byUrl.set(url, file);
  }
  const visited = new Set<string>();
  function visit(name: string): void {
    if (visited.has(name)) return;
    const file = byName.get(name);
    if (!file || excludedClientAsset(name)) throw new TypeError(`The public client asset graph contains an unsupported or external dependency: ${name}`);
    visited.add(name);
    const content = bytes(file);
    const urls = publicClientUrls(name, vite);
    for (const url of urls) {
      if (resources.has(url)) throw new TypeError(`The client and offline asset graphs collide at ${url}.`);
      resources.set(url, content);
    }
    for (const dependency of [...file.imports ?? [], ...file.dynamicImports ?? [], ...file.referencedFiles ?? [],
      ...file.viteMetadata?.importedCss ?? [], ...file.viteMetadata?.importedAssets ?? []]) visit(dependency);
    if (!name.endsWith(".css")) return;
    for (const resource of cssResources(new TextDecoder().decode(content))) {
      const url = new URL(resource, `https://sync-engine.invalid${urls[0]}`);
      if (url.origin !== "https://sync-engine.invalid") throw new TypeError(`Client CSS references a cross-origin offline asset: ${resource}`);
      const path = `${url.pathname}${url.search}`;
      const dependency = byUrl.get(path);
      if (dependency) visit(dependency.fileName);
      else if (!resources.has(path)) throw new TypeError(`Client CSS references an undeclared offline asset: ${resource}`);
    }
  }
  // Framework client references can be independent entry points rooted in SSR HTML.
  // Every JavaScript chunk emitted by the client environment is public; its assets
  // are reached through bundler metadata rather than a directory-wide cache glob.
  for (const file of files) if (file.type === "chunk") visit(file.fileName);
}

function publicClientUrls(fileName: string, vite: ResolvedConfig): string[] {
  const renderUrl = vite.experimental?.renderBuiltUrl;
  const rendered = new Set<string>();
  // Vinext assetPrefix can already include basePath in these file names. Asking
  // its public URL renderer avoids prepending that base a second time.
  if (renderUrl && fileName.includes("_next/static/")) {
    for (const hostType of ["js", "css", "html"] as const) {
      const value = renderUrl(fileName, { type: "asset", hostId: "virtual:vinext-app-browser-entry", hostType, ssr: false });
      if (typeof value === "string") rendered.add(value);
      else if (value?.runtime !== undefined) throw new TypeError("Runtime client asset URLs are unsupported by the offline cache.");
    }
  }
  if (rendered.size === 0) rendered.add(`${vite.base}${fileName}`);
  return [...rendered].map(value => {
    if (!value.startsWith("/") || value.startsWith("//") || /[\\#]/.test(value)) throw new TypeError("Client assets must have same-origin public URL paths.");
    const url = new URL(value, "https://sync-engine.invalid");
    return `${url.pathname}${url.search}`;
  });
}

function excludedClientAsset(path: string): boolean {
  return path.startsWith("/") || path.includes("\\") || path.split("/").some(segment => segment === ".." || segment === ".")
    || path.startsWith(".vite/") || path === "vinext-client-entry-manifest.json" || path === ".assetsignore"
    || /\.(?:html|rsc|map)$/i.test(path);
}

function cssResources(css: string): string[] {
  const values: string[] = [];
  for (const match of css.replace(/\/\*[\s\S]*?\*\//g, "").matchAll(/\burl\(\s*(?:"([^"]*)"|'([^']*)'|([^\s)]*))\s*\)|@import\s+(?:"([^"]*)"|'([^']*)')/gi)) {
    const value = match.slice(1).find(value => value !== undefined)!;
    if (value.startsWith("#") || /^data:/i.test(value)) continue;
    if (value.includes("\\")) throw new TypeError("Escaped CSS resource URLs are unsupported in the offline asset graph.");
    values.push(value);
  }
  return values;
}
