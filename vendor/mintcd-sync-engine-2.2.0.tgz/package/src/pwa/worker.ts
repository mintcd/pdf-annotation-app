import type { SyncOptions, SyncResult, SyncRunOptions } from "../client/types.js";
import { SyncTransportError } from "../client/errors.js";
import { SyncError } from "../core/errors.js";
import { PwaSyncError, SYNC_WORKER_PROTOCOL, SYNC_WORKER_VERSION, decodeSyncWorkerRequest, encodeSyncWorkerFailure, isSyncWorkerMessage, pwaDuration, pwaIdentifier, syncWorkerTag } from "./protocol.js";
import type { SyncWorkerReply, SyncWorkerRequest } from "./protocol.js";
export { PwaSyncError, syncWorkerTag } from "./protocol.js";

export interface SyncWorkerSession {
  readonly engine: { sync(options?: SyncOptions): Promise<SyncResult>; close(): void | Promise<void> };
  /** A durable account/enablement check, performed immediately before sync. */
  readonly assertEnabled?: () => void | Promise<void>;
  /** For example a durable registry lease's logout/disable signal. */
  readonly signal?: AbortSignal;
  /** Release owned database/registry handles after engine close; drain writes here. */
  readonly close?: () => void | Promise<void>;
}
export interface CreateSyncWorkerHostOptions {
  readonly contractVersion: string;
  readonly replicaKeys: readonly string[];
  readonly openSession: (replicaKey: string, options: { readonly signal: AbortSignal }) => SyncWorkerSession | Promise<SyncWorkerSession>;
  readonly syncOptions?: SyncRunOptions;
  readonly maximumDurationMs?: number;
  readonly cleanupTimeoutMs?: number;
  readonly maximumConcurrentRuns?: number;
  /** Shell cache readiness only; account bootstrap and page control are separate. */
  readonly isOfflineReady?: () => boolean | Promise<boolean>;
  readonly onError?: (error: unknown, replicaKey: string) => void;
}
export interface SyncWorkerMessageEvent {
  readonly data: unknown;
  readonly ports?: readonly { postMessage(message: unknown): void }[];
  waitUntil(work: Promise<unknown>): void;
}
export interface SyncWorkerBackgroundEvent { readonly tag: string; waitUntil(work: Promise<unknown>): void }
export interface SyncWorkerHost {
  handleMessage(event: SyncWorkerMessageEvent): boolean;
  handleSync(event: SyncWorkerBackgroundEvent): boolean;
  /** Stops this host's runs. App cleanup must separately establish cross-context quiescence. */
  close(): Promise<void>;
}
function race<Value>(work: Promise<Value>, signal: AbortSignal): Promise<Value> {
  if (signal.aborted) { void work.catch(() => undefined); return Promise.reject(signal.reason); }
  return new Promise((resolve, reject) => {
    const cancel = () => { signal.removeEventListener("abort", cancel); reject(signal.reason); };
    signal.addEventListener("abort", cancel, { once: true });
    work.then(value => { signal.removeEventListener("abort", cancel); resolve(value); }, error => { signal.removeEventListener("abort", cancel); reject(error); });
  });
}

/** Attach handlers explicitly to a service worker; importing this module does nothing. */
export function createSyncWorkerHost(options: CreateSyncWorkerHostOptions): SyncWorkerHost {
  pwaIdentifier(options.contractVersion, "contractVersion", 256);
  if (!Array.isArray(options.replicaKeys) || options.replicaKeys.length > 256 || typeof options.openSession !== "function") throw new PwaSyncError("invalid-message", "A worker needs bounded configured replica keys and an application session factory.");
  const keys = new Set(options.replicaKeys);
  for (const key of keys) pwaIdentifier(key, "replicaKey");
  const tags = new Map([...keys].map(key => [syncWorkerTag(key), key]));
  const duration = pwaDuration(options.maximumDurationMs, 45_000, "maximumDurationMs");
  const cleanupDuration = pwaDuration(options.cleanupTimeoutMs, 10_000, "cleanupTimeoutMs");
  const concurrency = pwaDuration(options.maximumConcurrentRuns, 4, "maximumConcurrentRuns");
  if (concurrency > 256) throw new PwaSyncError("invalid-message", "maximumConcurrentRuns exceeds 256.");
  const syncOptions = options.syncOptions === undefined ? {} : structuredClone(options.syncOptions);
  const active = new Map<string, { controller: AbortController; promise: Promise<SyncResult> }>();
  const opening = new Set<string>();
  const disposing = new Set<string>();
  const handshakes = new Set<AbortController>();
  let closed = false;
  let closePromise: Promise<void> | undefined;
  function report(error: unknown, key: string): void { try { options.onError?.(error, key); } catch { /* Error observers do not own event work. */ } }
  async function dispose(session: SyncWorkerSession, key: string): Promise<void> {
    let failure: unknown;
    try { await session.engine.close(); } catch (error) { failure = error; }
    try { await session.close?.(); } catch (error) { failure = failure === undefined ? error : new AggregateError([failure, error], "Worker resource cleanup failed."); }
    if (failure !== undefined) { report(failure, key); throw failure; }
  }
  async function boundedCleanup(session: SyncWorkerSession, key: string): Promise<void> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new PwaSyncError("timeout", "Worker cleanup exceeded its budget.")), cleanupDuration);
    disposing.add(key);
    const cleanup = dispose(session, key).finally(() => disposing.delete(key));
    try { await race(cleanup, controller.signal); } finally { clearTimeout(timer); }
  }
  function run(key: string, override?: SyncRunOptions): Promise<SyncResult> {
    if (closed) return Promise.reject(new PwaSyncError("closed", "The worker host is closed."));
    const existing = active.get(key);
    if (existing) return existing.promise;
    if (opening.has(key) || disposing.has(key) || new Set([...active.keys(), ...opening, ...disposing]).size >= concurrency) return Promise.reject(new PwaSyncError("busy", "The worker session budget is exhausted."));
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(new PwaSyncError("timeout", "Worker execution exceeded its budget.")), duration);
    const work = { controller, promise: undefined as unknown as Promise<SyncResult> };
    work.promise = (async () => {
      let session: SyncWorkerSession | undefined;
      let removeSessionSignal: (() => void) | undefined;
      opening.add(key);
      const factory = Promise.resolve().then(() => {
        if (controller.signal.aborted) throw controller.signal.reason;
        return options.openSession(key, { signal: controller.signal });
      });
      // A factory ignoring cancellation still has its late resources disposed.
      void factory.then(value => {
        if (controller.signal.aborted && session === undefined) return boundedCleanup(value, key);
      }).catch(error => { report(error, key); }).finally(() => opening.delete(key));
      try {
        session = await race(factory, controller.signal);
        if (!session || typeof session.engine?.sync !== "function" || typeof session.engine.close !== "function") throw new PwaSyncError("execution-failed", "Invalid worker session.");
        if (session.signal) {
          const cancel = () => controller.abort(session!.signal!.reason ?? new PwaSyncError("closed", "The replica was disabled."));
          session.signal.addEventListener("abort", cancel, { once: true });
          removeSessionSignal = () => session!.signal!.removeEventListener("abort", cancel);
          if (session.signal.aborted) cancel();
        }
        await race(Promise.resolve().then(() => session!.assertEnabled?.()), controller.signal);
        return await race(Promise.resolve().then(() => {
          if (controller.signal.aborted) throw controller.signal.reason;
          return session!.engine.sync({ ...syncOptions, ...override, retry: { ...syncOptions.retry, ...override?.retry }, maximumDurationMs: Math.min(override?.maximumDurationMs ?? syncOptions.maximumDurationMs ?? 30_000, duration), signal: controller.signal });
        }), controller.signal);
      } finally {
        removeSessionSignal?.();
        clearTimeout(timer);
        if (session) await boundedCleanup(session, key);
      }
    })().finally(() => { clearTimeout(timer); if (active.get(key) === work) active.delete(key); });
    active.set(key, work);
    return work.promise;
  }
  function reply(event: SyncWorkerMessageEvent, message: SyncWorkerReply): void {
    try { event.ports?.[0]?.postMessage(message); } catch { /* A closed page cannot cancel event-owned work. */ }
  }
  function valid(request: SyncWorkerRequest): void {
    if (request.contractVersion !== options.contractVersion) throw new PwaSyncError("contract-mismatch", "The worker contract does not match.");
    if (!keys.has(request.replicaKey)) throw new PwaSyncError("unknown-replica", "This replica is not configured.");
    if (closed) throw new PwaSyncError("closed", "The worker host is closed.");
  }
  return {
    handleMessage(event) {
      if (!isSyncWorkerMessage(event.data)) return false;
      // waitUntil is called synchronously while the browser event can be extended.
      const work = Promise.resolve().then(async () => {
        let request: SyncWorkerRequest;
        try { request = decodeSyncWorkerRequest(event.data); }
        catch (error) {
          const data = event.data as Partial<SyncWorkerRequest>;
          // Reply only when correlation fields are bounded; never echo arbitrary data.
          try { pwaIdentifier(data.id, "id"); pwaIdentifier(data.replicaKey, "replicaKey"); }
          catch { return; }
          reply(event, { type: SYNC_WORKER_PROTOCOL, version: SYNC_WORKER_VERSION, contractVersion: options.contractVersion, replicaKey: data.replicaKey!, id: data.id!, ok: false, error: encodeSyncWorkerFailure(error) });
          return;
        }
        const base = { type: SYNC_WORKER_PROTOCOL, version: SYNC_WORKER_VERSION, contractVersion: options.contractVersion, replicaKey: request.replicaKey, id: request.id } as const;
        try {
          valid(request);
          if (request.command === "hello") {
            const controller = new AbortController();
            handshakes.add(controller);
            const timer = setTimeout(() => controller.abort(new PwaSyncError("timeout", "Worker handshake exceeded its budget.")), duration);
            try { reply(event, { ...base, ok: true, shellReady: !!await race(Promise.resolve().then(() => options.isOfflineReady?.() ?? false), controller.signal) }); }
            finally { clearTimeout(timer); handshakes.delete(controller); }
          } else reply(event, { ...base, ok: true, result: await run(request.replicaKey, request.options) });
        } catch (error) { reply(event, { ...base, ok: false, error: encodeSyncWorkerFailure(error) }); }
      });
      event.waitUntil(work);
      return true;
    },
    handleSync(event) {
      const key = tags.get(event.tag);
      if (key === undefined) return false;
      event.waitUntil(run(key).catch(error => {
        // Reject only classified transient failures: browsers may retry rejected sync events.
        // In particular access failures must wait for a later application-authorized trigger.
        if ((error instanceof SyncTransportError || error instanceof SyncError) && error.retryable) throw error;
        report(error, key);
      }));
      return true;
    },
    close() {
      if (closePromise) return closePromise;
      const runs = [...active.values()];
      closePromise = Promise.resolve().then(() => Promise.allSettled(runs.map(work => work.promise))).then(() => undefined);
      closed = true;
      for (const controller of handshakes) controller.abort(new PwaSyncError("closed", "The worker host was closed."));
      for (const work of active.values()) work.controller.abort(new PwaSyncError("closed", "The worker host was closed."));
      return closePromise;
    },
  };
}
