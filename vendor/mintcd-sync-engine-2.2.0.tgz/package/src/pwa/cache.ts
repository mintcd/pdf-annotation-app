/** The small Cache API surface needed by the PWA shell helper. */
export interface PwaAssetCache {
  match(request: string): Promise<Response | undefined>;
  put(request: string, response: Response): Promise<void>;
  keys(): Promise<readonly Request[]>;
}

export interface PwaCacheStorage {
  has(name: string): Promise<boolean>;
  open(name: string): Promise<PwaAssetCache>;
  delete(name: string): Promise<boolean>;
}

export interface PwaCacheOptions {
  /** Immutable and unique to this application/build; old build caches are retained. */
  cacheName: string;
  /** Explicit public same-origin URLs, including shellUrl and every offline dependency. */
  assets: readonly string[];
  shellUrl: string;
  /** Exact document pathnames, without queries, fragments or wildcard matching. */
  navigationPaths: readonly string[];
  /** Registration scope as a same-origin directory URL. Defaults to /. */
  scope?: string;
  origin?: string;
  cacheStorage?: PwaCacheStorage;
  fetch?: typeof globalThis.fetch;
}

export interface PwaCache {
  /** Rejects an incomplete install, preserving all other application/build caches. */
  install(): Promise<void>;
  /** Undefined means another application fetch handler should decide this request. */
  handleFetch(request: Request): Promise<Response> | undefined;
  /** Checks the completion marker and the entire declared asset set. */
  isReady(): Promise<boolean>;
}

const metadataPath = "/.sync-engine-pwa/cache-metadata";
const excludedSegments = new Set(["api", "auth", "session", "sessions", "sync", "login", "logout", "signin", "signout", "_actions"]);
const sensitiveQueries = new Set(["_rsc", "__rsc", "__flight__", "action", "_action", "__action", "session", "token", "access_token", "auth"]);
const javascriptTypes = new Set(["text/javascript", "application/javascript", "text/ecmascript", "application/ecmascript"]);
const mimeTypes: Readonly<Record<string, readonly string[]>> = {
  css: ["text/css"], json: ["application/json", "application/manifest+json"], webmanifest: ["application/manifest+json", "application/json"],
  svg: ["image/svg+xml"], png: ["image/png"], jpg: ["image/jpeg"], jpeg: ["image/jpeg"], gif: ["image/gif"],
  webp: ["image/webp"], avif: ["image/avif"], ico: ["image/x-icon", "image/vnd.microsoft.icon"],
  woff: ["font/woff", "application/font-woff"], woff2: ["font/woff2"],
  ttf: ["font/ttf", "application/x-font-ttf"], otf: ["font/otf", "application/x-font-opentype"], wasm: ["application/wasm"],
};

/**
 * Install an explicit public shell, without registering listeners or a worker.
 * Cache names are immutable build identities. Activation, old-cache cleanup and
 * account data are application concerns; this helper never migrates IndexedDB.
 */
export function createPwaCache(options: PwaCacheOptions): PwaCache {
  if (typeof options.cacheName !== "string" || options.cacheName.length === 0 || options.cacheName.length > 200 || /[\u0000-\u001f\u007f]/.test(options.cacheName)) {
    throw new TypeError("cacheName must be a nonempty, bounded immutable application/build name.");
  }
  const cacheName = options.cacheName;
  const origin = resolveOrigin(options.origin);
  const scopeUrl = publicUrl(options.scope ?? "/", origin, "scope");
  if (scopeUrl.search || !scopeUrl.pathname.endsWith("/")) throw new TypeError("scope must be a same-origin directory URL.");
  const scope = scopeUrl.pathname;
  const shell = publicUrl(options.shellUrl, origin, "shellUrl").href;
  if (!Array.isArray(options.assets) || options.assets.length === 0 || options.assets.length > 4096) throw new TypeError("assets must be a nonempty, bounded public asset list.");
  const assets = [...new Set(options.assets.map(asset => publicUrl(asset, origin, "asset").href))].sort();
  if (!assets.includes(shell)) throw new TypeError("assets must include shellUrl.");
  if (!Array.isArray(options.navigationPaths) || options.navigationPaths.length === 0 || options.navigationPaths.length > 4096) throw new TypeError("navigationPaths must be a nonempty, bounded exact-path list.");
  const navigationPaths = new Set(options.navigationPaths.map(path => {
    const url = publicUrl(path, origin, "navigation path");
    if (url.search || !url.pathname.startsWith(scope) || /[*]/.test(url.pathname)) throw new TypeError("Navigation paths must be exact paths inside the registration scope.");
    return url.pathname;
  }));
  const cacheStorage = options.cacheStorage ?? globalThis.caches;
  if (!cacheStorage) throw new TypeError("The Cache API is unavailable.");
  const fetchAsset = options.fetch ?? globalThis.fetch.bind(globalThis);
  const metadataUrl = new URL(metadataPath, origin).href;
  const manifest = { version: 1, cacheName, assets, shell, scope, navigationPaths: [...navigationPaths].sort() };
  const installingMetadata = JSON.stringify({ ...manifest, state: "installing" });
  const readyMetadata = JSON.stringify({ ...manifest, state: "ready" });
  let installing: Promise<void> | undefined;

  async function readMetadata(cache: PwaAssetCache): Promise<string | undefined> {
    const response = await cache.match(metadataUrl);
    return response?.status === 200 ? response.text() : undefined;
  }

  async function complete(cache: PwaAssetCache): Promise<boolean> {
    if (await readMetadata(cache) !== readyMetadata) return false;
    for (const asset of assets) {
      const response = await cache.match(asset);
      if (!response || !validAssetResponse(response, asset, shell)) return false;
    }
    return true;
  }

  async function readyCache(): Promise<PwaAssetCache | undefined> {
    if (!await cacheStorage.has(cacheName)) return undefined;
    const cache = await cacheStorage.open(cacheName);
    return await readMetadata(cache) === readyMetadata ? cache : undefined;
  }

  async function performInstall(): Promise<void> {
    if (await cacheStorage.has(cacheName)) {
      const existing = await cacheStorage.open(cacheName);
      const metadata = await readMetadata(existing);
      if (metadata === readyMetadata) {
        if (!await complete(existing)) throw new Error("The installed build cache is incomplete; use a new cacheName to replace it safely.");
        return;
      }
      if (metadata !== installingMetadata && (metadata !== undefined || (await existing.keys()).length !== 0)) {
        throw new Error("cacheName is already occupied by a different cache/manifest; use a unique immutable build name.");
      }
      // Recover only our own interrupted candidate (or an empty cache). Never
      // delete a complete cache, a different build, or unrelated application data.
      await cacheStorage.delete(cacheName);
    }
    const cache = await cacheStorage.open(cacheName);
    try {
      await cache.put(metadataUrl, metadataResponse(installingMetadata));
      for (const asset of assets) {
        const response = await fetchAsset(asset, { method: "GET", credentials: "omit", cache: "no-store", redirect: "error" });
        if (!validAssetResponse(response, asset, shell)) throw new Error(`The public PWA asset has an invalid status, redirect, cache policy or MIME type: ${asset}`);
        await cache.put(asset, response);
      }
      // Written last, after every body has finished entering the cache. A crash
      // before this point cannot make the candidate appear ready.
      await cache.put(metadataUrl, metadataResponse(readyMetadata));
    } catch (error) {
      try { await cacheStorage.delete(cacheName); } catch { /* An incomplete marker never reports readiness. */ }
      throw error;
    }
  }

  async function install(): Promise<void> {
    if (installing) return installing;
    const pending = performInstall();
    installing = pending;
    try { await pending; } finally { if (installing === pending) installing = undefined; }
  }

  async function isReady(): Promise<boolean> {
    try {
      if (!await cacheStorage.has(cacheName)) return false;
      return await complete(await cacheStorage.open(cacheName));
    } catch { return false; }
  }

  async function serveAsset(request: Request, url: string): Promise<Response> {
    try {
      const cache = await readyCache();
      const cached = await cache?.match(url);
      if (cached && validAssetResponse(cached, url, shell)) return cached;
    } catch { /* An unavailable cache must not prevent ordinary online loading. */ }
    // Never turn a runtime response into an undeclared or partial cache entry.
    return fetchAsset(request);
  }

  async function serveNavigation(request: Request): Promise<Response> {
    try { return await fetchAsset(request); } catch (networkError) {
      try {
        const cache = await readyCache();
        const cached = await cache?.match(shell);
        if (cached && validAssetResponse(cached, shell, shell)) return cached;
      } catch { /* Preserve the original network error when storage is unavailable. */ }
      throw networkError;
    }
  }

  function handleFetch(request: Request): Promise<Response> | undefined {
    const url = new URL(request.url);
    if (request.method !== "GET" || url.origin !== origin || excludedUrl(url) || excludedRequest(request)) return undefined;
    if (assets.includes(url.href)) return serveAsset(request, url.href);
    const document = request.mode === "navigate" || request.destination === "document";
    if (document && navigationPaths.has(url.pathname) && request.headers.get("accept")?.toLowerCase().includes("text/html")) return serveNavigation(request);
    return undefined;
  }

  return Object.freeze({ install, handleFetch, isReady });
}

function resolveOrigin(explicit: string | undefined): string {
  const value = explicit ?? globalThis.location?.origin;
  if (typeof value !== "string") throw new TypeError("origin is required outside a browser/service-worker location.");
  const url = new URL(value);
  if (!/^https?:$/.test(url.protocol) || url.username || url.password || url.pathname !== "/" || url.search || url.hash) throw new TypeError("origin must be an HTTP(S) origin without a path or credentials.");
  return url.origin;
}

function publicUrl(value: string, origin: string, label: string): URL {
  if (typeof value !== "string" || value.length === 0 || value.length > 4096 || /[\u0000-\u0020\u007f\\]/.test(value)) throw new TypeError(`${label} must be an explicit same-origin public URL.`);
  const url = new URL(value, `${origin}/`);
  if (url.origin !== origin || url.username || url.password || url.hash || excludedUrl(url)) throw new TypeError(`${label} must be a public same-origin URL outside API/auth/session/RSC routes.`);
  return url;
}

function excludedUrl(url: URL): boolean {
  let pathname: string;
  try { pathname = decodeURIComponent(url.pathname).toLowerCase(); } catch { return true; }
  if (pathname.startsWith("/.sync-engine-pwa/") || pathname.endsWith(".rsc") || pathname.endsWith(".rsc/")) return true;
  const segments = pathname.split("/");
  if (segments.some(segment => excludedSegments.has(segment))) return true;
  if (pathname.includes("/_next/data/") || pathname.includes("/__vinext/")) return true;
  let excluded = false;
  url.searchParams.forEach((_value, name) => {
    const key = name.toLowerCase();
    if (sensitiveQueries.has(key) || key.startsWith("__next") || key.startsWith("__vinext")) excluded = true;
  });
  return excluded;
}

function excludedRequest(request: Request): boolean {
  if (request.headers.has("authorization") || request.headers.has("range") || request.headers.get("accept")?.toLowerCase().includes("text/x-component")) return true;
  let excluded = false;
  request.headers.forEach((_value, name) => {
    if (name === "rsc" || name === "next-action" || name.startsWith("next-router-") || name.startsWith("x-vinext-rsc") || name.startsWith("x-vinext-action")) excluded = true;
  });
  return excluded;
}

function validAssetResponse(response: Response, asset: string, shell: string): boolean {
  if (response.status !== 200 || response.redirected || response.type === "opaque" || response.type === "opaqueredirect" || response.type === "error") return false;
  if (response.url && response.url !== asset) return false;
  if (response.headers.has("set-cookie") || /(?:^|,)\s*(?:private|no-store)\b/i.test(response.headers.get("cache-control") ?? "")) return false;
  if (response.headers.get("vary")?.split(",").some(value => ["*", "cookie", "authorization"].includes(value.trim().toLowerCase()))) return false;
  const type = response.headers.get("content-type")?.split(";", 1)[0]?.trim().toLowerCase();
  if (!type) return false;
  if (asset === shell) return type === "text/html";
  if (type === "text/html" || type === "application/xhtml+xml" || type === "text/x-component") return false;
  const extension = new URL(asset).pathname.split(".").pop()?.toLowerCase();
  if (extension === "js" || extension === "mjs") return javascriptTypes.has(type);
  const expected = extension ? mimeTypes[extension] : undefined;
  return expected ? expected.includes(type) : true;
}

function metadataResponse(body: string): Response {
  return new Response(body, { headers: { "Content-Type": "application/json" } });
}
