import { SyncError } from "../core/errors.js";
import { assertIdentifier, assertSequence } from "../core/validation.js";

/** Worker-readable bootstrap, never credentials. Authentication remains app-owned. */
export interface PwaReplicaDescriptor {
  readonly replicaKey: string;
  readonly accountId: string;
  readonly databaseName: string;
  readonly streamId: string;
  readonly clientId: string;
  readonly contractVersion: string;
  readonly modelKey: string;
  /** Build/deployment marker; omitted by callers that do not rebuild on deployment. */
  readonly deploymentVersion?: string;
}
export interface PwaReplicaRegistration extends PwaReplicaDescriptor {
  readonly enabled: boolean;
  readonly generation: number;
}
export interface PwaRegistryLockManager {
  request<Value>(name: string, options: { readonly mode: "shared" | "exclusive"; readonly signal?: AbortSignal }, run: () => Value | Promise<Value>): Promise<Value>;
}
export interface PwaRegistryChannel {
  postMessage(value: unknown): void;
  addEventListener(type: "message", listener: (event: { readonly data: unknown }) => void): void;
  close(): void;
}
export interface OpenPwaReplicaRegistryOptions {
  readonly name: string;
  readonly indexedDB?: IDBFactory;
  /** Web Locks coordinate every participating page/worker before destructive cleanup. */
  readonly locks?: PwaRegistryLockManager;
  readonly broadcastChannel?: false | ((name: string) => PwaRegistryChannel);
}
export interface PwaReplicaLease {
  readonly descriptor: PwaReplicaRegistration;
  /** Invalidation asks the owner to close/drain its engine/database before release. */
  readonly signal: AbortSignal;
  assertEnabled(): Promise<void>;
  /** Call only after owned storage transactions are drained. Idempotent. */
  release(): Promise<void>;
}
export interface PwaReplicaRegistry {
  get(replicaKey: string): Promise<PwaReplicaRegistration | undefined>;
  listEnabled(): Promise<readonly PwaReplicaRegistration[]>;
  enable(descriptor: PwaReplicaDescriptor, options?: { readonly signal?: AbortSignal }): Promise<PwaReplicaRegistration>;
  acquire(replicaKey: string, options?: { readonly signal?: AbortSignal; readonly timeoutMs?: number }): Promise<PwaReplicaLease>;
  /** Quiesce owners, prepare a replacement, then publish it; restore the retained registration on failure. */
  replace(replicaKey: string, prepare: (retained: PwaReplicaRegistration) => PwaReplicaDescriptor | Promise<PwaReplicaDescriptor>, options?: { readonly timeoutMs?: number }): Promise<PwaReplicaRegistration>;
  /** Disable first, then wait for all cooperating leases before optional cleanup. */
  disable(replicaKey: string, options?: { readonly timeoutMs?: number; readonly cleanup?: (descriptor: PwaReplicaRegistration) => void | Promise<void> }): Promise<void>;
  /** Abort lease signals; owners must still drain resources and release their leases. */
  close(): void;
}
export type PwaRegistryErrorCode = "disabled" | "stale-generation" | "locks-unavailable" | "timeout";
export class PwaRegistryError extends Error {
  readonly code: PwaRegistryErrorCode;
  constructor(code: PwaRegistryErrorCode, message: string) { super(message); this.name = "PwaRegistryError"; this.code = code; }
}

const requiredFields = ["replicaKey", "accountId", "databaseName", "streamId", "clientId", "contractVersion", "modelKey"] as const;
const fields = [...requiredFields, "deploymentVersion"] as const;
function descriptor(value: PwaReplicaDescriptor): PwaReplicaDescriptor {
  if (!value || typeof value !== "object" || Object.keys(value).some(key => !fields.includes(key as typeof fields[number]))) {
    throw new SyncError("invalid-input", "Expected only public replica descriptor fields.");
  }
  const result = {} as Record<typeof requiredFields[number], string> & { deploymentVersion?: string };
  for (const key of requiredFields) { assertIdentifier(value[key], key); result[key] = value[key]; }
  if (value.deploymentVersion !== undefined) {
    if (typeof value.deploymentVersion !== "string" || !/^[A-Za-z0-9_.:/-]{1,128}$/.test(value.deploymentVersion)) throw new SyncError("invalid-input", "Invalid deployment version.");
    result.deploymentVersion = value.deploymentVersion;
  }
  return result;
}
function record(value: unknown): PwaReplicaRegistration | undefined {
  if (value === undefined) return undefined;
  if (!value || typeof value !== "object") throw new SyncError("corrupt-state", "Invalid PWA bootstrap record.");
  const input = value as PwaReplicaRegistration;
  if (Object.keys(input).some(key => ![...fields, "enabled", "generation"].includes(key))) throw new SyncError("corrupt-state", "Unknown PWA bootstrap fields.");
  const data = descriptor(Object.fromEntries(fields.filter(key => input[key] !== undefined).map(key => [key, input[key]])) as unknown as PwaReplicaDescriptor);
  assertSequence(input.generation, "bootstrap generation", 1);
  if (typeof input.enabled !== "boolean") throw new SyncError("corrupt-state", "Invalid PWA bootstrap enablement.");
  return { ...data, generation: input.generation, enabled: input.enabled };
}
function request<Value>(operation: IDBRequest<Value>): Promise<Value> {
  return new Promise((resolve, reject) => { operation.onsuccess = () => resolve(operation.result); operation.onerror = () => reject(operation.error); });
}
function completed(transaction: IDBTransaction): Promise<void> {
  const result = new Promise<void>((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onabort = () => reject(transaction.error ?? new SyncError("closed", "PWA bootstrap transaction aborted."));
  });
  void result.catch(() => undefined);
  return result;
}
function waitOptions(signal: AbortSignal | undefined, timeoutMs: number | undefined, lifetime: AbortSignal) {
  if (timeoutMs !== undefined) {
    assertSequence(timeoutMs, "lock timeout", 1);
    if (timeoutMs > 300_000) throw new SyncError("invalid-input", "Lock timeout exceeds five minutes.");
  }
  const controller = new AbortController();
  const abort = () => controller.abort(signal?.reason);
  const close = () => controller.abort(lifetime.reason);
  signal?.addEventListener("abort", abort, { once: true });
  lifetime.addEventListener("abort", close, { once: true });
  if (signal?.aborted) abort();
  if (lifetime.aborted) close();
  const timer = timeoutMs === undefined ? undefined : setTimeout(() => controller.abort(new PwaRegistryError("timeout", "Timed out waiting for PWA replica owners to quiesce.")), timeoutMs);
  return { signal: controller.signal, clear() { clearTimeout(timer); signal?.removeEventListener("abort", abort); lifetime.removeEventListener("abort", close); } };
}

/** Separate bootstrap database: does not change the existing replica schema. */
export async function openPwaReplicaRegistry(options: OpenPwaReplicaRegistryOptions): Promise<PwaReplicaRegistry> {
  assertIdentifier(options.name, "PWA registry name");
  const registryName = options.name;
  const factory = options.indexedDB ?? globalThis.indexedDB;
  if (!factory) throw new SyncError("invalid-input", "IndexedDB is required for PWA bootstrap.");
  const locks = options.locks ?? globalThis.navigator?.locks;
  const lifetime = new AbortController();
  let closed = false;
  const opening = factory.open(registryName, 1);
  opening.onupgradeneeded = () => { opening.result.createObjectStore("replicas", { keyPath: "replicaKey" }); };
  const database = await request(opening);
  const leases = new Set<{ descriptor: PwaReplicaRegistration; controller: AbortController }>();
  let channel: PwaRegistryChannel | undefined;
  function assertOpen() { if (closed) throw new SyncError("closed", "PWA registry is closed."); }
  const lockName = (key: string) => `sync-engine:pwa:${JSON.stringify([registryName, key])}`;
  function requireLocks(): PwaRegistryLockManager {
    if (!locks) throw new PwaRegistryError("locks-unavailable", "Coordinated PWA sessions require Web Locks; use the foreground client or an application-provided durable gate.");
    return locks;
  }
  async function get(key: string): Promise<PwaReplicaRegistration | undefined> {
    assertOpen(); assertIdentifier(key, "replica key");
    const transaction = database.transaction("replicas", "readonly");
    const done = completed(transaction);
    const value = record(await request(transaction.objectStore("replicas").get(key)));
    await done;
    return value;
  }
  async function change(key: string, update: (current: PwaReplicaRegistration | undefined) => PwaReplicaRegistration | undefined) {
    assertOpen();
    const transaction = database.transaction("replicas", "readwrite");
    const done = completed(transaction);
    try {
      const store = transaction.objectStore("replicas");
      const current = record(await request(store.get(key)));
      const next = update(current);
      if (next) await request(store.put(next));
      await done;
      return next;
    } catch (error) { try { transaction.abort(); } catch {} await done.catch(() => undefined); throw error; }
  }
  async function invalidate(key: string) {
    const matching = [...leases].filter(lease => lease.descriptor.replicaKey === key);
    if (matching.length === 0) return;
    try {
      const current = await get(key);
      for (const lease of matching) if (!current?.enabled || current.generation !== lease.descriptor.generation) {
        lease.controller.abort(new PwaRegistryError("disabled", "PWA replica has been disabled or replaced."));
      }
    } catch (error) { for (const lease of matching) lease.controller.abort(error); }
  }
  function notify(key: string) {
    void invalidate(key);
    try { channel?.postMessage({ replicaKey: key }); } catch { /* A lost hint cannot bypass the exclusive cleanup barrier. */ }
  }
  function close() {
    if (closed) return;
    closed = true;
    lifetime.abort(new SyncError("closed", "PWA registry closed."));
    for (const lease of leases) lease.controller.abort(new SyncError("closed", "PWA registry closed."));
    channel?.close(); database.close();
  }
  database.onversionchange = close;
  database.onclose = close;
  try {
    const createChannel = options.broadcastChannel === false ? undefined : options.broadcastChannel ??
      (typeof globalThis.BroadcastChannel === "function" ? (name: string) => new BroadcastChannel(name) : undefined);
    channel = createChannel?.(`sync-engine:pwa-registry:${registryName}`);
    channel?.addEventListener("message", event => {
      const key = (event.data as { replicaKey?: unknown } | null)?.replicaKey;
      if (!closed && typeof key === "string" && key.length > 0 && key.length <= 1024) void invalidate(key);
    });
  } catch { /* Invalidation is advisory; Web Locks still prevent unsafe cleanup. */ }
  return {
    get,
    async listEnabled() {
      assertOpen();
      const transaction = database.transaction("replicas", "readonly");
      const done = completed(transaction);
      const values = await request(transaction.objectStore("replicas").getAll(undefined, 257));
      await done;
      if (values.length > 256) throw new SyncError("limit-exceeded", "PWA bootstrap registry exceeds 256 configured replicas.");
      return values.map(value => record(value)!).filter(value => value.enabled);
    },
    async enable(input, configuration = {}) {
      assertOpen();
      const data = descriptor(input);
      const before = await get(data.replicaKey);
      assertOpen();
      if (configuration.signal?.aborted) throw configuration.signal.reason;
      if (before?.enabled && fields.every(key => before[key] === data[key])) return before;
      const manager = requireLocks();
      const waiting = waitOptions(configuration.signal, undefined, lifetime.signal);
      try {
        return await manager.request(lockName(data.replicaKey), { mode: "exclusive", signal: waiting.signal }, async () => {
          assertOpen();
          waiting.clear();
          const next = await change(data.replicaKey, current => {
            const generation = (current?.generation ?? 0) + 1;
            assertSequence(generation, "bootstrap generation", 1);
            return { ...data, enabled: true, generation };
          });
          assertOpen();
          notify(data.replicaKey);
          return next!;
        });
      } catch (error) { throw waiting.signal.aborted ? waiting.signal.reason : error; }
      finally { waiting.clear(); }
    },
    async acquire(key, configuration = {}) {
      assertOpen(); assertIdentifier(key, "replica key");
      const manager = requireLocks();
      const waiting = waitOptions(configuration.signal, configuration.timeoutMs ?? 30_000, lifetime.signal);
      let resolveReady!: (value: PwaReplicaLease) => void;
      let rejectReady!: (reason: unknown) => void;
      const ready = new Promise<PwaReplicaLease>((resolve, reject) => { resolveReady = resolve; rejectReady = reject; });
      let unlock!: () => void;
      const held = new Promise<void>(resolve => { unlock = resolve; });
      const lock = Promise.resolve().then(() => manager.request(lockName(key), { mode: "shared", signal: waiting.signal }, async () => {
        const current = await get(key);
        // Closing or cancellation can happen while the native bootstrap read is
        // pending, after Web Locks has already granted the shared lock.
        assertOpen();
        if (waiting.signal.aborted) throw waiting.signal.reason;
        if (!current?.enabled) throw new PwaRegistryError("disabled", "PWA replica bootstrap is missing or disabled.");
        const controller = new AbortController();
        const entry = { descriptor: current, controller };
        leases.add(entry);
        const externalAbort = () => controller.abort(configuration.signal?.reason);
        configuration.signal?.addEventListener("abort", externalAbort, { once: true });
        if (configuration.signal?.aborted) externalAbort();
        let released = false;
        resolveReady({
          descriptor: Object.freeze({ ...current }), signal: controller.signal,
          async assertEnabled() {
            if (released) throw new SyncError("closed", "PWA replica lease is released.");
            if (controller.signal.aborted) throw controller.signal.reason;
            const value = await get(key);
            if (released) throw new SyncError("closed", "PWA replica lease is released.");
            if (controller.signal.aborted) throw controller.signal.reason;
            if (!value?.enabled || value.generation !== current.generation) {
              controller.abort(new PwaRegistryError("stale-generation", "PWA replica generation changed."));
              throw controller.signal.reason;
            }
          },
          async release() { if (!released) { released = true; unlock(); } await lock; },
        });
        waiting.clear();
        try { await held; }
        finally { leases.delete(entry); configuration.signal?.removeEventListener("abort", externalAbort); }
      }));
      void lock.catch(error => { waiting.clear(); rejectReady(waiting.signal.aborted ? waiting.signal.reason : error); });
      return ready;
    },
    async replace(key, prepare, configuration = {}) {
      assertOpen(); assertIdentifier(key, "replica key");
      if (typeof prepare !== "function") throw new TypeError("Replacement preparation is required.");
      const manager = requireLocks();
      let retained: PwaReplicaRegistration | undefined;
      let disabled: PwaReplicaRegistration | undefined;
      // Validate the wait budget before changing durable enablement.
      const waiting = waitOptions(undefined, configuration.timeoutMs ?? 30_000, lifetime.signal);
      try {
        disabled = await change(key, current => {
          if (!current) throw new PwaRegistryError("disabled", "PWA replica bootstrap is missing.");
          retained = current;
          const generation = current.generation + 1;
          assertSequence(generation, "bootstrap generation", 1);
          return { ...current, enabled: false, generation };
        });
        notify(key);
        return await manager.request(lockName(key), { mode: "exclusive", signal: waiting.signal }, async () => {
          waiting.clear();
          const current = await get(key);
          assertOpen();
          if (!current || current.enabled || current.generation !== disabled!.generation) throw new PwaRegistryError("stale-generation", "PWA replica changed while preparing replacement.");
          const data = descriptor(await prepare(Object.freeze({ ...retained! })));
          if (data.replicaKey !== key) throw new TypeError("A replacement must keep the same replica key.");
          const next = await change(key, value => {
            if (!value || value.enabled || value.generation !== disabled!.generation) throw new PwaRegistryError("stale-generation", "PWA replica changed before replacement was published.");
            const generation = value.generation + 1;
            assertSequence(generation, "bootstrap generation", 1);
            return { ...data, enabled: true, generation };
          });
          notify(key);
          return next!;
        });
      } catch (error) {
        // Retain the database/identity, including all pending work. A failed
        // snapshot never leaves an empty replacement registered as current.
        if (disabled && !closed) {
          await change(key, current => {
            if (!current || current.enabled || current.generation !== disabled!.generation) return current;
            const generation = current.generation + 1;
            assertSequence(generation, "bootstrap generation", 1);
            return { ...retained!, generation };
          });
          notify(key);
        }
        throw waiting.signal.aborted ? waiting.signal.reason : error;
      } finally { waiting.clear(); }
    },
    async disable(key, configuration = {}) {
      assertOpen(); assertIdentifier(key, "replica key");
      const disabled = await change(key, current => {
        if (!current || !current.enabled) return current;
        const generation = current.generation + 1;
        assertSequence(generation, "bootstrap generation", 1);
        return { ...current, enabled: false, generation };
      });
      notify(key);
      if (!disabled) return;
      const manager = requireLocks();
      const waiting = waitOptions(undefined, configuration.timeoutMs ?? 30_000, lifetime.signal);
      try {
        await manager.request(lockName(key), { mode: "exclusive", signal: waiting.signal }, async () => {
          waiting.clear();
          const current = await get(key);
          assertOpen();
          if (!current || current.enabled || current.generation !== disabled.generation) throw new PwaRegistryError("stale-generation", "PWA replica was replaced while waiting for cleanup.");
          await configuration.cleanup?.(Object.freeze({ ...disabled }));
        });
      } catch (error) { throw waiting.signal.aborted ? waiting.signal.reason : error; }
      finally { waiting.clear(); }
    },
    close,
  };
}
