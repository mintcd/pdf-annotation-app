import { SyncTransportError } from "../client/errors.js";
import type { SyncResult, SyncRunOptions } from "../client/types.js";
import { SyncError } from "../core/errors.js";
import type { SyncErrorCode } from "../core/errors.js";
import type { SyncTransportErrorCode } from "../client/errors.js";

export const SYNC_WORKER_PROTOCOL = "sync-engine:pwa";
export const SYNC_WORKER_VERSION = 1;
export type PwaSyncErrorCode = "invalid-message" | "unsupported-version" | "contract-mismatch" | "unknown-replica" | "unavailable" | "timeout" | "closed" | "aborted" | "busy" | "execution-failed";
/** Availability failures permit foreground fallback; execution failures do not. */
export class PwaSyncError extends Error {
  readonly code: PwaSyncErrorCode;
  constructor(code: PwaSyncErrorCode, message: string, options?: ErrorOptions) { super(message, options); this.name = "PwaSyncError"; this.code = code; }
}
export interface SyncWorkerRequest {
  readonly type: typeof SYNC_WORKER_PROTOCOL;
  readonly version: typeof SYNC_WORKER_VERSION;
  readonly contractVersion: string;
  readonly replicaKey: string;
  readonly id: string;
  readonly command: "hello" | "sync";
  readonly options?: SyncRunOptions;
}
export interface SyncWorkerFailure {
  readonly kind: "worker" | "transport" | "protocol";
  readonly code: string;
  readonly retryAfterMs?: number;
}
export interface SyncWorkerReply {
  readonly type: typeof SYNC_WORKER_PROTOCOL;
  readonly version: typeof SYNC_WORKER_VERSION;
  readonly contractVersion: string;
  readonly replicaKey: string;
  readonly id: string;
  readonly ok: boolean;
  readonly shellReady?: boolean;
  readonly result?: SyncResult;
  readonly error?: SyncWorkerFailure;
}
const transportCodes = ["network", "timeout", "aborted", "access", "rate-limit", "invalid-response"] as const;
const protocolCodes = ["invalid-input", "unsupported-version", "contract-mismatch", "stream-mismatch", "invalid-cursor", "identity-conflict", "divergence", "commit-conflict", "closed", "limit-exceeded", "corrupt-state"] as const;
const workerCodes = ["invalid-message", "unsupported-version", "contract-mismatch", "unknown-replica", "unavailable", "timeout", "closed", "aborted", "busy", "execution-failed"] as const;

export function pwaIdentifier(value: unknown, label: string, maximum = 128): asserts value is string {
  if (typeof value !== "string" || !value || value.length > maximum || /[\u0000-\u001f\u007f]/u.test(value)) throw new PwaSyncError("invalid-message", `${label} must be a nonempty bounded identifier.`);
}
export function pwaDuration(value: unknown, fallback: number, label: string): number {
  const duration = value ?? fallback;
  if (typeof duration !== "number" || !Number.isSafeInteger(duration) || duration < 1 || duration > 2_147_483_647) throw new PwaSyncError("invalid-message", `${label} must be a positive bounded integer.`);
  return duration;
}
function object(value: unknown, allowed: readonly string[]): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value) || Object.keys(value).some(key => !allowed.includes(key))) throw new PwaSyncError("invalid-message", "Invalid worker message fields.");
  return value as Record<string, unknown>;
}
function envelope(value: Record<string, unknown>): void {
  if (value.type !== SYNC_WORKER_PROTOCOL) throw new PwaSyncError("invalid-message", "Unrecognized worker message.");
  if (value.version !== SYNC_WORKER_VERSION) throw new PwaSyncError("unsupported-version", "Unsupported worker message version.");
  pwaIdentifier(value.contractVersion, "contractVersion", 256); pwaIdentifier(value.replicaKey, "replicaKey"); pwaIdentifier(value.id, "id");
}
export function isSyncWorkerMessage(value: unknown): boolean { return !!value && typeof value === "object" && (value as { type?: unknown }).type === SYNC_WORKER_PROTOCOL; }
export function decodeSyncWorkerRequest(input: unknown): SyncWorkerRequest {
  const value = object(input, ["type", "version", "contractVersion", "replicaKey", "id", "command", "options"]); envelope(value);
  if (value.command !== "hello" && value.command !== "sync") throw new PwaSyncError("invalid-message", "Unknown worker command.");
  if (value.command === "hello" && value.options !== undefined) throw new PwaSyncError("invalid-message", "Handshake cannot contain run options.");
  return { type: SYNC_WORKER_PROTOCOL, version: SYNC_WORKER_VERSION, contractVersion: value.contractVersion as string, replicaKey: value.replicaKey as string, id: value.id as string, command: value.command, ...(value.options === undefined ? {} : { options: decodeSyncWorkerRunOptions(value.options) }) };
}
export function decodeSyncWorkerRunOptions(input: unknown): SyncRunOptions {
  const value = object(input, ["maximumRounds", "maximumDurationMs", "requestTimeoutMs", "maximumProposals", "maximumEntries", "retry"]);
  for (const key of Object.keys(value)) {
    if (key === "retry") continue;
    const minimum = key === "maximumProposals" ? 0 : 1;
    if (typeof value[key] !== "number" || !Number.isSafeInteger(value[key]) || (value[key] as number) < minimum || (value[key] as number) > 2_147_483_647) throw new PwaSyncError("invalid-message", "Invalid worker run bound.");
  }
  if (value.retry !== undefined) {
    const retry = object(value.retry, ["maximumRetries", "initialDelayMs", "maximumDelayMs", "jitterRatio"]);
    for (const key of Object.keys(retry)) if (typeof retry[key] !== "number" || !Number.isFinite(retry[key]) || (key === "jitterRatio" ? (retry[key] as number) < 0 || (retry[key] as number) > 1 : !Number.isSafeInteger(retry[key]) || (retry[key] as number) < 0 || (retry[key] as number) > 2_147_483_647)) throw new PwaSyncError("invalid-message", "Invalid worker retry bound.");
  }
  return structuredClone(value) as SyncRunOptions;
}
function count(value: unknown): value is number { return typeof value === "number" && Number.isSafeInteger(value) && value >= 0; }
function result(input: unknown): SyncResult {
  const value = object(input, ["status", "rounds", "attempts", "retries", "reason"]);
  const status = object(value.status, ["streamId", "clientId", "revision", "confirmedSequence", "headSequence", "nextClientSequence", "pendingCount", "acceptedAwaitingCount", "resolutionCount"]);
  pwaIdentifier(status.streamId, "streamId", 1024); pwaIdentifier(status.clientId, "clientId", 1024);
  for (const key of ["revision", "confirmedSequence", "headSequence", "nextClientSequence", "pendingCount", "acceptedAwaitingCount", "resolutionCount"]) if (!count(status[key])) throw new PwaSyncError("invalid-message", "Invalid replica status.");
  if (!count(value.rounds) || !count(value.attempts) || !count(value.retries) || !["settled", "round-budget", "time-budget", "no-progress"].includes(value.reason as string)) throw new PwaSyncError("invalid-message", "Invalid worker progress.");
  return structuredClone(value) as unknown as SyncResult;
}
export function decodeSyncWorkerReply(input: unknown, request: SyncWorkerRequest): SyncWorkerReply {
  const value = object(input, ["type", "version", "contractVersion", "replicaKey", "id", "ok", "shellReady", "result", "error"]); envelope(value);
  if (value.contractVersion !== request.contractVersion) throw new PwaSyncError("contract-mismatch", "Worker contract does not match the page.");
  if (value.id !== request.id || value.replicaKey !== request.replicaKey || typeof value.ok !== "boolean") throw new PwaSyncError("invalid-message", "Worker reply does not match the request.");
  if (value.ok) {
    if (value.error !== undefined || (request.command === "hello" ? typeof value.shellReady !== "boolean" || value.result !== undefined : value.result === undefined || value.shellReady !== undefined)) throw new PwaSyncError("invalid-message", "Invalid worker success reply.");
    return { ...request, ok: true, ...(request.command === "hello" ? { shellReady: value.shellReady as boolean } : { result: result(value.result) }) };
  }
  if (value.result !== undefined || value.shellReady !== undefined) throw new PwaSyncError("invalid-message", "Invalid worker failure reply.");
  const error = object(value.error, ["kind", "code", "retryAfterMs"]);
  const allowed: readonly string[] = error.kind === "worker" ? workerCodes : error.kind === "transport" ? transportCodes : error.kind === "protocol" ? protocolCodes : [];
  if (typeof error.code !== "string" || !allowed.includes(error.code) || (error.retryAfterMs !== undefined && (typeof error.retryAfterMs !== "number" || !Number.isFinite(error.retryAfterMs) || error.retryAfterMs < 0))) throw new PwaSyncError("invalid-message", "Invalid worker error.");
  return { ...request, ok: false, error: error as unknown as SyncWorkerFailure };
}
/** Errors carry stable classifications only, never application stacks or credentials. */
export function encodeSyncWorkerFailure(error: unknown): SyncWorkerFailure {
  if (error instanceof SyncTransportError) return { kind: "transport", code: error.code, ...(error.retryAfterMs === undefined ? {} : { retryAfterMs: error.retryAfterMs }) };
  if (error instanceof SyncError) return { kind: "protocol", code: error.code };
  return { kind: "worker", code: error instanceof PwaSyncError ? error.code : "execution-failed" };
}
export function syncWorkerFailure(error: SyncWorkerFailure): Error {
  if (error.kind === "transport") return new SyncTransportError(error.code as SyncTransportErrorCode, "Worker synchronization failed.", error.retryAfterMs === undefined ? undefined : { retryAfterMs: error.retryAfterMs });
  if (error.kind === "protocol") return new SyncError(error.code as SyncErrorCode, "Worker synchronization failed.");
  return new PwaSyncError(error.code as PwaSyncErrorCode, "The synchronization worker could not complete the request.");
}
export function syncWorkerTag(replicaKey: string): string { pwaIdentifier(replicaKey, "replicaKey"); return `${SYNC_WORKER_PROTOCOL}:${encodeURIComponent(replicaKey)}`; }
