import { createSyncEngine } from "../client/engine.js";
import { createCollectionAccess } from "../client/collections.js";
import type { SyncCollectionDefinitions } from "../client/collections.js";
import type { CreateSyncEngineOptions, SyncEngine, SyncOptions, SyncResult, SyncRunOptions } from "../client/types.js";
import type { RecordSchema } from "../records/types.js";
import { PwaSyncError, SYNC_WORKER_PROTOCOL, SYNC_WORKER_VERSION, decodeSyncWorkerReply, decodeSyncWorkerRunOptions, pwaDuration, pwaIdentifier, syncWorkerFailure, syncWorkerTag } from "./protocol.js";
import type { SyncWorkerReply, SyncWorkerRequest } from "./protocol.js";
export { PwaSyncError, syncWorkerTag } from "./protocol.js";

/** Structural types keep service-worker container/window globals out of the API. */
export interface PwaWorkerTarget { postMessage(message: unknown, transfer: Transferable[]): void }
export interface PwaWorkerRegistration {
  readonly active: PwaWorkerTarget | null;
  readonly sync?: { register(tag: string): Promise<void> };
}
export interface PwaWorkerOptions {
  readonly replicaKey: string;
  readonly contractVersion: string;
  readonly getRegistration?: () => PwaWorkerRegistration | undefined | Promise<PwaWorkerRegistration | undefined>;
  readonly handshakeTimeoutMs?: number;
  readonly responseTimeoutMs?: number;
}
export interface PwaWorkerSnapshot {
  readonly availability: "unknown" | "available" | "unavailable" | "closed";
  readonly phase: "idle" | "syncing" | "error";
  readonly shellReady: boolean;
  readonly mode?: "worker" | "foreground";
  readonly lastError?: unknown;
}
export interface CreatePwaSyncEngineOptions<Schema extends RecordSchema, Intent, Operation, Rejection, Collections extends SyncCollectionDefinitions<Schema, Intent> | undefined = undefined> extends CreateSyncEngineOptions<Schema, Intent, Operation, Rejection, Collections> {
  readonly worker: PwaWorkerOptions;
  /** Defaults to browser online events when available. No polling is installed. */
  readonly subscribeReconnect?: (listener: () => void) => () => void;
  /** The app retains its account lease until engine/database writes are drained. */
  readonly lifecycle?: { readonly signal?: AbortSignal; readonly assertEnabled?: () => void | Promise<void> };
}
export interface PwaSyncEngine<Schema extends RecordSchema, Intent, Operation, Rejection, Collections extends SyncCollectionDefinitions<Schema, Intent> | undefined = undefined> extends SyncEngine<Schema, Intent, Operation, Rejection, Collections> {
  /** Observations only; shellReady is not complete offline readiness or installability. */
  getWorkerSnapshot(): PwaWorkerSnapshot;
  subscribeWorker(listener: (snapshot: PwaWorkerSnapshot) => void): () => void;
}
function aborted(): PwaSyncError { return new PwaSyncError("aborted", "The page stopped waiting for synchronization."); }
function race<Value>(work: Promise<Value>, signal: AbortSignal): Promise<Value> {
  if (signal.aborted) { void work.catch(() => undefined); return Promise.reject(aborted()); }
  return new Promise((resolve, reject) => {
    const cancel = () => { signal.removeEventListener("abort", cancel); reject(aborted()); };
    signal.addEventListener("abort", cancel, { once: true });
    work.then(value => { signal.removeEventListener("abort", cancel); resolve(value); }, error => { signal.removeEventListener("abort", cancel); reject(error); });
  });
}
async function bounded<Value>(work: Promise<Value>, duration: number, signal: AbortSignal): Promise<Value> {
  let timer: ReturnType<typeof setTimeout> | undefined;
  try { return await race(Promise.race([work, new Promise<never>((_, reject) => { timer = setTimeout(() => reject(new PwaSyncError("timeout", "The worker did not respond within its budget.")), duration); })]), signal); }
  finally { clearTimeout(timer); }
}
function browserRegistration(): Promise<PwaWorkerRegistration | undefined> {
  const browser = globalThis as { navigator?: { serviceWorker?: { getRegistration(): Promise<PwaWorkerRegistration | undefined> } } };
  return browser.navigator?.serviceWorker?.getRegistration() ?? Promise.resolve(undefined);
}
function browserReconnect(listener: () => void): () => void {
  if (typeof globalThis.addEventListener !== "function") return () => undefined;
  globalThis.addEventListener("online", listener);
  return () => globalThis.removeEventListener("online", listener);
}
function fallback(error: unknown): boolean {
  return error instanceof PwaSyncError && ["unavailable", "timeout", "invalid-message", "unsupported-version", "contract-mismatch", "unknown-replica", "busy", "closed"].includes(error.code);
}

/** Local-first facade; automatic startup/reconnect work defaults to enabled. */
export async function createPwaSyncEngine<Schema extends RecordSchema, Intent, Operation, Rejection, Collections extends SyncCollectionDefinitions<Schema, Intent> | undefined = undefined>(options: CreatePwaSyncEngineOptions<Schema, Intent, Operation, Rejection, Collections>): Promise<PwaSyncEngine<Schema, Intent, Operation, Rejection, Collections>> {
  pwaIdentifier(options.worker.replicaKey, "replicaKey"); pwaIdentifier(options.worker.contractVersion, "contractVersion", 256);
  const worker = { ...options.worker };
  const handshakeDuration = pwaDuration(worker.handshakeTimeoutMs, 1_000, "handshakeTimeoutMs");
  const responseDuration = pwaDuration(worker.responseTimeoutMs, 45_000, "responseTimeoutMs");
  const automatic = options.autoSync ?? true;
  const lifecycle = options.lifecycle === undefined ? undefined : { ...options.lifecycle };
  const baseSyncOptions = options.syncOptions === undefined ? undefined : decodeSyncWorkerRunOptions(options.syncOptions);
  if (typeof automatic !== "boolean") throw new PwaSyncError("invalid-message", "autoSync must be a boolean.");
  if (lifecycle?.signal?.aborted) throw new PwaSyncError("closed", "The replica is disabled.");
  const initialCheck = Promise.resolve().then(() => {
    if (lifecycle?.signal?.aborted) throw new PwaSyncError("closed", "The replica is disabled.");
    return lifecycle?.assertEnabled?.();
  });
  if (lifecycle?.signal) await race(initialCheck, lifecycle.signal);
  else await initialCheck;
  if (lifecycle?.signal?.aborted) throw new PwaSyncError("closed", "The replica is disabled.");
  const inner = await createSyncEngine({ ...options, autoSync: false });
  const lifetime = new AbortController();
  let closed = false;
  let closePromise: Promise<void> | undefined;
  let active: { controller: AbortController; promise: Promise<SyncResult>; followup: boolean } | undefined;
  let scheduled = false;
  let sequence = inner.getSnapshot().replica.nextClientSequence;
  let identifier = 0;
  let observation: PwaWorkerSnapshot = Object.freeze({ availability: "unknown", phase: "idle", shellReady: false });
  const listeners = new Set<(value: PwaWorkerSnapshot) => void>();
  let unsubscribeEngine: (() => void) | undefined;
  let unsubscribeReconnect: (() => void) | undefined;
  let removeLifecycle: (() => void) | undefined;
  function assertOpen(): void { if (closed) throw new PwaSyncError("closed", "The PWA engine is closed."); }
  async function assertLifecycle(signal: AbortSignal): Promise<void> {
    if (signal.aborted) throw aborted();
    await race(Promise.resolve().then(() => {
      if (signal.aborted) throw aborted();
      return lifecycle?.assertEnabled?.();
    }), signal);
    if (signal.aborted) throw aborted();
  }
  function observe(change: Partial<PwaWorkerSnapshot>, clearError = false): void {
    if (closed && change.availability !== "closed") return;
    observation = Object.freeze({ ...observation, ...(clearError ? { lastError: undefined } : {}), ...change });
    for (const listener of listeners) { try { listener(observation); } catch { /* Status observers cannot affect persistence. */ } }
  }
  function request(command: "hello" | "sync", runOptions?: SyncRunOptions): SyncWorkerRequest {
    return { type: SYNC_WORKER_PROTOCOL, version: SYNC_WORKER_VERSION, contractVersion: worker.contractVersion, replicaKey: worker.replicaKey, id: `${Date.now().toString(36)}-${++identifier}`, command, ...(runOptions === undefined ? {} : { options: runOptions }) };
  }
  function exchange(target: PwaWorkerTarget, message: SyncWorkerRequest, duration: number, signal: AbortSignal): Promise<SyncWorkerReply> {
    if (signal.aborted) return Promise.reject(aborted());
    if (typeof globalThis.MessageChannel !== "function") return Promise.reject(new PwaSyncError("unavailable", "Message channels are unavailable."));
    const channel = new MessageChannel();
    let remove: (() => void) | undefined;
    const work = new Promise<SyncWorkerReply>((resolve, reject) => {
      const listener = (event: MessageEvent<unknown>) => {
        try { resolve(decodeSyncWorkerReply(event.data, message)); } catch (error) { reject(error); }
      };
      channel.port1.addEventListener("message", listener);
      remove = () => channel.port1.removeEventListener("message", listener);
      channel.port1.start();
      try { target.postMessage(message, [channel.port2]); }
      catch (cause) { reject(new PwaSyncError("unavailable", "The worker could not receive the request.", { cause })); }
    });
    return bounded(work, duration, signal).finally(() => { remove?.(); channel.port1.close(); channel.port2.close(); });
  }
  async function workerSync(runOptions: SyncRunOptions | undefined, signal: AbortSignal): Promise<SyncResult> {
    let registration: PwaWorkerRegistration | undefined;
    try { registration = await bounded(Promise.resolve().then(worker.getRegistration ?? browserRegistration), handshakeDuration, signal); }
    catch (cause) { if (cause instanceof PwaSyncError) throw cause; throw new PwaSyncError("unavailable", "Worker registration lookup failed.", { cause }); }
    const target = registration?.active;
    if (!registration || !target) throw new PwaSyncError("unavailable", "No active synchronization worker is available.");
    const hello = await exchange(target, request("hello"), handshakeDuration, signal);
    if (!hello.ok) throw syncWorkerFailure(hello.error!);
    observe({ availability: "available", shellReady: hello.shellReady!, mode: "worker" });
    if (signal.aborted) throw aborted();
    // Registering is a best-effort wake-up, never part of the local commit result.
    try { await bounded(Promise.resolve().then(() => { if (signal.aborted) throw aborted(); return registration!.sync?.register(syncWorkerTag(worker.replicaKey)); }), handshakeDuration, signal); }
    catch { /* Explicit event execution and foreground recovery remain available. */ }
    const reply = await exchange(target, request("sync", runOptions), responseDuration, signal);
    if (!reply.ok) throw syncWorkerFailure(reply.error!);
    // A message is never authoritative local state: reread IndexedDB through the replica.
    const status = (await inner.status()).replica;
    return { ...reply.result!, status };
  }
  function schedule(): void {
    if (!automatic || closed || scheduled) return;
    if (active) { active.followup = true; return; }
    scheduled = true;
    queueMicrotask(() => { scheduled = false; if (!closed) void synchronize().catch(() => undefined); });
  }
  async function execute(runOptions: SyncRunOptions | undefined, signal: AbortSignal): Promise<SyncResult> {
    try {
      await assertLifecycle(signal);
      observe({ phase: "syncing" }, true);
      let value: SyncResult;
      try { value = await workerSync(runOptions, signal); }
      catch (error) {
        if (signal.aborted || !fallback(error)) throw error;
        observe({ availability: "unavailable", shellReady: false, mode: "foreground", lastError: error });
        await assertLifecycle(signal);
        value = await inner.sync({ ...runOptions, signal });
      }
      observe({ phase: "idle" }, true);
      return value;
    } catch (error) { observe({ phase: "error", lastError: error }); throw error; }
  }
  function synchronize(input?: SyncOptions): Promise<SyncResult> {
    try {
      assertOpen();
      if (input?.signal?.aborted) return Promise.reject(aborted());
      const { signal, ...rawOptions } = input ?? {};
      const explicit = Object.keys(rawOptions).length === 0 ? undefined : decodeSyncWorkerRunOptions(rawOptions);
      const runOptions = baseSyncOptions === undefined && explicit === undefined ? undefined : {
        ...baseSyncOptions, ...explicit, retry: { ...baseSyncOptions?.retry, ...explicit?.retry },
      };
      if (!active) {
        const work = { controller: new AbortController(), promise: undefined as unknown as Promise<SyncResult>, followup: false };
        active = work;
        let completed = false;
        work.promise = Promise.resolve().then(() => execute(runOptions, work.controller.signal)).then(value => { completed = true; return value; }).finally(() => {
          if (active === work) active = undefined;
          if (completed && work.followup) schedule();
        });
        void work.promise.catch(() => undefined);
      }
      return signal ? race(active.promise, signal) : active.promise;
    } catch (error) { return Promise.reject(error); }
  }
  const engine: PwaSyncEngine<Schema, Intent, Operation, Rejection, Collections> = {
    ...inner,
    from: createCollectionAccess<Schema, Intent, Collections>(() => engine, options.collections),
    async mutate(intent, input) {
      const capturedIntent = structuredClone(intent);
      const capturedInput = input === undefined ? undefined : structuredClone(input);
      assertOpen(); await assertLifecycle(lifetime.signal); assertOpen();
      const receipt = await inner.mutate(capturedIntent, capturedInput);
      // Scheduling cannot reject an already successful local commit.
      if (sequence <= receipt.clientSequence) schedule();
      return receipt;
    },
    sync: synchronize,
    getWorkerSnapshot() { return observation; },
    subscribeWorker(listener) {
      assertOpen(); if (typeof listener !== "function") throw new PwaSyncError("invalid-message", "A worker observer must be a function.");
      listeners.add(listener); return () => listeners.delete(listener);
    },
    close() {
      if (closePromise) return closePromise;
      // A status observer may synchronously call close again.
      closePromise = Promise.resolve().then(async () => {
        const errors: unknown[] = [];
        for (const release of [unsubscribeEngine, unsubscribeReconnect, removeLifecycle]) {
          try { release?.(); } catch (error) { errors.push(error); }
        }
        try { await inner.close(); } catch (error) { errors.push(error); }
        if (errors.length) throw new AggregateError(errors, "PWA engine cleanup failed.");
      });
      closed = true;
      lifetime.abort(aborted());
      active?.controller.abort(aborted());
      observe({ availability: "closed", phase: "idle", shellReady: false });
      listeners.clear();
      return closePromise;
    },
  };
  try {
    unsubscribeEngine = inner.subscribe(snapshot => {
      if (snapshot.replica.nextClientSequence > sequence) { sequence = snapshot.replica.nextClientSequence; schedule(); }
    });
    unsubscribeReconnect = (options.subscribeReconnect ?? browserReconnect)(() => { if (automatic) schedule(); });
    if (lifecycle?.signal) {
      const signal = lifecycle.signal;
      const cancel = () => { void engine.close().catch(() => undefined); };
      signal.addEventListener("abort", cancel, { once: true });
      removeLifecycle = () => signal.removeEventListener("abort", cancel);
      if (signal.aborted) cancel();
    }
  } catch (error) { await engine.close(); throw error; }
  schedule();
  return engine;
}
