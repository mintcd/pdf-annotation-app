export type SyncErrorCode =
  | "invalid-input" | "unsupported-version" | "contract-mismatch" | "stream-mismatch"
  | "invalid-cursor" | "identity-conflict" | "divergence" | "commit-conflict"
  | "closed" | "limit-exceeded" | "corrupt-state";

export class SyncError extends Error {
  readonly code: SyncErrorCode;
  readonly retryable: boolean;

  constructor(code: SyncErrorCode, message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "SyncError";
    this.code = code;
    this.retryable = code === "commit-conflict";
  }
}
