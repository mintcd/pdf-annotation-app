import { SyncError } from "./errors.js";
import { canonicalizeJson } from "./fingerprint.js";
import { decodeCodecValue, encodeCodecValue } from "./codecs.js";
import { assertIdentifier, assertIdentity, assertSequence, clientPositionKey } from "./validation.js";
import type { Codec, CommittedOperation, Decision, JsonValue, OperationIdentity, Proposal, ProtocolLimits, SyncRequest, SyncResponse } from "./types.js";

export const DEFAULT_PROTOCOL_LIMITS: ProtocolLimits = Object.freeze({ maximumProposals: 64, maximumEntries: 256 });

export interface ProtocolModel<Intent, Operation, Rejection> {
  readonly contractVersion: string;
  readonly intent: Codec<Intent>;
  readonly operation: Codec<Operation>;
  readonly rejection: Codec<Rejection>;
}

export interface ProtocolOptions {
  readonly streamId?: string;
  readonly limits?: Partial<ProtocolLimits>;
}

export function resolveProtocolLimits(limits?: Partial<ProtocolLimits>): ProtocolLimits {
  const result = { ...DEFAULT_PROTOCOL_LIMITS, ...limits };
  assertSequence(result.maximumProposals, "maximumProposals", 1);
  assertSequence(result.maximumEntries, "maximumEntries", 1);
  return result;
}

const identityKeys = ["operationId", "clientId", "clientSequence", "intentHash"];
const requestKeys = ["protocolVersion", "contractVersion", "streamId", "baseSequence", "maximumEntries", "proposals"];
const responseKeys = ["protocolVersion", "contractVersion", "streamId", "requestedBaseSequence", "throughSequence", "headSequence", "entries", "decisions"];

function record(value: unknown, keys: readonly string[]): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)) throw new SyncError("invalid-input", "Expected a protocol object.");
  const prototype: unknown = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null) throw new SyncError("invalid-input", "Expected a plain protocol object.");
  const ownKeys = Reflect.ownKeys(value);
  if (ownKeys.length !== keys.length || ownKeys.some((key) => typeof key !== "string" || !keys.includes(key))) {
    throw new SyncError("invalid-input", "Unexpected or missing protocol fields.");
  }
  for (const key of keys) {
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) throw new SyncError("invalid-input", "Expected protocol data properties.");
  }
  return value as Record<string, unknown>;
}

function parse(value: unknown): unknown {
  if (typeof value !== "string") return value;
  try { return JSON.parse(value) as unknown; }
  catch (cause) { throw new SyncError("invalid-input", "Invalid JSON message.", { cause }); }
}

function array(value: unknown, maximum: number, label: string): readonly unknown[] {
  if (!Array.isArray(value)) throw new SyncError("invalid-input", `${label} must be an array.`);
  if (value.length > maximum) throw new SyncError("limit-exceeded", `${label} exceeds the configured count limit.`);
  canonicalizeJson(value);
  return value;
}

function headers(value: Record<string, unknown>, contractVersion: string, options: ProtocolOptions): string {
  if (value.protocolVersion !== 1) throw new SyncError("unsupported-version", "Unsupported sync protocol version.");
  assertIdentifier(value.contractVersion, "contractVersion");
  assertIdentifier(contractVersion, "model.contractVersion");
  if (value.contractVersion !== contractVersion) throw new SyncError("contract-mismatch", "The domain contract version does not match.");
  assertIdentifier(value.streamId, "streamId");
  if (options.streamId !== undefined && value.streamId !== options.streamId) throw new SyncError("stream-mismatch", "The stream does not match this instance.");
  return value.streamId;
}

function identity(value: Record<string, unknown>): OperationIdentity {
  assertIdentity(value);
  return { operationId: value.operationId, clientId: value.clientId, clientSequence: value.clientSequence, intentHash: value.intentHash };
}

function decodeValue<Value>(codec: Codec<Value>, value: unknown): Value {
  return decodeCodecValue(codec, value, "domain payload");
}

function encodeValue<Value>(codec: Codec<Value>, value: Value): JsonValue {
  return encodeCodecValue(codec, value, "domain payload");
}

function uniqueIdentities(values: readonly OperationIdentity[]): void {
  const ids = new Set<string>();
  const positions = new Set<string>();
  for (const value of values) {
    const position = clientPositionKey(value);
    if (ids.has(value.operationId) || positions.has(position)) throw new SyncError("invalid-input", "A batch repeats an operation identity or client position.");
    ids.add(value.operationId);
    positions.add(position);
  }
}

export function decodeSyncRequest<Intent, Operation, Rejection>(input: unknown, model: ProtocolModel<Intent, Operation, Rejection>, options: ProtocolOptions = {}): SyncRequest<Intent> {
  const value = record(parse(input), requestKeys);
  const streamId = headers(value, model.contractVersion, options);
  const limits = resolveProtocolLimits(options.limits);
  assertSequence(value.baseSequence, "baseSequence");
  assertSequence(value.maximumEntries, "maximumEntries", 1);
  if (value.maximumEntries > limits.maximumEntries) throw new SyncError("limit-exceeded", "Requested page exceeds the configured limit.");
  const proposals: Proposal<Intent>[] = array(value.proposals, limits.maximumProposals, "proposals").map((item) => {
    const proposal = record(item, [...identityKeys, "intent"]);
    return { ...identity(proposal), intent: decodeValue(model.intent, proposal.intent) };
  });
  uniqueIdentities(proposals);
  return { protocolVersion: 1, contractVersion: model.contractVersion, streamId, baseSequence: value.baseSequence, maximumEntries: value.maximumEntries, proposals };
}

export function decodeSyncResponse<Intent, Operation, Rejection>(input: unknown, model: ProtocolModel<Intent, Operation, Rejection>, options: ProtocolOptions = {}): SyncResponse<Operation, Rejection> {
  const value = record(parse(input), responseKeys);
  const streamId = headers(value, model.contractVersion, options);
  const limits = resolveProtocolLimits(options.limits);
  assertSequence(value.requestedBaseSequence, "requestedBaseSequence");
  assertSequence(value.throughSequence, "throughSequence");
  assertSequence(value.headSequence, "headSequence");
  if (value.requestedBaseSequence > value.throughSequence || value.throughSequence > value.headSequence) throw new SyncError("invalid-cursor", "Response cursors must be ordered.");
  const entries: CommittedOperation<Operation>[] = array(value.entries, limits.maximumEntries, "entries").map((item, index) => {
    const entry = record(item, [...identityKeys, "sequence", "operation"]);
    assertSequence(entry.sequence, "sequence", 1);
    if (entry.sequence !== (value.requestedBaseSequence as number) + index + 1) throw new SyncError("invalid-cursor", "Canonical entries must be contiguous from the requested base.");
    return { ...identity(entry), sequence: entry.sequence, operation: decodeValue(model.operation, entry.operation) };
  });
  if (entries.length !== value.throughSequence - value.requestedBaseSequence) throw new SyncError("invalid-cursor", "The page does not cover its declared cursor range.");
  uniqueIdentities(entries);
  const acceptedSequences = new Set<number>();
  const decisions: Decision<Operation, Rejection>[] = array(value.decisions, limits.maximumProposals, "decisions").map((item) => {
    if (item === null || typeof item !== "object") throw new SyncError("invalid-input", "Expected a proposal decision.");
    const status = Object.getOwnPropertyDescriptor(item, "status")?.value as unknown;
    if (status === "accepted") {
      const decision = record(item, [...identityKeys, "status", "sequence", "operation"]);
      assertSequence(decision.sequence, "sequence", 1);
      if (decision.sequence > (value.headSequence as number) || acceptedSequences.has(decision.sequence)) throw new SyncError("invalid-cursor", "Accepted decisions must have distinct positions at or below the observed head.");
      acceptedSequences.add(decision.sequence);
      return { ...identity(decision), status: "accepted", sequence: decision.sequence, operation: decodeValue(model.operation, decision.operation) };
    }
    if (status === "rejected") {
      const decision = record(item, [...identityKeys, "status", "reason"]);
      return { ...identity(decision), status: "rejected", reason: decodeValue(model.rejection, decision.reason) };
    }
    throw new SyncError("invalid-input", "Unknown decision status.");
  });
  uniqueIdentities(decisions);
  return { protocolVersion: 1, contractVersion: model.contractVersion, streamId, requestedBaseSequence: value.requestedBaseSequence, throughSequence: value.throughSequence, headSequence: value.headSequence, entries, decisions };
}

export function encodeSyncRequest<Intent, Operation, Rejection>(input: SyncRequest<Intent>, model: ProtocolModel<Intent, Operation, Rejection>, options: ProtocolOptions = {}): string {
  const value = record(input, requestKeys);
  const limits = resolveProtocolLimits(options.limits);
  const wire = { ...value, proposals: arrayForEncoding(value.proposals, limits.maximumProposals).map((item) => {
    const proposal = record(item, [...identityKeys, "intent"]);
    return { ...identity(proposal), intent: encodeValue(model.intent, proposal.intent as Intent) };
  }) };
  decodeSyncRequest(wire, model, options);
  return canonicalizeJson(wire);
}

export function encodeSyncResponse<Intent, Operation, Rejection>(input: SyncResponse<Operation, Rejection>, model: ProtocolModel<Intent, Operation, Rejection>, options: ProtocolOptions = {}): string {
  const value = record(input, responseKeys);
  const limits = resolveProtocolLimits(options.limits);
  const wire = { ...value,
    entries: arrayForEncoding(value.entries, limits.maximumEntries).map((item) => {
      const entry = record(item, [...identityKeys, "sequence", "operation"]);
      return { ...identity(entry), sequence: entry.sequence, operation: encodeValue(model.operation, entry.operation as Operation) };
    }),
    decisions: arrayForEncoding(value.decisions, limits.maximumProposals).map((item) => {
      const status = item !== null && typeof item === "object" ? Object.getOwnPropertyDescriptor(item, "status")?.value as unknown : undefined;
      if (status === "accepted") {
        const decision = record(item, [...identityKeys, "status", "sequence", "operation"]);
        return { ...identity(decision), status, sequence: decision.sequence, operation: encodeValue(model.operation, decision.operation as Operation) };
      }
      if (status === "rejected") {
        const decision = record(item, [...identityKeys, "status", "reason"]);
        return { ...identity(decision), status, reason: encodeValue(model.rejection, decision.reason as Rejection) };
      }
      throw new SyncError("invalid-input", "Unknown decision status.");
    }),
  };
  decodeSyncResponse(wire, model, options);
  return canonicalizeJson(wire);
}

/** Domain-valued arrays need not be JSON until their payload codecs run. */
function arrayForEncoding(value: unknown, maximum: number): readonly unknown[] {
  if (!Array.isArray(value)) throw new SyncError("invalid-input", "Expected a protocol array.");
  if (Object.getPrototypeOf(value) !== Array.prototype) throw new SyncError("invalid-input", "Protocol arrays require the ordinary array prototype.");
  if (value.length > maximum) throw new SyncError("limit-exceeded", "Protocol array exceeds the configured limit.");
  const descriptors = Object.getOwnPropertyDescriptors(value);
  if (Reflect.ownKeys(descriptors).length !== value.length + 1) throw new SyncError("invalid-input", "Protocol arrays must be dense without extra properties.");
  for (let index = 0; index < value.length; index++) {
    const descriptor = descriptors[String(index)];
    if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) throw new SyncError("invalid-input", "Protocol arrays require ordinary data properties.");
  }
  return value;
}
