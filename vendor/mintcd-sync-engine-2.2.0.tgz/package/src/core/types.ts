/** JSON is the wire representation; codecs may expose richer domain values. */
export type JsonValue = null | boolean | number | string | readonly JsonValue[] | { readonly [key: string]: JsonValue };

/** After one normalization, decode/encode roundtrips must have a stable encoding. */
export interface Codec<Value> {
  encode(value: Value): JsonValue;
  decode(value: unknown): Value;
}

export interface OperationIdentity {
  readonly operationId: string;
  readonly clientId: string;
  readonly clientSequence: number;
  readonly intentHash: string;
}

export interface Proposal<Intent> extends OperationIdentity {
  readonly intent: Intent;
}

export interface CommittedOperation<Operation> extends OperationIdentity {
  readonly sequence: number;
  readonly operation: Operation;
}

export interface AcceptedDecision<Operation> extends CommittedOperation<Operation> {
  readonly status: "accepted";
}

export interface RejectedDecision<Rejection> extends OperationIdentity {
  readonly status: "rejected";
  readonly reason: Rejection;
}

export type Decision<Operation, Rejection> = AcceptedDecision<Operation> | RejectedDecision<Rejection>;

export type PolicyDecision<Operation, Rejection> =
  | { readonly status: "accepted"; readonly operation: Operation }
  | { readonly status: "rejected"; readonly reason: Rejection };

export type DecisionPolicy<State, Intent, Operation, Rejection, Context = undefined> =
  (state: State, proposal: Proposal<Intent>, context: Context) => PolicyDecision<Operation, Rejection>;

export type PreviewResult<State> =
  | { readonly status: "applied"; readonly state: State }
  | { readonly status: "unavailable"; readonly reason: string };

/**
 * Reducers/codecs must be deterministic and must not mutate their inputs.
 * State and domain values must retain their meaning under structuredClone.
 * Codec encode/decode roundtrips must stabilize after their first normalization.
 */
export interface DomainModel<State, Intent, Operation, Rejection> {
  readonly contractVersion: string;
  readonly intent: Codec<Intent>;
  readonly operation: Codec<Operation>;
  readonly rejection: Codec<Rejection>;
  applyCommitted(state: State, operation: Operation): State;
  previewIntent(state: State, intent: Intent): PreviewResult<State>;
  previewOperation(state: State, operation: Operation): PreviewResult<State>;
}

export interface ProtocolLimits {
  readonly maximumProposals: number;
  readonly maximumEntries: number;
}

export interface SyncRequest<Intent> {
  readonly protocolVersion: 1;
  readonly contractVersion: string;
  readonly streamId: string;
  readonly baseSequence: number;
  readonly maximumEntries: number;
  readonly proposals: readonly Proposal<Intent>[];
}

export interface SyncResponse<Operation, Rejection> {
  readonly protocolVersion: 1;
  readonly contractVersion: string;
  readonly streamId: string;
  readonly requestedBaseSequence: number;
  readonly throughSequence: number;
  readonly headSequence: number;
  readonly entries: readonly CommittedOperation<Operation>[];
  readonly decisions: readonly Decision<Operation, Rejection>[];
}

export interface OutboxEntry<Intent, Operation> {
  readonly proposal: Proposal<Intent>;
  readonly decision?: AcceptedDecision<Operation>;
}

export type OverlayPreview =
  | { readonly operationId: string; readonly status: "applied" }
  | { readonly operationId: string; readonly status: "unavailable"; readonly reason: string };

/** Retained entries and decisions validate late responses even after UI acknowledgement. */
export interface ReplicaState<State, Intent, Operation, Rejection> {
  readonly streamId: string;
  readonly contractVersion: string;
  readonly clientId: string;
  readonly nextClientSequence: number;
  readonly confirmedSequence: number;
  readonly headSequence: number;
  readonly confirmedState: State;
  readonly entries: readonly CommittedOperation<Operation>[];
  readonly outbox: readonly OutboxEntry<Intent, Operation>[];
  readonly decisions: readonly Decision<Operation, Rejection>[];
  readonly resolutions: readonly Decision<Operation, Rejection>[];
  readonly visibleState: State;
  readonly previews: readonly OverlayPreview[];
}

export interface EnqueueInput<Intent> {
  readonly operationId: string;
  readonly intent: Intent;
}

export interface PrepareSyncOptions {
  readonly maximumProposals?: number;
  readonly maximumEntries?: number;
}

/** Each mutation reads the latest durable state and commits atomically. */
export interface ReplicaStore<State, Intent, Operation, Rejection> {
  read(): Promise<ReplicaState<State, Intent, Operation, Rejection>>;
  enqueue(input: EnqueueInput<Intent>): Promise<OperationIdentity>;
  prepareSyncRequest(options?: PrepareSyncOptions): Promise<SyncRequest<Intent>>;
  reconcile(response: SyncResponse<Operation, Rejection>): Promise<ReplicaState<State, Intent, Operation, Rejection>>;
  readResolutions(): Promise<readonly Decision<Operation, Rejection>[]>;
  acknowledgeResolutions(operationIds: readonly string[]): Promise<void>;
  close(): Promise<void>;
}

/** Store instances are scoped to one immutable stream identity. */
export interface AuthorityRead {
  readonly baseSequence: number;
  readonly maximumEntries: number;
  readonly identities: readonly OperationIdentity[];
}

export interface AuthoritySnapshot<State, Operation, Rejection> {
  readonly revision: number;
  readonly headSequence: number;
  readonly state: State;
  /** A bounded contiguous page beginning at the requested base + 1. */
  readonly entries: readonly CommittedOperation<Operation>[];
  /** Bindings matching either requested operation IDs OR requested client positions. */
  readonly decisions: readonly Decision<Operation, Rejection>[];
}

export interface AuthorityCommit<State, Operation, Rejection> {
  readonly expectedRevision: number;
  readonly state: State;
  readonly entries: readonly CommittedOperation<Operation>[];
  readonly decisions: readonly Decision<Operation, Rejection>[];
}

export type CommitResult =
  | { readonly status: "committed"; readonly revision: number }
  | { readonly status: "conflict" };

/** Consistent reads and all-or-nothing CAS; rejection-only commits advance revision. */
export interface AuthorityStore<State, Operation, Rejection> {
  readonly streamId: string;
  read(query: AuthorityRead): Promise<AuthoritySnapshot<State, Operation, Rejection>>;
  compareAndCommit(plan: AuthorityCommit<State, Operation, Rejection>): Promise<CommitResult>;
}

export interface SynchronizeOptions<Operation, Rejection> {
  /**
   * Synchronous, pure validation of an isolated final response before commit.
   * Throwing aborts the complete decision plan. May run again after a conflict.
   */
  readonly validateResponse?: (response: SyncResponse<Operation, Rejection>) => void;
}

export interface SyncAuthority<Intent, Operation, Rejection, Context = undefined> {
  synchronize(request: SyncRequest<Intent>, context: Context, options?: SynchronizeOptions<Operation, Rejection>): Promise<SyncResponse<Operation, Rejection>>;
}

export interface SyncTransport<Intent, Operation, Rejection> {
  exchange(request: SyncRequest<Intent>, options?: { readonly signal?: AbortSignal }): Promise<SyncResponse<Operation, Rejection>>;
}
