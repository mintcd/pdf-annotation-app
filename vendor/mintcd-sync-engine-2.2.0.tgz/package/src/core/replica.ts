import { SyncError } from "./errors.js";
import { canonicalizeJson } from "./fingerprint.js";
import { decodeSyncResponse, encodeSyncResponse, resolveProtocolLimits } from "./protocol.js";
import { assertIdentifier, assertIdentity, assertSameIdentity, assertSequence, clientPositionKey } from "./validation.js";
import type {
  AcceptedDecision, Codec, CommittedOperation, Decision, DomainModel, OperationIdentity,
  OutboxEntry, OverlayPreview, PrepareSyncOptions, ProtocolLimits, ReplicaState, SyncRequest, SyncResponse,
} from "./types.js";

export interface CreateReplicaStateOptions<State, Intent, Operation, Rejection> {
  readonly streamId: string;
  readonly clientId: string;
  readonly initialState: State;
  readonly model: DomainModel<State, Intent, Operation, Rejection>;
}

export interface EnqueueReplicaOperationInput<Intent> {
  readonly operationId: string;
  readonly intent: Intent;
  readonly intentHash: string;
}

export interface ReconcileSyncResponseOptions {
  readonly limits?: Partial<ProtocolLimits>;
}

/** Domain values and state must support structuredClone. No references escape a transition. */
function copy<Value>(value: Value): Value {
  return structuredClone(value);
}

function isolatedCodec<Value>(codec: Codec<Value>): Codec<Value> {
  return {
    encode: value => codec.encode(copy(value)),
    decode: value => copy(codec.decode(copy(value))),
  };
}

function assertContract<State, Intent, Operation, Rejection>(
  state: ReplicaState<State, Intent, Operation, Rejection>,
  model: DomainModel<State, Intent, Operation, Rejection>,
): void {
  if (state.contractVersion !== model.contractVersion) {
    throw new SyncError("contract-mismatch", "Replica and model contract versions differ.");
  }
}

/** All identity bindings survive acknowledgement of an application resolution. */
function bindIdentity(
  identity: OperationIdentity,
  byId: Map<string, OperationIdentity>,
  byPosition: Map<string, OperationIdentity>,
): void {
  assertIdentity(identity);
  const previousId = byId.get(identity.operationId);
  const previousPosition = byPosition.get(clientPositionKey(identity));
  if (previousId) assertSameIdentity(previousId, identity);
  if (previousPosition) assertSameIdentity(previousPosition, identity);
  byId.set(identity.operationId, identity);
  byPosition.set(clientPositionKey(identity), identity);
}

function encodedEquals<Value>(left: Value, right: Value, encode: (value: Value) => unknown): boolean {
  return canonicalizeJson(encode(copy(left))) === canonicalizeJson(encode(copy(right)));
}

function assertSameEntry<State, Intent, Operation, Rejection>(
  left: CommittedOperation<Operation>,
  right: CommittedOperation<Operation>,
  model: DomainModel<State, Intent, Operation, Rejection>,
): void {
  assertSameIdentity(left, right);
  if (left.sequence !== right.sequence || !encodedEquals(left.operation, right.operation, value => model.operation.encode(value))) {
    throw new SyncError("divergence", "Canonical operation differs from retained history.");
  }
}

function assertSameDecision<State, Intent, Operation, Rejection>(
  left: Decision<Operation, Rejection>,
  right: Decision<Operation, Rejection>,
  model: DomainModel<State, Intent, Operation, Rejection>,
): void {
  assertSameIdentity(left, right);
  if (left.status !== right.status) {
    throw new SyncError("divergence", "A retained decision cannot change its outcome.");
  }
  if (left.status === "accepted" && right.status === "accepted") {
    assertSameEntry(left, right, model);
  } else if (left.status === "rejected" && right.status === "rejected"
    && !encodedEquals(left.reason, right.reason, value => model.rejection.encode(value))) {
    throw new SyncError("divergence", "A retained rejection cannot change its reason.");
  }
}

/** Validate the retained, complete prefix and identity bindings before a transition. */
function inspectState<State, Intent, Operation, Rejection>(
  state: ReplicaState<State, Intent, Operation, Rejection>,
): { byId: Map<string, OperationIdentity>; byPosition: Map<string, OperationIdentity> } {
  assertIdentifier(state.streamId, "streamId");
  assertIdentifier(state.clientId, "clientId");
  assertIdentifier(state.contractVersion, "contractVersion");
  assertSequence(state.confirmedSequence, "confirmedSequence");
  assertSequence(state.headSequence, "headSequence");
  assertSequence(state.nextClientSequence, "nextClientSequence", 1);
  if (state.entries.length !== state.confirmedSequence || state.headSequence < state.confirmedSequence) {
    throw new SyncError("corrupt-state", "Replica must retain its complete confirmed prefix.");
  }
  const byId = new Map<string, OperationIdentity>();
  const byPosition = new Map<string, OperationIdentity>();
  const ids = new Set<string>();
  for (const [index, entry] of state.entries.entries()) {
    if (entry.sequence !== index + 1 || ids.has(entry.operationId)) {
      throw new SyncError("corrupt-state", "Retained canonical entries are not a unique contiguous prefix.");
    }
    bindIdentity(entry, byId, byPosition);
    ids.add(entry.operationId);
  }
  ids.clear();
  for (const decision of state.decisions) {
    if (ids.has(decision.operationId)) throw new SyncError("corrupt-state", "Retained decisions contain duplicates.");
    bindIdentity(decision, byId, byPosition);
    ids.add(decision.operationId);
  }
  ids.clear();
  let previousSequence = 0;
  for (const entry of state.outbox) {
    const proposal = entry.proposal;
    bindIdentity(proposal, byId, byPosition);
    if (proposal.clientId !== state.clientId || proposal.clientSequence <= previousSequence || ids.has(proposal.operationId)) {
      throw new SyncError("corrupt-state", "Outbox must contain unique proposals in local client order.");
    }
    if (entry.decision) assertSameIdentity(proposal, entry.decision);
    previousSequence = proposal.clientSequence;
    ids.add(proposal.operationId);
  }
  for (const identity of byId.values()) {
    if (identity.clientId === state.clientId && identity.clientSequence >= state.nextClientSequence) {
      throw new SyncError("identity-conflict", "The next client sequence is already bound to retained work.");
    }
  }
  return { byId, byPosition };
}

function replayOverlay<State, Intent, Operation, Rejection>(
  confirmedState: State,
  outbox: readonly OutboxEntry<Intent, Operation>[],
  model: DomainModel<State, Intent, Operation, Rejection>,
): { visibleState: State; previews: readonly OverlayPreview[] } {
  let visibleState = copy(confirmedState);
  const previews: OverlayPreview[] = [];
  for (const entry of outbox) {
    try {
      const result = entry.decision
        ? model.previewOperation(copy(visibleState), copy(entry.decision.operation))
        : model.previewIntent(copy(visibleState), copy(entry.proposal.intent));
      if (result?.status === "applied") {
        visibleState = copy(result.state);
        previews.push({ operationId: entry.proposal.operationId, status: "applied" });
      } else {
        const reason = result?.status === "unavailable" && typeof result.reason === "string"
          ? result.reason : "Preview returned an invalid result.";
        previews.push({ operationId: entry.proposal.operationId, status: "unavailable", reason });
      }
    } catch (error) {
      previews.push({ operationId: entry.proposal.operationId, status: "unavailable",
        reason: error instanceof Error ? error.message : "Preview failed." });
    }
  }
  return { visibleState, previews };
}

export function createReplicaState<State, Intent, Operation, Rejection>(
  options: CreateReplicaStateOptions<State, Intent, Operation, Rejection>,
): ReplicaState<State, Intent, Operation, Rejection> {
  assertIdentifier(options.streamId, "streamId");
  assertIdentifier(options.clientId, "clientId");
  assertIdentifier(options.model.contractVersion, "contractVersion");
  return {
    streamId: options.streamId, clientId: options.clientId, contractVersion: options.model.contractVersion,
    nextClientSequence: 1, confirmedSequence: 0, headSequence: 0,
    confirmedState: copy(options.initialState), visibleState: copy(options.initialState),
    entries: [], outbox: [], decisions: [], resolutions: [], previews: [],
  };
}

/** Hashing happens before this synchronous transition, outside native transactions. */
export function enqueueReplicaOperation<State, Intent, Operation, Rejection>(
  state: ReplicaState<State, Intent, Operation, Rejection>,
  input: EnqueueReplicaOperationInput<Intent>,
  model: DomainModel<State, Intent, Operation, Rejection>,
): ReplicaState<State, Intent, Operation, Rejection> {
  assertContract(state, model);
  const { byId, byPosition } = inspectState(state);
  assertSequence(state.nextClientSequence + 1, "nextClientSequence", 1);
  const proposal = { operationId: input.operationId, clientId: state.clientId,
    clientSequence: state.nextClientSequence, intentHash: input.intentHash, intent: copy(input.intent) };
  assertIdentity(proposal);
  if (byId.has(proposal.operationId) || byPosition.has(clientPositionKey(proposal))) {
    throw new SyncError("identity-conflict", "Operation ID or client position has already been used.");
  }
  const next = copy(state);
  const outbox = [...next.outbox, { proposal }];
  return { ...next, nextClientSequence: state.nextClientSequence + 1, outbox,
    ...replayOverlay(next.confirmedState, outbox, model) };
}

/** Snapshot preparation does not mark proposals as in flight or remove durable work. */
export function prepareSyncRequest<State, Intent, Operation, Rejection>(
  state: ReplicaState<State, Intent, Operation, Rejection>,
  options: PrepareSyncOptions = {},
  limitsInput?: Partial<ProtocolLimits>,
): SyncRequest<Intent> {
  inspectState(state);
  const limits = resolveProtocolLimits(limitsInput);
  const maximumProposals = options.maximumProposals ?? limits.maximumProposals;
  const maximumEntries = options.maximumEntries ?? limits.maximumEntries;
  assertSequence(maximumProposals, "maximumProposals");
  assertSequence(maximumEntries, "maximumEntries", 1);
  if (maximumProposals > limits.maximumProposals || maximumEntries > limits.maximumEntries) {
    throw new SyncError("limit-exceeded", "Requested synchronization bounds exceed configured limits.");
  }
  return {
    protocolVersion: 1, contractVersion: state.contractVersion, streamId: state.streamId,
    baseSequence: state.confirmedSequence, maximumEntries,
    proposals: copy(state.outbox.filter(entry => !entry.decision).slice(0, maximumProposals).map(entry => entry.proposal)),
  };
}

/** Merge a bounded page and receipts against the latest durable state. */
export function reconcileSyncResponse<State, Intent, Operation, Rejection>(
  state: ReplicaState<State, Intent, Operation, Rejection>,
  response: SyncResponse<Operation, Rejection>,
  model: DomainModel<State, Intent, Operation, Rejection>,
  options: ReconcileSyncResponseOptions = {},
): ReplicaState<State, Intent, Operation, Rejection> {
  assertContract(state, model);
  inspectState(state);
  const next = copy(state);
  const { byId, byPosition } = inspectState(next);
  const protocolOptions = { streamId: state.streamId, ...(options.limits ? { limits: options.limits } : {}) };
  const protocolModel = { contractVersion: model.contractVersion,
    intent: isolatedCodec(model.intent), operation: isolatedCodec(model.operation), rejection: isolatedCodec(model.rejection) };
  // Responses passed by a typed transport still cross the same validated codec boundary.
  // Validate the original envelope before cloning can discard accessors or extra keys.
  const incoming = decodeSyncResponse(encodeSyncResponse(response, protocolModel, protocolOptions), protocolModel, protocolOptions);
  if (incoming.requestedBaseSequence > state.confirmedSequence) {
    throw new SyncError("invalid-cursor", "A canonical page cannot skip the replica's confirmed prefix.");
  }
  const decisions = [...next.decisions];
  const byDecision = new Map(decisions.map(decision => [decision.operationId, decision]));
  const bySequence = new Map<number, AcceptedDecision<Operation>>();
  const addDecision = (decision: Decision<Operation, Rejection>): void => {
    bindIdentity(decision, byId, byPosition);
    const known = byDecision.get(decision.operationId);
    if (known) assertSameDecision(known, decision, model);
    if (decision.status === "accepted") {
      const atSequence = bySequence.get(decision.sequence);
      if (atSequence) assertSameEntry(atSequence, decision, model);
      bySequence.set(decision.sequence, decision);
    }
    if (!known) {
      decisions.push(copy(decision));
      byDecision.set(decision.operationId, decision);
    }
  };
  // Revalidate retained receipts against the retained canonical log, too.
  for (const decision of next.decisions) addDecision(decision);
  for (const entry of next.entries) addDecision({ ...entry, status: "accepted" });
  for (const decision of incoming.decisions) addDecision(decision);
  const entries = [...next.entries];
  let confirmedState = next.confirmedState;
  for (const entry of incoming.entries) {
    addDecision({ ...entry, status: "accepted" });
    const retained = entries[entry.sequence - 1];
    if (retained) {
      assertSameEntry(retained, entry, model);
    } else {
      if (entry.sequence !== entries.length + 1) {
        throw new SyncError("invalid-cursor", "Canonical entries must extend the confirmed prefix contiguously.");
      }
      confirmedState = copy(model.applyCommitted(copy(confirmedState), copy(entry.operation)));
      entries.push(copy(entry));
    }
  }
  for (const decision of decisions) {
    if (decision.status === "accepted" && decision.sequence <= entries.length) {
      const canonical = entries[decision.sequence - 1];
      if (!canonical) throw new SyncError("corrupt-state", "Canonical prefix is incomplete.");
      assertSameEntry(canonical, decision, model);
    }
  }
  const knownDecisions = new Set(state.decisions.map(decision => decision.operationId));
  const resolutions = [...next.resolutions];
  const outbox: OutboxEntry<Intent, Operation>[] = [];
  for (const entry of next.outbox) {
    const decision = byDecision.get(entry.proposal.operationId);
    if (!decision) {
      outbox.push(entry);
      continue;
    }
    assertSameIdentity(entry.proposal, decision);
    if (!knownDecisions.has(decision.operationId)) resolutions.push(copy(decision));
    if (decision.status === "accepted" && decision.sequence > entries.length) {
      outbox.push({ proposal: entry.proposal, decision: copy(decision) });
    }
  }
  const result = { ...next, confirmedState, confirmedSequence: entries.length,
    headSequence: Math.max(state.headSequence, incoming.headSequence), entries, decisions, resolutions, outbox,
    ...replayOverlay(confirmedState, outbox, model) };
  // A response may expose another binding for this client's unused future position.
  inspectState(result);
  return result;
}

/** Remove UI notices only; canonical history and identity/decision bindings remain. */
export function acknowledgeResolutions<State, Intent, Operation, Rejection>(
  state: ReplicaState<State, Intent, Operation, Rejection>,
  operationIds: readonly string[],
): ReplicaState<State, Intent, Operation, Rejection> {
  inspectState(state);
  for (const id of operationIds) assertIdentifier(id, "operationId");
  const acknowledged = new Set(operationIds);
  const next = copy(state);
  return { ...next, resolutions: next.resolutions.filter(decision => !acknowledged.has(decision.operationId)) };
}
