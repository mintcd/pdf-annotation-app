import { SyncError } from "./errors.js";
import type { OperationIdentity } from "./types.js";

export function assertIdentifier(value: unknown, label: string): asserts value is string {
  if (typeof value !== "string" || value.trim().length === 0 || value.length > 1024) {
    throw new SyncError("invalid-input", `${label} must be a nonempty string of at most 1024 characters.`);
  }
}

export function assertSequence(value: unknown, label: string, minimum = 0): asserts value is number {
  if (typeof value !== "number" || !Number.isSafeInteger(value) || value < minimum) {
    throw new SyncError("invalid-input", `${label} must be a safe integer >= ${minimum}.`);
  }
}

export function assertIdentity(value: unknown): asserts value is OperationIdentity {
  if (value === null || typeof value !== "object") throw new SyncError("invalid-input", "Expected an operation identity.");
  const candidate = value as Record<string, unknown>;
  assertIdentifier(candidate.operationId, "operationId");
  assertIdentifier(candidate.clientId, "clientId");
  assertSequence(candidate.clientSequence, "clientSequence", 1);
  if (typeof candidate.intentHash !== "string" || !/^sha256:[0-9a-f]{64}$/.test(candidate.intentHash)) {
    throw new SyncError("invalid-input", "intentHash must be a lowercase SHA-256 fingerprint.");
  }
}

export function identityEquals(left: OperationIdentity, right: OperationIdentity): boolean {
  return left.operationId === right.operationId && left.clientId === right.clientId
    && left.clientSequence === right.clientSequence && left.intentHash === right.intentHash;
}

export function assertSameIdentity(left: OperationIdentity, right: OperationIdentity): void {
  if (!identityEquals(left, right)) throw new SyncError("identity-conflict", "An operation identity or client position is already bound to different content.");
}

export function clientPositionKey(identity: Pick<OperationIdentity, "clientId" | "clientSequence">): string {
  return JSON.stringify([identity.clientId, identity.clientSequence]);
}
