import { SyncError } from "./errors.js";

/** A package-defined canonical JSON encoding, not a cross-language JSON standard. */
export function canonicalizeJson(value: unknown): string {
  const ancestors = new Set<object>();
  function visit(current: unknown, depth = 0): string {
    if (depth > 256) throw new SyncError("limit-exceeded", "JSON nesting exceeds 256 levels.");
    if (current === null) return "null";
    if (typeof current === "string" || typeof current === "boolean") return JSON.stringify(current);
    if (typeof current === "number" && Number.isFinite(current)) return JSON.stringify(current);
    if (typeof current !== "object") throw new SyncError("invalid-input", "Expected a JSON-compatible value.");
    if (ancestors.has(current)) throw new SyncError("invalid-input", "JSON cannot contain cycles.");
    ancestors.add(current);
    try {
      if (Array.isArray(current)) {
        if (Object.getPrototypeOf(current) !== Array.prototype) {
          throw new SyncError("invalid-input", "JSON arrays must have the ordinary array prototype.");
        }
        const descriptors = Object.getOwnPropertyDescriptors(current);
        if (Reflect.ownKeys(descriptors).length !== current.length + 1) {
          throw new SyncError("invalid-input", "Arrays must be dense and have no extra properties.");
        }
        const items: string[] = [];
        for (let index = 0; index < current.length; index++) {
          const descriptor = descriptors[String(index)];
          if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) {
            throw new SyncError("invalid-input", "Arrays must contain ordinary enumerable data properties.");
          }
          items.push(visit(descriptor.value, depth + 1));
        }
        return `[${items.join(",")}]`;
      }
      const prototype: unknown = Object.getPrototypeOf(current);
      if (prototype !== Object.prototype && prototype !== null) {
        throw new SyncError("invalid-input", "JSON objects must have a plain or null prototype.");
      }
      const keys = Reflect.ownKeys(current);
      if (keys.some((key) => typeof key !== "string")) throw new SyncError("invalid-input", "JSON cannot contain symbol keys.");
      const fields: string[] = [];
      for (const key of (keys as string[]).sort()) {
        const descriptor = Object.getOwnPropertyDescriptor(current, key);
        if (!descriptor || !("value" in descriptor) || !descriptor.enumerable) {
          throw new SyncError("invalid-input", "JSON objects must contain ordinary enumerable data properties.");
        }
        fields.push(`${JSON.stringify(key)}:${visit(descriptor.value, depth + 1)}`);
      }
      return `{${fields.join(",")}}`;
    } finally {
      ancestors.delete(current);
    }
  }
  return visit(value);
}

/** Hash the codec's JSON representation before entering a storage transaction. */
export async function createIntentHash(value: unknown): Promise<string> {
  const bytes = new TextEncoder().encode(canonicalizeJson(value));
  const digest = await globalThis.crypto.subtle.digest("SHA-256", bytes);
  return `sha256:${Array.from(new Uint8Array(digest), (byte) => byte.toString(16).padStart(2, "0")).join("")}`;
}
