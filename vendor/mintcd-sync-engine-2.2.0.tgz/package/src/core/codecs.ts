import { SyncError } from "./errors.js";
import { canonicalizeJson } from "./fingerprint.js";
import type { Codec, JsonValue } from "./types.js";

/** One normalization is allowed; repeated roundtrips must preserve its encoding. */
export function decodeCodecValue<Value>(codec: Codec<Value>, wire: unknown, label: string): Value {
  try {
    canonicalizeJson(wire);
    const value = codec.decode(structuredClone(wire));
    const canonical = canonicalizeJson(codec.encode(structuredClone(value)));
    const repeated = codec.decode(JSON.parse(canonical) as unknown);
    if (canonicalizeJson(codec.encode(repeated)) !== canonical) {
      throw new SyncError("invalid-input", `${label} codec does not stabilize after normalization.`);
    }
    return value;
  } catch (cause) {
    if (cause instanceof SyncError && cause.code === "limit-exceeded") throw cause;
    throw new SyncError("invalid-input", `Invalid ${label}.`, { cause });
  }
}

export function encodeCodecValue<Value>(codec: Codec<Value>, value: Value, label: string): JsonValue {
  try {
    const wire = codec.encode(structuredClone(value));
    decodeCodecValue(codec, wire, label);
    return structuredClone(wire);
  } catch (cause) {
    if (cause instanceof SyncError && cause.code === "limit-exceeded") throw cause;
    throw new SyncError("invalid-input", `Cannot encode ${label}.`, { cause });
  }
}

export function cloneCodecValue<Value>(codec: Codec<Value>, value: Value, label: string): Value {
  return decodeCodecValue(codec, encodeCodecValue(codec, value, label), label);
}
