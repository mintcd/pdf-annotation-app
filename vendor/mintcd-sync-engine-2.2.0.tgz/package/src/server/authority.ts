import { SyncError } from "../core/errors.js";
import { createIntentHash } from "../core/fingerprint.js";
import { cloneCodecValue } from "../core/codecs.js";
import { decodeSyncRequest, decodeSyncResponse, encodeSyncRequest, encodeSyncResponse, resolveProtocolLimits } from "../core/protocol.js";
import { assertIdentifier, assertSameIdentity, assertSequence, clientPositionKey } from "../core/validation.js";
import type { AuthoritySnapshot, AuthorityStore, Codec, CommittedOperation, Decision, DecisionPolicy, DomainModel, PolicyDecision, Proposal, ProtocolLimits, SyncAuthority, SyncResponse } from "../core/types.js";

export interface SyncAuthorityOptions<State, Intent, Operation, Rejection, Context = undefined> {
  readonly store: AuthorityStore<State, Operation, Rejection>;
  readonly model: DomainModel<State, Intent, Operation, Rejection>;
  readonly policy: DecisionPolicy<State, Intent, Operation, Rejection, Context>;
  readonly limits?: Partial<ProtocolLimits>;
  readonly maximumCommitAttempts?: number;
}

function cloneState<State>(state: State): State {
  try {
    return structuredClone(state);
  } catch (cause) {
    throw new SyncError("invalid-input", "Authority state must support structuredClone.", { cause });
  }
}

function cloneValue<Value>(codec: Codec<Value>, value: Value, label: string): Value {
  return cloneCodecValue(codec, value, label);
}

function assertPage<State, Operation, Rejection>(snapshot: AuthoritySnapshot<State, Operation, Rejection>, baseSequence: number, maximumEntries: number): void {
  assertSequence(snapshot.revision, "authority revision");
  assertSequence(snapshot.headSequence, "authority head");
  if (baseSequence > snapshot.headSequence) {
    throw new SyncError("invalid-cursor", "The requested base is beyond the authority head.");
  }
  const maximumCount = Math.min(maximumEntries, snapshot.headSequence - baseSequence);
  if (snapshot.headSequence > baseSequence && snapshot.entries.length === 0) {
    throw new SyncError("corrupt-state", "The authority store returned a page that makes no progress toward its head.");
  }
  if (snapshot.entries.length > maximumCount || snapshot.entries.some((entry, index) => entry.sequence !== baseSequence + index + 1)) {
    throw new SyncError("corrupt-state", "The authority store returned a noncontiguous page.");
  }
}

/** Coordinates pure decisions with an atomic, revision-guarded authority store. */
export function createSyncAuthority<State, Intent, Operation, Rejection, Context = undefined>(
  options: SyncAuthorityOptions<State, Intent, Operation, Rejection, Context>,
): SyncAuthority<Intent, Operation, Rejection, Context> {
  const { store, model, policy } = options;
  assertIdentifier(store.streamId, "streamId");
  assertIdentifier(model.contractVersion, "contractVersion");
  const limits = resolveProtocolLimits(options.limits);
  const maximumCommitAttempts = options.maximumCommitAttempts ?? 8;
  assertSequence(maximumCommitAttempts, "maximumCommitAttempts", 1);
  const protocolOptions = { streamId: store.streamId, limits };

  return {
    async synchronize(input, context, synchronizeOptions) {
      const validateResponse = synchronizeOptions?.validateResponse;
      if (validateResponse !== undefined && typeof validateResponse !== "function") {
        throw new SyncError("invalid-input", "Response validation must be a synchronous function.");
      }
      // Typed callers still cross the same validation boundary as wire callers.
      const request = decodeSyncRequest(JSON.parse(encodeSyncRequest(input, model, protocolOptions)), model, protocolOptions);
      const hashes = await Promise.all(request.proposals.map((proposal) => createIntentHash(model.intent.encode(proposal.intent))));
      for (let index = 0; index < request.proposals.length; index += 1) {
        if (request.proposals[index]!.intentHash !== hashes[index]) {
          throw new SyncError("identity-conflict", "The proposal intent does not match its intent hash.");
        }
      }

      const query = {
        baseSequence: request.baseSequence,
        maximumEntries: request.maximumEntries,
        identities: request.proposals.map(({ operationId, clientId, clientSequence, intentHash }) => ({ operationId, clientId, clientSequence, intentHash })),
      };

      for (let attempt = 0; attempt < maximumCommitAttempts; attempt += 1) {
        const snapshot = await store.read(query);
        assertPage(snapshot, request.baseSequence, request.maximumEntries);
        const byOperation = new Map(snapshot.decisions.map((decision) => [decision.operationId, decision]));
        const byPosition = new Map(snapshot.decisions.map((decision) => [clientPositionKey(decision), decision]));
        const decisions: Decision<Operation, Rejection>[] = [];
        const newDecisions: Decision<Operation, Rejection>[] = [];
        const entries: CommittedOperation<Operation>[] = [];
        let state = cloneState(snapshot.state);
        let headSequence = snapshot.headSequence;

        for (const proposal of request.proposals) {
          const operationBinding = byOperation.get(proposal.operationId);
          const positionBinding = byPosition.get(clientPositionKey(proposal));
          if (operationBinding !== undefined) assertSameIdentity(operationBinding, proposal);
          if (positionBinding !== undefined) assertSameIdentity(positionBinding, proposal);
          const known = operationBinding ?? positionBinding;
          if (known !== undefined) {
            decisions.push(known);
            continue;
          }

          const isolatedProposal: Proposal<Intent> = { ...proposal, intent: cloneValue(model.intent, proposal.intent, "proposal intent") };
          const outcome: PolicyDecision<Operation, Rejection> = policy(cloneState(state), isolatedProposal, context);
          if (outcome === null || typeof outcome !== "object") {
            throw new SyncError("invalid-input", "The decision policy returned an invalid result.");
          }
          let decision: Decision<Operation, Rejection>;
          const identity = query.identities[decisions.length]!;
          if (outcome.status === "accepted") {
            const operation = cloneValue(model.operation, outcome.operation, "canonical operation");
            const sequence = headSequence + 1;
            assertSequence(sequence, "canonical sequence", 1);
            // A reducer receives owned inputs so accidental mutation cannot leak to a store or receipt.
            state = cloneState(model.applyCommitted(cloneState(state), cloneValue(model.operation, operation, "canonical operation")));
            const entry: CommittedOperation<Operation> = { ...identity, sequence, operation };
            entries.push(entry);
            decision = { ...entry, status: "accepted" };
            headSequence = sequence;
          } else if (outcome.status === "rejected") {
            decision = { ...identity, status: "rejected", reason: cloneValue(model.rejection, outcome.reason, "rejection reason") };
          } else {
            throw new SyncError("invalid-input", "The decision policy returned an invalid status.");
          }
          newDecisions.push(decision);
          decisions.push(decision);
          byOperation.set(decision.operationId, decision);
          byPosition.set(clientPositionKey(decision), decision);
        }

        if (newDecisions.length > 0) {
          // Standalone payload validation is insufficient: the response envelope also
          // contributes nesting. Never retain a decision that cannot later be sent.
          for (const decision of newDecisions) {
            const accepted = decision.status === "accepted";
            const baseSequence = accepted ? decision.sequence - 1 : snapshot.headSequence;
            let pageEntries: readonly CommittedOperation<Operation>[] = [];
            if (decision.status === "accepted") {
              const { status: _status, ...entry } = decision;
              pageEntries = [entry];
            }
            encodeSyncResponse({
              protocolVersion: 1,
              contractVersion: model.contractVersion,
              streamId: store.streamId,
              requestedBaseSequence: baseSequence,
              throughSequence: baseSequence + pageEntries.length,
              headSequence: accepted ? headSequence : snapshot.headSequence,
              entries: pageEntries,
              decisions: [decision],
            }, model, protocolOptions);
          }
        }

        // Build exactly the response this plan will return before committing it.
        // A shortened retained page must remain contiguous; append new entries only
        // when the retained page reaches the head against which they were decided.
        const pageEntries = snapshot.entries.slice();
        if (request.baseSequence + pageEntries.length === snapshot.headSequence) {
          pageEntries.push(...entries.slice(0, request.maximumEntries - pageEntries.length));
        }
        const response: SyncResponse<Operation, Rejection> = {
          protocolVersion: 1,
          contractVersion: model.contractVersion,
          streamId: store.streamId,
          requestedBaseSequence: request.baseSequence,
          throughSequence: request.baseSequence + pageEntries.length,
          headSequence,
          entries: pageEntries,
          decisions,
        };
        // Return detached domain values, validated with the authority's configured limits.
        const detached = decodeSyncResponse(JSON.parse(encodeSyncResponse(response, model, protocolOptions)), model, protocolOptions);
        if (validateResponse !== undefined) {
          const validated: unknown = validateResponse(structuredClone(detached));
          if (validated !== null && (typeof validated === "object" || typeof validated === "function") && "then" in validated) {
            // Observe accidental asynchronous rejection while refusing to commit.
            void Promise.resolve(validated).catch(() => undefined);
            throw new SyncError("invalid-input", "Response validation must be synchronous.");
          }
        }
        if (newDecisions.length > 0) {
          const result = await store.compareAndCommit({ expectedRevision: snapshot.revision, state, entries, decisions: newDecisions });
          if (result.status === "conflict") continue;
        }
        return detached;
      }
      throw new SyncError("commit-conflict", "The authority could not commit within its retry budget.");
    },
  };
}
