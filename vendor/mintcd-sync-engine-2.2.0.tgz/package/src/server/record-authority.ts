import { cloneCodecValue } from "../core/codecs.js";
import { SyncError } from "../core/errors.js";
import { canonicalizeJson, createIntentHash } from "../core/fingerprint.js";
import { decodeSyncRequest, decodeSyncResponse, encodeSyncRequest, encodeSyncResponse, resolveProtocolLimits } from "../core/protocol.js";
import { assertIdentifier, assertIdentity, assertSameIdentity, assertSequence } from "../core/validation.js";
import type { Codec, CommittedOperation, Decision, OperationIdentity, Proposal, ProtocolLimits, SyncAuthority, SyncResponse } from "../core/types.js";
import type { RecordDatabase, RecordDecisionPolicy, RecordDomainModel, RecordSchema, RecordTransaction } from "../records/types.js";
import { schemaIdentity } from "../records/schema.js";
import { loadDeclaredRecordView } from "../records/view.js";

export interface RecordSyncAuthorityOptions<Schema extends RecordSchema, Intent, Operation, Rejection, Context = undefined> {
  readonly database: RecordDatabase<Schema>;
  readonly model: RecordDomainModel<Schema, Intent, Operation, Rejection>;
  readonly policy: RecordDecisionPolicy<Schema, Intent, Operation, Rejection, Context>;
  readonly limits?: Partial<ProtocolLimits>;
  readonly maximumCommitAttempts?: number;
}

interface AuthorityMetadata {
  readonly contractVersion: string;
  readonly schemaVersion: string;
  readonly schemaIdentity: string;
  readonly headSequence: number;
}

function identityOf(value: OperationIdentity): OperationIdentity {
  return { operationId: value.operationId, clientId: value.clientId, clientSequence: value.clientSequence, intentHash: value.intentHash };
}

function isolatedCodec<Value>(codec: Codec<Value>): Codec<Value> {
  return { encode: value => codec.encode(structuredClone(value)), decode: value => structuredClone(codec.decode(structuredClone(value))) };
}

function assertMetadata(value: AuthorityMetadata): void {
  if (value === null || typeof value !== "object") throw new SyncError("corrupt-state", "Invalid authority metadata.");
  try {
    assertIdentifier(value.contractVersion, "authority contractVersion");
    assertIdentifier(value.schemaVersion, "authority schemaVersion");
    if (typeof value.schemaIdentity !== "string") throw new SyncError("corrupt-state", "Invalid authority schema identity.");
    assertSequence(value.headSequence, "authority headSequence");
  } catch (cause) {
    throw new SyncError("corrupt-state", "Invalid authority metadata.", { cause });
  }
}

function assertStoredIdentity(value: OperationIdentity): void {
  try { assertIdentity(value); }
  catch (cause) { throw new SyncError("corrupt-state", "Invalid retained authority identity.", { cause }); }
}

function assertSynchronous(value: unknown, label: string): void {
  if (value !== null && (typeof value === "object" || typeof value === "function") && "then" in value) {
    // Observe an accidentally async rejection while aborting its storage plan.
    void Promise.resolve(value).catch(() => undefined);
    throw new SyncError("invalid-input", `${label} must be synchronous.`);
  }
}

/**
 * Decides against declared current records and atomically appends their canonical
 * changes and receipts. No whole-domain snapshot or historical scan is needed.
 */
export function createRecordSyncAuthority<Schema extends RecordSchema, Intent, Operation, Rejection, Context = undefined>(
  options: RecordSyncAuthorityOptions<Schema, Intent, Operation, Rejection, Context>,
): SyncAuthority<Intent, Operation, Rejection, Context> {
  const { database, model, policy } = options;
  assertIdentifier(database.streamId, "streamId");
  assertIdentifier(model.contractVersion, "contractVersion");
  assertIdentifier(model.schema.version, "schemaVersion");
  const modelSchemaIdentity = schemaIdentity(model.schema);
  if (schemaIdentity(database.schema) !== modelSchemaIdentity) {
    throw new SyncError("contract-mismatch", "The record model and database schemas do not match.");
  }
  const limits = resolveProtocolLimits(options.limits);
  const maximumCommitAttempts = options.maximumCommitAttempts ?? 8;
  assertSequence(maximumCommitAttempts, "maximumCommitAttempts", 1);
  const protocolOptions = { streamId: database.streamId, limits };
  const protocolModel = { contractVersion: model.contractVersion, intent: isolatedCodec(model.intent),
    operation: isolatedCodec(model.operation), rejection: isolatedCodec(model.rejection) };

  async function page(transaction: RecordTransaction<Schema>, baseSequence: number, maximumEntries: number, headSequence: number): Promise<readonly CommittedOperation<Operation>[]> {
    const rows = await transaction.scanInternal<CommittedOperation<Operation>>("canonical", {
      lower: { key: [baseSequence], inclusive: false }, upper: { key: [headSequence] }, limit: maximumEntries,
    });
    const maximumCount = Math.min(maximumEntries, headSequence - baseSequence);
    if (rows.length > maximumCount || (headSequence > baseSequence && rows.length === 0)
      || rows.some((row, index) => row.key.length !== 1 || row.key[0] !== baseSequence + index + 1 || row.value.sequence !== row.key[0])) {
      throw new SyncError("corrupt-state", "The record database returned a noncontiguous canonical page.");
    }
    return rows.map(({ value }) => value);
  }

  return {
    async synchronize(input, context, synchronizeOptions) {
      const validateResponse = synchronizeOptions?.validateResponse;
      if (validateResponse !== undefined && typeof validateResponse !== "function") {
        throw new SyncError("invalid-input", "Response validation must be a synchronous function.");
      }
      const request = decodeSyncRequest(JSON.parse(encodeSyncRequest(input, protocolModel, protocolOptions)), protocolModel, protocolOptions);
      // Hashing happens before opening a native transaction.
      const hashes = await Promise.all(request.proposals.map((proposal) => createIntentHash(protocolModel.intent.encode(proposal.intent))));
      for (let index = 0; index < request.proposals.length; index += 1) {
        if (hashes[index] !== request.proposals[index]!.intentHash) {
          throw new SyncError("identity-conflict", "The proposal intent does not match its intent hash.");
        }
      }

      for (let attempt = 0; attempt < maximumCommitAttempts; attempt += 1) {
        try {
          const result = await database.transaction("readwrite", async (transaction) => {
            assertSequence(transaction.revision, "record database revision");
            if (await transaction.getInternal("meta", ["replica"])) throw new SyncError("contract-mismatch", "A replica database cannot also host an authority.");
            const retainedMeta = await transaction.getInternal<AuthorityMetadata>("meta", ["authority"]);
            const metadata = retainedMeta ?? { contractVersion: model.contractVersion, schemaVersion: model.schema.version, schemaIdentity: modelSchemaIdentity, headSequence: 0 };
            assertMetadata(metadata);
            if (metadata.contractVersion !== model.contractVersion || metadata.schemaVersion !== model.schema.version || metadata.schemaIdentity !== modelSchemaIdentity) {
              throw new SyncError("contract-mismatch", "The authority storage is bound to another contract or schema version.");
            }
            if (request.baseSequence > metadata.headSequence) {
              throw new SyncError("invalid-cursor", "The requested base is beyond the authority head.");
            }
            // Check the existing prefix before staging domain writes.
            await page(transaction, request.baseSequence, request.maximumEntries, metadata.headSequence);
            let headSequence = metadata.headSequence;
            const decisions: Decision<Operation, Rejection>[] = [];
            let changed = retainedMeta === undefined;

            for (const proposal of request.proposals) {
              const [operationBinding, positionBinding, retainedDecision] = await Promise.all([
                transaction.getInternal<OperationIdentity>("identities", [proposal.operationId]),
                transaction.getInternal<OperationIdentity>("positions", [proposal.clientId, proposal.clientSequence]),
                transaction.getInternal<Decision<Operation, Rejection>>("decisions", [proposal.operationId]),
              ]);
              if (operationBinding !== undefined) { assertStoredIdentity(operationBinding); assertSameIdentity(operationBinding, proposal); }
              if (positionBinding !== undefined) { assertStoredIdentity(positionBinding); assertSameIdentity(positionBinding, proposal); }
              if (operationBinding !== undefined || positionBinding !== undefined || retainedDecision !== undefined) {
                if (operationBinding === undefined || positionBinding === undefined || retainedDecision === undefined) {
                  throw new SyncError("corrupt-state", "A retained authority decision is missing its identity bindings.");
                }
                assertStoredIdentity(retainedDecision);
                assertSameIdentity(retainedDecision, proposal);
                if (retainedDecision.status === "accepted") {
                  const entry = await transaction.getInternal<CommittedOperation<Operation>>("canonical", [retainedDecision.sequence]);
                  if (entry === undefined || entry.sequence !== retainedDecision.sequence || retainedDecision.sequence > headSequence) throw new SyncError("corrupt-state", "An accepted authority decision is missing its canonical entry.");
                  assertSameIdentity(entry, retainedDecision);
                  if (canonicalizeJson(protocolModel.operation.encode(entry.operation)) !== canonicalizeJson(protocolModel.operation.encode(retainedDecision.operation))) {
                    throw new SyncError("corrupt-state", "An accepted authority decision differs from its canonical entry.");
                  }
                } else if (retainedDecision.status !== "rejected") {
                  throw new SyncError("corrupt-state", "Invalid retained authority decision status.");
                }
                decisions.push(retainedDecision);
                continue;
              }

              const isolatedProposal: Proposal<Intent> = { ...proposal, intent: cloneCodecValue(protocolModel.intent, proposal.intent, "proposal intent") };
              const intentView = await loadDeclaredRecordView(transaction, "confirmed", model.intentReads(cloneCodecValue(protocolModel.intent, isolatedProposal.intent, "proposal intent")));
              const outcome = policy(intentView.readView, isolatedProposal, context);
              assertSynchronous(outcome, "The decision policy");
              if (outcome === null || typeof outcome !== "object") throw new SyncError("invalid-input", "The decision policy returned an invalid result.");
              const identity = identityOf(proposal);
              let decision: Decision<Operation, Rejection>;
              if (outcome.status === "accepted") {
                const operation = cloneCodecValue(protocolModel.operation, outcome.operation, "canonical operation");
                const sequence = headSequence + 1;
                assertSequence(sequence, "canonical sequence", 1);
                const entry: CommittedOperation<Operation> = { ...identity, sequence, operation };
                decision = { ...entry, status: "accepted" };
                // A receipt must fit a complete response, including envelope nesting,
                // before either its rows or its identity are retained.
                encodeSyncResponse({ protocolVersion: 1, contractVersion: model.contractVersion, streamId: database.streamId,
                  requestedBaseSequence: headSequence, throughSequence: sequence, headSequence: sequence, entries: [entry], decisions: [decision] }, protocolModel, protocolOptions);
                const [occupied, accepted] = await Promise.all([
                  transaction.getInternal<CommittedOperation<Operation>>("canonical", [sequence]),
                  transaction.getInternal<string>("accepted", [sequence]),
                ]);
                if (occupied !== undefined || accepted !== undefined) throw new SyncError("corrupt-state", "The next canonical sequence is already occupied.");
                const operationView = await loadDeclaredRecordView(transaction, "confirmed", model.operationReads(cloneCodecValue(protocolModel.operation, operation, "canonical operation")));
                const applied: unknown = model.applyCommitted(operationView.view, cloneCodecValue(protocolModel.operation, operation, "canonical operation"));
                assertSynchronous(applied, "Canonical record application");
                await transaction.apply("confirmed", operationView.writes());
                await transaction.putInternal("canonical", [sequence], entry);
                await transaction.putInternal("accepted", [sequence], identity.operationId);
                headSequence = sequence;
              } else if (outcome.status === "rejected") {
                decision = { ...identity, status: "rejected", reason: cloneCodecValue(protocolModel.rejection, outcome.reason, "rejection reason") };
                encodeSyncResponse({ protocolVersion: 1, contractVersion: model.contractVersion, streamId: database.streamId,
                  requestedBaseSequence: headSequence, throughSequence: headSequence, headSequence, entries: [], decisions: [decision] }, protocolModel, protocolOptions);
              } else {
                throw new SyncError("invalid-input", "The decision policy returned an invalid status.");
              }
              await transaction.putInternal("identities", [identity.operationId], identity);
              await transaction.putInternal("positions", [identity.clientId, identity.clientSequence], identity);
              await transaction.putInternal("decisions", [identity.operationId], decision);
              decisions.push(decision);
              changed = true;
            }

            if (changed) await transaction.putInternal("meta", ["authority"], { ...metadata, headSequence });
            const entries = await page(transaction, request.baseSequence, request.maximumEntries, headSequence);
            const response: SyncResponse<Operation, Rejection> = {
              protocolVersion: 1, contractVersion: model.contractVersion, streamId: database.streamId,
              requestedBaseSequence: request.baseSequence, throughSequence: request.baseSequence + entries.length,
              headSequence, entries, decisions,
            };
            // Failure here aborts the complete transaction, including all staged rows.
            const detached = decodeSyncResponse(JSON.parse(encodeSyncResponse(response, protocolModel, protocolOptions)), protocolModel, protocolOptions);
            if (validateResponse !== undefined) {
              const validated: unknown = validateResponse(structuredClone(detached));
              assertSynchronous(validated, "Response validation");
            }
            return detached;
          });
          return result.value;
        } catch (error) {
          if (!(error instanceof SyncError) || error.code !== "commit-conflict") throw error;
        }
      }
      throw new SyncError("commit-conflict", "The authority could not commit within its retry budget.");
    },
  };
}
