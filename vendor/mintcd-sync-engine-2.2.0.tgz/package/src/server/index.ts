export { createSyncAuthority } from "./authority.js";
export type { SyncAuthorityOptions } from "./authority.js";
export { createRecordSyncAuthority } from "./record-authority.js";
export type { RecordSyncAuthorityOptions } from "./record-authority.js";
