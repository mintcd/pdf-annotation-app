import type { OperationIdentity } from "../core/types.js";

/** Shared Fetch helpers; neither side buffers more than its configured body cap. */
export const DEFAULT_MAXIMUM_REQUEST_BYTES = 1024 * 1024;
export const DEFAULT_MAXIMUM_RESPONSE_BYTES = 4 * 1024 * 1024;

export function byteLimit(value: number | undefined, fallback: number, label: string): number {
  const result = value ?? fallback;
  if (!Number.isSafeInteger(result) || result < 1) throw new TypeError(`${label} must be a positive safe integer.`);
  return result;
}

export function utf8Length(value: string): number { return new TextEncoder().encode(value).byteLength; }

export function sameSubmittedIdentities(expected: readonly OperationIdentity[], actual: readonly OperationIdentity[]): boolean {
  if (expected.length !== actual.length) return false;
  const byId = new Map(expected.map(identity => [identity.operationId, identity]));
  return actual.every(identity => {
    const original = byId.get(identity.operationId);
    return original !== undefined && original.clientId === identity.clientId && original.clientSequence === identity.clientSequence && original.intentHash === identity.intentHash;
  });
}

export function isJsonContentType(value: string | null): boolean {
  return value !== null && /^\s*application\/json\s*(?:;\s*charset\s*=\s*(?:utf-8|"utf-8")\s*)?$/i.test(value);
}

export class HttpBodyError extends Error {
  constructor(readonly code: "too-large" | "invalid-length" | "invalid-utf8" | "aborted" | "read-failed", options?: ErrorOptions) {
    super(`HTTP body ${code}.`, options);
    this.name = "HttpBodyError";
  }
}

export function throwIfAborted(signal?: AbortSignal): void {
  if (signal?.aborted) throw new HttpBodyError("aborted", { cause: signal.reason });
}

/** Observe late rejections too, including Fetch implementations that ignore the signal. */
export function withAbort<Value>(promise: Promise<Value>, signal?: AbortSignal): Promise<Value> {
  if (!signal) return promise;
  return new Promise<Value>((resolve, reject) => {
    const aborted = () => reject(new HttpBodyError("aborted", { cause: signal.reason }));
    signal.addEventListener("abort", aborted, { once: true });
    if (signal.aborted) aborted();
    promise.then(value => { signal.removeEventListener("abort", aborted); resolve(value); },
      cause => { signal.removeEventListener("abort", aborted); reject(cause); });
  });
}

function cancel(reader: ReadableStreamDefaultReader<Uint8Array>, reason?: unknown): void {
  try { void reader.cancel(reason).catch(() => {}); } catch { /* Cancellation must not mask the original failure. */ }
}

export function cancelBody(body: ReadableStream<Uint8Array> | null): void {
  if (body) { try { void body.cancel().catch(() => {}); } catch { /* A used or locked body cannot be canceled here. */ } }
}

export async function readLimitedBody(body: ReadableStream<Uint8Array> | null, headers: Headers, maximumBytes: number, signal?: AbortSignal): Promise<string> {
  if (signal?.aborted) { cancelBody(body); throwIfAborted(signal); }
  const length = headers.get("content-length");
  if (length !== null) {
    if (!/^\d+$/.test(length)) { cancelBody(body); throw new HttpBodyError("invalid-length"); }
    const normalized = length.replace(/^0+/, "") || "0";
    const maximum = String(maximumBytes);
    if (normalized.length > maximum.length || (normalized.length === maximum.length && normalized > maximum)) { cancelBody(body); throw new HttpBodyError("too-large"); }
  }
  if (!body) return "";
  let reader: ReadableStreamDefaultReader<Uint8Array>;
  try { reader = body.getReader(); }
  catch (cause) { throw new HttpBodyError("read-failed", { cause }); }
  const onAbort = () => cancel(reader, signal?.reason);
  signal?.addEventListener("abort", onAbort, { once: true });
  const chunks: Uint8Array[] = [];
  let size = 0;
  try {
    while (true) {
      throwIfAborted(signal);
      const result = await withAbort(reader.read(), signal);
      throwIfAborted(signal);
      if (result.done) break;
      if (!(result.value instanceof Uint8Array)) throw new HttpBodyError("read-failed");
      size += result.value.byteLength;
      if (size > maximumBytes) throw new HttpBodyError("too-large");
      chunks.push(result.value);
    }
    const bytes = new Uint8Array(size);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
    try { return new TextDecoder("utf-8", { fatal: true }).decode(bytes); }
    catch (cause) { throw new HttpBodyError("invalid-utf8", { cause }); }
  } catch (cause) {
    cancel(reader, cause);
    if (cause instanceof HttpBodyError) throw cause;
    if (signal?.aborted) throw new HttpBodyError("aborted", { cause });
    throw new HttpBodyError("read-failed", { cause });
  } finally {
    signal?.removeEventListener("abort", onAbort);
    reader.releaseLock();
  }
}

export interface HttpErrorEnvelope {
  readonly protocolVersion: 1;
  readonly error: { readonly code: string; readonly message: string; readonly retryable: boolean; readonly retryAfterMs?: number };
}

/** Only display explicitly bounded server text; classification is local and based on status. */
export function parseErrorEnvelope(text: string): HttpErrorEnvelope | undefined {
  let value: unknown;
  try { value = JSON.parse(text) as unknown; } catch { return undefined; }
  if (value === null || typeof value !== "object") return undefined;
  const envelope = value as Record<string, unknown>;
  if (envelope.protocolVersion !== 1 || Object.keys(envelope).length !== 2 || envelope.error === null || typeof envelope.error !== "object") return undefined;
  const error = envelope.error as Record<string, unknown>;
  if (Object.keys(error).some(key => !["code", "message", "retryable", "retryAfterMs"].includes(key))
    || typeof error.code !== "string" || !/^[a-z][a-z0-9-]{0,127}$/.test(error.code)
    || typeof error.message !== "string" || error.message.length > 1024 || typeof error.retryable !== "boolean"
    || (error.retryAfterMs !== undefined && (typeof error.retryAfterMs !== "number" || !Number.isFinite(error.retryAfterMs) || error.retryAfterMs < 0))) return undefined;
  return value as HttpErrorEnvelope;
}

export function retryAfterMilliseconds(headers: Headers): number | undefined {
  const value = headers.get("retry-after");
  if (value === null) return undefined;
  if (/^\d+$/.test(value)) {
    const milliseconds = Number(value) * 1000;
    return Number.isSafeInteger(milliseconds) ? milliseconds : undefined;
  }
  const date = Date.parse(value);
  return Number.isFinite(date) ? Math.max(0, date - Date.now()) : undefined;
}
