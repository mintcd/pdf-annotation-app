import { SyncError } from "../core/errors.js";
import { decodeSyncRequest, encodeSyncResponse, resolveProtocolLimits } from "../core/protocol.js";
import type { ProtocolModel } from "../core/protocol.js";
import type { ProtocolLimits, SyncAuthority, SyncResponse } from "../core/types.js";
import { byteLimit, cancelBody, DEFAULT_MAXIMUM_REQUEST_BYTES, DEFAULT_MAXIMUM_RESPONSE_BYTES, HttpBodyError, isJsonContentType, readLimitedBody, sameSubmittedIdentities, throwIfAborted, utf8Length, withAbort } from "./http-common.js";

export interface SyncRequestScope {
  readonly protocolVersion: 1;
  readonly contractVersion: string;
  readonly streamId: string;
}

export interface ResolvedSyncContext<Context> {
  /** This must be the stream authorized by the application, then checked against the wire. */
  readonly streamId: string;
  readonly context: Context;
}

export interface SyncHandlerOptions<Intent, Operation, Rejection, Context> {
  readonly model: ProtocolModel<Intent, Operation, Rejection>;
  /** Required: authenticate, authorize this stream, and enforce the application's origin/CSRF policy. */
  readonly resolveContext: (request: Request, scope: SyncRequestScope) => ResolvedSyncContext<Context> | Promise<ResolvedSyncContext<Context>>;
  readonly getAuthority: (context: Context, streamId: string) => SyncAuthority<Intent, Operation, Rejection, Context> | Promise<SyncAuthority<Intent, Operation, Rejection, Context>>;
  readonly maximumRequestBytes?: number;
  readonly maximumResponseBytes?: number;
  readonly limits?: Partial<ProtocolLimits>;
}

/** Throw from a trusted application hook to return a deliberate, public HTTP error. */
export class SyncHttpError extends Error {
  readonly status: number;
  readonly code: string;
  readonly retryable: boolean;
  readonly retryAfterMs: number | undefined;

  constructor(status: number, code: string, message: string, options?: ErrorOptions & { readonly retryAfterMs?: number }) {
    super(message, options);
    if (!Number.isInteger(status) || status < 400 || status > 599 || !/^[a-z][a-z0-9-]{0,127}$/.test(code) || message.length > 1024) throw new TypeError("SyncHttpError requires a 4xx/5xx status, a short error code, and a public message of at most 1024 characters.");
    if (options?.retryAfterMs !== undefined && (!Number.isFinite(options.retryAfterMs) || options.retryAfterMs < 0)) throw new TypeError("retryAfterMs must be finite and nonnegative.");
    this.name = "SyncHttpError";
    this.status = status;
    this.code = code;
    this.retryable = [408, 429, 502, 503, 504].includes(status);
    this.retryAfterMs = options?.retryAfterMs;
  }
}

function publicError(cause: unknown): SyncHttpError {
  if (cause instanceof SyncHttpError) return cause;
  if (cause instanceof HttpBodyError) {
    if (cause.code === "too-large") return new SyncHttpError(413, "request-too-large", "Sync request exceeds the configured byte limit.");
    if (cause.code === "aborted") return new SyncHttpError(408, "request-aborted", "Sync request was aborted.");
    return new SyncHttpError(400, "invalid-input", "Sync request body is invalid.");
  }
  if (cause instanceof SyncError) {
    const messages = {
      "invalid-input": "Sync request is invalid.", "unsupported-version": "Sync protocol version is unsupported.",
      "contract-mismatch": "Sync contract version does not match.", "stream-mismatch": "Sync stream does not match.",
      "invalid-cursor": "Sync cursor is invalid.", "identity-conflict": "Sync operation identity conflicts with retained history.",
      "divergence": "Sync history diverges from retained history.", "commit-conflict": "Sync authority is busy. Retry the request.",
      "closed": "Sync authority is unavailable.", "limit-exceeded": "Sync request exceeds a configured limit.", "corrupt-state": "Sync authority failed to read its state.",
    } as const;
    if (!Object.hasOwn(messages, cause.code)) return new SyncHttpError(500, "internal-error", "The sync endpoint failed to process the request.");
    const status = cause.code === "corrupt-state" ? 500 : cause.code === "commit-conflict" || cause.code === "closed" ? 503
      : cause.code === "limit-exceeded" ? 413 : ["identity-conflict", "divergence", "invalid-cursor", "contract-mismatch", "stream-mismatch"].includes(cause.code) ? 409 : 400;
    return new SyncHttpError(status, cause.code, messages[cause.code]);
  }
  return new SyncHttpError(500, "internal-error", "The sync endpoint failed to process the request.");
}

function responseHeaders(): Headers {
  return new Headers({ "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" });
}

/** A framework-neutral Fetch endpoint. Route generation only needs to bind this handler. */
export function createSyncHandler<Intent, Operation, Rejection, Context>(options: SyncHandlerOptions<Intent, Operation, Rejection, Context>): (request: Request) => Promise<Response> {
  if (typeof options.resolveContext !== "function" || typeof options.getAuthority !== "function") throw new TypeError("resolveContext and getAuthority are required.");
  const maximumRequestBytes = byteLimit(options.maximumRequestBytes, DEFAULT_MAXIMUM_REQUEST_BYTES, "maximumRequestBytes");
  const maximumResponseBytes = byteLimit(options.maximumResponseBytes, DEFAULT_MAXIMUM_RESPONSE_BYTES, "maximumResponseBytes");
  const limits = resolveProtocolLimits(options.limits);
  const { model, resolveContext, getAuthority } = options;
  return async (request) => {
    try {
      throwIfAborted(request.signal);
      if (request.method !== "POST") throw new SyncHttpError(405, "method-not-allowed", "Sync endpoint accepts POST requests.");
      if (!isJsonContentType(request.headers.get("content-type")) || request.headers.has("content-encoding")) throw new SyncHttpError(415, "unsupported-media-type", "Sync endpoint accepts uncompressed UTF-8 application/json.");
      const text = await readLimitedBody(request.body, request.headers, maximumRequestBytes, request.signal);
      const input = decodeSyncRequest(text, model, { limits });
      const { streamId, baseSequence, maximumEntries } = input;
      const identities = input.proposals.map(({ operationId, clientId, clientSequence, intentHash }) => ({ operationId, clientId, clientSequence, intentHash }));
      const scope: SyncRequestScope = Object.freeze({ protocolVersion: 1, contractVersion: input.contractVersion, streamId: input.streamId });
      const resolved = await withAbort(Promise.resolve().then(() => resolveContext(request, scope)), request.signal);
      if (resolved === null || typeof resolved !== "object" || resolved.streamId !== streamId) throw new SyncHttpError(403, "access-denied", "The requested sync stream is not authorized.");
      const context = resolved.context;
      throwIfAborted(request.signal);
      const authority = await withAbort(Promise.resolve().then(() => getAuthority(context, streamId)), request.signal);
      throwIfAborted(request.signal);
      const encode = (response: SyncResponse<Operation, Rejection>): string => {
        throwIfAborted(request.signal);
        if (response.requestedBaseSequence !== baseSequence || response.entries.length > maximumEntries) throw new SyncError("corrupt-state", "Authority returned a different requested page.");
        const body = encodeSyncResponse(response, model, { streamId, limits });
        if (!sameSubmittedIdentities(identities, response.decisions)) throw new SyncError("corrupt-state", "Authority returned decisions that do not match submitted proposals.");
        if (utf8Length(body) > maximumResponseBytes) throw new SyncHttpError(413, "response-too-large", "Sync response exceeds the configured byte limit.");
        return body;
      };
      const result = await authority.synchronize(input, context, { validateResponse: response => { encode(response); } });
      return new Response(encode(result), { status: 200, headers: responseHeaders() });
    } catch (cause) {
      cancelBody(request.body);
      const error = publicError(cause);
      const headers = responseHeaders();
      if (error.status === 405) headers.set("allow", "POST");
      if (error.retryAfterMs !== undefined) headers.set("retry-after", String(Math.ceil(error.retryAfterMs / 1000)));
      const body = JSON.stringify({ protocolVersion: 1, error: { code: error.code, message: error.message, retryable: error.retryable,
        ...(error.retryAfterMs === undefined ? {} : { retryAfterMs: error.retryAfterMs }) } });
      // A deliberately tiny response cap still bounds errors; clients can classify the status alone.
      return new Response(utf8Length(body) <= maximumResponseBytes ? body : null, { status: error.status, headers });
    }
  };
}
