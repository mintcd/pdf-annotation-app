import { SyncTransportError } from "../client/errors.js";
import type { SyncTransportErrorCode } from "../client/errors.js";
import { SyncError } from "../core/errors.js";
import type { SyncErrorCode } from "../core/errors.js";
import { decodeSyncResponse, encodeSyncRequest, resolveProtocolLimits } from "../core/protocol.js";
import type { ProtocolModel } from "../core/protocol.js";
import type { ProtocolLimits, SyncTransport } from "../core/types.js";
import { byteLimit, cancelBody, DEFAULT_MAXIMUM_REQUEST_BYTES, DEFAULT_MAXIMUM_RESPONSE_BYTES, HttpBodyError, isJsonContentType, parseErrorEnvelope, readLimitedBody, retryAfterMilliseconds, sameSubmittedIdentities, throwIfAborted, utf8Length, withAbort } from "./http-common.js";

export interface HttpSyncTransportOptions<Intent, Operation, Rejection> {
  readonly url: string | URL;
  readonly streamId: string;
  readonly model: ProtocolModel<Intent, Operation, Rejection>;
  readonly fetch?: typeof globalThis.fetch;
  /** Read again for every exchange, so token refresh does not rebuild the engine. */
  readonly headers?: HeadersInit | (() => HeadersInit | Promise<HeadersInit>);
  readonly credentials?: RequestCredentials;
  readonly maximumRequestBytes?: number;
  readonly maximumResponseBytes?: number;
  readonly limits?: Partial<ProtocolLimits>;
}

export class HttpSyncTransportError extends SyncTransportError {
  readonly httpStatus: number | undefined;
  readonly serverCode: string | undefined;

  constructor(code: SyncTransportErrorCode, message: string, options?: ErrorOptions & { readonly httpStatus?: number; readonly serverCode?: string; readonly retryAfterMs?: number }) {
    super(code, message, options);
    this.name = "HttpSyncTransportError";
    this.httpStatus = options?.httpStatus;
    this.serverCode = options?.serverCode;
  }
}

/** A recognized protocol failure keeps the same code/retry semantics as an in-process authority. */
export class HttpSyncProtocolError extends SyncError {
  constructor(code: SyncErrorCode, message: string, readonly httpStatus: number) {
    super(code, message);
    this.name = "HttpSyncProtocolError";
  }
}

const protocolStatuses: Readonly<Record<SyncErrorCode, number>> = {
  "invalid-input": 400, "unsupported-version": 400, "contract-mismatch": 409, "stream-mismatch": 409,
  "invalid-cursor": 409, "identity-conflict": 409, "divergence": 409, "commit-conflict": 503,
  "closed": 503, "limit-exceeded": 413, "corrupt-state": 500,
};

function statusCode(status: number): SyncTransportErrorCode {
  if (status === 401 || status === 403) return "access";
  if (status === 429) return "rate-limit";
  if (status === 408 || status === 504) return "timeout";
  if (status === 502 || status === 503) return "network";
  return "invalid-response";
}

/** Fetch only carries protocol messages; the coordinator owns scheduling and retries. */
export function createHttpSyncTransport<Intent, Operation, Rejection>(options: HttpSyncTransportOptions<Intent, Operation, Rejection>): SyncTransport<Intent, Operation, Rejection> {
  const maximumRequestBytes = byteLimit(options.maximumRequestBytes, DEFAULT_MAXIMUM_REQUEST_BYTES, "maximumRequestBytes");
  const maximumResponseBytes = byteLimit(options.maximumResponseBytes, DEFAULT_MAXIMUM_RESPONSE_BYTES, "maximumResponseBytes");
  const url = String(options.url);
  const parsedUrl = new URL(url, "https://sync.invalid/");
  if (!url || !["https:", "http:"].includes(parsedUrl.protocol) || parsedUrl.username || parsedUrl.password || parsedUrl.hash) throw new TypeError("url must be an HTTP(S) endpoint without URL credentials or a fragment.");
  const fetcher = options.fetch ?? globalThis.fetch;
  if (typeof fetcher !== "function") throw new TypeError("A Fetch implementation is required.");
  const protocolOptions = { streamId: options.streamId, limits: resolveProtocolLimits(options.limits) };
  const credentials = options.credentials ?? "same-origin";
  const suppliedHeaders = options.headers;
  const model = options.model;
  return {
    async exchange(request, exchangeOptions) {
      const signal = exchangeOptions?.signal;
      try {
        throwIfAborted(signal);
        const body = encodeSyncRequest(request, model, protocolOptions);
        if (utf8Length(body) > maximumRequestBytes) throw new SyncError("limit-exceeded", "Sync request exceeds the configured byte limit.");
        const baseSequence = request.baseSequence;
        const maximumEntries = request.maximumEntries;
        const identities = request.proposals.map(({ operationId, clientId, clientSequence, intentHash }) => ({ operationId, clientId, clientSequence, intentHash }));
        const headers = new Headers(typeof suppliedHeaders === "function" ? await withAbort(Promise.resolve().then(suppliedHeaders), signal) : suppliedHeaders);
        headers.set("content-type", "application/json; charset=utf-8");
        headers.set("accept", "application/json");
        headers.set("cache-control", "no-store");
        throwIfAborted(signal);
        let response: Response;
        try {
          const pending = fetcher(url, { method: "POST", body, headers, credentials, redirect: "error", cache: "no-store", ...(signal ? { signal } : {}) });
          // A custom Fetch can ignore abort. Release any late response body in that case.
          void pending.then(value => { if (signal?.aborted) cancelBody(value.body); }, () => {});
          response = await withAbort(pending, signal);
        } catch (cause) {
          if (cause instanceof HttpBodyError || signal?.aborted) throw new HttpBodyError("aborted", { cause });
          throw new HttpSyncTransportError("network", "The sync endpoint could not be reached.", { cause });
        }
        if (response.redirected || response.type === "opaqueredirect" || response.type === "opaque") {
          cancelBody(response.body);
          throw new HttpSyncTransportError("invalid-response", "Redirected and opaque sync responses are not accepted.", { httpStatus: response.status });
        }
        const text = await readLimitedBody(response.body, response.headers, maximumResponseBytes, signal);
        if (response.status !== 200) {
          const envelope = isJsonContentType(response.headers.get("content-type")) ? parseErrorEnvelope(text) : undefined;
          const serverCode = envelope?.error.code;
          if (serverCode !== undefined && Object.hasOwn(protocolStatuses, serverCode) && protocolStatuses[serverCode as SyncErrorCode] === response.status) {
            throw new HttpSyncProtocolError(serverCode as SyncErrorCode, envelope!.error.message, response.status);
          }
          const retryAfterMs = retryAfterMilliseconds(response.headers) ?? envelope?.error.retryAfterMs;
          throw new HttpSyncTransportError(statusCode(response.status), envelope?.error.message ?? "The sync endpoint rejected the request.", {
            httpStatus: response.status, ...(envelope ? { serverCode: envelope.error.code } : {}), ...(retryAfterMs === undefined ? {} : { retryAfterMs }),
          });
        }
        if (!isJsonContentType(response.headers.get("content-type"))) throw new HttpSyncTransportError("invalid-response", "The sync endpoint did not return JSON.", { httpStatus: response.status });
        try {
          const result = decodeSyncResponse(text, model, protocolOptions);
          if (result.requestedBaseSequence !== baseSequence || result.entries.length > maximumEntries) throw new SyncError("invalid-cursor", "The sync response does not match its request page.");
          if (!sameSubmittedIdentities(identities, result.decisions)) throw new SyncError("identity-conflict", "The sync response decisions do not match its submitted proposals.");
          return result;
        } catch (cause) { throw new HttpSyncTransportError("invalid-response", "The sync endpoint returned an invalid protocol response.", { httpStatus: response.status, ...(cause instanceof SyncError ? { serverCode: cause.code } : {}), cause }); }
      } catch (cause) {
        if (cause instanceof HttpBodyError) {
          if (cause.code === "aborted") {
            const timedOut = (signal?.reason instanceof SyncTransportError && signal.reason.code === "timeout")
              || (signal?.reason instanceof DOMException && signal.reason.name === "TimeoutError");
            throw new HttpSyncTransportError(timedOut ? "timeout" : "aborted", timedOut ? "The sync request timed out." : "The sync request was aborted.", { cause });
          }
          if (cause.code === "read-failed") throw new HttpSyncTransportError("network", "The sync response body could not be read.", { cause });
          throw new HttpSyncTransportError("invalid-response", "The sync response body is invalid or exceeds the configured byte limit.", { cause });
        }
        throw cause;
      }
    },
  };
}
