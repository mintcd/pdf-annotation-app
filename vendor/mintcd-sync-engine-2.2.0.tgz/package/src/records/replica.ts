import { cloneCodecValue } from "../core/codecs.js";
import { SyncError } from "../core/errors.js";
import { canonicalizeJson, createIntentHash } from "../core/fingerprint.js";
import { decodeSyncResponse, encodeSyncRequest, encodeSyncResponse, resolveProtocolLimits } from "../core/protocol.js";
import { assertIdentifier, assertIdentity, assertSameIdentity, assertSequence } from "../core/validation.js";
import type { AcceptedDecision, Codec, CommittedOperation, Decision, OperationIdentity, OverlayPreview, Proposal, SyncRequest } from "../core/types.js";
import { addressKey, recordAddress, schemaIdentity } from "./schema.js";
import { loadDeclaredRecordView } from "./view.js";
import type {
  OpenRecordReplicaOptions, RecordAddress, RecordCommitSummary,
  RecordReplica, RecordReplicaStatus, RecordSchema, RecordTransaction, RecordWrite,
} from "./types.js";

interface ReplicaMeta {
  readonly kind: "record-replica-v1";
  readonly clientId: string;
  readonly contractVersion: string;
  readonly schemaVersion: string;
  readonly schemaIdentity: string;
  /** History before this materialized checkpoint is intentionally absent. */
  readonly bootstrapSequence?: number;
  nextClientSequence: number;
  confirmedSequence: number;
  headSequence: number;
  pendingCount: number;
  acceptedAwaitingCount: number;
  resolutionCount: number;
}

interface RecordOutbox<Schema extends RecordSchema, Intent, Operation> {
  readonly proposal: Proposal<Intent>;
  readonly decision?: AcceptedDecision<Operation>;
  readonly touched: readonly RecordAddress<Schema>[];
  readonly preview: OverlayPreview;
}

const metaKey = ["replica"] as const;
const copy = <Value>(value: Value): Value => structuredClone(value);

function isolatedCodec<Value>(codec: Codec<Value>): Codec<Value> {
  return { encode: value => codec.encode(copy(value)), decode: value => copy(codec.decode(copy(value))) };
}

function identityOf(value: OperationIdentity): OperationIdentity {
  return { operationId: value.operationId, clientId: value.clientId, clientSequence: value.clientSequence, intentHash: value.intentHash };
}

function assertSynchronous(value: unknown, label: string): void {
  if (value !== null && (typeof value === "object" || typeof value === "function") && "then" in value) {
    void Promise.resolve(value).catch(() => undefined);
    throw new SyncError("invalid-input", `${label} must be synchronous.`);
  }
}

function samePayload<Value>(left: Value, right: Value, codec: Codec<Value>): boolean {
  return canonicalizeJson(codec.encode(copy(left))) === canonicalizeJson(codec.encode(copy(right)));
}

function assertSameEntry<Operation>(left: CommittedOperation<Operation>, right: CommittedOperation<Operation>, codec: Codec<Operation>): void {
  assertSameIdentity(left, right);
  if (left.sequence !== right.sequence || !samePayload(left.operation, right.operation, codec)) {
    throw new SyncError("divergence", "Canonical operation differs from retained history.");
  }
}

function assertSameDecision<Operation, Rejection>(left: Decision<Operation, Rejection>, right: Decision<Operation, Rejection>, operation: Codec<Operation>, rejection: Codec<Rejection>): void {
  assertSameIdentity(left, right);
  if (left.status !== right.status) throw new SyncError("divergence", "A retained decision cannot change its outcome.");
  if (left.status === "accepted" && right.status === "accepted") assertSameEntry(left, right, operation);
  if (left.status === "rejected" && right.status === "rejected" && !samePayload(left.reason, right.reason, rejection)) {
    throw new SyncError("divergence", "A retained rejection cannot change its reason.");
  }
}

/** Record-mode replica: normal operations use exact receipts and the current outbox, never history scans. */
export async function openRecordReplica<Schema extends RecordSchema, Intent, Operation, Rejection>(
  options: OpenRecordReplicaOptions<Schema, Intent, Operation, Rejection>,
): Promise<RecordReplica<Schema, Intent, Operation, Rejection>> {
  const { database, model, clientId } = options;
  const requireExisting = options.requireExisting ?? false;
  if (typeof requireExisting !== "boolean") throw new SyncError("invalid-input", "requireExisting must be a boolean.");
  assertIdentifier(database.streamId, "streamId");
  assertIdentifier(clientId, "clientId");
  assertIdentifier(model.contractVersion, "contractVersion");
  assertIdentifier(model.schema.version, "schemaVersion");
  const modelSchemaIdentity = schemaIdentity(model.schema);
  if (schemaIdentity(database.schema) !== modelSchemaIdentity) throw new SyncError("contract-mismatch", "Database and model schemas differ.");
  const limits = resolveProtocolLimits(options.limits);
  const protocolModel = { contractVersion: model.contractVersion, intent: isolatedCodec(model.intent),
    operation: isolatedCodec(model.operation), rejection: isolatedCodec(model.rejection) };
  const protocolOptions = { streamId: database.streamId, limits };
  let closed = false;
  const assertOpen = (): void => {
    if (closed) throw new SyncError("closed", "Record replica is closed.");
  };
  const loadMeta = async (tx: RecordTransaction<Schema>): Promise<ReplicaMeta> => {
    const meta = await tx.getInternal<ReplicaMeta>("meta", metaKey);
    if (!meta || meta.kind !== "record-replica-v1") throw new SyncError("corrupt-state", "Record replica metadata is missing.");
    if (meta.clientId !== clientId) throw new SyncError("identity-conflict", "The database belongs to a different client identity.");
    if (meta.contractVersion !== model.contractVersion || meta.schemaVersion !== model.schema.version || meta.schemaIdentity !== modelSchemaIdentity) {
      throw new SyncError("contract-mismatch", "Stored schema or contract version differs from this model.");
    }
    assertSequence(meta.nextClientSequence, "nextClientSequence", 1);
    for (const field of ["confirmedSequence", "headSequence", "pendingCount", "acceptedAwaitingCount", "resolutionCount"] as const) assertSequence(meta[field], field);
    assertSequence(meta.bootstrapSequence ?? 0, "bootstrapSequence");
    if ((meta.bootstrapSequence ?? 0) > meta.confirmedSequence) throw new SyncError("corrupt-state", "Bootstrap checkpoint exceeds the confirmed cursor.");
    if (meta.headSequence < meta.confirmedSequence) throw new SyncError("corrupt-state", "Observed head precedes the confirmed cursor.");
    return meta;
  };
  const statusOf = (meta: ReplicaMeta, revision: number): RecordReplicaStatus => ({
    streamId: database.streamId, clientId, revision, confirmedSequence: meta.confirmedSequence,
    headSequence: meta.headSequence, nextClientSequence: meta.nextClientSequence, pendingCount: meta.pendingCount,
    acceptedAwaitingCount: meta.acceptedAwaitingCount, resolutionCount: meta.resolutionCount,
  });
  await database.transaction("readwrite", async tx => {
    if (await tx.getInternal("meta", ["authority"])) throw new SyncError("contract-mismatch", "An authority database cannot also host a replica.");
    const previous = await tx.getInternal<ReplicaMeta>("meta", metaKey);
    if (previous) { await loadMeta(tx); return; }
    if (requireExisting) throw new SyncError("corrupt-state", "Replica metadata is missing; explicit bootstrap is required.");
    await tx.putInternal<ReplicaMeta>("meta", metaKey, { kind: "record-replica-v1", clientId,
      contractVersion: model.contractVersion, schemaVersion: model.schema.version, schemaIdentity: modelSchemaIdentity, nextClientSequence: 1,
      confirmedSequence: 0, headSequence: 0, pendingCount: 0, acceptedAwaitingCount: 0, resolutionCount: 0 });
  });

  const bindIdentity = async (tx: RecordTransaction<Schema>, meta: ReplicaMeta, value: OperationIdentity): Promise<void> => {
    assertIdentity(value);
    if (value.clientId === clientId && value.clientSequence >= meta.nextClientSequence) {
      throw new SyncError("identity-conflict", "The next client sequence is already bound to received work.");
    }
    const byId = await tx.getInternal<OperationIdentity>("identities", [value.operationId]);
    const byPosition = await tx.getInternal<OperationIdentity>("positions", [value.clientId, value.clientSequence]);
    if (byId) assertSameIdentity(byId, value);
    if (byPosition) assertSameIdentity(byPosition, value);
    if (!byId) await tx.putInternal("identities", [value.operationId], identityOf(value));
    if (!byPosition) await tx.putInternal("positions", [value.clientId, value.clientSequence], identityOf(value));
  };

  const preview = async (tx: RecordTransaction<Schema>, entry: Omit<RecordOutbox<Schema, Intent, Operation>, "touched" | "preview">): Promise<RecordOutbox<Schema, Intent, Operation>> => {
    let result: OverlayPreview;
    let writes: readonly RecordWrite<Schema>[] | undefined;
    let reads;
    try {
      reads = entry.decision ? model.operationReads(copy(entry.decision.operation)) : model.intentReads(copy(entry.proposal.intent));
      assertSynchronous(reads, "Preview read declarations");
    } catch (error) {
      return { ...entry, touched: [], preview: { operationId: entry.proposal.operationId, status: "unavailable",
        reason: error instanceof Error ? error.message : "Preview reads failed." } };
    }
    // Adapter read failures must abort, just like write failures. A malformed read
    // declaration is a model contract error, rather than a domain preview result.
    const staged = await loadDeclaredRecordView(tx, "visible", copy(reads));
    try {
      const outcome = entry.decision ? model.previewOperation(staged.view, copy(entry.decision.operation))
        : model.previewIntent(staged.view, copy(entry.proposal.intent));
      assertSynchronous(outcome, "Record previews");
      if (outcome?.status === "applied") {
        writes = staged.writes();
        result = { operationId: entry.proposal.operationId, status: "applied" };
      } else {
        result = { operationId: entry.proposal.operationId, status: "unavailable",
          reason: outcome?.status === "unavailable" && typeof outcome.reason === "string" ? outcome.reason : "Preview returned an invalid result." };
      }
    } catch (error) {
      result = { operationId: entry.proposal.operationId, status: "unavailable", reason: error instanceof Error ? error.message : "Preview failed." };
    }
    // Storage failures abort the outer transaction; only domain preview failures are unavailable.
    if (writes) {
      await tx.apply("visible", writes);
      return { ...entry, touched: writes.map(write => recordAddress(model.schema, write)), preview: result };
    }
    return { ...entry, touched: [], preview: result };
  };

  return {
    async status() {
      assertOpen();
      return (await database.transaction("readonly", async tx => statusOf(await loadMeta(tx), tx.revision))).value;
    },
    async get(collection, key) {
      assertOpen();
      const capturedKey = copy(key);
      return (await database.transaction("readonly", async tx => ({ row: await tx.get("visible", collection, capturedKey), status: statusOf(await loadMeta(tx), tx.revision) }))).value;
    },
    async query(query) {
      assertOpen();
      const captured = copy(query);
      return (await database.transaction("readonly", async tx => ({ ...await tx.query("visible", captured), status: statusOf(await loadMeta(tx), tx.revision) }))).value;
    },
    async enqueue(input) {
      assertOpen();
      const captured = copy(input);
      assertIdentifier(captured.operationId, "operationId");
      const intent = cloneCodecValue(model.intent, captured.intent, "intent");
      const intentHash = await createIntentHash(model.intent.encode(copy(intent)));
      assertOpen();
      // Validate the entire envelope before a native transaction, including wrapper nesting.
      // Number allocation changes no count/depth constraints checked by protocol v1.
      encodeSyncRequest({ protocolVersion: 1, contractVersion: model.contractVersion, streamId: database.streamId,
        baseSequence: 0, maximumEntries: limits.maximumEntries,
        proposals: [{ operationId: captured.operationId, clientId, clientSequence: 1, intentHash, intent: copy(intent) }] }, protocolModel, protocolOptions);
      return (await database.transaction("readwrite", async tx => {
        assertOpen();
        const meta = await loadMeta(tx);
        assertSequence(meta.nextClientSequence + 1, "nextClientSequence", 1);
        const proposal: Proposal<Intent> = { operationId: captured.operationId, clientId,
          clientSequence: meta.nextClientSequence, intentHash, intent: copy(intent) };
        if (await tx.getInternal("identities", [proposal.operationId]) || await tx.getInternal("positions", [clientId, proposal.clientSequence])) {
          throw new SyncError("identity-conflict", "Operation ID or client position has already been used.");
        }
        const entry = await preview(tx, { proposal });
        await tx.putInternal("identities", [proposal.operationId], identityOf(proposal));
        await tx.putInternal("positions", [clientId, proposal.clientSequence], identityOf(proposal));
        await tx.putInternal("outbox", [proposal.clientSequence], entry);
        await tx.putInternal("pending", [proposal.clientSequence], proposal);
        meta.nextClientSequence++;
        meta.pendingCount++;
        await tx.putInternal("meta", metaKey, meta);
        return identityOf(proposal);
      })).value;
    },
    async prepareSyncRequest(syncOptions = {}) {
      assertOpen();
      const maximumProposals = syncOptions.maximumProposals ?? limits.maximumProposals;
      const maximumEntries = syncOptions.maximumEntries ?? limits.maximumEntries;
      assertSequence(maximumProposals, "maximumProposals");
      assertSequence(maximumEntries, "maximumEntries", 1);
      if (maximumProposals > limits.maximumProposals || maximumEntries > limits.maximumEntries) throw new SyncError("limit-exceeded", "Requested synchronization bounds exceed configured limits.");
      return (await database.transaction("readonly", async tx => {
        const meta = await loadMeta(tx);
        const pending = maximumProposals === 0 ? [] : await tx.scanInternal<Proposal<Intent>>("pending", { limit: maximumProposals });
        const request: SyncRequest<Intent> = { protocolVersion: 1, contractVersion: model.contractVersion,
          streamId: database.streamId, baseSequence: meta.confirmedSequence, maximumEntries, proposals: pending.map(item => item.value) };
        return request;
      })).value;
    },
    async reconcile(response) {
      assertOpen();
      const incoming = decodeSyncResponse(encodeSyncResponse(response, protocolModel, protocolOptions), protocolModel, protocolOptions);
      const commit = await database.transaction("readwrite", async tx => {
        assertOpen();
        const meta = await loadMeta(tx);
        if (incoming.requestedBaseSequence < (meta.bootstrapSequence ?? 0)) throw new SyncError("invalid-cursor", "A canonical page cannot precede the installed bootstrap checkpoint.");
        if (incoming.requestedBaseSequence > meta.confirmedSequence) throw new SyncError("invalid-cursor", "A canonical page cannot skip the replica's confirmed prefix.");
        const outboxCount = meta.pendingCount + meta.acceptedAwaitingCount;
        assertSequence(outboxCount + 1, "outbox scan limit", 1);
        const retained = await tx.scanInternal<RecordOutbox<Schema, Intent, Operation>>("outbox", { limit: outboxCount + 1 });
        if (retained.length !== outboxCount) throw new SyncError("corrupt-state", "Outbox count does not match metadata.");
        const outbox = retained.map(item => item.value);
        const local = new Map(outbox.map(item => [item.proposal.operationId, item]));
        const changed = new Map<string, RecordAddress<Schema>>();
        const remember = (address: RecordAddress<Schema>): void => { changed.set(addressKey(address), address); };
        for (const entry of outbox) for (const address of entry.touched) remember(address);
        const addDecision = async (decision: Decision<Operation, Rejection>): Promise<void> => {
          await bindIdentity(tx, meta, decision);
          const known = await tx.getInternal<Decision<Operation, Rejection>>("decisions", [decision.operationId]);
          if (known) assertSameDecision(known, decision, model.operation, model.rejection);
          if (decision.status === "accepted") {
            const atSequence = await tx.getInternal<AcceptedDecision<Operation>>("accepted", [decision.sequence]);
            if (atSequence) assertSameEntry(atSequence, decision, model.operation);
            if (decision.sequence <= meta.confirmedSequence) {
              const canonical = await tx.getInternal<CommittedOperation<Operation>>("canonical", [decision.sequence]);
              if (!canonical) throw new SyncError("corrupt-state", "Canonical prefix is incomplete.");
              assertSameEntry(canonical, decision, model.operation);
            }
            if (!atSequence) await tx.putInternal("accepted", [decision.sequence], decision);
          }
          if (!known) {
            await tx.putInternal("decisions", [decision.operationId], decision);
            if (local.has(decision.operationId)) {
              await tx.putInternal("resolutions", [decision.operationId], decision);
              meta.resolutionCount++;
            }
          }
        };
        for (const decision of incoming.decisions) await addDecision(decision);
        for (const entry of incoming.entries) {
          await addDecision({ ...entry, status: "accepted" });
          const previous = await tx.getInternal<CommittedOperation<Operation>>("canonical", [entry.sequence]);
          if (previous) { assertSameEntry(previous, entry, model.operation); continue; }
          if (entry.sequence !== meta.confirmedSequence + 1) throw new SyncError("invalid-cursor", "Canonical entries must extend the confirmed prefix contiguously.");
          const reads = model.operationReads(copy(entry.operation));
          assertSynchronous(reads, "Canonical read declarations");
          const staged = await loadDeclaredRecordView(tx, "confirmed", copy(reads));
          const result: unknown = model.applyCommitted(staged.view, copy(entry.operation));
          assertSynchronous(result, "Committed record interpreters");
          const writes = staged.writes();
          await tx.apply("confirmed", writes);
          for (const write of writes) remember(recordAddress(model.schema, write));
          await tx.putInternal("canonical", [entry.sequence], entry);
          meta.confirmedSequence = entry.sequence;
        }
        meta.headSequence = Math.max(meta.headSequence, incoming.headSequence);
        const remaining: Omit<RecordOutbox<Schema, Intent, Operation>, "touched" | "preview">[] = [];
        meta.pendingCount = 0;
        meta.acceptedAwaitingCount = 0;
        for (const entry of outbox) {
          const decision = await tx.getInternal<Decision<Operation, Rejection>>("decisions", [entry.proposal.operationId]);
          if (decision) {
            assertSameIdentity(entry.proposal, decision);
            await tx.deleteInternal("pending", [entry.proposal.clientSequence]);
            if (decision.status === "rejected" || decision.sequence <= meta.confirmedSequence) {
              await tx.deleteInternal("outbox", [entry.proposal.clientSequence]);
              continue;
            }
            remaining.push({ proposal: entry.proposal, decision });
            meta.acceptedAwaitingCount++;
          } else {
            remaining.push({ proposal: entry.proposal });
            meta.pendingCount++;
          }
        }
        // Clear every old optimistic effect, including inserts/deletes of resolved work.
        const reset: RecordWrite<Schema>[] = [];
        for (const address of changed.values()) {
          const row = await tx.get("confirmed", address.collection, address.key);
          reset.push(row === undefined ? { type: "delete", collection: address.collection, key: address.key } as RecordWrite<Schema>
            : { type: "put", collection: address.collection, row } as RecordWrite<Schema>);
        }
        await tx.apply("visible", reset);
        const previews: OverlayPreview[] = [];
        for (const entry of remaining) {
          const replayed = await preview(tx, entry);
          await tx.putInternal("outbox", [entry.proposal.clientSequence], replayed);
          previews.push(replayed.preview);
          for (const address of replayed.touched) remember(address);
        }
        await tx.putInternal("meta", metaKey, meta);
        return { status: statusOf(meta, tx.revision), changed: [...changed.values()], previews } satisfies RecordCommitSummary<Schema>;
      });
      return { ...commit.value, status: { ...commit.value.status, revision: commit.revision } };
    },
    async readResolutions(pageOptions = {}) {
      assertOpen();
      const limit = pageOptions.limit ?? limits.maximumProposals;
      const after = pageOptions.after;
      assertSequence(limit, "limit", 1);
      assertSequence(limit + 1, "resolution scan limit", 1);
      if (limit > limits.maximumProposals) throw new SyncError("limit-exceeded", "Resolution page exceeds the configured limit.");
      if (after !== undefined) assertIdentifier(after, "after");
      return (await database.transaction("readonly", async tx => {
        const records = await tx.scanInternal<Decision<Operation, Rejection>>("resolutions", {
          limit: limit + 1, ...(after === undefined ? {} : { lower: { key: [after], inclusive: false } }),
        });
        const decisions = records.slice(0, limit).map(item => item.value);
        const status = statusOf(await loadMeta(tx), tx.revision);
        return { decisions, status, ...(records.length > limit ? { nextAfter: decisions[decisions.length - 1]!.operationId } : {}) };
      })).value;
    },
    async acknowledgeResolutions(operationIds) {
      assertOpen();
      const ids = [...new Set(operationIds)];
      for (const id of ids) assertIdentifier(id, "operationId");
      await database.transaction("readwrite", async tx => {
        assertOpen();
        const meta = await loadMeta(tx);
        for (const id of ids) {
          if (await tx.getInternal("resolutions", [id])) {
            await tx.deleteInternal("resolutions", [id]);
            meta.resolutionCount--;
          }
        }
        await tx.putInternal("meta", metaKey, meta);
      });
    },
    async close() { closed = true; },
  };
}
