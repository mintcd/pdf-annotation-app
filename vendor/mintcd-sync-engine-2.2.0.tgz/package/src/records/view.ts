import { SyncError } from "../core/errors.js";
import { assertIdentifier } from "../core/validation.js";
import { addressKey, collectionDefinition, normalizeRecord } from "./schema.js";
import { validateRecordKey } from "./keys.js";
import type { CollectionName, CollectionRow, RecordArea, RecordKey, RecordPage, RecordRead, RecordReadView, RecordSchema, RecordTransaction, RecordWrite, RecordWriteView } from "./types.js";

export async function loadDeclaredRecordView<Schema extends RecordSchema>(
  transaction: RecordTransaction<Schema>, area: RecordArea, reads: readonly RecordRead<Schema>[],
): Promise<{ view: RecordWriteView<Schema>; readView: RecordReadView<Schema>; writes(): readonly RecordWrite<Schema>[] }> {
  if (reads !== null && typeof reads === "object" && "then" in reads) {
    void Promise.resolve(reads).catch(() => undefined);
    throw new SyncError("invalid-input", "Read declarations must be synchronous.");
  }
  if (!Array.isArray(reads)) throw new SyncError("invalid-input", "Read declarations must be an array.");
  const rows = new Map<string, unknown>();
  const queries = new Map<string, { collection: string; page: RecordPage<unknown> }>();
  const staged = new Map<string, RecordWrite<Schema>>();
  for (const read of reads) {
    if (read.type === "get") {
      collectionDefinition(transaction.schema, read.collection);
      validateRecordKey(read.key);
      rows.set(addressKey(read), await transaction.get(area, read.collection, read.key));
    } else if (read.type === "query") {
      assertIdentifier(read.name, "query read name");
      if (queries.has(read.name)) throw new SyncError("invalid-input", "A declared query name is repeated.");
      const page = await transaction.query(area, read.query);
      queries.set(read.name, { collection: read.query.collection, page });
      const definition = collectionDefinition(transaction.schema, read.query.collection);
      for (const row of page.rows) {
        rows.set(addressKey({ collection: read.query.collection, key: definition.key(structuredClone(row)) }), structuredClone(row));
      }
    } else throw new SyncError("invalid-input", "Unknown declared read kind.");
  }
  const readView: RecordReadView<Schema> = Object.freeze({
    get<Name extends CollectionName<Schema>>(collection: Name, key: RecordKey): CollectionRow<Schema, Name> | undefined {
      validateRecordKey(key);
      const encoded = addressKey({ collection, key });
      if (!rows.has(encoded)) throw new SyncError("invalid-input", "Undeclared record read or write.");
      return structuredClone(rows.get(encoded)) as CollectionRow<Schema, Name> | undefined;
    },
    query<Name extends CollectionName<Schema>>(name: string, collection: Name): RecordPage<CollectionRow<Schema, Name>> {
      const result = queries.get(name);
      if (!result || result.collection !== collection) throw new SyncError("invalid-input", "Undeclared query read.");
      return structuredClone(result.page) as RecordPage<CollectionRow<Schema, Name>>;
    },
  });
  const view: RecordWriteView<Schema> = Object.freeze({
    ...readView,
    put<Name extends CollectionName<Schema>>(collection: Name, input: CollectionRow<Schema, Name>): void {
      const row = normalizeRecord(transaction.schema, collection, input);
      const key = collectionDefinition(transaction.schema, collection).key(row);
      readView.get(collection, key);
      const encoded = addressKey({ collection, key });
      rows.set(encoded, structuredClone(row));
      staged.set(encoded, { type: "put", collection, row } as RecordWrite<Schema>);
    },
    delete<Name extends CollectionName<Schema>>(collection: Name, key: RecordKey): void {
      readView.get(collection, key);
      const encoded = addressKey({ collection, key });
      rows.set(encoded, undefined);
      staged.set(encoded, { type: "delete", collection, key: structuredClone(key) } as RecordWrite<Schema>);
    },
  });
  return { view, readView, writes: () => structuredClone([...staged.values()]) };
}
