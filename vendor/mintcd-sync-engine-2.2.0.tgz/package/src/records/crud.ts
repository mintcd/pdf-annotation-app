import { SyncError } from "../core/errors.js";
import type { Codec, JsonValue } from "../core/types.js";
import { assertIdentifier } from "../core/validation.js";
import { validateRecordKey } from "./keys.js";
import { defineRecordSchema } from "./schema.js";
import type { CollectionDefinition, CollectionIndex, CollectionName, CollectionRow, RecordDecisionPolicy, RecordDomainModel, RecordKey, RecordPreviewResult, RecordSchema, RecordWriteView } from "./types.js";

/** Runtime declarations are shared by generated clients, workers and authorities. */
export interface CrudFieldDefinition {
  readonly type: "string" | "number" | "boolean";
  readonly optional?: boolean;
  readonly nullable?: boolean;
  readonly enum?: readonly (string | number | boolean)[];
}
export interface CrudCollectionDefinition {
  readonly fields: Readonly<Record<string, CrudFieldDefinition>>;
  readonly primaryKey: readonly string[];
  readonly indexes?: Readonly<Record<string, readonly string[]>>;
}
export interface CrudModelDefinition {
  readonly contractVersion: string;
  readonly schemaVersion?: string;
  readonly collections: Readonly<Record<string, CrudCollectionDefinition>>;
}

type ScalarType<Type extends CrudFieldDefinition["type"]> = Type extends "string" ? string : Type extends "number" ? number : boolean;
type Scalar<Field extends CrudFieldDefinition> = ScalarType<Field["type"]>;
export type CrudFieldValue<Field extends CrudFieldDefinition> =
  (Field extends { readonly enum: readonly (infer Value)[] } ? Extract<Value, Scalar<Field>> : Scalar<Field>)
  | (Field extends { readonly nullable: true } ? null : never);
export type CrudRow<Collection extends CrudCollectionDefinition> = {
  -readonly [Field in keyof Collection["fields"] as Collection["fields"][Field] extends { readonly optional: true } ? never : Field]: CrudFieldValue<Collection["fields"][Field]>;
} & {
  -readonly [Field in keyof Collection["fields"] as Collection["fields"][Field] extends { readonly optional: true } ? Field : never]?: CrudFieldValue<Collection["fields"][Field]>;
};
type KeyTuple<Fields extends Readonly<Record<string, CrudFieldDefinition>>, Names extends readonly string[]> = {
  readonly [Position in keyof Names]: Names[Position] extends keyof Fields ? Extract<CrudFieldValue<Fields[Names[Position]]>, string | number> : never;
};
export type CrudKey<Collection extends CrudCollectionDefinition> = KeyTuple<Collection["fields"], Collection["primaryKey"]>;
export type CrudChanges<Collection extends CrudCollectionDefinition> = Partial<Omit<CrudRow<Collection>, Collection["primaryKey"][number]>>;
type Indexes<Collection extends CrudCollectionDefinition> = Collection extends { readonly indexes: infer Value } ? Value : {};
export type CrudSchema<Definition extends CrudModelDefinition> = RecordSchema<{
  readonly [Name in keyof Definition["collections"]]: Omit<CollectionDefinition<CrudRow<Definition["collections"][Name]>>, "indexes"> & {
    readonly indexes: { readonly [Index in keyof Indexes<Definition["collections"][Name]>]: CollectionIndex<CrudRow<Definition["collections"][Name]>> };
  };
}>;
export type CrudIntent<Definition extends CrudModelDefinition> = {
  [Name in keyof Definition["collections"] & string]:
    | { readonly type: "insert"; readonly collection: Name; readonly row: CrudRow<Definition["collections"][Name]> }
    | { readonly type: "update"; readonly collection: Name; readonly key: CrudKey<Definition["collections"][Name]>; readonly changes: CrudChanges<Definition["collections"][Name]> }
    | { readonly type: "delete"; readonly collection: Name; readonly key: CrudKey<Definition["collections"][Name]> };
}[keyof Definition["collections"] & string];
export type CrudOperation<Definition extends CrudModelDefinition> = {
  [Name in keyof Definition["collections"] & string]:
    | { readonly type: "put"; readonly collection: Name; readonly row: CrudRow<Definition["collections"][Name]> }
    | { readonly type: "delete"; readonly collection: Name; readonly key: CrudKey<Definition["collections"][Name]> };
}[keyof Definition["collections"] & string];
export interface CrudRejection {
  /** Application codes use lowercase hyphen-separated segments, at most 128 characters. */
  readonly code: string;
  /** Public explanation, between 1 and 1024 characters. */
  readonly message: string;
}
export interface CrudModel<Definition extends CrudModelDefinition> extends RecordDomainModel<CrudSchema<Definition>, CrudIntent<Definition>, CrudOperation<Definition>, CrudRejection> {
  readonly definition: Definition;
}
export type CrudCollections<Definition extends CrudModelDefinition> = {
  readonly [Name in keyof Definition["collections"] & string]: {
    readonly primaryKey: Definition["collections"][Name]["primaryKey"];
    readonly indexes: Indexes<Definition["collections"][Name]>;
    readonly sparseIndexes: Readonly<Record<string, readonly (keyof Definition["collections"][Name]["fields"] & string)[]>>;
    readonly mutations: {
      insert(row: CrudRow<Definition["collections"][Name]>): Extract<CrudIntent<Definition>, { readonly type: "insert"; readonly collection: Name }>;
      update(key: CrudKey<Definition["collections"][Name]>, changes: CrudChanges<Definition["collections"][Name]>): Extract<CrudIntent<Definition>, { readonly type: "update"; readonly collection: Name }>;
      delete(key: CrudKey<Definition["collections"][Name]>): Extract<CrudIntent<Definition>, { readonly type: "delete"; readonly collection: Name }>;
    };
  };
};

function invalid(message: string): never { throw new SyncError("invalid-input", message); }
function object(value: unknown, label: string): Record<string, unknown> {
  if (value === null || typeof value !== "object" || Array.isArray(value)
      || ![Object.prototype, null].includes(Object.getPrototypeOf(value) as object | null)
      || Object.getOwnPropertySymbols(value).length > 0) invalid(`${label} must be a JSON object.`);
  for (const property of Object.values(Object.getOwnPropertyDescriptors(value))) {
    if (!property.enumerable || !("value" in property)) invalid(`${label} must contain ordinary JSON fields.`);
  }
  return value as Record<string, unknown>;
}
function fields(value: Record<string, unknown>, required: readonly string[], allowed: readonly string[], label: string): void {
  if (required.some(field => !Object.hasOwn(value, field)) || Object.keys(value).some(field => !allowed.includes(field))) invalid(`Invalid ${label} fields.`);
}
function fieldValue(definition: CrudFieldDefinition, value: unknown, label: string): string | number | boolean | null {
  if (value === null && definition.nullable === true) return null;
  if (typeof value !== definition.type || (typeof value === "number" && !Number.isFinite(value))) invalid(`Invalid ${label}.`);
  if (definition.enum && !definition.enum.includes(value as string | number | boolean)) invalid(`Invalid ${label} enum value.`);
  return value as string | number | boolean;
}
function fieldNames(value: unknown, collection: CrudCollectionDefinition, label: string, primary: boolean): readonly string[] {
  if (!Array.isArray(value) || value.length === 0 || value.length > 32 || new Set(value).size !== value.length) invalid(`${label} needs 1 to 32 distinct field names.`);
  for (const field of value) {
    if (typeof field !== "string" || !Object.hasOwn(collection.fields, field)) invalid(`${label} references an unknown field.`);
    const definition = collection.fields[field]!;
    if (definition.type === "boolean" || (primary && (definition.optional === true || definition.nullable === true))) invalid(`${label} requires ${primary ? "required nonnullable " : ""}string or number fields.`);
  }
  return Object.freeze([...value]) as readonly string[];
}
function normalizeDefinition<Definition extends CrudModelDefinition>(input: Definition): Definition {
  const candidate = object(input, "CRUD definition");
  fields(candidate, ["contractVersion", "collections"], ["contractVersion", "schemaVersion", "collections"], "CRUD definition");
  assertIdentifier(candidate.contractVersion, "contractVersion");
  if (candidate.schemaVersion !== undefined) assertIdentifier(candidate.schemaVersion, "schemaVersion");
  const source = object(candidate.collections, "collections");
  if (Object.keys(source).length === 0) invalid("A CRUD model needs collections.");
  const collections = Object.fromEntries(Object.entries(source).map(([name, inputCollection]) => {
    assertIdentifier(name, "collection");
    const collection = object(inputCollection, "collection definition");
    fields(collection, ["fields", "primaryKey"], ["fields", "primaryKey", "indexes"], "collection definition");
    const sourceFields = object(collection.fields, "collection fields");
    if (Object.keys(sourceFields).length === 0) invalid("A collection needs fields.");
    const normalizedFields = Object.fromEntries(Object.entries(sourceFields).map(([field, inputField]) => {
      assertIdentifier(field, "field");
      const definition = object(inputField, "field definition");
      fields(definition, ["type"], ["type", "optional", "nullable", "enum"], "field definition");
      if (!["string", "number", "boolean"].includes(definition.type as string)) invalid("Unknown CRUD field type.");
      for (const flag of ["optional", "nullable"] as const) if (Object.hasOwn(definition, flag) && typeof definition[flag] !== "boolean") invalid(`Invalid ${flag} flag.`);
      if (Object.hasOwn(definition, "enum")) {
        if (!Array.isArray(definition.enum) || definition.enum.length === 0 || new Set(definition.enum).size !== definition.enum.length) invalid("Enums need distinct values.");
        for (const value of definition.enum) fieldValue({ type: definition.type as CrudFieldDefinition["type"] }, value, "enum");
      }
      return [field, Object.freeze({ ...definition, ...(definition.enum ? { enum: Object.freeze([...(definition.enum as unknown[])]) } : {}) })];
    }));
    const temporary = { fields: normalizedFields } as unknown as CrudCollectionDefinition;
    const primaryKey = fieldNames(collection.primaryKey, temporary, "primaryKey", true);
    const indexes = Object.fromEntries(Object.entries(collection.indexes === undefined ? {} : object(collection.indexes, "indexes")).map(([index, names]) => {
      assertIdentifier(index, "index");
      return [index, fieldNames(names, temporary, "index", false)];
    }));
    return [name, Object.freeze({ fields: Object.freeze(normalizedFields), primaryKey, indexes: Object.freeze(indexes) })];
  }));
  return Object.freeze({ contractVersion: candidate.contractVersion, ...(candidate.schemaVersion === undefined ? {} : { schemaVersion: candidate.schemaVersion }), collections: Object.freeze(collections) }) as unknown as Definition;
}

/** Standard CRUD uses field patches; concurrent changes to the same field follow authority order. */
export function defineCrudModel<const Definition extends CrudModelDefinition>(input: Definition): CrudModel<Definition> {
  const definition = normalizeDefinition(input);
  const collection = (name: unknown): CrudCollectionDefinition => {
    if (typeof name !== "string" || !Object.hasOwn(definition.collections, name)) invalid("Unknown CRUD collection.");
    return definition.collections[name]!;
  };
  const row = (name: string, value: unknown): Record<string, string | number | boolean | null> => {
    const declared = collection(name);
    const candidate = object(value, "row");
    if (Object.keys(candidate).some(field => !Object.hasOwn(declared.fields, field))) invalid("Unknown row field.");
    return Object.fromEntries(Object.entries(declared.fields).flatMap(([field, fieldDefinition]) => {
      if (!Object.hasOwn(candidate, field)) {
        if (fieldDefinition.optional !== true) invalid(`Missing required field ${field}.`);
        return [];
      }
      return [[field, fieldValue(fieldDefinition, candidate[field], `field ${field}`)]];
    }));
  };
  const key = (name: string, value: unknown): RecordKey => {
    const declared = collection(name);
    validateRecordKey(value);
    if (value.length !== declared.primaryKey.length) invalid("CRUD key has the wrong length.");
    return declared.primaryKey.map((field, index) => fieldValue(declared.fields[field]!, value[index], "primary key") as string | number);
  };
  const rowKey = (name: string, value: Record<string, unknown>): RecordKey => collection(name).primaryKey.map(field => value[field] as string | number);
  const changes = (name: string, value: unknown): Record<string, string | number | boolean | null> => {
    const declared = collection(name);
    const candidate = object(value, "changes");
    if (Object.keys(candidate).length === 0) invalid("An update needs at least one changed field.");
    return Object.fromEntries(Object.entries(candidate).map(([field, value]) => {
      if (!Object.hasOwn(declared.fields, field) || declared.primaryKey.includes(field)) invalid("Updates cannot change primary keys or unknown fields.");
      return [field, fieldValue(declared.fields[field]!, value, `field ${field}`)];
    }));
  };
  const codec = <Value>(decode: (value: unknown) => Value): Codec<Value> => Object.freeze({ decode, encode: (value: Value): JsonValue => decode(value) as JsonValue });
  const schema = defineRecordSchema({ version: definition.schemaVersion ?? definition.contractVersion, collections: Object.fromEntries(Object.entries(definition.collections).map(([name, declared]) => [name, {
    codec: codec(value => row(name, value)), key: (value: Record<string, unknown>) => rowKey(name, value),
    indexes: Object.fromEntries(Object.entries(declared.indexes ?? {}).map(([index, names]) => [index, { key: (value: Record<string, unknown>) => {
      const values = names.map(field => value[field]);
      return values.some(value => value === undefined || value === null) ? undefined : values as RecordKey;
    } }])),
  }])) }) as CrudSchema<Definition>;
  const intent = codec<CrudIntent<Definition>>(value => {
    const candidate = object(value, "CRUD intent");
    collection(candidate.collection);
    const name = candidate.collection as string;
    if (candidate.type === "insert") {
      fields(candidate, ["type", "collection", "row"], ["type", "collection", "row"], "insert intent");
      return { type: "insert", collection: name, row: row(name, candidate.row) } as CrudIntent<Definition>;
    }
    if (candidate.type === "update") {
      fields(candidate, ["type", "collection", "key", "changes"], ["type", "collection", "key", "changes"], "update intent");
      return { type: "update", collection: name, key: key(name, candidate.key), changes: changes(name, candidate.changes) } as CrudIntent<Definition>;
    }
    if (candidate.type === "delete") {
      fields(candidate, ["type", "collection", "key"], ["type", "collection", "key"], "delete intent");
      return { type: "delete", collection: name, key: key(name, candidate.key) } as CrudIntent<Definition>;
    }
    return invalid("Unknown CRUD intent type.");
  });
  const operation = codec<CrudOperation<Definition>>(value => {
    const candidate = object(value, "CRUD operation");
    collection(candidate.collection);
    const name = candidate.collection as string;
    if (candidate.type === "put") {
      fields(candidate, ["type", "collection", "row"], ["type", "collection", "row"], "put operation");
      return { type: "put", collection: name, row: row(name, candidate.row) } as CrudOperation<Definition>;
    }
    if (candidate.type === "delete") {
      fields(candidate, ["type", "collection", "key"], ["type", "collection", "key"], "delete operation");
      return { type: "delete", collection: name, key: key(name, candidate.key) } as CrudOperation<Definition>;
    }
    return invalid("Unknown CRUD operation type.");
  });
  const rejection = codec<CrudRejection>(value => {
    const candidate = object(value, "CRUD rejection");
    fields(candidate, ["code", "message"], ["code", "message"], "CRUD rejection");
    if (typeof candidate.code !== "string" || candidate.code.length > 128 || !/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*$/.test(candidate.code)
        || typeof candidate.message !== "string" || candidate.message.trim().length === 0 || candidate.message.length > 1024) invalid("Invalid CRUD rejection.");
    return { code: candidate.code, message: candidate.message };
  });
  const apply = (view: RecordWriteView<CrudSchema<Definition>>, input: CrudOperation<Definition>): void => {
    const canonical = operation.decode(input);
    if (canonical.type === "put") view.put(canonical.collection, canonical.row as CollectionRow<CrudSchema<Definition>, CollectionName<CrudSchema<Definition>>>);
    else view.delete(canonical.collection, canonical.key as RecordKey);
  };
  return Object.freeze({
    definition, contractVersion: definition.contractVersion, schema, intent, operation, rejection,
    intentReads(input) {
      const value = intent.decode(input);
      return [{ type: "get", collection: value.collection, key: value.type === "insert" ? rowKey(value.collection, value.row) : value.key as RecordKey }];
    },
    operationReads(input) {
      const value = operation.decode(input);
      return [{ type: "get", collection: value.collection, key: value.type === "put" ? rowKey(value.collection, value.row) : value.key as RecordKey }];
    },
    applyCommitted: apply,
    previewOperation(view, value): RecordPreviewResult { apply(view, value); return { status: "applied" }; },
    previewIntent(view, input): RecordPreviewResult {
      const value = intent.decode(input);
      const address = value.type === "insert" ? rowKey(value.collection, value.row) : value.key as RecordKey;
      const current = view.get(value.collection, address);
      if (value.type === "insert") {
        if (current !== undefined) return { status: "unavailable", reason: "The record already exists." };
        view.put(value.collection, value.row as CollectionRow<CrudSchema<Definition>, CollectionName<CrudSchema<Definition>>>);
      } else if (value.type === "update") {
        if (current === undefined) return { status: "unavailable", reason: "The record does not exist." };
        view.put(value.collection, row(value.collection, { ...current, ...value.changes }) as never);
      } else view.delete(value.collection, address);
      return { status: "applied" };
    },
  } satisfies CrudModel<Definition>);
}

/** A pure CRUD decision policy. Applications must authorize requests separately. */
export function createCrudPolicy<Definition extends CrudModelDefinition>(model: CrudModel<Definition>): RecordDecisionPolicy<CrudSchema<Definition>, CrudIntent<Definition>, CrudOperation<Definition>, CrudRejection, unknown> {
  return (view, proposal) => {
    const intent = model.intent.decode(proposal.intent);
    const declared = model.definition.collections[intent.collection]!;
    const key = intent.type === "insert" ? declared.primaryKey.map(field => (intent.row as Record<string, unknown>)[field] as string | number) : intent.key as RecordKey;
    const current = view.get(intent.collection, key);
    if (intent.type === "insert" && current !== undefined) return { status: "rejected", reason: { code: "already-exists", message: "The record already exists." } };
    if (intent.type === "update" && current === undefined) return { status: "rejected", reason: { code: "not-found", message: "The record does not exist." } };
    const operation = intent.type === "delete" ? { type: "delete", collection: intent.collection, key }
      : { type: "put", collection: intent.collection, row: intent.type === "insert" ? intent.row : { ...(current as Record<string, unknown>), ...intent.changes } };
    return { status: "accepted", operation: model.operation.decode(operation) };
  };
}

/** Collection metadata and validated intent builders for the fluent client engine. */
export function crudCollections<Definition extends CrudModelDefinition>(model: CrudModel<Definition>): CrudCollections<Definition> {
  return Object.freeze(Object.fromEntries(Object.entries(model.definition.collections).map(([collection, declared]) => [collection, Object.freeze({
    primaryKey: declared.primaryKey, indexes: declared.indexes ?? Object.freeze({}),
    sparseIndexes: Object.freeze(Object.fromEntries(Object.entries(declared.indexes ?? {}).flatMap(([index, fields]) => {
      const sparse = fields.filter(field => declared.fields[field]!.optional === true || declared.fields[field]!.nullable === true);
      return sparse.length === 0 ? [] : [[index, Object.freeze(sparse)]];
    }))),
    mutations: Object.freeze({
      insert: (row: unknown) => model.intent.decode({ type: "insert", collection, row }),
      update: (key: unknown, changes: unknown) => model.intent.decode({ type: "update", collection, key, changes }),
      delete: (key: unknown) => model.intent.decode({ type: "delete", collection, key }),
    }),
  })]))) as CrudCollections<Definition>;
}
