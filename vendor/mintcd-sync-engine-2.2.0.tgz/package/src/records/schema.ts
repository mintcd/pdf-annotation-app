import { SyncError } from "../core/errors.js";
import { cloneCodecValue } from "../core/codecs.js";
import { canonicalizeJson } from "../core/fingerprint.js";
import { assertIdentifier } from "../core/validation.js";
import { encodeRecordKey, validateRecordKey } from "./keys.js";
import type { CollectionDefinition, CollectionDefinitions, CollectionName, CollectionRow, RecordAddress, RecordSchema, RecordWrite } from "./types.js";

export function defineRecordSchema<Collections extends CollectionDefinitions>(schema: RecordSchema<Collections>): RecordSchema<Collections> {
  assertIdentifier(schema.version, "schema.version");
  if (!schema.collections || typeof schema.collections !== "object" || Object.keys(schema.collections).length === 0) throw new SyncError("invalid-input", "A schema needs declared collections.");
  const collections: Record<string, CollectionDefinition<unknown>> = Object.create(null) as Record<string, CollectionDefinition<unknown>>;
  for (const [name, definition] of Object.entries(schema.collections)) {
    assertIdentifier(name, "collection");
    if (!definition || typeof definition.key !== "function" || typeof definition.codec?.encode !== "function" || typeof definition.codec?.decode !== "function") throw new SyncError("invalid-input", "Invalid collection definition.");
    const indexes = Object.fromEntries(Object.entries(definition.indexes ?? {}).map(([indexName, index]) => {
      assertIdentifier(indexName, "index");
      if (!index || typeof index.key !== "function") throw new SyncError("invalid-input", "Invalid index definition.");
      if (Object.keys(index).some(field => field !== "key")) throw new SyncError("invalid-input", "Only nonunique key-extractor indexes are supported.");
      return [indexName, Object.freeze({ key: index.key.bind(index) })];
    }));
    collections[name] = Object.freeze({ codec: Object.freeze({ encode: definition.codec.encode.bind(definition.codec), decode: definition.codec.decode.bind(definition.codec) }), key: definition.key.bind(definition), indexes: Object.freeze(indexes) });
  }
  return Object.freeze({ version: schema.version, collections: Object.freeze(collections) as Collections });
}

/** Function semantics are application-versioned, not inferred from function source. */
export function schemaIdentity(schema: RecordSchema): string {
  return canonicalizeJson({ version: schema.version, collections: Object.keys(schema.collections).sort().map(name => ({ name, indexes: Object.keys(schema.collections[name]!.indexes ?? {}).sort() })) });
}

export function collectionDefinition<Schema extends RecordSchema>(schema: Schema, collection: string): CollectionDefinition<unknown> {
  if (!Object.hasOwn(schema.collections, collection)) throw new SyncError("invalid-input", "Unknown collection.");
  return schema.collections[collection]!;
}

export function normalizeRecord<Schema extends RecordSchema, Name extends CollectionName<Schema>>(schema: Schema, collection: Name, row: CollectionRow<Schema, Name>): CollectionRow<Schema, Name> {
  const definition = collectionDefinition(schema, collection);
  const result = cloneCodecValue(definition.codec, row, `record in ${collection}`);
  validateRecordKey(definition.key(structuredClone(result)));
  for (const index of Object.values(definition.indexes ?? {})) {
    const key = index.key(structuredClone(result));
    if (key !== undefined) validateRecordKey(key);
  }
  return result as CollectionRow<Schema, Name>;
}

export function recordAddress<Schema extends RecordSchema>(schema: Schema, write: RecordWrite<Schema>): RecordAddress<Schema> {
  const definition = collectionDefinition(schema, write.collection);
  const key = write.type === "delete" ? write.key : definition.key(structuredClone(write.row));
  validateRecordKey(key);
  return { collection: write.collection, key: structuredClone(key) };
}

export function addressKey<Schema extends RecordSchema>(address: RecordAddress<Schema>): string {
  return canonicalizeJson([address.collection, encodeRecordKey(address.key)]);
}
