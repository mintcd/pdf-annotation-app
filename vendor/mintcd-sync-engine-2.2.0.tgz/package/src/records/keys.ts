import { SyncError } from "../core/errors.js";
import { canonicalizeJson } from "../core/fingerprint.js";
import type { InternalScan, RecordKey } from "./types.js";

export function validateRecordKey(value: unknown, allowEmpty = false): asserts value is RecordKey {
  if (!Array.isArray(value) || Object.getPrototypeOf(value) !== Array.prototype || (!allowEmpty && value.length === 0) || value.length > 32) {
    throw new SyncError("invalid-input", "Record keys must be ordinary tuples of 1 to 32 numbers or strings.");
  }
  canonicalizeJson(value);
  if (value.some(part => typeof part !== "string" && (typeof part !== "number" || !Number.isFinite(part)))) {
    throw new SyncError("invalid-input", "Record key components must be strings or finite numbers.");
  }
}

export function compareRecordKeys(left: RecordKey, right: RecordKey): number {
  for (let index = 0; index < Math.min(left.length, right.length); index++) {
    const a = left[index]!;
    const b = right[index]!;
    if (a === b) continue;
    if (typeof a !== typeof b) return typeof a === "number" ? -1 : 1;
    return a < b ? -1 : 1;
  }
  return Math.sign(left.length - right.length);
}

export function encodeRecordKey(key: RecordKey): string {
  validateRecordKey(key);
  return canonicalizeJson(key);
}

export function validateScan(scan: InternalScan, maximum = Number.MAX_SAFE_INTEGER): void {
  if (!Number.isSafeInteger(scan.limit) || scan.limit < 1 || scan.limit > maximum) {
    throw new SyncError("limit-exceeded", `A scan limit must be between 1 and ${maximum}.`);
  }
  if (scan.direction !== undefined && scan.direction !== "asc" && scan.direction !== "desc") throw new SyncError("invalid-input", "Invalid scan direction.");
  if (scan.prefix !== undefined) validateRecordKey(scan.prefix, true);
  for (const bound of [scan.lower, scan.upper]) {
    if (bound === undefined) continue;
    validateRecordKey(bound.key);
    if (bound.inclusive !== undefined && typeof bound.inclusive !== "boolean") throw new SyncError("invalid-input", "Invalid bound inclusion flag.");
  }
  if (scan.lower && scan.upper && compareRecordKeys(scan.lower.key, scan.upper.key) > 0) throw new SyncError("invalid-input", "Lower bound exceeds upper bound.");
}

/** Negative/positive compare against the contiguous index interval a scan selects. */
export function compareScanRange(key: RecordKey, scan: InternalScan): number {
  if (scan.prefix) {
    const prefixComparison = compareRecordKeys(key.slice(0, scan.prefix.length), scan.prefix);
    if (prefixComparison !== 0) return prefixComparison;
  }
  if (scan.lower) {
    const comparison = compareRecordKeys(key, scan.lower.key);
    if (comparison < 0 || (comparison === 0 && scan.lower.inclusive === false)) return -1;
  }
  if (scan.upper) {
    const comparison = compareRecordKeys(key, scan.upper.key);
    if (comparison > 0 || (comparison === 0 && scan.upper.inclusive === false)) return 1;
  }
  return 0;
}

export function lowerBound<Value>(values: readonly Value[], compare: (value: Value) => number, strict = false): number {
  let lower = 0;
  let upper = values.length;
  while (lower < upper) {
    const middle = lower + Math.floor((upper - lower) / 2);
    const comparison = compare(values[middle]!);
    if (comparison < 0 || (strict && comparison === 0)) lower = middle + 1;
    else upper = middle;
  }
  return lower;
}
