import { decodeCodecValue, encodeCodecValue } from "../core/codecs.js";
import { SyncError } from "../core/errors.js";
import { canonicalizeJson, createIntentHash } from "../core/fingerprint.js";
import { assertIdentifier, assertSequence } from "../core/validation.js";
import { addressKey, collectionDefinition, normalizeRecord, recordAddress, schemaIdentity } from "./schema.js";
import type {
  CollectionName, CollectionRow, ExportRecordBootstrapOptions, InstallRecordBootstrapOptions,
  RecordBootstrapLimits, RecordBootstrapSnapshot, RecordCursor, RecordInternalTable, RecordSchema, RecordWrite,
} from "./types.js";

const defaults: RecordBootstrapLimits = { maximumRows: 10_000, maximumBytes: 8 * 1024 * 1024 };
const encoder = new TextEncoder();
const internalTables: readonly RecordInternalTable[] = ["meta", "canonical", "identities", "positions", "decisions", "accepted", "outbox", "pending", "resolutions"];
type SnapshotBody = Omit<RecordBootstrapSnapshot, "checksum">;

function bounds(input: Partial<RecordBootstrapLimits> | undefined): RecordBootstrapLimits {
  const limits = { ...defaults, ...input };
  for (const [field, value] of Object.entries(limits)) assertSequence(value, field, 1);
  return limits;
}

function byteLength(value: unknown): number { return encoder.encode(canonicalizeJson(value)).byteLength; }

function object(input: unknown, fields: readonly string[], label: string): Record<string, unknown> {
  if (!input || typeof input !== "object" || Array.isArray(input)
    || Object.keys(input).length !== fields.length || Object.keys(input).some(field => !fields.includes(field))) {
    throw new SyncError("invalid-input", `Invalid ${label} fields.`);
  }
  return input as Record<string, unknown>;
}

/** Capture all confirmed rows and the authority watermark in one consistent readonly transaction. */
export async function exportRecordBootstrap<Schema extends RecordSchema, Intent, Operation, Rejection>(
  options: ExportRecordBootstrapOptions<Schema, Intent, Operation, Rejection>,
): Promise<RecordBootstrapSnapshot> {
  const { database, model } = options;
  assertIdentifier(database.streamId, "streamId");
  assertIdentifier(model.contractVersion, "contractVersion");
  const identity = schemaIdentity(model.schema);
  if (schemaIdentity(database.schema) !== identity) throw new SyncError("contract-mismatch", "Database and bootstrap model schemas differ.");
  const limits = bounds(options.limits);
  const maximumReadAttempts = options.maximumReadAttempts ?? 8;
  assertSequence(maximumReadAttempts, "maximumReadAttempts", 1);
  for (let attempt = 0; attempt < maximumReadAttempts; attempt++) {
    try {
      const result = await database.transaction("readonly", async tx => {
        if (await tx.getInternal("meta", ["replica"])) throw new SyncError("contract-mismatch", "A replica cannot export an authority bootstrap.");
        const meta = await tx.getInternal<{ contractVersion: string; schemaVersion: string; schemaIdentity: string; headSequence: number }>("meta", ["authority"]);
        if (!meta) throw new SyncError("corrupt-state", "Authority metadata must be initialized before exporting a bootstrap.");
        if (meta.contractVersion !== model.contractVersion || meta.schemaVersion !== model.schema.version || meta.schemaIdentity !== identity) {
          throw new SyncError("contract-mismatch", "Authority bootstrap contract or schema differs.");
        }
        assertSequence(meta.headSequence, "authority headSequence");
        const rows: { collection: string; row: RecordBootstrapSnapshot["rows"][number]["row"] }[] = [];
        const seen = new Set<string>();
        let rowBytes = 0;
        for (const collection of Object.keys(model.schema.collections).sort() as CollectionName<Schema>[]) {
          let cursor: RecordCursor | undefined;
          do {
            const page = await tx.query("confirmed", { collection, limit: 256, ...(cursor ? { cursor } : {}) });
            if (page.revision !== tx.revision || (page.nextCursor && page.rows.length === 0)) throw new SyncError("corrupt-state", "Invalid bootstrap query page.");
            for (const input of page.rows) {
              const normalized = normalizeRecord(model.schema, collection, input);
              const address = addressKey(recordAddress(model.schema, { type: "put", collection, row: normalized } as RecordWrite<Schema>));
              if (seen.has(address)) throw new SyncError("corrupt-state", "Bootstrap query returned a duplicate row.");
              seen.add(address);
              const item = { collection, row: encodeCodecValue(collectionDefinition(model.schema, collection).codec, normalized, "bootstrap row") };
              rowBytes += byteLength(item);
              if (rows.length >= limits.maximumRows || rowBytes > limits.maximumBytes) throw new SyncError("limit-exceeded", "Authority bootstrap exceeds its row or byte budget.");
              rows.push(item);
            }
            cursor = page.nextCursor;
          } while (cursor);
        }
        return { version: 1, streamId: database.streamId, contractVersion: model.contractVersion,
          schemaVersion: model.schema.version, schemaIdentity: identity, watermark: meta.headSequence,
          rowCount: rows.length, rows } satisfies SnapshotBody;
      });
      const snapshot: RecordBootstrapSnapshot = { ...result.value, checksum: await createIntentHash(result.value) };
      if (byteLength(snapshot) > limits.maximumBytes) throw new SyncError("limit-exceeded", "Authority bootstrap exceeds its byte budget.");
      return snapshot;
    } catch (cause) {
      if (!(cause instanceof SyncError && cause.code === "commit-conflict") || attempt + 1 === maximumReadAttempts) throw cause;
    }
  }
  throw new SyncError("commit-conflict", "Authority bootstrap could not obtain a consistent snapshot.");
}

/** Validate outside storage, then atomically install into a fresh, completely empty replica database. */
export async function installRecordBootstrap<Schema extends RecordSchema, Intent, Operation, Rejection>(
  options: InstallRecordBootstrapOptions<Schema, Intent, Operation, Rejection>,
): Promise<void> {
  const { database, model, clientId } = options;
  assertIdentifier(database.streamId, "streamId");
  assertIdentifier(clientId, "clientId");
  assertIdentifier(model.contractVersion, "contractVersion");
  const identity = schemaIdentity(model.schema);
  if (schemaIdentity(database.schema) !== identity) throw new SyncError("contract-mismatch", "Database and bootstrap model schemas differ.");
  const limits = bounds(options.limits);
  if (byteLength(options.snapshot) > limits.maximumBytes) throw new SyncError("limit-exceeded", "Bootstrap exceeds its byte budget.");
  const captured = structuredClone(options.snapshot);
  const input = object(captured, ["version", "streamId", "contractVersion", "schemaVersion", "schemaIdentity", "watermark", "rowCount", "rows", "checksum"], "bootstrap");
  if (input.version !== 1) throw new SyncError("unsupported-version", "Unsupported record bootstrap version.");
  if (input.streamId !== database.streamId) throw new SyncError("stream-mismatch", "Bootstrap belongs to another stream.");
  if (input.contractVersion !== model.contractVersion || input.schemaVersion !== model.schema.version || input.schemaIdentity !== identity) {
    throw new SyncError("contract-mismatch", "Bootstrap contract or schema differs.");
  }
  assertSequence(input.watermark, "bootstrap watermark");
  assertSequence(input.rowCount, "bootstrap rowCount");
  if (!Array.isArray(input.rows) || input.rows.length !== input.rowCount) throw new SyncError("invalid-input", "Bootstrap is incomplete or has an invalid row count.");
  if (input.rowCount > limits.maximumRows) throw new SyncError("limit-exceeded", "Bootstrap exceeds its row budget.");
  const { checksum, ...body } = input;
  if (typeof checksum !== "string" || checksum !== await createIntentHash(body)) throw new SyncError("invalid-input", "Bootstrap checksum does not match its complete contents.");
  const writes: RecordWrite<Schema>[] = [];
  const seen = new Set<string>();
  for (const wire of input.rows) {
    const item = object(wire, ["collection", "row"], "bootstrap row");
    if (typeof item.collection !== "string") throw new SyncError("invalid-input", "Bootstrap row collection must be a string.");
    const definition = collectionDefinition(model.schema, item.collection);
    const collection = item.collection as CollectionName<Schema>;
    const row = normalizeRecord(model.schema, collection, decodeCodecValue(definition.codec, item.row, "bootstrap row") as CollectionRow<Schema, typeof collection>);
    const write = { type: "put", collection, row } as RecordWrite<Schema>;
    const address = addressKey(recordAddress(model.schema, write));
    if (seen.has(address)) throw new SyncError("invalid-input", "Bootstrap contains a duplicate primary key.");
    seen.add(address);
    writes.push(write);
  }
  await database.transaction("readwrite", async tx => {
    for (const table of internalTables) {
      if ((await tx.scanInternal(table, { limit: 1 })).length !== 0) throw new SyncError("identity-conflict", "Bootstrap requires a fresh replica with no retained metadata or work.");
    }
    for (const collection of Object.keys(model.schema.collections) as CollectionName<Schema>[]) {
      for (const area of ["confirmed", "visible"] as const) {
        if ((await tx.query(area, { collection, limit: 1 })).rows.length !== 0) throw new SyncError("identity-conflict", "Bootstrap requires a fresh replica with no existing rows.");
      }
    }
    await tx.apply("confirmed", writes);
    await tx.apply("visible", writes);
    await tx.putInternal("meta", ["replica"], { kind: "record-replica-v1", clientId,
      contractVersion: model.contractVersion, schemaVersion: model.schema.version, schemaIdentity: identity,
      bootstrapSequence: input.watermark, confirmedSequence: input.watermark, headSequence: input.watermark,
      nextClientSequence: 1, pendingCount: 0, acceptedAwaitingCount: 0, resolutionCount: 0 });
  });
}
