/** An ordered memory index; rotations keep edits from copying unrelated records. */
interface Node<Value> { value: Value; priority: number; left?: Node<Value>; right?: Node<Value> }

export class OrderedIndex<Value> {
  private root: Node<Value> | undefined;
  private random = 0x7f4a7c15;
  constructor(private readonly compare: (left: Value, right: Value) => number) {}

  put(value: Value): void {
    this.random ^= this.random << 13;
    this.random ^= this.random >>> 17;
    this.random ^= this.random << 5;
    const node: Node<Value> = { value, priority: this.random >>> 0 };
    const insert = (current: Node<Value> | undefined): Node<Value> => {
      if (!current) return node;
      const order = this.compare(value, current.value);
      if (order === 0) { current.value = value; return current; }
      if (order < 0) {
        current.left = insert(current.left);
        if (current.left.priority < current.priority) {
          const next = current.left;
          if (next.right) current.left = next.right; else delete current.left;
          next.right = current;
          return next;
        }
      } else {
        current.right = insert(current.right);
        if (current.right.priority < current.priority) {
          const next = current.right;
          if (next.left) current.right = next.left; else delete current.right;
          next.left = current;
          return next;
        }
      }
      return current;
    };
    this.root = insert(this.root);
  }

  delete(value: Value): void {
    const merge = (left: Node<Value> | undefined, right: Node<Value> | undefined): Node<Value> | undefined => {
      if (!left) return right;
      if (!right) return left;
      if (left.priority < right.priority) {
        const result = merge(left.right, right);
        if (result) left.right = result; else delete left.right;
        return left;
      }
      const result = merge(left, right.left);
      if (result) right.left = result; else delete right.left;
      return right;
    };
    const remove = (current: Node<Value> | undefined): Node<Value> | undefined => {
      if (!current) return undefined;
      const order = this.compare(value, current.value);
      if (order === 0) return merge(current.left, current.right);
      if (order < 0) {
        const result = remove(current.left);
        if (result) current.left = result; else delete current.left;
      } else {
        const result = remove(current.right);
        if (result) current.right = result; else delete current.right;
      }
      return current;
    };
    this.root = remove(this.root);
  }

  /** match is monotonic: -1 before the desired interval, 0 inside, 1 after. */
  *range(match: (value: Value) => number, direction: "asc" | "desc"): Generator<Value> {
    const stack: Node<Value>[] = [];
    let node = this.root;
    while (node) {
      const comparison = match(node.value);
      if (direction === "asc" ? comparison < 0 : comparison > 0) node = direction === "asc" ? node.right : node.left;
      else { stack.push(node); node = direction === "asc" ? node.left : node.right; }
    }
    while (stack.length > 0) {
      const current = stack.pop()!;
      if (match(current.value) !== 0) return;
      yield current.value;
      node = direction === "asc" ? current.right : current.left;
      while (node) { stack.push(node); node = direction === "asc" ? node.left : node.right; }
    }
  }
}
