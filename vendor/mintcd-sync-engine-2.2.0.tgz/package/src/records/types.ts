import type { Codec, Decision, EnqueueInput, JsonValue, OperationIdentity, OverlayPreview, PolicyDecision, PrepareSyncOptions, Proposal, ProtocolLimits, SyncRequest, SyncResponse } from "../core/types.js";

/** Portable ordering: finite numbers before strings; tuples compare lexicographically. */
export type RecordKey = readonly (number | string)[];

export interface CollectionIndex<Row> {
  key(row: Row): RecordKey | undefined;
}

export interface CollectionDefinition<Row> {
  readonly codec: Codec<Row>;
  key(row: Row): RecordKey;
  readonly indexes?: Readonly<Record<string, CollectionIndex<Row>>>;
}

export type CollectionDefinitions = Readonly<Record<string, CollectionDefinition<unknown>>>;
export interface RecordSchema<Collections extends CollectionDefinitions = CollectionDefinitions> {
  readonly version: string;
  readonly collections: Collections;
}
export type CollectionName<Schema extends RecordSchema> = keyof Schema["collections"] & string;
export type CollectionRow<Schema extends RecordSchema, Name extends CollectionName<Schema>> =
  Schema["collections"][Name] extends CollectionDefinition<infer Row> ? Row : never;
export type CollectionIndexName<Schema extends RecordSchema, Name extends CollectionName<Schema>> =
  Name extends CollectionName<Schema> ? keyof NonNullable<Schema["collections"][Name]["indexes"]> & string : never;

export interface RecordBound { readonly key: RecordKey; readonly inclusive?: boolean }
export interface RecordCursor {
  readonly version: 1;
  readonly schemaVersion: string;
  readonly streamId: string;
  readonly queryIdentity: string;
  readonly revision: number;
  readonly indexKey: RecordKey;
  readonly primaryKey: RecordKey;
}

export interface RecordQuery<Schema extends RecordSchema, Name extends CollectionName<Schema> = CollectionName<Schema>> {
  readonly collection: Name;
  /** Omit for primary-key traversal. Secondary names must be explicitly declared. */
  readonly index?: CollectionIndexName<Schema, Name>;
  readonly prefix?: RecordKey;
  readonly lower?: RecordBound;
  readonly upper?: RecordBound;
  readonly direction?: "asc" | "desc";
  readonly limit: number;
  readonly cursor?: RecordCursor;
}

export interface RecordPage<Row> {
  readonly rows: readonly Row[];
  readonly revision: number;
  readonly nextCursor?: RecordCursor;
}

export interface RecordAddress<Schema extends RecordSchema = RecordSchema> {
  readonly collection: CollectionName<Schema>;
  readonly key: RecordKey;
}
export type RecordWrite<Schema extends RecordSchema> = {
  [Name in CollectionName<Schema>]:
    | { readonly type: "put"; readonly collection: Name; readonly row: CollectionRow<Schema, Name> }
    | { readonly type: "delete"; readonly collection: Name; readonly key: RecordKey }
}[CollectionName<Schema>];

export type RecordRead<Schema extends RecordSchema> =
  | ({ readonly type: "get" } & RecordAddress<Schema>)
  | { readonly type: "query"; readonly name: string; readonly query: RecordQuery<Schema> };

/** Reads are prefetched at one revision; named query results are fixed for this operation. */
export interface RecordReadView<Schema extends RecordSchema> {
  get<Name extends CollectionName<Schema>>(collection: Name, key: RecordKey): CollectionRow<Schema, Name> | undefined;
  query<Name extends CollectionName<Schema>>(name: string, collection: Name): RecordPage<CollectionRow<Schema, Name>>;
}
export interface RecordWriteView<Schema extends RecordSchema> extends RecordReadView<Schema> {
  /** Write targets must have been declared via get or included in a declared query result. */
  put<Name extends CollectionName<Schema>>(collection: Name, row: CollectionRow<Schema, Name>): void;
  delete<Name extends CollectionName<Schema>>(collection: Name, key: RecordKey): void;
}
export type RecordPreviewResult = { readonly status: "applied" } | { readonly status: "unavailable"; readonly reason: string };

export interface RecordDomainModel<Schema extends RecordSchema, Intent, Operation, Rejection> {
  readonly contractVersion: string;
  readonly schema: Schema;
  readonly intent: Codec<Intent>;
  readonly operation: Codec<Operation>;
  readonly rejection: Codec<Rejection>;
  intentReads(intent: Intent): readonly RecordRead<Schema>[];
  operationReads(operation: Operation): readonly RecordRead<Schema>[];
  applyCommitted(view: RecordWriteView<Schema>, operation: Operation): void;
  previewIntent(view: RecordWriteView<Schema>, intent: Intent): RecordPreviewResult;
  previewOperation(view: RecordWriteView<Schema>, operation: Operation): RecordPreviewResult;
}
export type RecordDecisionPolicy<Schema extends RecordSchema, Intent, Operation, Rejection, Context = undefined> =
  (view: RecordReadView<Schema>, proposal: Proposal<Intent>, context: Context) => PolicyDecision<Operation, Rejection>;

export type RecordArea = "confirmed" | "visible";
export type RecordInternalTable = "meta" | "canonical" | "identities" | "positions" | "decisions" | "accepted" | "outbox" | "pending" | "resolutions";
export interface InternalScan {
  readonly prefix?: RecordKey;
  readonly lower?: RecordBound;
  readonly upper?: RecordBound;
  readonly direction?: "asc" | "desc";
  readonly limit: number;
}
export interface InternalRecord<Value> { readonly key: RecordKey; readonly value: Value }

/**
 * Native adapters supply consistent reads and all-or-nothing writes. Coordinators
 * await only storage requests here; hashing, network and user async work stay outside.
 */
export interface RecordTransaction<Schema extends RecordSchema> {
  readonly revision: number;
  readonly schema: Schema;
  get<Name extends CollectionName<Schema>>(area: RecordArea, collection: Name, key: RecordKey): Promise<CollectionRow<Schema, Name> | undefined>;
  query<Name extends CollectionName<Schema>>(area: RecordArea, query: RecordQuery<Schema, Name>): Promise<RecordPage<CollectionRow<Schema, Name>>>;
  /** Each call stages its entire write set or nothing, including validation failure. */
  apply(area: RecordArea, writes: readonly RecordWrite<Schema>[]): Promise<void>;
  getInternal<Value>(table: RecordInternalTable, key: RecordKey): Promise<Value | undefined>;
  putInternal<Value>(table: RecordInternalTable, key: RecordKey, value: Value): Promise<void>;
  deleteInternal(table: RecordInternalTable, key: RecordKey): Promise<void>;
  scanInternal<Value>(table: RecordInternalTable, scan: InternalScan): Promise<readonly InternalRecord<Value>[]>;
}

export interface RecordDatabase<Schema extends RecordSchema> {
  readonly streamId: string;
  readonly schema: Schema;
  transaction<Value>(mode: "readonly" | "readwrite", run: (transaction: RecordTransaction<Schema>) => Value | Promise<Value>, options?: { readonly expectedRevision?: number }): Promise<{ readonly revision: number; readonly value: Value }>;
}

export interface RecordStoreMetrics {
  readonly rowReads: number;
  readonly rowWrites: number;
  readonly indexEntriesVisited: number;
  readonly internalReads: number;
  readonly internalWrites: number;
  readonly internalEntriesVisited: number;
}
export interface MemoryRecordDatabase<Schema extends RecordSchema> extends RecordDatabase<Schema> {
  metrics(): RecordStoreMetrics;
  resetMetrics(): void;
}
export interface MemoryRecordDatabaseOptions<Schema extends RecordSchema> {
  readonly streamId: string;
  readonly schema: Schema;
  /** Shared genesis data at canonical sequence zero, not an imported sync snapshot. */
  readonly initialRows?: readonly RecordWrite<Schema>[];
}

export interface RecordReplicaStatus {
  readonly streamId: string;
  readonly clientId: string;
  readonly revision: number;
  readonly confirmedSequence: number;
  readonly headSequence: number;
  readonly nextClientSequence: number;
  readonly pendingCount: number;
  readonly acceptedAwaitingCount: number;
  readonly resolutionCount: number;
}
export interface RecordCommitSummary<Schema extends RecordSchema> {
  readonly status: RecordReplicaStatus;
  readonly changed: readonly RecordAddress<Schema>[];
  readonly previews: readonly OverlayPreview[];
}
export interface RecordResolutionPage<Operation, Rejection> {
  readonly decisions: readonly Decision<Operation, Rejection>[];
  readonly nextAfter?: string;
  readonly status: RecordReplicaStatus;
}
export interface RecordReplica<Schema extends RecordSchema, Intent, Operation, Rejection> {
  status(): Promise<RecordReplicaStatus>;
  get<Name extends CollectionName<Schema>>(collection: Name, key: RecordKey): Promise<{ readonly row: CollectionRow<Schema, Name> | undefined; readonly status: RecordReplicaStatus }>;
  query<Name extends CollectionName<Schema>>(query: RecordQuery<Schema, Name>): Promise<RecordPage<CollectionRow<Schema, Name>> & { readonly status: RecordReplicaStatus }>;
  enqueue(input: EnqueueInput<Intent>): Promise<OperationIdentity>;
  prepareSyncRequest(options?: PrepareSyncOptions): Promise<SyncRequest<Intent>>;
  reconcile(response: SyncResponse<Operation, Rejection>): Promise<RecordCommitSummary<Schema>>;
  readResolutions(options?: { readonly after?: string; readonly limit?: number }): Promise<RecordResolutionPage<Operation, Rejection>>;
  acknowledgeResolutions(operationIds: readonly string[]): Promise<void>;
  close(): Promise<void>;
}

export interface OpenRecordReplicaOptions<Schema extends RecordSchema, Intent, Operation, Rejection> {
  readonly database: RecordDatabase<Schema>;
  readonly clientId: string;
  readonly model: RecordDomainModel<Schema, Intent, Operation, Rejection>;
  readonly limits?: Partial<ProtocolLimits>;
  /** Fail recovery instead of allocating sequence 1 when replica metadata is missing. */
  readonly requireExisting?: boolean;
}

/** Complete materialized authority state at a real canonical watermark, without historical operations. */
export interface RecordBootstrapSnapshot {
  readonly version: 1;
  readonly streamId: string;
  readonly contractVersion: string;
  readonly schemaVersion: string;
  readonly schemaIdentity: string;
  readonly watermark: number;
  readonly rowCount: number;
  readonly rows: readonly { readonly collection: string; readonly row: JsonValue }[];
  /** SHA-256 of the canonical snapshot envelope excluding this field. Not an authentication signature. */
  readonly checksum: string;
}

export interface RecordBootstrapLimits {
  readonly maximumRows: number;
  readonly maximumBytes: number;
}

export interface ExportRecordBootstrapOptions<Schema extends RecordSchema, Intent, Operation, Rejection> {
  readonly database: RecordDatabase<Schema>;
  readonly model: RecordDomainModel<Schema, Intent, Operation, Rejection>;
  readonly limits?: Partial<RecordBootstrapLimits>;
  /** Retry a consistent read when an optimistic adapter observes a concurrent commit. Defaults to 8. */
  readonly maximumReadAttempts?: number;
}

export interface InstallRecordBootstrapOptions<Schema extends RecordSchema, Intent, Operation, Rejection> {
  readonly database: RecordDatabase<Schema>;
  /** Must be a fresh client identity; caller must never reuse the retired replica identity. */
  readonly clientId: string;
  readonly model: RecordDomainModel<Schema, Intent, Operation, Rejection>;
  readonly snapshot: unknown;
  readonly limits?: Partial<RecordBootstrapLimits>;
}
