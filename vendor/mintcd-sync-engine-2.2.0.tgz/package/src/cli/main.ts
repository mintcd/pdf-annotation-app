import * as fs from "node:fs/promises";
import * as path from "node:path";
import { SyncError } from "../core/errors.js";
import { parseVinextGeneratorConfig } from "../integrations/vinext/index.js";
import { generateVinext } from "./filesystem.js";
import { VinextGenerationError } from "./types.js";
import type { VinextGenerationMode } from "./types.js";

const usage = `Usage: sync-engine generate vinext --config <json-file> [options]

Options:
  --root <directory>       Application root (default: configuration directory)
  --app-dir app|src/app    Override the appDirectory configuration field
  --scaffold-server       Create an application-owned server module if missing
  --dry-run               Show planned changes without writing files
  --check                 Fail when generated files differ; write nothing
  --json                  Emit a structured JSON result
  --help                  Show this help

Configuration is strict JSON and is never executed or imported.
`;

export interface VinextCliIo {
  readonly cwd?: string;
  readonly stdout?: (value: string) => void;
  readonly stderr?: (value: string) => void;
}

/** Return an exit code, allowing callers to embed the CLI without process side effects. */
export async function runVinextCli(argv: readonly string[], io: VinextCliIo = {}): Promise<number> {
  const stdout = io.stdout ?? ((value: string) => { process.stdout.write(value); });
  const stderr = io.stderr ?? ((value: string) => { process.stderr.write(value); });
  const cwd = io.cwd ?? process.cwd();
  const json = argv.includes("--json");
  if (argv.length === 0 || argv.includes("--help") || argv.includes("-h")) {
    stdout(usage);
    return 0;
  }
  try {
    if (argv[0] !== "generate" || argv[1] !== "vinext") throw new TypeError("Expected 'generate vinext'.");
    const flags = new Map<string, string | true>();
    for (let index = 2; index < argv.length; index++) {
      const flag = argv[index]!;
      if (!["--config", "--root", "--app-dir", "--scaffold-server", "--dry-run", "--check", "--json"].includes(flag)) {
        throw new TypeError(`Unknown argument: ${flag}`);
      }
      if (flags.has(flag)) throw new TypeError(`Duplicate argument: ${flag}`);
      if (["--config", "--root", "--app-dir"].includes(flag)) {
        const value = argv[++index];
        if (value === undefined || value.startsWith("--") || value.length === 0) throw new TypeError(`A value is required for ${flag}.`);
        flags.set(flag, value);
      } else flags.set(flag, true);
    }
    const configArgument = flags.get("--config");
    if (typeof configArgument !== "string") throw new TypeError("--config <json-file> is required.");
    if (flags.has("--dry-run") && flags.has("--check")) throw new TypeError("--dry-run and --check cannot be combined.");
    const appDirectory = flags.get("--app-dir");
    if (appDirectory !== undefined && appDirectory !== "app" && appDirectory !== "src/app") {
      throw new TypeError("--app-dir must be 'app' or 'src/app'.");
    }
    const configFile = path.resolve(cwd, configArgument);
    let raw: unknown;
    try { raw = JSON.parse(await fs.readFile(configFile, "utf8")); }
    catch (cause) { throw new TypeError(`Cannot read strict JSON configuration: ${configFile}`, { cause }); }
    const base = parseVinextGeneratorConfig(raw);
    const config = parseVinextGeneratorConfig({
      ...base,
      ...(appDirectory === undefined ? {} : { appDirectory }),
      ...(flags.has("--scaffold-server") ? { scaffoldServer: true } : {}),
    });
    const rootArgument = flags.get("--root");
    const root = typeof rootArgument === "string" ? path.resolve(cwd, rootArgument) : path.dirname(configFile);
    const mode: VinextGenerationMode = flags.has("--check") ? "check" : flags.has("--dry-run") ? "dry-run" : "write";
    const result = await generateVinext({ root, config, mode });
    if (json) stdout(`${JSON.stringify(result, null, 2)}\n`);
    else {
      for (const file of result.files) stdout(`${file.status.padEnd(9)} ${file.path}${file.reason === undefined ? "" : `: ${file.reason}`}\n`);
    }
    return result.ok ? 0 : 1;
  } catch (error) {
    const errorCode = error instanceof VinextGenerationError ? error.code :
      error instanceof TypeError || error instanceof SyntaxError ||
      error instanceof SyncError && (error.code === "invalid-input" || error.code === "unsupported-version") ? "invalid-arguments" : "io-error";
    const message = error instanceof Error ? error.message : "Vinext generation failed.";
    if (json) stdout(`${JSON.stringify({ ok: false, error: { code: errorCode, message } }, null, 2)}\n`);
    else stderr(`${errorCode}: ${message}\n`);
    return errorCode === "invalid-arguments" ? 2 : 1;
  }
}
