import type { VinextGenerationPlan, VinextGeneratorConfig } from "../integrations/vinext/index.js";

export type VinextGenerationMode = "write" | "dry-run" | "check";
export type VinextGeneratedFileStatus = "create" | "update" | "delete" | "unchanged" | "conflict";

export interface VinextFileChange {
  readonly path: string;
  readonly ownership: "generated" | "scaffold" | "manifest";
  readonly status: VinextGeneratedFileStatus;
  readonly reason?: string;
}

export interface GenerateVinextOptions {
  /** Existing application root. Outputs and generator state remain inside this directory. */
  readonly root: string;
  readonly config: VinextGeneratorConfig;
  readonly mode?: VinextGenerationMode;
}

/** Apply a pre-rendered plan using the same ownership and transaction protections. */
export interface ApplyVinextGenerationPlanOptions {
  readonly root: string;
  readonly plan: VinextGenerationPlan;
  readonly mode?: VinextGenerationMode;
}

export interface VinextGenerationResult {
  readonly mode: VinextGenerationMode;
  /** False for conflicts, and for drift in check mode. */
  readonly ok: boolean;
  /** Whether the files differed from the requested generation before this invocation. */
  readonly drift: boolean;
  readonly files: readonly VinextFileChange[];
}

export type VinextGenerationErrorCode =
  | "unsafe-path"
  | "invalid-plan"
  | "invalid-manifest"
  | "locked"
  | "incomplete-generation"
  | "io-error";

export class VinextGenerationError extends Error {
  readonly code: VinextGenerationErrorCode;

  constructor(code: VinextGenerationErrorCode, message: string, options?: ErrorOptions) {
    super(message, options);
    this.name = "VinextGenerationError";
    this.code = code;
  }
}
