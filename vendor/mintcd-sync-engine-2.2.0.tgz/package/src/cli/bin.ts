#!/usr/bin/env node
import { realpath } from "node:fs/promises";
import { pathToFileURL } from "node:url";
import { runVinextCli } from "./main.js";

const entry = process.argv[1] === undefined ? undefined : await realpath(process.argv[1]).catch(() => undefined);
if (entry !== undefined && import.meta.url === pathToFileURL(entry).href) {
  process.exitCode = await runVinextCli(process.argv.slice(2));
}
