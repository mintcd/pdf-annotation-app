import type { RecordDatabase, RecordDomainModel, RecordSchema, CollectionName, CollectionRow, RecordWrite } from "../../records/types.js";

/** The primary D1 binding. Do not pass a read-replica session to this adapter. */
export interface D1Binding {
  /** D1DatabaseSession exposes this method and is deliberately excluded. */
  readonly getBookmark?: never;
  prepare(query: string): D1PreparedStatementPort;
  batch<T = unknown>(statements: D1PreparedStatementPort[]): Promise<D1ResultPort<T>[]>;
}
export interface D1PreparedStatementPort {
  bind(...values: unknown[]): D1PreparedStatementPort;
  all<T = Record<string, unknown>>(): Promise<D1ResultPort<T>>;
}
export interface D1ResultPort<T = unknown> { readonly success: boolean; readonly results: T[] }
export type D1ColumnValue = string | number | null | ArrayBuffer;
export interface D1ColumnMapping<Row> {
  readonly type: "TEXT" | "REAL" | "INTEGER" | "BLOB";
  value(row: Row): D1ColumnValue;
  /** Creates an application SQL index on (stream, column), separate from sync indexes. */
  readonly indexed?: boolean;
}
export type D1CollectionMappings<Schema extends RecordSchema> = {
  readonly [Name in CollectionName<Schema>]: {
    readonly table: string;
    readonly columns?: Readonly<Record<string, D1ColumnMapping<CollectionRow<Schema, Name>>>>;
  }
};
export interface D1RecordMigrationOptions<Schema extends RecordSchema> {
  readonly schema: Schema;
  readonly collections: D1CollectionMappings<Schema>;
  /** Internal table prefix; collection table names are used exactly as declared. */
  readonly tablePrefix?: string;
}
export interface D1RecordLimits {
  /** Maximum statements in any one atomic batch, including its guard. */
  readonly maximumStatements: number;
  /** UTF-8 SQL and bound-data budget for a batch. */
  readonly maximumBytes: number;
  /** Bound on rows fetched by an individual storage read. */
  readonly maximumReadRows: number;
}
export interface D1RecordDatabaseOptions<Schema extends RecordSchema, Intent, Operation, Rejection> {
  readonly database: D1Binding;
  readonly streamId: string;
  readonly model: RecordDomainModel<Schema, Intent, Operation, Rejection>;
  readonly collections: D1CollectionMappings<Schema>;
  readonly tablePrefix?: string;
  readonly initialRows?: readonly RecordWrite<Schema>[];
  readonly limits?: Partial<D1RecordLimits>;
}
/** Authority-only storage; optimistic visible rows and replica queues are unsupported. */
export interface D1RecordDatabase<Schema extends RecordSchema> extends RecordDatabase<Schema> {}
