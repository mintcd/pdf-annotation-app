import { validateRecordKey } from "../../records/keys.js";
import type { RecordKey } from "../../records/types.js";

/** ASCII BINARY order equals the portable numeric/UTF-16 tuple ordering. */
export function d1SortKey(key: RecordKey, prefix = false): string {
  validateRecordKey(key, prefix);
  let result = "";
  for (const part of key) {
    if (typeof part === "number") {
      const buffer = new ArrayBuffer(8);
      new DataView(buffer).setFloat64(0, part === 0 ? 0 : part, false);
      const bytes = new Uint8Array(buffer);
      const negative = (bytes[0]! & 128) !== 0;
      for (let index = 0; index < bytes.length; index++) bytes[index] = negative ? bytes[index]! ^ 255 : (index === 0 ? bytes[index]! ^ 128 : bytes[index]!);
      result += "1" + Array.from(bytes, value => value.toString(16).padStart(2, "0")).join("");
    } else {
      result += "2";
      for (let index = 0; index < part.length; index++) result += (part.charCodeAt(index) + 1).toString(16).padStart(5, "0");
      result += "00000";
    }
  }
  return result + (prefix ? "" : "0");
}
