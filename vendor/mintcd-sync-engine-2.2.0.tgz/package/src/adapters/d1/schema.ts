import { SyncError } from "../../core/errors.js";
import { canonicalizeJson } from "../../core/fingerprint.js";
import { defineRecordSchema, schemaIdentity } from "../../records/schema.js";
import type { RecordSchema } from "../../records/types.js";
import type { D1CollectionMappings, D1ColumnMapping, D1RecordMigrationOptions } from "./types.js";

export const internalTables = ["meta", "canonical", "identities", "positions", "decisions", "accepted"] as const;
export function identifier(value: string): string {
  if (typeof value !== "string" || !/^[A-Za-z_][A-Za-z0-9_]{0,95}$/.test(value)) throw new SyncError("invalid-input", "D1 table and column names must be short SQL identifiers.");
  return `"${value}"`;
}
export interface Layout<Schema extends RecordSchema> {
  readonly schema: Schema;
  readonly collections: D1CollectionMappings<Schema>;
  readonly prefix: string;
  readonly binding: string;
  readonly indexes: ReadonlyMap<string, ReadonlyMap<string, string>>;
}
interface CollectionMapping { readonly table: string; readonly columns: Readonly<Record<string, D1ColumnMapping<unknown>>> }
export function makeLayout<Schema extends RecordSchema>(options: D1RecordMigrationOptions<Schema>): Layout<Schema> {
  const schema = defineRecordSchema(options.schema) as Schema;
  const prefix = options.tablePrefix ?? "sync_";
  identifier(prefix + "layout");
  const names = Object.keys(schema.collections).sort();
  const mappedNames = options.collections ? Object.keys(options.collections).sort() : [];
  if (mappedNames.length !== names.length || mappedNames.some((name, position) => name !== names[position])) throw new SyncError("invalid-input", "D1 mappings must cover exactly the declared collections.");
  const tables = new Set(["layout", "streams", "guards", ...internalTables].map(name => (prefix + name).toLowerCase()));
  const indexes = new Map<string, ReadonlyMap<string, string>>();
  const mappings: Record<string, CollectionMapping> = Object.create(null) as Record<string, CollectionMapping>;
  const bindings = [];
  for (const name of names) {
    const mapping = options.collections[name]!;
    identifier(mapping.table);
    if (tables.has(mapping.table.toLowerCase())) throw new SyncError("invalid-input", "D1 collection tables must be distinct from each other and internal tables.");
    tables.add(mapping.table.toLowerCase());
    const columns = Object.entries(mapping.columns ?? {}).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    const columnNames = new Set<string>();
    const mappedColumns: Record<string, D1ColumnMapping<unknown>> = Object.create(null) as Record<string, D1ColumnMapping<unknown>>;
    for (const [column, definition] of columns) {
      identifier(column);
      if (column.toLowerCase().startsWith("__sync_") || columnNames.has(column.toLowerCase()) || !definition || !["TEXT", "REAL", "INTEGER", "BLOB"].includes(definition.type) || typeof definition.value !== "function" || (definition.indexed !== undefined && typeof definition.indexed !== "boolean")) throw new SyncError("invalid-input", "Invalid or reserved D1 application column mapping.");
      columnNames.add(column.toLowerCase());
      mappedColumns[column] = Object.freeze({ type: definition.type, value: definition.value.bind(definition), indexed: definition.indexed ?? false });
    }
    if (3 + columns.length + Object.keys(schema.collections[name]!.indexes ?? {}).length > 100) throw new SyncError("limit-exceeded", "A D1 collection exceeds the 100 column limit.");
    mappings[name] = Object.freeze({ table: mapping.table, columns: Object.freeze(mappedColumns) });
    indexes.set(name, new Map(Object.keys(schema.collections[name]!.indexes ?? {}).sort().map((index, position) => [index, `__sync_index_${position}`])));
    bindings.push({ collection: name, table: mapping.table, columns: columns.map(([column, definition]) => ({ name: column, type: definition.type, indexed: definition.indexed ?? false })) });
  }
  return { schema, collections: Object.freeze(mappings) as D1CollectionMappings<Schema>, prefix, indexes, binding: canonicalizeJson({ format: "d1-records/v1", prefix, schema: schemaIdentity(schema), collections: bindings }) };
}
const literal = (value: string): string => `'${value.replaceAll("'", "''")}'`;

/** Generate an initial migration for review and application through deployment tooling. */
export function createD1RecordMigration<Schema extends RecordSchema>(options: D1RecordMigrationOptions<Schema>): string {
  const layout = makeLayout(options);
  const table = (name: string): string => identifier(layout.prefix + name);
  const statements = [
    `CREATE TABLE IF NOT EXISTS ${table("layout")} (id INTEGER PRIMARY KEY CHECK (id = 1), binding TEXT NOT NULL);`,
    `INSERT INTO ${table("layout")} (id, binding) VALUES (1, ${literal(layout.binding)}) ON CONFLICT (id) DO UPDATE SET binding = CASE WHEN binding = excluded.binding THEN binding ELSE NULL END;`,
    `CREATE TABLE IF NOT EXISTS ${table("streams")} (stream_id TEXT PRIMARY KEY, revision INTEGER NOT NULL CHECK (revision >= 0), contract_version TEXT NOT NULL, schema_binding TEXT NOT NULL);`,
    `CREATE TABLE IF NOT EXISTS ${table("guards")} (id INTEGER PRIMARY KEY CHECK (id = 1), valid INTEGER NOT NULL CHECK (valid = 1));`,
  ];
  for (const name of internalTables) statements.push(`CREATE TABLE IF NOT EXISTS ${table(name)} (stream_id TEXT NOT NULL, sort_key TEXT COLLATE BINARY NOT NULL, key_json TEXT NOT NULL, value_json TEXT NOT NULL, PRIMARY KEY (stream_id, sort_key));`);
  for (const name of Object.keys(layout.schema.collections).sort()) {
    const mapping = layout.collections[name]!;
    const indexColumns = [...layout.indexes.get(name)!.values()];
    const columns = Object.entries(mapping.columns ?? {}).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);
    const fields = ["__sync_stream TEXT NOT NULL", "__sync_key TEXT COLLATE BINARY NOT NULL", "__sync_data TEXT NOT NULL", ...indexColumns.map(column => `${identifier(column)} TEXT COLLATE BINARY`), ...columns.map(([column, definition]) => `${identifier(column)} ${definition.type}`), "PRIMARY KEY (__sync_stream, __sync_key)"];
    statements.push(`CREATE TABLE IF NOT EXISTS ${identifier(mapping.table)} (${fields.join(", ")});`);
    for (const [position, column] of indexColumns.entries()) statements.push(`CREATE INDEX IF NOT EXISTS ${identifier(mapping.table + "_sync_i" + position)} ON ${identifier(mapping.table)} (__sync_stream, ${identifier(column)}, __sync_key);`);
    for (const [position, [column, definition]] of columns.entries()) if (definition.indexed) statements.push(`CREATE INDEX IF NOT EXISTS ${identifier(mapping.table + "_sync_c" + position)} ON ${identifier(mapping.table)} (__sync_stream, ${identifier(column)});`);
  }
  return statements.join("\n") + "\n";
}
