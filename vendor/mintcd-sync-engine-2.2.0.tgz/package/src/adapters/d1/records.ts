import { decodeCodecValue, encodeCodecValue } from "../../core/codecs.js";
import { SyncError } from "../../core/errors.js";
import { canonicalizeJson } from "../../core/fingerprint.js";
import { assertIdentifier, assertSequence } from "../../core/validation.js";
import { compareRecordKeys, compareScanRange, validateRecordKey, validateScan } from "../../records/keys.js";
import { collectionDefinition, normalizeRecord, schemaIdentity } from "../../records/schema.js";
import type { CollectionName, CollectionRow, InternalRecord, InternalScan, RecordArea, RecordCursor, RecordInternalTable, RecordKey, RecordPage, RecordSchema, RecordTransaction, RecordWrite } from "../../records/types.js";
import { d1SortKey } from "./keys.js";
import { identifier, internalTables, makeLayout } from "./schema.js";
import type { D1ColumnValue, D1PreparedStatementPort, D1RecordDatabase, D1RecordDatabaseOptions, D1RecordLimits } from "./types.js";

interface StreamState { revision: number; contract_version: string; schema_binding: string }
interface RawRow { __sync_key: string; __sync_data: string }
interface RawInternal { sort_key: string; key_json: string; value_json: string }
interface StoredRow { key: RecordKey; row: unknown; json: string; sort: string; indexes: Map<string, RecordKey>; columns: Map<string, D1ColumnValue> }
interface StoredInternal { key: RecordKey; value: unknown; json: string; sort: string }
interface Statement { sql: string; values: readonly unknown[] }
interface RangeSql { clauses: string[]; values: unknown[] }
const encoder = new TextEncoder();
const defaultLimits: D1RecordLimits = { maximumStatements: 1000, maximumBytes: 1024 * 1024, maximumReadRows: 4096 };

function rangeSql(column: string, scan: InternalScan): RangeSql {
  const clauses: string[] = [];
  const values: unknown[] = [];
  if (scan.prefix !== undefined && scan.prefix.length > 0) {
    const prefix = d1SortKey(scan.prefix, true);
    clauses.push(`${column} >= ?`, `${column} < ?`); values.push(prefix, prefix + "z");
  }
  if (scan.lower) { clauses.push(`${column} ${scan.lower.inclusive === false ? ">" : ">="} ?`); values.push(d1SortKey(scan.lower.key)); }
  if (scan.upper) { clauses.push(`${column} ${scan.upper.inclusive === false ? "<" : "<="} ?`); values.push(d1SortKey(scan.upper.key)); }
  return { clauses, values };
}
function bytes(value: unknown): number {
  if (value instanceof ArrayBuffer) return value.byteLength;
  return encoder.encode(typeof value === "string" ? value : String(value)).byteLength;
}

/**
 * D1 has no interactive transaction callback. Reads build a plan against a
 * primary revision; a CHECK assertion guards the complete atomic write batch.
 */
export async function openD1RecordDatabase<Schema extends RecordSchema, Intent, Operation, Rejection>(
  options: D1RecordDatabaseOptions<Schema, Intent, Operation, Rejection>,
): Promise<D1RecordDatabase<Schema>> {
  assertIdentifier(options.streamId, "streamId");
  assertIdentifier(options.model.contractVersion, "contractVersion");
  const streamId = options.streamId;
  const contractVersion = options.model.contractVersion;
  const model = options.model;
  const initialRows = structuredClone(options.initialRows ?? []);
  const database = options.database;
  if (database.getBookmark !== undefined) throw new SyncError("invalid-input", "Pass the primary D1 database binding, not a read-replica session.");
  const layout = makeLayout({ schema: model.schema, collections: options.collections, ...(options.tablePrefix !== undefined ? { tablePrefix: options.tablePrefix } : {}) });
  const schema = layout.schema;
  const schemaId = schemaIdentity(schema);
  const limits = { ...defaultLimits, ...options.limits };
  for (const [name, value] of Object.entries(limits)) assertSequence(value, name, 1);
  const table = (name: string): string => identifier(layout.prefix + name);

  function prepare(statement: Statement): D1PreparedStatementPort { return database.prepare(statement.sql).bind(...statement.values); }
  async function all<Value>(sql: string, values: readonly unknown[]): Promise<Value[]> {
    try {
      const result = await prepare({ sql, values }).all<Value>();
      if (!result.success || !Array.isArray(result.results)) throw new Error("D1 did not return a successful result.");
      return result.results;
    } catch (cause) {
      if (cause instanceof SyncError) throw cause;
      throw new SyncError("corrupt-state", "The D1 storage request failed.", { cause });
    }
  }
  async function readState(): Promise<StreamState | undefined> {
    const rows = await all<StreamState>(`SELECT revision, contract_version, schema_binding FROM ${table("streams")} WHERE stream_id = ? LIMIT 1`, [streamId]);
    const state = rows[0];
    if (state) {
      if (!Number.isSafeInteger(state.revision) || state.revision < 0) throw new SyncError("corrupt-state", "Invalid D1 stream revision.");
      if (state.contract_version !== contractVersion || state.schema_binding !== layout.binding) throw new SyncError("contract-mismatch", "D1 stream belongs to a different contract or storage layout.");
    }
    return state;
  }
  function checkedLimit(limit: number): number {
    if (!Number.isSafeInteger(limit) || limit < 1 || limit > limits.maximumReadRows) throw new SyncError("limit-exceeded", "The D1 read exceeds its row budget.");
    return limit;
  }
  async function batch(statements: readonly Statement[]): Promise<void> {
    if (statements.some(statement => statement.values.length > 100 || bytes(statement.sql) > 100_000)) throw new SyncError("limit-exceeded", "A D1 statement exceeds the bound-parameter or SQL byte limit.");
    if (statements.length > limits.maximumStatements || statements.reduce((sum, statement) => sum + bytes(statement.sql) + statement.values.reduce<number>((total, value) => total + bytes(value), 0), 0) > limits.maximumBytes) throw new SyncError("limit-exceeded", "The D1 atomic batch exceeds its statement or byte budget.");
    const result = await database.batch(statements.map(prepare));
    if (result.length !== statements.length || result.some(item => !item.success)) throw new Error("D1 atomic batch did not succeed.");
  }
  function checkArea(area: RecordArea, collection: string): void {
    if (area !== "confirmed") throw new SyncError("invalid-input", "The D1 adapter stores authority confirmed records only.");
    collectionDefinition(schema, collection);
  }
  function checkInternal(name: RecordInternalTable, writeKey?: RecordKey): void {
    if (!(internalTables as readonly string[]).includes(name)) throw new SyncError("invalid-input", "The D1 authority does not store replica queues or optimistic state.");
    if (name === "meta" && writeKey?.[0] === "replica") throw new SyncError("invalid-input", "The D1 authority cannot be opened as a local replica.");
  }
  function makeRow(collection: string, input: unknown): StoredRow {
    const definition = collectionDefinition(schema, collection);
    const row = normalizeRecord(schema, collection, input as CollectionRow<Schema, CollectionName<Schema>>);
    const key = structuredClone(definition.key(structuredClone(row)));
    const indexes = new Map<string, RecordKey>([["", key]]);
    for (const [name, index] of Object.entries(definition.indexes ?? {})) {
      const indexKey = index.key(structuredClone(row));
      if (indexKey !== undefined) indexes.set(name, structuredClone(indexKey));
    }
    const columns = new Map<string, D1ColumnValue>();
    for (const [column, mapping] of Object.entries(layout.collections[collection]!.columns ?? {})) {
      const value = mapping.value(structuredClone(row));
      const valid = value === null || (mapping.type === "TEXT" ? typeof value === "string" : mapping.type === "BLOB" ? value instanceof ArrayBuffer : typeof value === "number" && Number.isFinite(value) && (mapping.type !== "INTEGER" || Number.isSafeInteger(value)));
      if (!valid) throw new SyncError("invalid-input", "D1 application column has the wrong mapped value type.");
      columns.set(column, value instanceof ArrayBuffer ? value.slice(0) : value);
    }
    return { key, row, json: canonicalizeJson(encodeCodecValue(definition.codec, row, "D1 row")), sort: d1SortKey(key), indexes, columns };
  }
  function decodeRow(collection: string, raw: RawRow): StoredRow {
    try {
      const definition = collectionDefinition(schema, collection);
      const row = makeRow(collection, decodeCodecValue(definition.codec, JSON.parse(raw.__sync_data) as unknown, "stored D1 row"));
      if (row.sort !== raw.__sync_key) throw new Error("Row primary key differs from its storage key.");
      return row;
    } catch (cause) { throw new SyncError("corrupt-state", "Invalid stored D1 row.", { cause }); }
  }
  function encodeInternal(name: RecordInternalTable, value: unknown): string {
    let wire = structuredClone(value);
    if (name === "canonical" || name === "decisions") {
      if (!wire || typeof wire !== "object" || Array.isArray(wire)) throw new SyncError("invalid-input", "Invalid D1 retained operation or decision.");
      const entry = wire as Record<string, unknown>;
      if (name === "canonical" || entry.status === "accepted") entry.operation = encodeCodecValue(model.operation, entry.operation as Operation, "D1 canonical operation");
      else if (entry.status === "rejected") entry.reason = encodeCodecValue(model.rejection, entry.reason as Rejection, "D1 rejection");
      else throw new SyncError("invalid-input", "Invalid D1 decision status.");
    }
    return canonicalizeJson(wire);
  }
  function decodeInternal(name: RecordInternalTable, raw: RawInternal): StoredInternal {
    try {
      const key: unknown = JSON.parse(raw.key_json); validateRecordKey(key);
      if (d1SortKey(key) !== raw.sort_key) throw new Error("Internal key differs from its storage key.");
      const value: unknown = JSON.parse(raw.value_json);
      if (name === "canonical" || name === "decisions") {
        if (!value || typeof value !== "object" || Array.isArray(value)) throw new Error("Invalid retained operation.");
        const entry = value as Record<string, unknown>;
        if (name === "canonical" || entry.status === "accepted") entry.operation = decodeCodecValue(model.operation, entry.operation, "stored D1 canonical operation");
        else if (entry.status === "rejected") entry.reason = decodeCodecValue(model.rejection, entry.reason, "stored D1 rejection");
        else throw new Error("Invalid retained decision status.");
      }
      return { key, value, json: raw.value_json, sort: raw.sort_key };
    } catch (cause) { throw new SyncError("corrupt-state", "Invalid stored D1 internal record.", { cause }); }
  }
  function rowStatement(collection: string, sort: string, row: StoredRow | undefined): Statement {
    const mapping = layout.collections[collection]!;
    if (!row) return { sql: `DELETE FROM ${identifier(mapping.table)} WHERE __sync_stream = ? AND __sync_key = ?`, values: [streamId, sort] };
    const columns = ["__sync_stream", "__sync_key", "__sync_data", ...layout.indexes.get(collection)!.values(), ...row.columns.keys()];
    const values: unknown[] = [streamId, sort, row.json];
    for (const name of layout.indexes.get(collection)!.keys()) values.push(row.indexes.has(name) ? d1SortKey(row.indexes.get(name)!) : null);
    values.push(...row.columns.values());
    return { sql: `INSERT INTO ${identifier(mapping.table)} (${columns.map(identifier).join(", ")}) VALUES (${columns.map(() => "?").join(", ")}) ON CONFLICT (__sync_stream, __sync_key) DO UPDATE SET ${columns.slice(2).map(column => `${identifier(column)} = excluded.${identifier(column)}`).join(", ")}`, values };
  }
  function guard(revision?: number): Statement {
    const condition = revision === undefined ? `NOT EXISTS (SELECT 1 FROM ${table("streams")} WHERE stream_id = ?)` : `EXISTS (SELECT 1 FROM ${table("streams")} WHERE stream_id = ? AND revision = ?)`;
    return { sql: `INSERT OR REPLACE INTO ${table("guards")} (id, valid) VALUES (1, CASE WHEN ${condition} THEN 1 ELSE 0 END)`, values: revision === undefined ? [streamId] : [streamId, revision] };
  }

  const layoutRows = await all<{ binding: string }>(`SELECT binding FROM ${table("layout")} WHERE id = 1`, []);
  if (layoutRows.length !== 1 || layoutRows[0]!.binding !== layout.binding) throw new SyncError("contract-mismatch", "Apply the matching explicit D1 migration before opening this storage layout.");
  // Genesis is an absent-stream guarded batch. A competing opener can never
  // overwrite existing rows or a stream that has already received decisions.
  let initialized = false;
  for (let attempt = 0; attempt < 8; attempt++) {
    if (await readState()) { initialized = true; break; }
    const genesis = new Map<string, Map<string, StoredRow | undefined>>();
    for (const write of initialRows) {
      checkArea("confirmed", write.collection);
      if (write.type !== "put" && write.type !== "delete") throw new SyncError("invalid-input", "Invalid D1 genesis write.");
      const row = write.type === "put" ? makeRow(write.collection, write.row) : undefined;
      const key = row?.key ?? (write.type === "delete" ? write.key : []); validateRecordKey(key);
      let collection = genesis.get(write.collection); if (!collection) { collection = new Map(); genesis.set(write.collection, collection); }
      collection.set(d1SortKey(key), row);
    }
    const statements: Statement[] = [guard(), { sql: `INSERT INTO ${table("streams")} (stream_id, revision, contract_version, schema_binding) VALUES (?, 0, ?, ?)`, values: [streamId, contractVersion, layout.binding] }];
    for (const [collection, changes] of genesis) for (const [sort, row] of changes) if (row) statements.push(rowStatement(collection, sort, row));
    try { await batch(statements); initialized = true; break; }
    catch (cause) {
      if (cause instanceof SyncError && cause.code === "limit-exceeded") throw cause;
      if (!(await readState())) throw new SyncError("corrupt-state", "The D1 genesis batch failed.", { cause });
    }
  }
  if (!initialized) throw new SyncError("commit-conflict", "The D1 stream could not be initialized within its retry budget.");

  return {
    streamId, schema,
    async transaction<Value>(mode: "readonly" | "readwrite", run: (transaction: RecordTransaction<Schema>) => Value | Promise<Value>, configuration?: { readonly expectedRevision?: number }) {
      if (mode !== "readonly" && mode !== "readwrite") throw new SyncError("invalid-input", "Invalid transaction mode.");
      const expectedRevision = configuration?.expectedRevision;
      if (expectedRevision !== undefined) assertSequence(expectedRevision, "expectedRevision");
      const state = await readState();
      if (!state) throw new SyncError("corrupt-state", "The D1 stream metadata is missing.");
      const revision = state.revision;
      if (expectedRevision !== undefined && expectedRevision !== revision) throw new SyncError("commit-conflict", "The D1 stream revision changed.");
      let active = true;
      const rowChanges = new Map<string, Map<string, StoredRow | undefined>>();
      const internalChanges = new Map<RecordInternalTable, Map<string, StoredInternal | undefined>>();
      function check(write = false): void {
        if (!active) throw new SyncError("closed", "D1 record transaction is no longer active.");
        if (write && mode !== "readwrite") throw new SyncError("invalid-input", "A readonly D1 transaction cannot write.");
      }
      async function baselineRow(collection: string, sort: string): Promise<StoredRow | undefined> {
        const mapping = layout.collections[collection]!;
        const rows = await all<RawRow>(`SELECT __sync_key, __sync_data FROM ${identifier(mapping.table)} WHERE __sync_stream = ? AND __sync_key = ? LIMIT 1`, [streamId, sort]);
        return rows[0] ? decodeRow(collection, rows[0]) : undefined;
      }
      const transaction: RecordTransaction<Schema> = {
        revision, schema,
        async get(area, collection, key) {
          check(); checkArea(area, collection); validateRecordKey(key);
          const sort = d1SortKey(key); const changes = rowChanges.get(collection);
          const row = changes?.has(sort) ? changes.get(sort) : await baselineRow(collection, sort);
          check(); return structuredClone(row?.row) as CollectionRow<Schema, typeof collection> | undefined;
        },
        async query(area, query) {
          check();
          if (!query || typeof query !== "object" || Object.keys(query).some(key => !["collection", "index", "prefix", "lower", "upper", "direction", "limit", "cursor"].includes(key))) throw new SyncError("invalid-input", "Unsupported record query fields.");
          checkArea(area, query.collection); validateScan(query, 256);
          const indexName = query.index ?? "";
          const indexColumn = query.index === undefined ? "__sync_key" : layout.indexes.get(query.collection)!.get(indexName);
          if (!indexColumn) throw new SyncError("invalid-input", "Unknown declared D1 collection index.");
          const direction = query.direction ?? "asc";
          const queryIdentity = canonicalizeJson({ schema: schemaId, area, collection: query.collection, index: indexName, prefix: query.prefix ?? [], lower: query.lower ?? null, upper: query.upper ?? null, direction });
          const cursor = query.cursor;
          if (cursor !== undefined) {
            canonicalizeJson(cursor); validateRecordKey(cursor.indexKey); validateRecordKey(cursor.primaryKey); assertSequence(cursor.revision, "cursor.revision");
            if (cursor.version !== 1 || cursor.schemaVersion !== schema.version || cursor.streamId !== streamId || cursor.queryIdentity !== queryIdentity || cursor.revision > revision || compareScanRange(cursor.indexKey, query) !== 0) throw new SyncError("invalid-cursor", "Cursor does not match this D1 query or stream revision.");
          }
          const range = rangeSql(identifier(indexColumn), query);
          if (query.index !== undefined) range.clauses.push(`${identifier(indexColumn)} IS NOT NULL`);
          if (cursor) {
            const operator = direction === "asc" ? ">" : "<";
            range.clauses.push(`(${identifier(indexColumn)} ${operator} ? OR (${identifier(indexColumn)} = ? AND __sync_key ${operator} ?))`);
            range.values.push(d1SortKey(cursor.indexKey), d1SortKey(cursor.indexKey), d1SortKey(cursor.primaryKey));
          }
          const changes = rowChanges.get(query.collection);
          const readLimit = checkedLimit(query.limit + (changes?.size ?? 0) + 1);
          const mapping = layout.collections[query.collection]!;
          const order = direction === "asc" ? "ASC" : "DESC";
          const raw = await all<RawRow>(`SELECT __sync_key, __sync_data FROM ${identifier(mapping.table)} WHERE __sync_stream = ?${range.clauses.map(clause => ` AND ${clause}`).join("")} ORDER BY ${identifier(indexColumn)} ${order}, __sync_key ${order} LIMIT ?`, [streamId, ...range.values, readLimit]);
          check();
          const candidates = raw.filter(row => !changes?.has(row.__sync_key)).map(row => decodeRow(query.collection, row));
          for (const row of changes?.values() ?? []) if (row) candidates.push(row);
          const selected = candidates.filter(row => {
            const key = row.indexes.get(indexName); if (!key || compareScanRange(key, query) !== 0) return false;
            const comparison = cursor ? compareRecordKeys(key, cursor.indexKey) || compareRecordKeys(row.key, cursor.primaryKey) : 0;
            return !cursor || (direction === "asc" ? comparison > 0 : comparison < 0);
          }).sort((a, b) => (compareRecordKeys(a.indexes.get(indexName)!, b.indexes.get(indexName)!) || compareRecordKeys(a.key, b.key)) * (direction === "asc" ? 1 : -1));
          const page = selected.slice(0, query.limit); const last = page.at(-1);
          const nextCursor: RecordCursor | undefined = selected.length > query.limit && last ? { version: 1, schemaVersion: schema.version, streamId, queryIdentity, revision, indexKey: structuredClone(last.indexes.get(indexName)!), primaryKey: structuredClone(last.key) } : undefined;
          return { rows: page.map(row => structuredClone(row.row)), revision, ...(nextCursor ? { nextCursor } : {}) } as RecordPage<CollectionRow<Schema, typeof query.collection>>;
        },
        async apply(area, writes) {
          check(true);
          const validated = writes.map(write => {
            checkArea(area, write.collection);
            if (write.type !== "put" && write.type !== "delete") throw new SyncError("invalid-input", "Invalid D1 row write.");
            const row = write.type === "put" ? makeRow(write.collection, write.row) : undefined;
            const key = row?.key ?? (write.type === "delete" ? write.key : []); validateRecordKey(key);
            return { collection: write.collection, sort: d1SortKey(key), row };
          });
          for (const { collection, sort, row } of validated) {
            let changes = rowChanges.get(collection); if (!changes) { changes = new Map(); rowChanges.set(collection, changes); }
            changes.set(sort, row);
          }
        },
        async getInternal<Value>(name: RecordInternalTable, key: RecordKey): Promise<Value | undefined> {
          check(); checkInternal(name); validateRecordKey(key);
          const sort = d1SortKey(key); const changes = internalChanges.get(name);
          if (changes?.has(sort)) return structuredClone(changes.get(sort)?.value) as Value | undefined;
          const rows = await all<RawInternal>(`SELECT sort_key, key_json, value_json FROM ${table(name)} WHERE stream_id = ? AND sort_key = ? LIMIT 1`, [streamId, sort]);
          check(); return rows[0] ? structuredClone(decodeInternal(name, rows[0]).value) as Value : undefined;
        },
        async putInternal(name, key, value) {
          check(true); checkInternal(name, key); validateRecordKey(key);
          const json = encodeInternal(name, value); const sort = d1SortKey(key);
          // Decode through the declared codecs before exposing read-your-writes.
          const entry = decodeInternal(name, { sort_key: sort, key_json: canonicalizeJson(key), value_json: json });
          let changes = internalChanges.get(name); if (!changes) { changes = new Map(); internalChanges.set(name, changes); }
          changes.set(sort, entry);
        },
        async deleteInternal(name, key) {
          check(true); checkInternal(name, key); validateRecordKey(key);
          let changes = internalChanges.get(name); if (!changes) { changes = new Map(); internalChanges.set(name, changes); }
          changes.set(d1SortKey(key), undefined);
        },
        async scanInternal<Value>(name: RecordInternalTable, scan: InternalScan): Promise<readonly InternalRecord<Value>[]> {
          check(); checkInternal(name); validateScan(scan);
          const changes = internalChanges.get(name);
          const range = rangeSql("sort_key", scan);
          const readLimit = checkedLimit(scan.limit + (changes?.size ?? 0));
          const order = scan.direction === "desc" ? "DESC" : "ASC";
          const raw = await all<RawInternal>(`SELECT sort_key, key_json, value_json FROM ${table(name)} WHERE stream_id = ?${range.clauses.map(clause => ` AND ${clause}`).join("")} ORDER BY sort_key ${order} LIMIT ?`, [streamId, ...range.values, readLimit]);
          check();
          const candidates = raw.filter(row => !changes?.has(row.sort_key)).map(row => decodeInternal(name, row));
          for (const entry of changes?.values() ?? []) if (entry) candidates.push(entry);
          return candidates.filter(entry => compareScanRange(entry.key, scan) === 0).sort((a, b) => compareRecordKeys(a.key, b.key) * (scan.direction === "desc" ? -1 : 1)).slice(0, scan.limit).map(entry => ({ key: structuredClone(entry.key), value: structuredClone(entry.value) as Value }));
        },
      };
      try {
        const value = structuredClone(await run(transaction));
        active = false;
        const statements: Statement[] = [];
        for (const [collection, changes] of rowChanges) for (const [sort, row] of changes) {
          const previous = await baselineRow(collection, sort);
          if ((!row && !previous) || (row && previous?.json === row.json)) continue;
          statements.push(rowStatement(collection, sort, row));
        }
        for (const [name, changes] of internalChanges) for (const [sort, entry] of changes) {
          if (entry) statements.push({ sql: `INSERT INTO ${table(name)} (stream_id, sort_key, key_json, value_json) VALUES (?, ?, ?, ?) ON CONFLICT (stream_id, sort_key) DO UPDATE SET key_json = excluded.key_json, value_json = excluded.value_json`, values: [streamId, sort, canonicalizeJson(entry.key), entry.json] });
          else {
            const exists = await all<{ sort_key: string }>(`SELECT sort_key FROM ${table(name)} WHERE stream_id = ? AND sort_key = ? LIMIT 1`, [streamId, sort]);
            if (exists.length) statements.push({ sql: `DELETE FROM ${table(name)} WHERE stream_id = ? AND sort_key = ?`, values: [streamId, sort] });
          }
        }
        const current = await readState();
        if (!current || current.revision !== revision) throw new SyncError("commit-conflict", "The D1 stream changed while building its read plan.");
        if (!statements.length) return { revision, value };
        assertSequence(revision + 1, "D1 revision", 1);
        try {
          await batch([guard(revision), ...statements, { sql: `UPDATE ${table("streams")} SET revision = revision + 1 WHERE stream_id = ?`, values: [streamId] }]);
        } catch (cause) {
          if (cause instanceof SyncError && cause.code === "limit-exceeded") throw cause;
          const after = await readState();
          if (!after || after.revision !== revision) throw new SyncError("commit-conflict", "The D1 guarded commit lost a revision race.", { cause });
          throw new SyncError("corrupt-state", "The D1 atomic commit failed.", { cause });
        }
        return { revision: revision + 1, value };
      } catch (cause) {
        active = false;
        // Mixed reads can make a pure policy report an otherwise misleading
        // error. Reclassify when a primary revision changed during the callback.
        if (!(cause instanceof SyncError && (cause.code === "commit-conflict" || cause.code === "limit-exceeded"))) {
          const after = await readState();
          if (!after || after.revision !== revision) throw new SyncError("commit-conflict", "The D1 stream changed during its transaction plan.", { cause });
        }
        throw cause;
      } finally { active = false; }
    },
  };
}
