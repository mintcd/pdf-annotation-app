import { SyncError } from "../../core/errors.js";
import { canonicalizeJson } from "../../core/fingerprint.js";
import { assertIdentifier, assertSequence } from "../../core/validation.js";
import { compareRecordKeys, compareScanRange, encodeRecordKey, validateRecordKey, validateScan } from "../../records/keys.js";
import { OrderedIndex } from "../../records/ordered.js";
import { collectionDefinition, defineRecordSchema, normalizeRecord, schemaIdentity } from "../../records/schema.js";
import type { CollectionName, CollectionRow, InternalRecord, InternalScan, MemoryRecordDatabase, MemoryRecordDatabaseOptions, RecordArea, RecordCursor, RecordInternalTable, RecordKey, RecordPage, RecordQuery, RecordSchema, RecordStoreMetrics, RecordTransaction, RecordWrite } from "../../records/types.js";

interface IndexEntry { key: RecordKey; primaryKey: RecordKey; token: string }
interface StoredRow { key: RecordKey; row: unknown; encoded: string; keys: Map<string, RecordKey> }
interface RowTable { rows: Map<string, StoredRow>; indexes: Map<string, OrderedIndex<IndexEntry>> }
interface ValueTable { rows: Map<string, InternalRecord<unknown>>; index: OrderedIndex<InternalRecord<unknown>> }
const internalNames: readonly RecordInternalTable[] = ["meta", "canonical", "identities", "positions", "decisions", "accepted", "outbox", "pending", "resolutions"];
const compareEntries = (a: IndexEntry, b: IndexEntry): number => compareRecordKeys(a.key, b.key) || compareRecordKeys(a.primaryKey, b.primaryKey);
const compareValues = (a: InternalRecord<unknown>, b: InternalRecord<unknown>): number => compareRecordKeys(a.key, b.key);

function* merge<Value>(base: Iterable<Value>, staged: Iterable<Value>, compare: (a: Value, b: Value) => number, direction: "asc" | "desc"): Generator<Value> {
  const first = base[Symbol.iterator]();
  const second = staged[Symbol.iterator]();
  let a = first.next();
  let b = second.next();
  while (!a.done || !b.done) {
    if (b.done || (!a.done && (direction === "asc" ? compare(a.value, b.value) <= 0 : compare(a.value, b.value) >= 0))) {
      yield a.value as Value;
      a = first.next();
    } else {
      yield b.value as Value;
      b = second.next();
    }
  }
}

export function createMemoryRecordDatabase<Schema extends RecordSchema>(options: MemoryRecordDatabaseOptions<Schema>): MemoryRecordDatabase<Schema> {
  assertIdentifier(options.streamId, "streamId");
  const streamId = options.streamId;
  const schema = defineRecordSchema(options.schema) as Schema;
  const schemaId = schemaIdentity(schema);
  const areas = new Map<RecordArea, Map<string, RowTable>>();
  for (const area of ["confirmed", "visible"] as const) {
    areas.set(area, new Map(Object.keys(schema.collections).map(collection => [collection, {
      rows: new Map<string, StoredRow>(), indexes: new Map(["", ...Object.keys(schema.collections[collection]!.indexes ?? {})].map(name => [name, new OrderedIndex(compareEntries)])),
    }])));
  }
  const internals = new Map(internalNames.map(name => [name, { rows: new Map<string, InternalRecord<unknown>>(), index: new OrderedIndex(compareValues) }]));
  let revision = 0;
  let queue: Promise<unknown> = Promise.resolve();
  const emptyMetrics = (): RecordStoreMetrics => ({ rowReads: 0, rowWrites: 0, indexEntriesVisited: 0, internalReads: 0, internalWrites: 0, internalEntriesVisited: 0 });
  let metrics = emptyMetrics();
  function count(name: keyof RecordStoreMetrics, amount = 1): void { metrics = { ...metrics, [name]: metrics[name] + amount }; }
  function rowTable(area: RecordArea, collection: string): RowTable {
    const table = areas.get(area)?.get(collection);
    if (!table) throw new SyncError("invalid-input", "Unknown record area or collection.");
    return table;
  }
  function valueTable(name: RecordInternalTable): ValueTable {
    const table = internals.get(name);
    if (!table) throw new SyncError("invalid-input", "Unknown internal record table.");
    return table;
  }
  function makeRow(collection: string, input: unknown): StoredRow {
    const definition = collectionDefinition(schema, collection);
    const row = normalizeRecord(schema, collection, input as CollectionRow<Schema, CollectionName<Schema>>);
    const key = structuredClone(definition.key(structuredClone(row)));
    const keys = new Map<string, RecordKey>([["", key]]);
    for (const [name, index] of Object.entries(definition.indexes ?? {})) {
      const indexKey = index.key(structuredClone(row));
      if (indexKey !== undefined) keys.set(name, structuredClone(indexKey));
    }
    return { key, row, encoded: canonicalizeJson(definition.codec.encode(structuredClone(row))), keys };
  }
  function replaceRow(table: RowTable, token: string, row: StoredRow | undefined): void {
    const previous = table.rows.get(token);
    if (previous) for (const [name, key] of previous.keys) table.indexes.get(name)!.delete({ key, primaryKey: previous.key, token });
    if (row) {
      table.rows.set(token, row);
      for (const [name, key] of row.keys) table.indexes.get(name)!.put({ key, primaryKey: row.key, token });
    } else table.rows.delete(token);
  }
  for (const write of options.initialRows ?? []) {
    if (write.type !== "put" && write.type !== "delete") throw new SyncError("invalid-input", "Unknown initial row write.");
    const row = write.type === "put" ? makeRow(write.collection, write.row) : undefined;
    const key = row?.key ?? (write.type === "delete" ? write.key : []);
    validateRecordKey(key);
    for (const area of ["confirmed", "visible"] as const) replaceRow(rowTable(area, write.collection), encodeRecordKey(key), row ? structuredClone(row) : undefined);
  }

  return {
    streamId, schema,
    metrics: () => ({ ...metrics }),
    resetMetrics: () => { metrics = emptyMetrics(); },
    async transaction<Value>(mode: "readonly" | "readwrite", run: (transaction: RecordTransaction<Schema>) => Value | Promise<Value>, configuration?: { readonly expectedRevision?: number }) {
      const expectedRevision = configuration?.expectedRevision;
      if (mode !== "readonly" && mode !== "readwrite") throw new SyncError("invalid-input", "Invalid transaction mode.");
      if (expectedRevision !== undefined) assertSequence(expectedRevision, "expectedRevision");
      const job = queue.then(async () => {
        if (expectedRevision !== undefined && expectedRevision !== revision) throw new SyncError("commit-conflict", "The record database revision changed.");
        const transactionRevision = revision;
        let active = true;
        const rowChanges = new Map<RowTable, Map<string, StoredRow | undefined>>();
        const internalChanges = new Map<ValueTable, Map<string, InternalRecord<unknown> | undefined>>();
        function check(write = false): void {
          if (!active) throw new SyncError("closed", "Record transaction is no longer active.");
          if (write && mode !== "readwrite") throw new SyncError("invalid-input", "A readonly transaction cannot write.");
        }
        function currentRow(table: RowTable, token: string): StoredRow | undefined {
          const changes = rowChanges.get(table);
          return changes?.has(token) ? changes.get(token) : table.rows.get(token);
        }
        function currentValue(table: ValueTable, token: string): InternalRecord<unknown> | undefined {
          const changes = internalChanges.get(table);
          return changes?.has(token) ? changes.get(token) : table.rows.get(token);
        }
        const transaction: RecordTransaction<Schema> = {
          revision: transactionRevision, schema,
          async get(area, collection, key) {
            check(); validateRecordKey(key); count("rowReads");
            return structuredClone(currentRow(rowTable(area, collection), encodeRecordKey(key))?.row) as CollectionRow<Schema, typeof collection> | undefined;
          },
          async query(area, query) {
            check();
            const allowed = ["collection", "index", "prefix", "lower", "upper", "direction", "limit", "cursor"];
            if (!query || typeof query !== "object" || Object.keys(query).some(key => !allowed.includes(key))) throw new SyncError("invalid-input", "Unsupported record query fields.");
            validateScan(query, 256);
            const table = rowTable(area, query.collection);
            const indexName = query.index ?? "";
            const index = table.indexes.get(indexName);
            if (!index || (query.index !== undefined && indexName === "")) throw new SyncError("invalid-input", "Unknown declared index.");
            const direction = query.direction ?? "asc";
            const queryIdentity = canonicalizeJson({ schema: schemaId, area, collection: query.collection, index: indexName, prefix: query.prefix ?? [], lower: query.lower ?? null, upper: query.upper ?? null, direction });
            const cursor = query.cursor;
            if (cursor !== undefined) {
              canonicalizeJson(cursor);
              validateRecordKey(cursor.indexKey); validateRecordKey(cursor.primaryKey);
              assertSequence(cursor.revision, "cursor.revision");
              if (cursor.version !== 1 || cursor.streamId !== streamId || cursor.schemaVersion !== schema.version || cursor.queryIdentity !== queryIdentity || cursor.revision > transactionRevision || compareScanRange(cursor.indexKey, query) !== 0) throw new SyncError("invalid-cursor", "Cursor does not match this query, schema, stream, or revision.");
            }
            const match = (entry: IndexEntry): number => {
              const comparison = compareScanRange(entry.key, query);
              if (comparison !== 0) return comparison;
              if (!cursor) return 0;
              const order = compareRecordKeys(entry.key, cursor.indexKey) || compareRecordKeys(entry.primaryKey, cursor.primaryKey);
              return direction === "asc" ? (order <= 0 ? -1 : 0) : (order >= 0 ? 1 : 0);
            };
            const changes = rowChanges.get(table);
            const staged = new OrderedIndex(compareEntries);
            for (const [token, row] of changes ?? []) {
              const key = row?.keys.get(indexName);
              if (row && key) staged.put({ key, primaryKey: row.key, token });
            }
            function* baseline(): Generator<IndexEntry> {
              for (const entry of index!.range(match, direction)) {
                count("indexEntriesVisited");
                if (!changes?.has(entry.token)) yield entry;
              }
            }
            const candidates: IndexEntry[] = [];
            for (const entry of merge(baseline(), staged.range(match, direction), compareEntries, direction)) {
              candidates.push(entry);
              if (candidates.length > query.limit) break;
            }
            const pageEntries = candidates.slice(0, query.limit);
            const rows = pageEntries.map(entry => { count("rowReads"); return structuredClone(currentRow(table, entry.token)!.row); });
            const last = pageEntries.at(-1);
            const nextCursor: RecordCursor | undefined = candidates.length > query.limit && last ? {
              version: 1, schemaVersion: schema.version, streamId, queryIdentity, revision: transactionRevision,
              indexKey: structuredClone(last.key), primaryKey: structuredClone(last.primaryKey),
            } : undefined;
            return { rows, revision: transactionRevision, ...(nextCursor ? { nextCursor } : {}) } as RecordPage<CollectionRow<Schema, typeof query.collection>>;
          },
          async apply(area, writes) {
            check(true);
            const validated = writes.map(write => {
              if (write.type !== "put" && write.type !== "delete") throw new SyncError("invalid-input", "Unknown row write kind.");
              const table = rowTable(area, write.collection);
              const row = write.type === "put" ? makeRow(write.collection, write.row) : undefined;
              const key = row?.key ?? (write.type === "delete" ? write.key : []);
              validateRecordKey(key);
              return { table, token: encodeRecordKey(key), row };
            });
            for (const { table, token, row } of validated) {
              let changes = rowChanges.get(table);
              if (!changes) { changes = new Map(); rowChanges.set(table, changes); }
              changes.set(token, row);
            }
          },
          async getInternal<Value>(name: RecordInternalTable, key: RecordKey): Promise<Value | undefined> {
            check(); validateRecordKey(key); count("internalReads");
            return structuredClone(currentValue(valueTable(name), encodeRecordKey(key))?.value) as Value | undefined;
          },
          async putInternal<Value>(name: RecordInternalTable, key: RecordKey, value: Value): Promise<void> {
            check(true); validateRecordKey(key);
            const entry = { key: structuredClone(key), value: structuredClone(value) };
            const table = valueTable(name);
            let changes = internalChanges.get(table);
            if (!changes) { changes = new Map(); internalChanges.set(table, changes); }
            changes.set(encodeRecordKey(key), entry);
          },
          async deleteInternal(name, key) {
            check(true); validateRecordKey(key);
            const table = valueTable(name);
            let changes = internalChanges.get(table);
            if (!changes) { changes = new Map(); internalChanges.set(table, changes); }
            changes.set(encodeRecordKey(key), undefined);
          },
          async scanInternal<Value>(name: RecordInternalTable, scan: InternalScan): Promise<readonly InternalRecord<Value>[]> {
            check(); validateScan(scan);
            const table = valueTable(name);
            const changes = internalChanges.get(table);
            const staged = new OrderedIndex(compareValues);
            for (const entry of changes?.values() ?? []) if (entry) staged.put(entry);
            const match = (entry: InternalRecord<unknown>): number => compareScanRange(entry.key, scan);
            const direction = scan.direction ?? "asc";
            function* baseline(): Generator<InternalRecord<unknown>> {
              for (const entry of table.index.range(match, direction)) {
                count("internalEntriesVisited");
                if (!changes?.has(encodeRecordKey(entry.key))) yield entry;
              }
            }
            const values: InternalRecord<Value>[] = [];
            for (const entry of merge(baseline(), staged.range(match, direction), compareValues, direction)) {
              values.push(structuredClone(entry) as InternalRecord<Value>);
              if (values.length === scan.limit) break;
            }
            return values;
          },
        };
        try {
          const value = structuredClone(await run(transaction));
          const changedRows: { table: RowTable; token: string; row: StoredRow | undefined }[] = [];
          for (const [table, changes] of rowChanges) for (const [token, row] of changes) {
            const old = table.rows.get(token);
            if (!row && !old) continue;
            if (row && old && row.encoded === old.encoded) continue;
            changedRows.push({ table, token, row });
          }
          const changedValues: { table: ValueTable; token: string; value: InternalRecord<unknown> | undefined }[] = [];
          for (const [table, changes] of internalChanges) for (const [token, entry] of changes) {
            if (!entry && !table.rows.has(token)) continue;
            changedValues.push({ table, token, value: entry });
          }
          if (changedRows.length > 0 || changedValues.length > 0) {
            assertSequence(revision + 1, "record revision", 1);
            for (const change of changedRows) replaceRow(change.table, change.token, change.row);
            for (const { table, token, value: entry } of changedValues) {
              const previous = table.rows.get(token);
              if (previous) table.index.delete(previous);
              if (entry) { table.rows.set(token, entry); table.index.put(entry); } else table.rows.delete(token);
            }
            revision++;
            count("rowWrites", changedRows.length); count("internalWrites", changedValues.length);
          }
          return { revision, value };
        } finally { active = false; }
      });
      queue = job.then(() => undefined, () => undefined);
      return job;
    },
  };
}
