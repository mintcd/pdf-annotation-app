import { SyncError } from "../../core/errors.js";
import { cloneCodecValue } from "../../core/codecs.js";
import { createIntentHash } from "../../core/fingerprint.js";
import { encodeSyncRequest, resolveProtocolLimits } from "../../core/protocol.js";
import {
  acknowledgeResolutions, createReplicaState, enqueueReplicaOperation, prepareSyncRequest, reconcileSyncResponse,
} from "../../core/replica.js";
import type {
  DomainModel, EnqueueInput, OperationIdentity, PrepareSyncOptions, ProtocolLimits, ReplicaStore, SyncResponse,
} from "../../core/types.js";

export interface CreateMemoryReplicaStoreOptions<State, Intent, Operation, Rejection> {
  readonly streamId: string;
  readonly clientId: string;
  readonly initialState: State;
  readonly model: DomainModel<State, Intent, Operation, Rejection>;
  readonly limits?: Partial<ProtocolLimits>;
}

/**
 * Reference native store: synchronous transitions commit against current state.
 * State and domain payloads must preserve their semantics through structuredClone.
 */
export function createMemoryReplicaStore<State, Intent, Operation, Rejection>(
  options: CreateMemoryReplicaStoreOptions<State, Intent, Operation, Rejection>,
): ReplicaStore<State, Intent, Operation, Rejection> {
  const model = options.model;
  const limits = resolveProtocolLimits(options.limits);
  let state = createReplicaState(options);
  let closed = false;
  const assertOpen = (): void => {
    if (closed) throw new SyncError("closed", "Replica store is closed.");
  };
  return {
    async read() {
      assertOpen();
      return structuredClone(state);
    },
    async enqueue(input: EnqueueInput<Intent>): Promise<OperationIdentity> {
      assertOpen();
      const captured = structuredClone(input);
      // Neither a codec nor an awaiting caller can mutate what will be committed.
      let encodedIntent;
      let normalizedIntent: Intent;
      try {
        normalizedIntent = cloneCodecValue(model.intent, captured.intent, "intent");
        encodedIntent = model.intent.encode(structuredClone(normalizedIntent));
      } catch (cause) {
        throw new SyncError("invalid-input", "Cannot encode or decode intent.", { cause });
      }
      const intentHash = await createIntentHash(encodedIntent);
      assertOpen();
      // Read state only after hashing: a reconciliation/enqueue may have committed meanwhile.
      const next = enqueueReplicaOperation(state, { operationId: captured.operationId, intent: normalizedIntent, intentHash }, model);
      const proposal = next.outbox[next.outbox.length - 1]?.proposal;
      if (!proposal) throw new SyncError("corrupt-state", "Enqueue did not produce an outbox entry.");
      // A standalone fingerprint can fit JSON limits while its protocol wrapper does not.
      // Check this particular proposal, even when older work fills the first request batch.
      encodeSyncRequest({ protocolVersion: 1, contractVersion: next.contractVersion, streamId: next.streamId,
        baseSequence: next.confirmedSequence, maximumEntries: limits.maximumEntries,
        proposals: [structuredClone(proposal)] }, model, { streamId: next.streamId, limits });
      state = next;
      return { operationId: proposal.operationId, clientId: proposal.clientId,
        clientSequence: proposal.clientSequence, intentHash: proposal.intentHash };
    },
    async prepareSyncRequest(syncOptions: PrepareSyncOptions = {}) {
      assertOpen();
      return prepareSyncRequest(state, syncOptions, limits);
    },
    async reconcile(response: SyncResponse<Operation, Rejection>) {
      assertOpen();
      const next = reconcileSyncResponse(state, response, model, { limits });
      state = next;
      return structuredClone(state);
    },
    async readResolutions() {
      assertOpen();
      return structuredClone(state.resolutions);
    },
    async acknowledgeResolutions(operationIds: readonly string[]) {
      assertOpen();
      state = acknowledgeResolutions(state, operationIds);
    },
    async close() {
      closed = true;
    },
  };
}
