import { openRecordReplica } from "../../records/replica.js";
import type { ProtocolLimits } from "../../core/types.js";
import type { RecordDomainModel, RecordReplica, RecordSchema, RecordWrite } from "../../records/types.js";
import { createMemoryRecordDatabase } from "./records.js";

export interface CreateMemoryRecordReplicaOptions<Schema extends RecordSchema, Intent, Operation, Rejection> {
  readonly streamId: string;
  readonly clientId: string;
  readonly model: RecordDomainModel<Schema, Intent, Operation, Rejection>;
  readonly initialRows?: readonly RecordWrite<Schema>[];
  readonly limits?: Partial<ProtocolLimits>;
}

export function createMemoryRecordReplica<Schema extends RecordSchema, Intent, Operation, Rejection>(
  options: CreateMemoryRecordReplicaOptions<Schema, Intent, Operation, Rejection>,
): Promise<RecordReplica<Schema, Intent, Operation, Rejection>> {
  const database = createMemoryRecordDatabase({ streamId: options.streamId, schema: options.model.schema,
    ...(options.initialRows ? { initialRows: options.initialRows } : {}) });
  return openRecordReplica({ database, clientId: options.clientId, model: options.model,
    ...(options.limits ? { limits: options.limits } : {}) });
}
