import { SyncError } from "../../core/errors.js";
import { canonicalizeJson } from "../../core/fingerprint.js";
import { cloneCodecValue } from "../../core/codecs.js";
import { assertIdentifier, assertIdentity, assertSameIdentity, assertSequence, clientPositionKey } from "../../core/validation.js";
import type { AuthorityStore, Codec, CommittedOperation, Decision } from "../../core/types.js";

export interface MemoryAuthorityStoreOptions<State, Operation, Rejection> {
  readonly streamId: string;
  readonly initialState: State;
  readonly operation: Codec<Operation>;
  readonly rejection: Codec<Rejection>;
}

function cloneState<State>(state: State): State {
  try {
    return structuredClone(state);
  } catch (cause) {
    throw new SyncError("invalid-input", "Authority state must support structuredClone.", { cause });
  }
}

function cloneValue<Value>(codec: Codec<Value>, value: Value, label: string): Value {
  return cloneCodecValue(codec, value, label);
}

/** In-memory contract reference. Every returned value is detached from retained data. */
export function createMemoryAuthorityStore<State, Operation, Rejection>(
  options: MemoryAuthorityStoreOptions<State, Operation, Rejection>,
): AuthorityStore<State, Operation, Rejection> {
  assertIdentifier(options.streamId, "streamId");
  const streamId = options.streamId;
  const operationCodec = options.operation;
  const rejectionCodec = options.rejection;
  let state = cloneState(options.initialState);
  let revision = 0;
  const entries: CommittedOperation<Operation>[] = [];
  const decisionsByOperation = new Map<string, Decision<Operation, Rejection>>();
  const decisionsByPosition = new Map<string, Decision<Operation, Rejection>>();

  function cloneEntry(entry: CommittedOperation<Operation>): CommittedOperation<Operation> {
    assertIdentity(entry);
    assertSequence(entry.sequence, "canonical sequence", 1);
    return {
      operationId: entry.operationId, clientId: entry.clientId, clientSequence: entry.clientSequence,
      intentHash: entry.intentHash, sequence: entry.sequence,
      operation: cloneValue(operationCodec, entry.operation, "canonical operation"),
    };
  }

  function cloneDecision(decision: Decision<Operation, Rejection>): Decision<Operation, Rejection> {
    assertIdentity(decision);
    if (decision.status === "accepted") return { ...cloneEntry(decision), status: "accepted" };
    if (decision.status === "rejected") {
      return {
        operationId: decision.operationId, clientId: decision.clientId, clientSequence: decision.clientSequence,
        intentHash: decision.intentHash, status: "rejected",
        reason: cloneValue(rejectionCodec, decision.reason, "rejection reason"),
      };
    }
    throw new SyncError("invalid-input", "Invalid decision status.");
  }

  return {
    streamId,
    async read(query) {
      assertSequence(query.baseSequence, "baseSequence");
      assertSequence(query.maximumEntries, "maximumEntries", 1);
      if (query.baseSequence > entries.length) throw new SyncError("invalid-cursor", "The requested base is beyond the authority head.");
      const matching = new Map<string, Decision<Operation, Rejection>>();
      for (const identity of query.identities) {
        assertIdentity(identity);
        const byOperation = decisionsByOperation.get(identity.operationId);
        const byPosition = decisionsByPosition.get(clientPositionKey(identity));
        if (byOperation !== undefined) matching.set(byOperation.operationId, byOperation);
        if (byPosition !== undefined) matching.set(byPosition.operationId, byPosition);
      }
      return {
        revision, headSequence: entries.length, state: cloneState(state),
        entries: entries.slice(query.baseSequence, query.baseSequence + query.maximumEntries).map(cloneEntry),
        decisions: [...matching.values()].map(cloneDecision),
      };
    },
    async compareAndCommit(plan) {
      assertSequence(plan.expectedRevision, "expectedRevision");
      if (plan.expectedRevision !== revision) return { status: "conflict" };

      // All validation and cloning finish before the first retained value changes.
      const nextState = cloneState(plan.state);
      const stagedEntries = plan.entries.map(cloneEntry);
      const stagedDecisions = plan.decisions.map(cloneDecision);
      if (stagedDecisions.length === 0) throw new SyncError("invalid-input", "An authority commit must bind at least one decision.");
      const stagedByOperation = new Map<string, Decision<Operation, Rejection>>();
      const stagedByPosition = new Map<string, Decision<Operation, Rejection>>();
      for (const decision of stagedDecisions) {
        const position = clientPositionKey(decision);
        if (decisionsByOperation.has(decision.operationId) || decisionsByPosition.has(position) || stagedByOperation.has(decision.operationId) || stagedByPosition.has(position)) {
          throw new SyncError("identity-conflict", "An authority commit would reuse a bound identity.");
        }
        stagedByOperation.set(decision.operationId, decision);
        stagedByPosition.set(position, decision);
      }
      const matched = new Set<string>();
      for (const [index, entry] of stagedEntries.entries()) {
        if (entry.sequence !== entries.length + index + 1) throw new SyncError("invalid-input", "Canonical entries must append a contiguous sequence.");
        const decision = stagedByOperation.get(entry.operationId);
        if (decision === undefined || decision.status !== "accepted") throw new SyncError("invalid-input", "Each canonical entry requires its accepted decision.");
        assertSameIdentity(entry, decision);
        if (decision.sequence !== entry.sequence || canonicalizeJson(operationCodec.encode(decision.operation)) !== canonicalizeJson(operationCodec.encode(entry.operation))) {
          throw new SyncError("invalid-input", "A canonical entry differs from its accepted decision.");
        }
        if (matched.has(entry.operationId)) throw new SyncError("invalid-input", "A canonical operation appears more than once.");
        matched.add(entry.operationId);
      }
      if (stagedDecisions.some((decision) => decision.status === "accepted" && !matched.has(decision.operationId))) {
        throw new SyncError("invalid-input", "Each accepted decision requires its canonical entry.");
      }
      const nextRevision = revision + 1;
      assertSequence(nextRevision, "authority revision", 1);

      // No await occurs between revision comparison and this all-or-nothing mutation.
      state = nextState;
      for (const entry of stagedEntries) entries.push(entry);
      for (const decision of stagedDecisions) {
        decisionsByOperation.set(decision.operationId, decision);
        decisionsByPosition.set(clientPositionKey(decision), decision);
      }
      revision = nextRevision;
      return { status: "committed", revision };
    },
  };
}
