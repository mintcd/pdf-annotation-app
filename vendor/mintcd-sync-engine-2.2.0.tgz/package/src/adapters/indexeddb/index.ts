import { SyncError } from "../../core/errors.js";
import { canonicalizeJson } from "../../core/fingerprint.js";
import { assertIdentifier, assertSequence } from "../../core/validation.js";
import { compareRecordKeys, compareScanRange, encodeRecordKey, validateRecordKey, validateScan } from "../../records/keys.js";
import { collectionDefinition, defineRecordSchema, normalizeRecord, schemaIdentity } from "../../records/schema.js";
import type { CollectionName, CollectionRow, InternalRecord, InternalScan, RecordArea, RecordCursor, RecordDatabase, RecordInternalTable, RecordKey, RecordPage, RecordSchema, RecordTransaction, RecordWrite } from "../../records/types.js";

export interface IndexedDbCommitChannel {
  postMessage(message: unknown): void;
  addEventListener(type: "message", listener: (event: MessageEvent<unknown>) => void): void;
  removeEventListener(type: "message", listener: (event: MessageEvent<unknown>) => void): void;
  close(): void;
}

export interface OpenIndexedDbRecordDatabaseOptions<Schema extends RecordSchema> {
  readonly name: string;
  readonly streamId: string;
  readonly schema: Schema;
  /** Native database version. Upgrades currently require the same declared schema. */
  readonly version?: number;
  readonly indexedDB?: IDBFactory;
  /** Supply together with an injected factory outside a browser. */
  readonly keyRange?: typeof IDBKeyRange;
  readonly initialRows?: readonly RecordWrite<Schema>[];
  /** Recovery opens must not recreate an evicted database or missing stream. */
  readonly requireExisting?: boolean;
  readonly durability?: IDBTransactionDurability;
  readonly onBlocked?: () => void;
  /** Notifications contain revision hints only; consumers reread committed data. */
  readonly broadcastChannel?: false | ((name: string) => IndexedDbCommitChannel);
}

export interface IndexedDbRecordDatabase<Schema extends RecordSchema> extends RecordDatabase<Schema> {
  /** Existing transactions may finish; later transactions reject with `closed`. */
  close(): void;
  /** Close this connection and wait for its already-started native transactions. */
  closeAndDrain(): Promise<void>;
  subscribe(listener: (revision: number) => void): () => void;
}

interface StoredRow {
  streamId: string;
  key: RecordKey;
  row: unknown;
  encoded: string;
  indexes: Record<string, RecordKey>;
}
interface StoredValue { streamId: string; key: RecordKey; value: unknown }
interface StreamMetadata { schemaIdentity: string; revision: number }
interface Bound { key: IDBValidKey; open: boolean }
const metadataStore = "__sync_metadata";
const schemaKey = ["schema"];
const internalNames: readonly RecordInternalTable[] = ["meta", "canonical", "identities", "positions", "decisions", "accepted", "outbox", "pending", "resolutions"];
const rowStoreName = (area: RecordArea, collection: string): string => `row:${area}:${collection}`;
const internalStoreName = (table: RecordInternalTable): string => `internal:${table}`;
const compareRows = (left: { key: RecordKey; row: StoredRow }, right: { key: RecordKey; row: StoredRow }): number => compareRecordKeys(left.key, right.key) || compareRecordKeys(left.row.key, right.row.key);

function request<Value>(native: IDBRequest<Value>): Promise<Value> {
  return new Promise((resolve, reject) => {
    native.onsuccess = () => resolve(native.result);
    native.onerror = () => reject(native.error ?? new SyncError("corrupt-state", "IndexedDB request failed."));
  });
}

function completion(native: IDBTransaction): { done: Promise<void>; finished: () => boolean } {
  let finished = false;
  const done = new Promise<void>((resolve, reject) => {
    native.oncomplete = () => { finished = true; resolve(); };
    native.onabort = () => { finished = true; reject(native.error ?? new SyncError("closed", "IndexedDB transaction was aborted.")); };
  });
  // An abort can precede the callback rejecting; observe it immediately.
  void done.catch(() => undefined);
  return { done, finished: () => finished };
}

function abort(native: IDBTransaction): void {
  try { native.abort(); } catch { /* Already completed or aborted. */ }
}

/**
 * Rows, indexes and protocol bookkeeping share one native transaction. Callback
 * writes stay staged until it returns; awaiting unrelated asynchronous work is
 * unsupported and fails if the browser has already ended the transaction.
 */
export async function openIndexedDbRecordDatabase<Schema extends RecordSchema>(options: OpenIndexedDbRecordDatabaseOptions<Schema>): Promise<IndexedDbRecordDatabase<Schema>> {
  assertIdentifier(options.name, "database name");
  assertIdentifier(options.streamId, "streamId");
  const name = options.name;
  const streamId = options.streamId;
  const schema = defineRecordSchema(options.schema) as Schema;
  const schemaId = schemaIdentity(schema);
  const version = options.version ?? 1;
  const requireExisting = options.requireExisting ?? false;
  if (typeof requireExisting !== "boolean") throw new SyncError("invalid-input", "requireExisting must be a boolean.");
  assertSequence(version, "IndexedDB version", 1);
  const factory = options.indexedDB ?? globalThis.indexedDB;
  const keyRange = options.keyRange ?? globalThis.IDBKeyRange;
  if (!factory || !keyRange) throw new SyncError("invalid-input", "IndexedDB and IDBKeyRange are required in this environment.");
  if (options.durability !== undefined && !["default", "strict", "relaxed"].includes(options.durability)) throw new SyncError("invalid-input", "Invalid IndexedDB durability.");
  const indexNames = new Map(Object.entries(schema.collections).map(([collection, definition]) => [collection, Object.keys(definition.indexes ?? {}).sort()]));
  const stores = [metadataStore, ...Object.keys(schema.collections).flatMap(collection => [rowStoreName("confirmed", collection), rowStoreName("visible", collection)]), ...internalNames.map(internalStoreName)];
  const streamKey = ["stream", streamId];
  function makeRow(collection: string, value: unknown): StoredRow {
    const definition = collectionDefinition(schema, collection);
    const row = normalizeRecord(schema, collection, value as CollectionRow<Schema, CollectionName<Schema>>);
    const key = structuredClone(definition.key(structuredClone(row)));
    const indexes: Record<string, RecordKey> = {};
    for (const [position, indexName] of indexNames.get(collection)!.entries()) {
      const extracted = definition.indexes![indexName]!.key(structuredClone(row));
      if (extracted !== undefined) indexes[`i${position}`] = structuredClone(extracted);
    }
    return { streamId, key, row, encoded: canonicalizeJson(definition.codec.encode(structuredClone(row))), indexes };
  }
  function validateWrite(area: RecordArea, write: RecordWrite<Schema>): { store: string; key: RecordKey; row: StoredRow | undefined } {
    if (area !== "confirmed" && area !== "visible") throw new SyncError("invalid-input", "Unknown record area.");
    collectionDefinition(schema, write.collection);
    if (write.type !== "put" && write.type !== "delete") throw new SyncError("invalid-input", "Unknown row write kind.");
    const row = write.type === "put" ? makeRow(write.collection, write.row) : undefined;
    const key = row?.key ?? (write.type === "delete" ? write.key : []);
    validateRecordKey(key);
    return { store: rowStoreName(area, write.collection), key: structuredClone(key), row };
  }
  const initial = (options.initialRows ?? []).map(write => validateWrite("confirmed", write));

  let upgradeError: unknown;
  const native = await new Promise<IDBDatabase>((resolve, reject) => {
    const opening = factory.open(name, version);
    let rejected = false;
    opening.onblocked = () => {
      try { options.onBlocked?.(); } catch (error) { rejected = true; reject(error); abort(opening.transaction!); }
    };
    opening.onupgradeneeded = event => {
      if (rejected) { abort(opening.transaction!); return; }
      try {
        const database = opening.result;
        const transaction = opening.transaction!;
        if (event.oldVersion === 0) {
          if (requireExisting) throw new SyncError("corrupt-state", "The local replica database is missing; explicit bootstrap is required.");
          database.createObjectStore(metadataStore).put({ format: "record-indexeddb-v1", schemaIdentity: schemaId }, schemaKey);
          for (const collection of Object.keys(schema.collections)) for (const area of ["confirmed", "visible"] as const) {
            const store = database.createObjectStore(rowStoreName(area, collection), { keyPath: ["streamId", "key"] });
            for (const [position, indexName] of indexNames.get(collection)!.entries()) store.createIndex(indexName, ["streamId", `indexes.i${position}`, "key"], { unique: false });
          }
          for (const table of internalNames) database.createObjectStore(internalStoreName(table), { keyPath: ["streamId", "key"] });
        } else {
          if (!database.objectStoreNames.contains(metadataStore)) throw new SyncError("contract-mismatch", "This database was not created by the record adapter.");
          const checking = transaction.objectStore(metadataStore).get(schemaKey);
          checking.onsuccess = () => {
            const stored = checking.result as { format?: string; schemaIdentity?: string } | undefined;
            if (stored?.format !== "record-indexeddb-v1" || stored.schemaIdentity !== schemaId) {
              upgradeError = new SyncError("contract-mismatch", "IndexedDB schema changes require an explicit migration; automatic upgrades preserve the existing schema.");
              abort(transaction);
            }
          };
        }
      } catch (error) { upgradeError = error; abort(opening.transaction!); }
    };
    opening.onsuccess = () => { if (rejected) opening.result.close(); else resolve(opening.result); };
    opening.onerror = () => reject(upgradeError ?? opening.error ?? new SyncError("corrupt-state", "Could not open IndexedDB."));
  });
  let closed = false;
  let channel: IndexedDbCommitChannel | undefined;
  const listeners = new Set<(revision: number) => void>();
  const nativeTransactions = new Set<Promise<void>>();
  function close(): void {
    if (closed) return;
    closed = true;
    native.close();
    channel?.close();
    listeners.clear();
  }
  native.onversionchange = close;
  native.onclose = close;
  function begin(mode: "readonly" | "readwrite"): IDBTransaction {
    if (closed) throw new SyncError("closed", "IndexedDB connection is closed.");
    const transaction = native.transaction(stores, mode, options.durability === undefined ? undefined : { durability: options.durability });
    let finish!: () => void;
    const pending = new Promise<void>(resolve => { finish = resolve; });
    nativeTransactions.add(pending);
    const settled = () => { nativeTransactions.delete(pending); finish(); };
    transaction.addEventListener("complete", settled, { once: true });
    transaction.addEventListener("abort", settled, { once: true });
    return transaction;
  }
  try {
    for (const store of stores) if (!native.objectStoreNames.contains(store)) throw new SyncError("contract-mismatch", "IndexedDB is missing a declared record store.");
    const initializing = begin("readwrite");
    const initialized = completion(initializing);
    try {
      const metadata = initializing.objectStore(metadataStore);
      const storedSchema = await request(metadata.get(schemaKey)) as { format?: string; schemaIdentity?: string } | undefined;
      if (storedSchema?.format !== "record-indexeddb-v1" || storedSchema.schemaIdentity !== schemaId) throw new SyncError("contract-mismatch", "IndexedDB schema does not match the requested schema.");
      for (const collection of Object.keys(schema.collections)) for (const area of ["confirmed", "visible"] as const) {
        const store = initializing.objectStore(rowStoreName(area, collection));
        for (const indexName of indexNames.get(collection)!) if (!store.indexNames.contains(indexName)) throw new SyncError("contract-mismatch", "IndexedDB is missing a declared record index.");
      }
      const existing = await request(metadata.get(streamKey)) as StreamMetadata | undefined;
      if (existing === undefined) {
        if (requireExisting) throw new SyncError("corrupt-state", "The local replica stream is missing; explicit bootstrap is required.");
        for (const item of initial) for (const area of ["confirmed", "visible"] as const) {
          const store = initializing.objectStore(item.store.replace("row:confirmed:", `row:${area}:`));
          if (item.row) await request(store.put(item.row)); else await request(store.delete([streamId, item.key as IDBValidKey]));
        }
        await request(metadata.put({ schemaIdentity: schemaId, revision: 0 }, streamKey));
      } else {
        if (existing.schemaIdentity !== schemaId) throw new SyncError("contract-mismatch", "Stream schema does not match the requested schema.");
        assertSequence(existing.revision, "stored record revision");
      }
      await initialized.done;
    } catch (error) { abort(initializing); await initialized.done.catch(() => undefined); throw error; }
    if (closed) throw new SyncError("closed", "IndexedDB connection closed while it was opening.");
    const channelFactory = options.broadcastChannel === false ? undefined : options.broadcastChannel ?? (typeof globalThis.BroadcastChannel === "function" ? (channelName: string) => new BroadcastChannel(channelName) : undefined);
    if (channelFactory) {
      channel = channelFactory(`sync-engine:indexeddb:${canonicalizeJson([name, streamId, schemaId])}`);
      channel.addEventListener("message", event => {
        const value = event.data as { revision?: unknown } | null;
        if (!closed && value && typeof value.revision === "number" && Number.isSafeInteger(value.revision) && value.revision >= 0) notify(value.revision);
      });
    }
  } catch (error) { close(); throw error; }

  function notify(revision: number): void {
    for (const listener of listeners) { try { listener(revision); } catch { /* Observers cannot undo a committed transaction. */ } }
  }
  function internalStore(table: RecordInternalTable): string {
    if (!internalNames.includes(table)) throw new SyncError("invalid-input", "Unknown internal record table.");
    return internalStoreName(table);
  }
  /** User keys contain only numbers/strings, so nested arrays are internal upper sentinels. */
  function range(scan: InternalScan, secondary: boolean, cursor?: RecordCursor): IDBKeyRange | null {
    let lower: Bound = { key: [streamId], open: false };
    let upper: Bound = { key: [streamId, [[]]], open: true };
    const setLower = (candidate: Bound): void => { const order = factory.cmp(candidate.key, lower.key); if (order > 0 || (order === 0 && candidate.open)) lower = candidate; };
    const setUpper = (candidate: Bound): void => { const order = factory.cmp(candidate.key, upper.key); if (order < 0 || (order === 0 && candidate.open)) upper = candidate; };
    if (scan.prefix?.length) {
      setLower({ key: [streamId, scan.prefix as IDBValidKey], open: false });
      setUpper({ key: [streamId, [...scan.prefix, []]], open: true });
    }
    if (scan.lower) setLower({ key: secondary && scan.lower.inclusive === false ? [streamId, scan.lower.key as IDBValidKey, [[]]] : [streamId, scan.lower.key as IDBValidKey], open: !secondary && scan.lower.inclusive === false });
    if (scan.upper) setUpper({ key: secondary && scan.upper.inclusive !== false ? [streamId, scan.upper.key as IDBValidKey, [[]]] : [streamId, scan.upper.key as IDBValidKey], open: scan.upper.inclusive === false });
    if (cursor) {
      const bound = { key: secondary ? [streamId, cursor.indexKey as IDBValidKey, cursor.primaryKey as IDBValidKey] : [streamId, cursor.indexKey as IDBValidKey], open: true };
      if (scan.direction === "desc") setUpper(bound); else setLower(bound);
    }
    const comparison = factory.cmp(lower.key, upper.key);
    if (comparison > 0 || (comparison === 0 && (lower.open || upper.open))) return null;
    return keyRange.bound(lower.key, upper.key, lower.open, upper.open);
  }
  function readCursor<Value>(source: IDBObjectStore | IDBIndex, bounds: IDBKeyRange | null, direction: "asc" | "desc", limit: number, include: (value: Value) => boolean): Promise<Value[]> {
    if (!bounds) return Promise.resolve([]);
    return new Promise((resolve, reject) => {
      const values: Value[] = [];
      const cursorRequest = source.openCursor(bounds, direction === "asc" ? "next" : "prev");
      cursorRequest.onerror = () => reject(cursorRequest.error);
      cursorRequest.onsuccess = () => {
        const cursor = cursorRequest.result;
        if (!cursor) { resolve(values); return; }
        const value = cursor.value as Value;
        if (include(value)) values.push(value);
        if (values.length >= limit) resolve(values); else cursor.continue();
      };
    });
  }
  return {
    streamId, schema, close,
    async closeAndDrain() { close(); await Promise.all([...nativeTransactions]); },
    subscribe(listener) {
      if (closed) throw new SyncError("closed", "IndexedDB connection is closed.");
      if (typeof listener !== "function") throw new SyncError("invalid-input", "A commit listener must be a function.");
      listeners.add(listener);
      return () => listeners.delete(listener);
    },
    async transaction<Value>(mode: "readonly" | "readwrite", run: (transaction: RecordTransaction<Schema>) => Value | Promise<Value>, configuration?: { readonly expectedRevision?: number }) {
      if (mode !== "readonly" && mode !== "readwrite") throw new SyncError("invalid-input", "Invalid transaction mode.");
      const expectedRevision = configuration?.expectedRevision;
      if (expectedRevision !== undefined) assertSequence(expectedRevision, "expectedRevision");
      const transaction = begin(mode);
      const completed = completion(transaction);
      let active = true;
      let changed = false;
      let revision = 0;
      const rowChanges = new Map<string, Map<string, { key: RecordKey; row: StoredRow | undefined }>>();
      const internalChanges = new Map<string, Map<string, { key: RecordKey; entry: StoredValue | undefined }>>();
      function check(write = false): void {
        if (!active || completed.finished()) throw new SyncError("closed", "Record transaction is no longer active; await only storage requests in its callback.");
        if (write && mode !== "readwrite") throw new SyncError("invalid-input", "A readonly transaction cannot write.");
      }
      function rowStore(area: RecordArea, collection: string): string {
        if (area !== "confirmed" && area !== "visible") throw new SyncError("invalid-input", "Unknown record area.");
        collectionDefinition(schema, collection);
        return rowStoreName(area, collection);
      }
      try {
        const storedMetadata = await request(transaction.objectStore(metadataStore).get(streamKey)) as StreamMetadata | undefined;
        if (!storedMetadata || storedMetadata.schemaIdentity !== schemaId) throw new SyncError("corrupt-state", "Missing or mismatched record database metadata.");
        assertSequence(storedMetadata.revision, "stored record revision");
        revision = storedMetadata.revision;
        if (expectedRevision !== undefined && expectedRevision !== revision) throw new SyncError("commit-conflict", "The record database revision changed.");
        const portable: RecordTransaction<Schema> = {
          revision, schema,
          async get(area, collection, key) {
            check(); validateRecordKey(key);
            const store = rowStore(area, collection);
            const staged = rowChanges.get(store)?.get(encodeRecordKey(key));
            const row = staged ? staged.row : await request(transaction.objectStore(store).get([streamId, key as IDBValidKey])) as StoredRow | undefined;
            return structuredClone(row?.row) as CollectionRow<Schema, typeof collection> | undefined;
          },
          async query(area, query) {
            check();
            const allowed = ["collection", "index", "prefix", "lower", "upper", "direction", "limit", "cursor"];
            if (!query || typeof query !== "object" || Object.keys(query).some(key => !allowed.includes(key))) throw new SyncError("invalid-input", "Unsupported record query fields.");
            validateScan(query, 256);
            const storeName = rowStore(area, query.collection);
            const declared = indexNames.get(query.collection)!;
            const indexName = query.index ?? "";
            const indexPosition = declared.indexOf(indexName);
            if (query.index !== undefined && indexPosition < 0) throw new SyncError("invalid-input", "Unknown declared index.");
            const secondary = query.index !== undefined;
            const direction = query.direction ?? "asc";
            const queryIdentity = canonicalizeJson({ schema: schemaId, area, collection: query.collection, index: indexName, prefix: query.prefix ?? [], lower: query.lower ?? null, upper: query.upper ?? null, direction });
            const cursor = query.cursor;
            if (cursor !== undefined) {
              canonicalizeJson(cursor); validateRecordKey(cursor.indexKey); validateRecordKey(cursor.primaryKey); assertSequence(cursor.revision, "cursor.revision");
              if (cursor.version !== 1 || cursor.streamId !== streamId || cursor.schemaVersion !== schema.version || cursor.queryIdentity !== queryIdentity || cursor.revision > revision || compareScanRange(cursor.indexKey, query) !== 0) throw new SyncError("invalid-cursor", "Cursor does not match this query, schema, stream, or revision.");
            }
            const indexKey = (row: StoredRow): RecordKey | undefined => secondary ? row.indexes[`i${indexPosition}`] : row.key;
            const matches = (row: StoredRow): boolean => {
              const key = indexKey(row);
              if (!key || compareScanRange(key, query) !== 0) return false;
              if (!cursor) return true;
              const order = compareRecordKeys(key, cursor.indexKey) || compareRecordKeys(row.key, cursor.primaryKey);
              return direction === "asc" ? order > 0 : order < 0;
            };
            const staged = rowChanges.get(storeName);
            const store = transaction.objectStore(storeName);
            const baseline = await readCursor<StoredRow>(secondary ? store.index(indexName) : store, range(query, secondary, cursor), direction, query.limit + 1, row => !staged?.has(encodeRecordKey(row.key)) && matches(row));
            const candidates = [...baseline, ...[...(staged?.values() ?? [])].flatMap(change => change.row && matches(change.row) ? [change.row] : [])].map(row => ({ key: indexKey(row)!, row }));
            candidates.sort((left, right) => (direction === "asc" ? 1 : -1) * compareRows(left, right));
            const page = candidates.slice(0, query.limit);
            const last = page.at(-1);
            const nextCursor: RecordCursor | undefined = candidates.length > query.limit && last ? { version: 1, schemaVersion: schema.version, streamId, queryIdentity, revision, indexKey: structuredClone(last.key), primaryKey: structuredClone(last.row.key) } : undefined;
            return { rows: page.map(entry => structuredClone(entry.row.row)), revision, ...(nextCursor ? { nextCursor } : {}) } as RecordPage<CollectionRow<Schema, typeof query.collection>>;
          },
          async apply(area, writes) {
            check(true);
            const validated = writes.map(write => validateWrite(area, write));
            for (const { store, key, row } of validated) {
              let changes = rowChanges.get(store);
              if (!changes) { changes = new Map(); rowChanges.set(store, changes); }
              changes.set(encodeRecordKey(key), { key, row });
            }
          },
          async getInternal<Value>(table: RecordInternalTable, key: RecordKey): Promise<Value | undefined> {
            check(); validateRecordKey(key);
            const store = internalStore(table);
            const staged = internalChanges.get(store)?.get(encodeRecordKey(key));
            const entry = staged ? staged.entry : await request(transaction.objectStore(store).get([streamId, key as IDBValidKey])) as StoredValue | undefined;
            return structuredClone(entry?.value) as Value | undefined;
          },
          async putInternal(table, key, value) {
            check(true); validateRecordKey(key);
            const store = internalStore(table);
            const copied = structuredClone({ streamId, key, value });
            let changes = internalChanges.get(store);
            if (!changes) { changes = new Map(); internalChanges.set(store, changes); }
            changes.set(encodeRecordKey(key), { key: copied.key, entry: copied });
          },
          async deleteInternal(table, key) {
            check(true); validateRecordKey(key);
            const store = internalStore(table);
            let changes = internalChanges.get(store);
            if (!changes) { changes = new Map(); internalChanges.set(store, changes); }
            changes.set(encodeRecordKey(key), { key: structuredClone(key), entry: undefined });
          },
          async scanInternal<Value>(table: RecordInternalTable, scan: InternalScan): Promise<readonly InternalRecord<Value>[]> {
            check(); validateScan(scan);
            const store = internalStore(table);
            const changes = internalChanges.get(store);
            const direction = scan.direction ?? "asc";
            const baseline = await readCursor<StoredValue>(transaction.objectStore(store), range(scan, false), direction, scan.limit, entry => !changes?.has(encodeRecordKey(entry.key)) && compareScanRange(entry.key, scan) === 0);
            const values = [...baseline, ...[...(changes?.values() ?? [])].flatMap(change => change.entry && compareScanRange(change.entry.key, scan) === 0 ? [change.entry] : [])];
            values.sort((left, right) => (direction === "asc" ? 1 : -1) * compareRecordKeys(left.key, right.key));
            return values.slice(0, scan.limit).map(entry => ({ key: structuredClone(entry.key), value: structuredClone(entry.value) as Value }));
          },
        };
        const value = structuredClone(await run(portable));
        check();
        for (const [storeName, changes] of rowChanges) for (const { key, row } of changes.values()) {
          const store = transaction.objectStore(storeName);
          const previous = await request(store.get([streamId, key as IDBValidKey])) as StoredRow | undefined;
          if ((!row && !previous) || (row && previous && row.encoded === previous.encoded)) continue;
          if (row) await request(store.put(row)); else await request(store.delete([streamId, key as IDBValidKey]));
          changed = true;
        }
        for (const [storeName, changes] of internalChanges) for (const { key, entry } of changes.values()) {
          const store = transaction.objectStore(storeName);
          if (entry) { await request(store.put(entry)); changed = true; }
          else if (await request(store.count([streamId, key as IDBValidKey])) > 0) { await request(store.delete([streamId, key as IDBValidKey])); changed = true; }
        }
        if (changed) {
          assertSequence(revision + 1, "record revision", 1);
          revision++;
          await request(transaction.objectStore(metadataStore).put({ schemaIdentity: schemaId, revision }, streamKey));
        }
        active = false;
        await completed.done;
        if (changed && !closed) {
          notify(revision);
          try { channel?.postMessage({ revision }); } catch { /* Persistence remains successful if a notification channel fails. */ }
        }
        return { revision, value };
      } catch (error) {
        active = false;
        abort(transaction);
        await completed.done.catch(() => undefined);
        throw error;
      }
    },
  };
}
