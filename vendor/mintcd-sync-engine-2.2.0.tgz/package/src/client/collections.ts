import { SyncError } from "../core/errors.js";
import type { OperationIdentity } from "../core/types.js";
import { validateRecordKey, validateScan } from "../records/keys.js";
import type { CollectionIndexName, CollectionName, CollectionRow, RecordBound, RecordCursor, RecordKey, RecordPage, RecordQuery, RecordReplicaStatus, RecordSchema } from "../records/types.js";

export type CollectionPredicateOperator = "eq" | "gt" | "gte" | "lt" | "lte";
export type CollectionField<Row> = keyof Row & string;

/** Field tuples describe the exact keys extracted by the corresponding record schema. */
export interface SyncCollectionDefinition<Row, Intent> {
  readonly primaryKey?: readonly string[];
  readonly indexes?: Readonly<Record<string, readonly string[]>>;
  /** Indexed fields whose absent/null values omit a row from the index. */
  readonly sparseIndexes?: Readonly<Record<string, readonly string[]>>;
  readonly mutations?: {
    insert(row: Row): Intent;
    update(key: RecordKey, changes: Partial<Row>): Intent;
    delete(key: RecordKey): Intent;
  };
}
export type SyncCollectionDefinitions<Schema extends RecordSchema, Intent> = {
  // Bindings retain their own exact row/key/patch types. Using an erased row
  // constraint lets application-generic factories compose a still-generic schema.
  readonly [Name in CollectionName<Schema>]?: SyncCollectionDefinition<unknown, Intent>;
};
export type CollectionQueryPage<Row> = RecordPage<Row> & { readonly status: RecordReplicaStatus };

/** Immutable, bounded local queries. Predicates must describe one declared index interval. */
export interface SyncCollectionQuery<Schema extends RecordSchema, Name extends CollectionName<Schema>, Selected extends CollectionField<CollectionRow<Schema, Name>> = CollectionField<CollectionRow<Schema, Name>>> {
  /** Project decoded local rows; this does not change the adapter's storage reads. */
  select<const Fields extends readonly [CollectionField<CollectionRow<Schema, Name>>, ...CollectionField<CollectionRow<Schema, Name>>[]]>(...fields: Fields): SyncCollectionQuery<Schema, Name, Fields[number]>;
  where<Field extends CollectionField<CollectionRow<Schema, Name>>>(field: Field, operator: CollectionPredicateOperator, value: CollectionRow<Schema, Name>[Field] & (string | number)): SyncCollectionQuery<Schema, Name, Selected>;
  /** Select a declared secondary index explicitly. */
  index(index: CollectionIndexName<Schema, Name>): SyncCollectionQuery<Schema, Name, Selected>;
  /** Raw index bounds cannot be combined with field predicates. */
  prefix(key: RecordKey): SyncCollectionQuery<Schema, Name, Selected>;
  lower(key: RecordKey, inclusive?: boolean): SyncCollectionQuery<Schema, Name, Selected>;
  upper(key: RecordKey, inclusive?: boolean): SyncCollectionQuery<Schema, Name, Selected>;
  order(direction: "asc" | "desc"): SyncCollectionQuery<Schema, Name, Selected>;
  limit(limit: number): SyncCollectionQuery<Schema, Name, Selected>;
  /** Keyset continuation; each page reports its own current revision. */
  cursor(cursor: RecordCursor): SyncCollectionQuery<Schema, Name, Selected>;
  execute(): Promise<CollectionQueryPage<Pick<CollectionRow<Schema, Name>, Selected>>>;
}
type MutationOptions = { readonly operationId?: string };
type CollectionMutations<Definition> = Definition extends { readonly mutations: infer Mutations }
  ? Mutations extends { insert: (...args: infer Insert) => unknown; update: (...args: infer Update) => unknown; delete: (...args: infer Delete) => unknown }
    ? {
      insert(row: Insert[0], options?: MutationOptions): Promise<OperationIdentity>;
      update(key: Update[0], changes: Update[1], options?: MutationOptions): Promise<OperationIdentity>;
      delete(key: Delete[0], options?: MutationOptions): Promise<OperationIdentity>;
    } : unknown
  : unknown;
type DefinitionFor<Definitions, Name extends PropertyKey> = Name extends keyof Definitions ? Definitions[Name] : undefined;
type KeyFor<Definition> = Definition extends { readonly mutations: { delete: (...args: infer Args) => unknown } } ? Args[0] : RecordKey;
export type SyncCollection<Schema extends RecordSchema, Name extends CollectionName<Schema>, Definitions = undefined> =
  SyncCollectionQuery<Schema, Name> & {
    get(key: KeyFor<DefinitionFor<Definitions, Name>>): Promise<{ readonly row: CollectionRow<Schema, Name> | undefined; readonly status: RecordReplicaStatus }>;
  } & CollectionMutations<DefinitionFor<Definitions, Name>>;

interface CollectionEngine<Schema extends RecordSchema, Intent> {
  get<Name extends CollectionName<Schema>>(collection: Name, key: RecordKey): Promise<{ readonly row: CollectionRow<Schema, Name> | undefined; readonly status: RecordReplicaStatus }>;
  query<Name extends CollectionName<Schema>>(query: RecordQuery<Schema, Name>): Promise<CollectionQueryPage<CollectionRow<Schema, Name>>>;
  mutate(intent: Intent, options?: MutationOptions): Promise<OperationIdentity>;
}
interface Predicate { readonly field: string; readonly operator: CollectionPredicateOperator; readonly value: number | string }
interface QueryState {
  readonly fields?: readonly string[];
  readonly predicates: readonly Predicate[];
  readonly index?: string;
  readonly prefix?: RecordKey;
  readonly lower?: RecordBound;
  readonly upper?: RecordBound;
  readonly direction?: "asc" | "desc";
  readonly limit: number;
  readonly cursor?: RecordCursor;
}
interface NormalizedDefinition<Intent> {
  readonly primaryKey?: readonly string[];
  readonly indexes: Readonly<Record<string, readonly string[]>>;
  readonly sparseIndexes: Readonly<Record<string, readonly string[]>>;
  readonly mutations?: SyncCollectionDefinition<unknown, Intent>["mutations"];
}
function invalid(message: string): never { throw new SyncError("invalid-input", message); }
function fieldTuple(value: readonly string[]): readonly string[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > 32 || value.some(field => typeof field !== "string" || !field) || new Set(value).size !== value.length) invalid("Collection index metadata needs 1 to 32 distinct field names.");
  return Object.freeze([...value]);
}
function normalizeDefinitions<Schema extends RecordSchema, Intent>(definitions: SyncCollectionDefinitions<Schema, Intent> | undefined): ReadonlyMap<string, NormalizedDefinition<Intent>> {
  const normalized = new Map<string, NormalizedDefinition<Intent>>();
  for (const [name, input] of Object.entries(definitions ?? {})) {
    if (!input || typeof input !== "object") invalid("Invalid collection query metadata.");
    const definition = input as SyncCollectionDefinition<unknown, Intent>;
    const indexes = Object.fromEntries(Object.entries(definition.indexes ?? {}).map(([index, fields]) => [index, fieldTuple(fields)]));
    const sparseIndexes = Object.fromEntries(Object.entries(definition.sparseIndexes ?? {}).map(([index, fields]) => {
      const sparse = fieldTuple(fields);
      if (!Object.hasOwn(indexes, index) || sparse.some(field => !indexes[index]!.includes(field))) invalid("Sparse index metadata must reference fields of a declared index.");
      return [index, sparse];
    }));
    if (definition.mutations && [definition.mutations.insert, definition.mutations.update, definition.mutations.delete].some(method => typeof method !== "function")) invalid("Collection mutations need insert, update and delete intent builders.");
    normalized.set(name, Object.freeze({
      ...(definition.primaryKey === undefined ? {} : { primaryKey: fieldTuple(definition.primaryKey) }),
      indexes: Object.freeze(indexes),
      sparseIndexes: Object.freeze(sparseIndexes),
      ...(definition.mutations === undefined ? {} : { mutations: {
        insert: definition.mutations.insert.bind(definition.mutations),
        update: definition.mutations.update.bind(definition.mutations),
        delete: definition.mutations.delete.bind(definition.mutations),
      } }),
    }));
  }
  return normalized;
}
function plannedBounds(fields: readonly string[], predicates: readonly Predicate[]): { readonly prefix?: RecordKey; readonly lower?: RecordBound; readonly upper?: RecordBound } | undefined {
  const prefix: (string | number)[] = [];
  let used = 0;
  for (let index = 0; index < fields.length; index++) {
    const conditions = predicates.filter(predicate => predicate.field === fields[index]);
    if (!conditions.length) break;
    const equality = conditions.filter(predicate => predicate.operator === "eq");
    if (equality.length) {
      if (conditions.length !== 1) return undefined;
      prefix.push(equality[0]!.value); used++;
      continue;
    }
    // Portable tuples have no infinity sentinel. Ranging a nonfinal component
    // would incorrectly include/exclude equal prefixes with trailing components.
    if (index !== fields.length - 1) return undefined;
    const lower = conditions.filter(predicate => predicate.operator === "gt" || predicate.operator === "gte");
    const upper = conditions.filter(predicate => predicate.operator === "lt" || predicate.operator === "lte");
    if (lower.length > 1 || upper.length > 1) return undefined;
    used += conditions.length;
    if (used !== predicates.length) return undefined;
    return {
      ...(prefix.length ? { prefix } : {}),
      ...(lower.length ? { lower: { key: [...prefix, lower[0]!.value], inclusive: lower[0]!.operator === "gte" } } : {}),
      ...(upper.length ? { upper: { key: [...prefix, upper[0]!.value], inclusive: upper[0]!.operator === "lte" } } : {}),
    };
  }
  return used === predicates.length ? { prefix } : undefined;
}
function plan(state: QueryState, definition: NormalizedDefinition<unknown> | undefined): { readonly index?: string; readonly prefix?: RecordKey; readonly lower?: RecordBound; readonly upper?: RecordBound } {
  if (!state.predicates.length) return {
    ...(state.index === undefined ? {} : { index: state.index }),
    ...(state.prefix === undefined ? {} : { prefix: state.prefix }),
    ...(state.lower === undefined ? {} : { lower: state.lower }),
    ...(state.upper === undefined ? {} : { upper: state.upper }),
  };
  if (state.prefix !== undefined || state.lower !== undefined || state.upper !== undefined) invalid("Field predicates cannot be combined with raw index bounds.");
  const candidates: { readonly index?: string; readonly fields: readonly string[] }[] = [];
  if (state.index !== undefined) {
    const fields = definition && Object.hasOwn(definition.indexes, state.index) ? definition.indexes[state.index] : undefined;
    if (fields) candidates.push({ index: state.index, fields });
  } else {
    if (definition?.primaryKey) candidates.push({ fields: definition.primaryKey });
    for (const [index, fields] of Object.entries(definition?.indexes ?? {})) candidates.push({ index, fields });
  }
  // Prefer the shortest matching index; declaration order breaks remaining ties.
  candidates.sort((left, right) => left.fields.length - right.fields.length);
  for (const candidate of candidates) {
    const sparse = candidate.index !== undefined && definition && Object.hasOwn(definition.sparseIndexes, candidate.index) ? definition.sparseIndexes[candidate.index] : undefined;
    if (sparse?.some(field => !state.predicates.some(predicate => predicate.field === field))) continue;
    const bounds = plannedBounds(candidate.fields, state.predicates);
    if (bounds) return { ...(candidate.index === undefined ? {} : { index: candidate.index }), ...bounds };
  }
  invalid("The predicates do not match a declared index interval. Declare field metadata and a matching index, or use index() with explicit prefix/lower/upper bounds. Queries never fall back to an unbounded filter scan.");
}

/** Internal composition helper; resolves the final facade for lifecycle-safe writes. */
export function createCollectionAccess<Schema extends RecordSchema, Intent, Definitions extends SyncCollectionDefinitions<Schema, Intent> | undefined>(
  getEngine: () => CollectionEngine<Schema, Intent>, definitions: Definitions | undefined,
): <Name extends CollectionName<Schema>>(collection: Name) => SyncCollection<Schema, Name, Definitions> {
  const normalized = normalizeDefinitions(definitions);
  return function from<Name extends CollectionName<Schema>>(collection: Name): SyncCollection<Schema, Name, Definitions> {
    const definition = normalized.get(collection);
    function query(state: QueryState): SyncCollectionQuery<Schema, Name> {
      const next = (change: Partial<QueryState>) => query({ ...state, ...change });
      return {
        select(...fields) {
          if (!fields.length || fields.some(field => typeof field !== "string" || !field)) invalid("select() needs at least one field name.");
          return next({ fields: Object.freeze([...fields]) }) as never;
        },
        where(field, operator, value) {
          if (typeof field !== "string" || !field || !["eq", "gt", "gte", "lt", "lte"].includes(operator) || (typeof value !== "string" && (typeof value !== "number" || !Number.isFinite(value)))) invalid("where() needs a field, a supported comparison and a finite number or string.");
          return next({ predicates: [...state.predicates, { field, operator, value }] });
        },
        index(index) { if (typeof index !== "string" || !index) invalid("index() needs a declared index name."); return next({ index }); },
        prefix(key) { validateRecordKey(key, true); return next({ prefix: structuredClone(key) }); },
        lower(key, inclusive = true) { validateRecordKey(key); if (typeof inclusive !== "boolean") invalid("Bound inclusion must be a boolean."); return next({ lower: { key: structuredClone(key), inclusive } }); },
        upper(key, inclusive = true) { validateRecordKey(key); if (typeof inclusive !== "boolean") invalid("Bound inclusion must be a boolean."); return next({ upper: { key: structuredClone(key), inclusive } }); },
        order(direction) { if (direction !== "asc" && direction !== "desc") invalid("Query order must be asc or desc."); return next({ direction }); },
        limit(limit) { validateScan({ limit }); return next({ limit }); },
        cursor(cursor) { return next({ cursor: structuredClone(cursor) }); },
        async execute() {
          const input = { collection, ...plan(state, definition), ...(state.direction === undefined ? {} : { direction: state.direction }), limit: state.limit, ...(state.cursor === undefined ? {} : { cursor: state.cursor }) } as RecordQuery<Schema, Name>;
          const page = await getEngine().query(input);
          if (!state.fields) return page;
          return { ...page, rows: page.rows.map(row => Object.fromEntries(state.fields!.map(field => [field, (row as Record<string, unknown>)[field]])) as CollectionRow<Schema, Name>) };
        },
      };
    }
    const result = {
      ...query({ predicates: [], limit: 50 }),
      get(key: RecordKey) { return getEngine().get(collection, key); },
      ...(definition?.mutations === undefined ? {} : {
        async insert(row: unknown, options?: MutationOptions) { return getEngine().mutate(definition.mutations!.insert(row), options); },
        async update(key: RecordKey, changes: Partial<unknown>, options?: MutationOptions) { return getEngine().mutate(definition.mutations!.update(key, changes), options); },
        async delete(key: RecordKey, options?: MutationOptions) { return getEngine().mutate(definition.mutations!.delete(key), options); },
      }),
    };
    return result as SyncCollection<Schema, Name, Definitions>;
  };
}
