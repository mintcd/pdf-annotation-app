import { SyncError } from "../core/errors.js";
import type { PrepareSyncOptions, SyncRequest } from "../core/types.js";
import type { RecordReplicaStatus, RecordSchema } from "../records/types.js";
import { SyncTransportError } from "./errors.js";
import { createCollectionAccess } from "./collections.js";
import type { SyncCollectionDefinitions } from "./collections.js";
import type { CreateSyncEngineOptions, SyncEngine, SyncEnginePhase, SyncEngineSnapshot, SyncOptions, SyncResult, SyncRunOptions } from "./types.js";

interface Settings {
  readonly maximumRounds: number;
  readonly maximumDurationMs: number;
  readonly requestTimeoutMs: number;
  readonly maximumRetries: number;
  readonly initialDelayMs: number;
  readonly maximumDelayMs: number;
  readonly jitterRatio: number;
  readonly prepare: PrepareSyncOptions;
}
interface Run {
  readonly controller: AbortController;
  readonly settings: Settings;
  promise: Promise<SyncResult>;
  waiters: number;
  rescan: boolean;
  followup: boolean;
  rounds: number;
  attempts: number;
  retries: number;
}
class TimeBudget extends Error {}

function integer(value: unknown, fallback: number, label: string, minimum = 1): number {
  const result = value === undefined ? fallback : value;
  if (typeof result !== "number" || !Number.isSafeInteger(result) || result < minimum || result > 2_147_483_647) {
    throw new SyncError("invalid-input", `${label} must be an integer between ${minimum} and 2147483647.`);
  }
  return result;
}
function settings(base: SyncRunOptions | undefined, override?: SyncRunOptions): Settings {
  const retry = { ...base?.retry, ...override?.retry };
  const initialDelayMs = integer(retry.initialDelayMs, 100, "initialDelayMs", 0);
  const maximumDelayMs = integer(retry.maximumDelayMs, 2_000, "maximumDelayMs", 0);
  if (maximumDelayMs < initialDelayMs) throw new SyncError("invalid-input", "maximumDelayMs must be at least initialDelayMs.");
  const jitterRatio = retry.jitterRatio ?? 0.2;
  if (typeof jitterRatio !== "number" || !Number.isFinite(jitterRatio) || jitterRatio < 0 || jitterRatio > 1) throw new SyncError("invalid-input", "jitterRatio must be between zero and one.");
  const maximumProposals = override?.maximumProposals ?? base?.maximumProposals;
  const maximumEntries = override?.maximumEntries ?? base?.maximumEntries;
  if (maximumProposals !== undefined) integer(maximumProposals, 64, "maximumProposals", 0);
  if (maximumEntries !== undefined) integer(maximumEntries, 256, "maximumEntries");
  return {
    maximumRounds: integer(override?.maximumRounds ?? base?.maximumRounds, 16, "maximumRounds"),
    maximumDurationMs: integer(override?.maximumDurationMs ?? base?.maximumDurationMs, 30_000, "maximumDurationMs"),
    requestTimeoutMs: integer(override?.requestTimeoutMs ?? base?.requestTimeoutMs, 10_000, "requestTimeoutMs"),
    maximumRetries: integer(retry.maximumRetries, 3, "maximumRetries", 0), initialDelayMs, maximumDelayMs, jitterRatio,
    prepare: { ...(maximumProposals === undefined ? {} : { maximumProposals }), ...(maximumEntries === undefined ? {} : { maximumEntries }) },
  };
}
function aborted(): SyncTransportError { return new SyncTransportError("aborted", "Synchronization was cancelled."); }
function abortReason(signal: AbortSignal): unknown { return signal.reason ?? aborted(); }
function raceAbort<Value>(work: Promise<Value>, signal: AbortSignal): Promise<Value> {
  if (signal.aborted) { void work.catch(() => undefined); return Promise.reject(abortReason(signal)); }
  return new Promise((resolve, reject) => {
    const cancel = () => { signal.removeEventListener("abort", cancel); reject(abortReason(signal)); };
    signal.addEventListener("abort", cancel, { once: true });
    work.then(value => { signal.removeEventListener("abort", cancel); resolve(value); }, error => { signal.removeEventListener("abort", cancel); reject(error); });
  });
}
function delay(duration: number, signal: AbortSignal): Promise<void> {
  if (signal.aborted) return Promise.reject(abortReason(signal));
  return new Promise((resolve, reject) => {
    const cancel = () => { clearTimeout(timer); reject(abortReason(signal)); };
    const timer = setTimeout(() => { signal.removeEventListener("abort", cancel); resolve(); }, Math.min(duration, 2_147_483_647));
    signal.addEventListener("abort", cancel, { once: true });
  });
}
function remaining(status: RecordReplicaStatus): boolean {
  return status.pendingCount > 0 || status.acceptedAwaitingCount > 0 || status.confirmedSequence < status.headSequence;
}
function retryable(error: unknown): boolean {
  return (error instanceof SyncError || error instanceof SyncTransportError) && error.retryable;
}

/** A portable coordinator: all semantic pending work stays in the supplied replica. */
export async function createSyncEngine<Schema extends RecordSchema, Intent, Operation, Rejection, Collections extends SyncCollectionDefinitions<Schema, Intent> | undefined = undefined>(
  options: CreateSyncEngineOptions<Schema, Intent, Operation, Rejection, Collections>,
): Promise<SyncEngine<Schema, Intent, Operation, Rejection, Collections>> {
  const baseSyncOptions = options.syncOptions === undefined ? undefined : structuredClone(options.syncOptions);
  const defaults = settings(baseSyncOptions);
  const { replica, transport } = options;
  if (typeof options.autoSync !== "undefined" && typeof options.autoSync !== "boolean") throw new SyncError("invalid-input", "autoSync must be a boolean.");
  let snapshot: SyncEngineSnapshot = Object.freeze({ replica: Object.freeze({ ...await replica.status() }), phase: "idle" });
  let closed = false;
  let active: Run | undefined;
  let closePromise: Promise<void> | undefined;
  let unsubscribeChanges: (() => void) | undefined;
  let automaticScheduled = false;
  let refreshing = false;
  let refreshAgain = false;
  let lastFailedRevision = -1;
  const listeners = new Set<(snapshot: SyncEngineSnapshot) => void>();

  function assertOpen(): void { if (closed) throw new SyncError("closed", "The sync engine is closed."); }
  function publish(phase: SyncEnginePhase = snapshot.phase, error: unknown = snapshot.lastError, clearError = false): void {
    snapshot = Object.freeze({ replica: snapshot.replica, phase, ...(clearError || error === undefined ? {} : { lastError: error }) });
    for (const listener of listeners) { try { listener(snapshot); } catch { /* Observers cannot invalidate a committed write. */ } }
  }
  function observe(status: RecordReplicaStatus): void {
    if (closed || status.revision < snapshot.replica.revision) return;
    if (status.revision === snapshot.replica.revision) return;
    const newAllocation = status.nextClientSequence > snapshot.replica.nextClientSequence;
    snapshot = Object.freeze({ ...snapshot, replica: Object.freeze({ ...status }) });
    publish();
    // Reconciliation itself advances the revision. A newly allocated local
    // identity is a scheduling trigger; old pending work keeps its run budget.
    if (newAllocation && status.revision > lastFailedRevision && remaining(status)) scheduleAutomatic(true);
  }
  async function refresh(): Promise<RecordReplicaStatus> {
    assertOpen();
    const status = await replica.status();
    observe(status);
    return status;
  }
  function report(error: unknown): void {
    if (closed) return;
    lastFailedRevision = snapshot.replica.revision;
    publish("error", error);
  }
  function scheduleAutomatic(newWork = false): void {
    if (!options.autoSync || closed || automaticScheduled) return;
    if (active) { active.rescan = true; if (newWork) active.followup = true; return; }
    automaticScheduled = true;
    queueMicrotask(() => {
      automaticScheduled = false;
      if (!closed) void synchronize().catch(() => undefined);
    });
  }
  async function refreshNotification(): Promise<void> {
    if (closed) return;
    if (refreshing) { refreshAgain = true; return; }
    refreshing = true;
    try {
      do {
        refreshAgain = false;
        await refresh();
      } while (refreshAgain && !closed);
    } catch (error) { report(error); }
    finally { refreshing = false; }
  }
  function result(run: Run, reason: SyncResult["reason"]): SyncResult {
    return Object.freeze({ status: snapshot.replica, rounds: run.rounds, attempts: run.attempts, retries: run.retries, reason });
  }
  async function exchange(request: SyncRequest<Intent>, run: Run): Promise<Awaited<ReturnType<typeof transport.exchange>>> {
    const controller = new AbortController();
    const cancel = () => controller.abort(abortReason(run.controller.signal));
    run.controller.signal.addEventListener("abort", cancel, { once: true });
    if (run.controller.signal.aborted) cancel();
    const timer = setTimeout(() => controller.abort(new SyncTransportError("timeout", "The sync request timed out.")), run.settings.requestTimeoutMs);
    try {
      return await raceAbort(Promise.resolve().then(() => {
        if (controller.signal.aborted) throw abortReason(controller.signal);
        return transport.exchange(request, { signal: controller.signal });
      }), controller.signal);
    } finally {
      clearTimeout(timer);
      run.controller.signal.removeEventListener("abort", cancel);
    }
  }
  async function execute(run: Run): Promise<SyncResult> {
    const signal = run.controller.signal;
    const timer = setTimeout(() => run.controller.abort(new TimeBudget()), run.settings.maximumDurationMs);
    try {
      if (signal.aborted) throw abortReason(signal);
      publish("syncing", undefined, true);
      for (; run.rounds < run.settings.maximumRounds;) {
        if (signal.aborted) throw abortReason(signal);
        run.rescan = false;
        run.followup = false;
        const request = await raceAbort(replica.prepareSyncRequest(run.settings.prepare), signal);
        const before = snapshot.replica;
        run.rounds++;
        let response: Awaited<ReturnType<typeof transport.exchange>>;
        for (;;) {
          if (signal.aborted) throw abortReason(signal);
          try {
            run.attempts++;
            response = await exchange(request, run);
            if (signal.aborted) throw abortReason(signal);
            const committed = await raceAbort(replica.reconcile(response), signal);
            observe(committed.status);
            break;
          } catch (error) {
            if (signal.aborted) throw abortReason(signal);
            if (!retryable(error) || run.retries >= run.settings.maximumRetries) throw error;
            const backoff = Math.min(run.settings.maximumDelayMs, run.settings.initialDelayMs * 2 ** Math.min(run.retries, 30));
            const adjustment = 1 + (Math.random() * 2 - 1) * run.settings.jitterRatio;
            const retryAfterMs = error instanceof SyncTransportError ? error.retryAfterMs ?? 0 : 0;
            run.retries++;
            publish("retrying", error);
            await delay(Math.max(retryAfterMs, Math.min(run.settings.maximumDelayMs, Math.round(backoff * adjustment))), signal);
            publish("syncing", undefined, true);
          }
        }
        const after = snapshot.replica;
        if (!remaining(after) && !run.rescan) return result(run, "settled");
        const requested = new Set(request.proposals.map(proposal => proposal.operationId));
        const progress = after.confirmedSequence > before.confirmedSequence || after.pendingCount < before.pendingCount
          || after.acceptedAwaitingCount < before.acceptedAwaitingCount || response.decisions.some(decision => requested.has(decision.operationId));
        if (!progress && !run.rescan) return result(run, "no-progress");
      }
      return result(run, "round-budget");
    } catch (error) {
      if (error instanceof TimeBudget) return result(run, "time-budget");
      throw error;
    } finally { clearTimeout(timer); }
  }
  function start(runSettings: Settings): Run {
    const run: Run = { controller: new AbortController(), settings: runSettings, promise: undefined as unknown as Promise<SyncResult>, waiters: 0, rescan: false, followup: false, rounds: 0, attempts: 0, retries: 0 };
    let completed = false;
    active = run;
    run.promise = Promise.resolve().then(() => execute(run)).then(value => {
      completed = true;
      if (!closed) publish("idle", undefined, true);
      return value;
    }, error => {
      if (!closed) {
        if (error instanceof SyncTransportError && error.code === "aborted") publish("idle", undefined, true);
        else report(error);
      }
      throw error;
    }).finally(() => {
      if (active === run) active = undefined;
      // New commits made after the last snapshot get a run of their own. Merely
      // exhausting a budget with old pending work never starts an unbounded drain.
      if (completed && run.followup && remaining(snapshot.replica)) scheduleAutomatic();
    });
    void run.promise.catch(() => undefined);
    return run;
  }
  function wait(run: Run, signal: AbortSignal | undefined): Promise<SyncResult> {
    run.waiters++;
    let finished = false;
    function leave(): void {
      if (finished) return;
      finished = true;
      run.waiters--;
      if (run.waiters === 0 && active === run) run.controller.abort(aborted());
    }
    if (!signal) return run.promise.finally(leave);
    // A caller's arbitrary AbortSignal.reason is not a transport failure classification.
    const cancellation = new AbortController();
    const cancel = () => cancellation.abort(aborted());
    signal.addEventListener("abort", cancel, { once: true });
    if (signal.aborted) cancel();
    return raceAbort(run.promise, cancellation.signal).finally(() => { signal.removeEventListener("abort", cancel); leave(); });
  }
  function synchronize(syncOptions?: SyncOptions): Promise<SyncResult> {
    try {
      assertOpen();
      if (syncOptions?.signal?.aborted) return Promise.reject(aborted());
      const runSettings = syncOptions === undefined ? defaults : settings(baseSyncOptions, syncOptions);
      if (active?.controller.signal.aborted) {
        return active.promise.catch(() => undefined).then(() => synchronize(syncOptions));
      }
      if (active) return wait(active, syncOptions?.signal);
      return wait(start(runSettings), syncOptions?.signal);
    } catch (error) { return Promise.reject(error); }
  }
  const engine: SyncEngine<Schema, Intent, Operation, Rejection, Collections> = {
    from: createCollectionAccess<Schema, Intent, Collections>(() => engine, options.collections),
    async mutate(intent, input) {
      assertOpen();
      const operationId = input?.operationId ?? (options.createOperationId ?? (() => globalThis.crypto.randomUUID()))();
      let identity;
      try { identity = await replica.enqueue({ operationId, intent }); }
      catch (error) { report(error); throw error; }
      if (!closed) {
        if (active) { active.rescan = true; active.followup = true; }
        try { await refresh(); } catch (error) { report(error); }
        scheduleAutomatic(true);
      }
      return identity;
    },
    sync: synchronize,
    async status() { await refresh(); return snapshot; },
    getSnapshot() { return snapshot; },
    subscribe(listener) {
      assertOpen();
      if (typeof listener !== "function") throw new SyncError("invalid-input", "A subscription listener must be a function.");
      listeners.add(listener);
      return () => { listeners.delete(listener); };
    },
    async get(collection, key) { assertOpen(); const value = await replica.get(collection, key); observe(value.status); return value; },
    async query(query) { assertOpen(); const value = await replica.query(query); observe(value.status); return value; },
    async readResolutions(input) { assertOpen(); const value = await replica.readResolutions(input); observe(value.status); return value; },
    async acknowledgeResolutions(operationIds) {
      assertOpen(); await replica.acknowledgeResolutions(operationIds);
      if (!closed) { try { await refresh(); } catch (error) { report(error); } }
    },
    close() {
      if (closePromise) return closePromise;
      // Publish may synchronously call application listeners, including close().
      closePromise = Promise.resolve().then(async () => {
        try { unsubscribeChanges?.(); } finally { await replica.close(); }
      });
      closed = true;
      active?.controller.abort(new SyncError("closed", "The sync engine is closed."));
      publish("closed");
      listeners.clear();
      return closePromise;
    },
  };
  try { unsubscribeChanges = options.subscribeChanges?.(() => { void refreshNotification(); }); }
  catch (error) { await engine.close(); throw error; }
  scheduleAutomatic();
  return engine;
}
