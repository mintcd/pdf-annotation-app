export type SyncTransportErrorCode = "network" | "timeout" | "aborted" | "access" | "rate-limit" | "invalid-response";

/** Transports classify failures explicitly; the engine never parses error messages. */
export class SyncTransportError extends Error {
  readonly code: SyncTransportErrorCode;
  readonly retryable: boolean;
  readonly retryAfterMs: number | undefined;

  constructor(code: SyncTransportErrorCode, message: string, options?: ErrorOptions & { readonly retryAfterMs?: number }) {
    super(message, options);
    this.name = "SyncTransportError";
    this.code = code;
    this.retryable = code === "network" || code === "timeout" || code === "rate-limit";
    const delay = options?.retryAfterMs;
    if (delay !== undefined && (!Number.isFinite(delay) || delay < 0)) throw new TypeError("retryAfterMs must be a finite nonnegative number.");
    this.retryAfterMs = delay;
  }
}
