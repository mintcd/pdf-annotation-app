import type { OperationIdentity, PrepareSyncOptions, SyncTransport } from "../core/types.js";
import type { CollectionName, CollectionRow, RecordKey, RecordPage, RecordQuery, RecordReplica, RecordReplicaStatus, RecordResolutionPage, RecordSchema } from "../records/types.js";
import type { SyncCollection, SyncCollectionDefinitions } from "./collections.js";

export type SyncEnginePhase = "idle" | "syncing" | "retrying" | "error" | "closed";
export interface SyncEngineSnapshot {
  readonly replica: RecordReplicaStatus;
  readonly phase: SyncEnginePhase;
  /** Transport, protocol, or storage failure; domain rejections are resolution notices. */
  readonly lastError?: unknown;
}
export interface SyncRetryOptions {
  /** Total retries within one run, shared across all rounds. Defaults to 3. */
  readonly maximumRetries?: number;
  readonly initialDelayMs?: number;
  readonly maximumDelayMs?: number;
  /** A fractional random adjustment in [0, 1]. Defaults to 0.2. */
  readonly jitterRatio?: number;
}
export interface SyncRunOptions extends PrepareSyncOptions {
  /** Defaults to 16. A round prepares one durable outbox snapshot. */
  readonly maximumRounds?: number;
  /** Defaults to 30 seconds, including requests and retry delays. */
  readonly maximumDurationMs?: number;
  /** Defaults to 10 seconds per transport attempt. */
  readonly requestTimeoutMs?: number;
  readonly retry?: SyncRetryOptions;
}
export interface SyncOptions extends SyncRunOptions {
  /** Cancels this caller's wait. Shared work stops when its last caller leaves. */
  readonly signal?: AbortSignal;
}
export interface SyncResult {
  readonly status: RecordReplicaStatus;
  readonly rounds: number;
  readonly attempts: number;
  readonly retries: number;
  readonly reason: "settled" | "round-budget" | "time-budget" | "no-progress";
}
export interface CreateSyncEngineOptions<Schema extends RecordSchema, Intent, Operation, Rejection, Collections extends SyncCollectionDefinitions<Schema, Intent> | undefined = undefined> {
  readonly replica: RecordReplica<Schema, Intent, Operation, Rejection>;
  readonly transport: SyncTransport<Intent, Operation, Rejection>;
  /** Optional field/index metadata and CRUD intent builders for the collection facade. */
  readonly collections?: Collections;
  /** Schedules one bounded run on startup and after new durable work. Defaults to false. */
  readonly autoSync?: boolean;
  readonly syncOptions?: SyncRunOptions;
  readonly createOperationId?: () => string;
  /** Storage notifications are invalidation hints; payloads are never trusted as state. */
  readonly subscribeChanges?: (listener: () => void) => () => void;
}
export interface SyncEngine<Schema extends RecordSchema, Intent, Operation, Rejection, Collections extends SyncCollectionDefinitions<Schema, Intent> | undefined = undefined> {
  mutate(intent: Intent, options?: { readonly operationId?: string }): Promise<OperationIdentity>;
  /** Overlapping calls share work and the first caller's run options. */
  sync(options?: SyncOptions): Promise<SyncResult>;
  status(): Promise<SyncEngineSnapshot>;
  /** Cached snapshot; subscribe for changes and use status() for an explicit refresh. */
  getSnapshot(): SyncEngineSnapshot;
  /** Listener exceptions are isolated from persistence and synchronization. */
  subscribe(listener: (snapshot: SyncEngineSnapshot) => void): () => void;
  /** Bounded queries read local visible records, including optimistic changes. */
  from<Name extends CollectionName<Schema>>(collection: Name): SyncCollection<Schema, Name, Collections>;
  get<Name extends CollectionName<Schema>>(collection: Name, key: RecordKey): Promise<{ readonly row: CollectionRow<Schema, Name> | undefined; readonly status: RecordReplicaStatus }>;
  query<Name extends CollectionName<Schema>>(query: RecordQuery<Schema, Name>): Promise<RecordPage<CollectionRow<Schema, Name>> & { readonly status: RecordReplicaStatus }>;
  readResolutions(options?: { readonly after?: string; readonly limit?: number }): Promise<RecordResolutionPage<Operation, Rejection>>;
  acknowledgeResolutions(operationIds: readonly string[]): Promise<void>;
  /** Stops timers/requests/subscriptions and closes the supplied replica handle. */
  close(): Promise<void>;
}
