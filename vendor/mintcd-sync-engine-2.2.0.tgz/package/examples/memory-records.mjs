import { defineRecordSchema, openRecordReplica } from '@mintcd/sync-engine/records';
import { createMemoryRecordDatabase } from '@mintcd/sync-engine/adapters/memory';
import { createRecordSyncAuthority } from '@mintcd/sync-engine/server';
import { createSyncEngine } from '@mintcd/sync-engine/client';

function note(value) {
  if (!value || typeof value !== 'object' || typeof value.id !== 'string' || !value.id
    || typeof value.title !== 'string' || !['open', 'done'].includes(value.status)
    || typeof value.updatedAt !== 'number' || !Number.isFinite(value.updatedAt)) throw new TypeError('Invalid note.');
  return { id: value.id, title: value.title, status: value.status, updatedAt: value.updatedAt };
}
const noteCodec = { encode: note, decode: note };
const schema = defineRecordSchema({
  version: 'notes/1',
  collections: { notes: {
    codec: noteCodec,
    key: row => [row.id],
    indexes: { byStatusUpdated: { key: row => [row.status, row.updatedAt] } },
  } },
});
const reads = row => [{ type: 'get', collection: 'notes', key: [row.id] }];
const model = {
  schema, contractVersion: 'notes/1', intent: noteCodec, operation: noteCodec,
  rejection: { encode: value => value, decode: value => {
    if (typeof value !== 'string') throw new TypeError('Invalid rejection.');
    return value;
  } },
  intentReads: reads, operationReads: reads,
  applyCommitted: (view, row) => { view.put('notes', row); },
  previewIntent: (view, row) => { view.put('notes', row); return { status: 'applied' }; },
  previewOperation: (view, row) => { view.put('notes', row); return { status: 'applied' }; },
};
const original = { id: 'note-1', title: 'Original', status: 'open', updatedAt: 1 };
const initialRows = [{ type: 'put', collection: 'notes', row: original }];
const clientDatabase = createMemoryRecordDatabase({ streamId: 'notes/demo', schema, initialRows });
const serverDatabase = createMemoryRecordDatabase({ streamId: 'notes/demo', schema, initialRows });
const replica = await openRecordReplica({ database: clientDatabase, clientId: 'browser-1', model });
const authority = createRecordSyncAuthority({ database: serverDatabase, model,
  policy: (_view, proposal) => proposal.intent.title.trim()
    ? { status: 'accepted', operation: { ...proposal.intent, title: proposal.intent.title.trim() } }
    : { status: 'rejected', reason: 'A title is required.' },
});
const engine = await createSyncEngine({
  replica,
  transport: { exchange: request => authority.synchronize(request, undefined) },
});
const openNotes = () => engine.query({ collection: 'notes', index: 'byStatusUpdated', prefix: ['open'], limit: 10 });

console.log('Initially open:', (await openNotes()).rows.length);
await engine.mutate({ ...original, title: '  Finished  ', status: 'done', updatedAt: 2 }, { operationId: 'finish-note' });
console.log('Open after local edit:', (await openNotes()).rows.length);
await engine.sync();
console.log('Canonical title:', (await engine.get('notes', ['note-1'])).row.title);

await engine.mutate({ ...original, title: '', updatedAt: 3 }, { operationId: 'invalid-title' });
console.log('Open during pending edit:', (await openNotes()).rows.length);
await engine.sync();
console.log('Open after rejection:', (await openNotes()).rows.length);
console.log('Resolution outcomes:', (await engine.readResolutions()).decisions.map(decision => decision.status));
await engine.close();
