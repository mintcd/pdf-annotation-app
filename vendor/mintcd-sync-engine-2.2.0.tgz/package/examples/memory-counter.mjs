import { createMemoryAuthorityStore, createMemoryReplicaStore } from '@mintcd/sync-engine/adapters/memory';
import { createSyncAuthority } from '@mintcd/sync-engine/server';

function number(value) {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new TypeError('Expected a finite number.');
  return value;
}

function string(value) {
  if (typeof value !== 'string') throw new TypeError('Expected a string.');
  return value;
}

const model = {
  contractVersion: 'counter/v1',
  intent: { encode: number, decode: number },
  operation: { encode: number, decode: number },
  rejection: { encode: string, decode: string },
  applyCommitted: (state, operation) => state + operation,
  previewIntent: (state, intent) => ({ status: 'applied', state: state + intent }),
  previewOperation: (state, operation) => ({ status: 'applied', state: state + operation }),
};

const store = createMemoryAuthorityStore({
  streamId: 'counter/demo', initialState: 0, operation: model.operation, rejection: model.rejection,
});
const authority = createSyncAuthority({
  store, model,
  policy: (state, proposal) => proposal.intent < 0
    ? { status: 'rejected', reason: 'Only nonnegative increments are allowed.' }
    : { status: 'accepted', operation: Math.min(proposal.intent, Math.max(0, 5 - state)) },
});
const replica = createMemoryReplicaStore({ streamId: 'counter/demo', clientId: 'browser-1', initialState: 0, model });

await replica.enqueue({ operationId: 'increment-1', intent: 8 });
console.log('Locally saved:', (await replica.read()).visibleState);

const response = await authority.synchronize(await replica.prepareSyncRequest(), undefined);
await replica.reconcile(response);
console.log('Authority confirmed:', (await replica.read()).confirmedState);
console.log('Resolution:', (await replica.readResolutions())[0].status);
await replica.close();
