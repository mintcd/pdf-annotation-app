# Changelog

## Unreleased

- Reduced Vinext generation to the sync route and `sync/generated.ts`, which
  exports only the typed `useSyncEngine` hook. Import `createSyncConfig` from
  `@mintcd/sync-engine-vinext`; logout is available on the hook's returned state.
  The React hook shares engines across consumers and handles opening, status
  subscriptions and cleanup. PWA worker/registration entries are virtual build
  modules, and D1 mappings are composed by the server package.
- Preserved application-owned authentication hooks and SQL migrations. Existing
  applications replace `client.generated` imports with `generated` and update
  their server hook to export `createPolicy(model)` using the route's type-only
  `SyncModel` export.

## 2.2.0 — 2026-10-18

- Added `defineCrudModel`, runtime field validation, typed CRUD intents and
  canonical operations, field-patch merging and bounded application rejection
  codes. Keys, enums, optional/null fields and indexes retain their inferred types.
- Added `engine.from()` with typed selection, indexed field predicates, explicit
  bounds, keyset pagination and optional CRUD methods. Writes retain PWA account
  checks and worker scheduling; unsupported query plans fail explicitly.
- Exposed the guarded Vinext generation-plan executor for integration packages.
- Added the separate `@mintcd/sync-engine-vinext` 1.0.0 package: Wrangler
  binding/environment validation, generated client/model/server/route/PWA wiring,
  initial migrations, explicit schema discovery and Wrangler binding type generation.
- Added typed `sync-engine.config.ts` configuration through `defineSyncConfig`,
  retaining JSON configuration and inferred generated client/schema types.

The PWA work was developed as the unpublished 2.1 milestone. Its changes are
included in 2.2.0; there was no separate 2.1 release.

- Added the opt-in PWA page coordinator and service-worker host, reusing the
  existing durable outbox and complete prepare/exchange/reconcile cycle.
- Added versioned worker messages, bounded execution, independent event lifetime,
  foreground fallback, reconnect scheduling and worker capability observations.
- Added a durable replica bootstrap registry with shared Web Lock leases and
  disable-before-drain account cleanup, plus IndexedDB `closeAndDrain()` and
  `requireExisting` recovery opens to avoid silently recreating lost state.
- Added public shell precaching, scoped offline navigation, complete-install
  readiness and preservation of older build caches.
- Added `syncEnginePwa` for Vinext/Vite: automatic production registration,
  manifest generation, executable worker/offline UI builds and complete client
  asset collection, including lazy JavaScript and CSS. Existing workers with a
  different script URL are preserved and require explicit manual integration.

PWA integration requires an application-owned offline UI, shared model, persistent
identity/bootstrap and worker-usable authentication. The Vite peer is optional
and used only by the build integration. Verification covers Chromium and the
pinned Vinext Node server with local workerd D1; browser-granted background
execution timing, automated installation UI and remote deployment are not
guaranteed. Old shell caches are retained until an application defines cleanup.

## 2.0.0

This release replaces the legacy implementation with explicit client, authority,
storage and transport roles. Version 1 APIs and persisted replica data are not
automatically compatible. Existing applications must plan their own migration;
the package does not import or overwrite legacy state.

- Added `createSyncEngine`, durable local receipts, subscriptions, bounded sync,
  classified retries, cancellation and close handling.
- Added typed record collections, indexed queries, atomic multi-row changes and
  separate confirmed/optimistic materializations.
- Added IndexedDB persistence, reopen recovery and cross-tab invalidation.
- Added Fetch transport and authorized handlers with bounded payloads and
  precommit response validation.
- Added D1 authority storage with typed SQL projections, explicit initial
  migrations and guarded atomic commits.
- Added vinext route/client configuration generation with dry-run/check,
  ownership protection and interrupted-write recovery.

The package is ESM and has no runtime dependencies. Browser, server, storage,
transport and generation entrypoints are separate. Source, API documentation and
runnable memory examples are included in the npm package.

Automatic schema upgrades, legacy migration, GitHub delivery and history
compaction remain deferred. Native browser checks cover Chromium. The vinext
fixture covers its Node development/production server with local D1; Cloudflare
deployment is not claimed.
