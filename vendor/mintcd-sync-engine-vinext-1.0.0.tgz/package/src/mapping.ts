import type { D1CollectionMappings, D1ColumnMapping } from "@mintcd/sync-engine/adapters/d1";
import type { CrudModel, CrudModelDefinition, CrudSchema } from "@mintcd/sync-engine/records";

/** Derive the server mapping from the same logical model used by the client. */
export function createVinextD1Mappings<D extends CrudModelDefinition>(model: CrudModel<D>, appId: string): D1CollectionMappings<CrudSchema<D>> {
  return Object.fromEntries(Object.entries(model.definition.collections).map(([name, collection]) => [name, {
    table: `se_${appId}_${name}`,
    columns: Object.fromEntries(Object.entries(collection.fields).map(([field, definition]) => [field, {
      type: definition.type === "string" ? "TEXT" : definition.type === "boolean" ? "INTEGER" : "REAL",
      value: (row: Record<string, unknown>) => row[field] == null ? null : definition.type === "boolean" ? Number(row[field]) : row[field],
    } as D1ColumnMapping<Record<string, unknown>>])),
  }])) as D1CollectionMappings<CrudSchema<D>>;
}
