import type { SyncRunOptions } from "@mintcd/sync-engine/client";
import type { VinextClientOptions } from "./session.js";

declare const clientConfig: unique symbol;
/** Immutable client session options; the generated hook supplies schema inference. */
export type SyncClientConfig = VinextClientOptions & { readonly [clientConfig]: true };

const configurations = new WeakSet<object>();

function syncOptionsSnapshot(input: SyncRunOptions): SyncRunOptions {
  const snapshot: Record<string, unknown> = {};
  const fields = ["maximumRounds", "maximumDurationMs", "requestTimeoutMs", "maximumProposals", "maximumEntries"] as const;
  if (!input || typeof input !== "object" || Array.isArray(input) || Object.keys(input).some(key => ![...fields, "retry"].includes(key as typeof fields[number]))) throw new TypeError("Invalid syncOptions.");
  for (const field of fields) {
    const value = input[field];
    if (value === undefined) continue;
    if (!Number.isSafeInteger(value) || value < (field === "maximumProposals" ? 0 : 1) || value > 2_147_483_647) throw new TypeError(`Invalid syncOptions.${field}.`);
    snapshot[field] = value;
  }
  if (input.retry !== undefined) {
    const retry: Record<string, number> = {};
    const fields = ["maximumRetries", "initialDelayMs", "maximumDelayMs", "jitterRatio"] as const;
    if (!input.retry || typeof input.retry !== "object" || Array.isArray(input.retry) || Object.keys(input.retry).some(key => !fields.includes(key as typeof fields[number]))) throw new TypeError("Invalid syncOptions.retry.");
    for (const field of fields) {
      const value = input.retry[field];
      if (value === undefined) continue;
      if (!Number.isFinite(value) || value < 0 || (field === "jitterRatio" ? value > 1 : !Number.isSafeInteger(value) || value > 2_147_483_647)) throw new TypeError(`Invalid syncOptions.retry.${field}.`);
      retry[field] = value;
    }
    if (Object.keys(retry).length) snapshot.retry = Object.freeze(retry);
  }
  return Object.freeze(snapshot);
}

/** Snapshot client options without React, browser storage or build configuration. */
export function createSyncConfig(options: VinextClientOptions): SyncClientConfig {
  if (!options || typeof options.accountId !== "string" || !options.accountId || typeof options.streamId !== "string" || !options.streamId) throw new TypeError("accountId and streamId are required.");
  if (options.replicaKey !== undefined && (typeof options.replicaKey !== "string" || !/^[A-Za-z0-9_-]{1,128}$/.test(options.replicaKey))) throw new TypeError("replicaKey must be a portable replica name.");
  for (const field of ["initialize", "freshStart", "autoSync"] as const) if (options[field] !== undefined && typeof options[field] !== "boolean") throw new TypeError(`${field} must be a boolean.`);
  if (options.deploymentVersion !== undefined && (typeof options.deploymentVersion !== "string" || !/^[A-Za-z0-9_.:/-]{1,128}$/.test(options.deploymentVersion))) throw new TypeError("Invalid deploymentVersion.");
  const syncOptions = options.syncOptions === undefined ? undefined : syncOptionsSnapshot(options.syncOptions);
  const config = Object.freeze({
    accountId: options.accountId, streamId: options.streamId, replicaKey: options.replicaKey ?? "main",
    ...(options.deploymentVersion === undefined ? {} : { deploymentVersion: options.deploymentVersion }),
    initialize: options.initialize ?? false, freshStart: options.freshStart ?? false, autoSync: options.autoSync ?? true,
    ...(syncOptions === undefined || Object.keys(syncOptions).length === 0 ? {} : { syncOptions }),
  }) as SyncClientConfig;
  configurations.add(config);
  return config;
}

/** Internal authenticity check shared by all generated hooks. */
export function assertSyncClientConfig(config: unknown): asserts config is SyncClientConfig {
  if (!config || typeof config !== "object" || !configurations.has(config)) throw new TypeError("Use createSyncConfig from @mintcd/sync-engine-vinext.");
}
