#!/usr/bin/env node
import { resolve } from "node:path";
import { generateSyncVinext } from "./node.js";
import { writeFile } from "node:fs/promises";
import { discoverConfiguredD1, generateWranglerTypes } from "./wrangler.js";
import { relativeFile } from "./config.js";

export async function runCli(args: readonly string[]) {
  let root = process.cwd();
  let configPath: string | undefined;
  let mode: "write" | "check" | "dry-run" = "write";
  let command = "generate";
  let wrangler = "wrangler.jsonc";
  let binding = "DB";
  let environment: string | undefined;
  let location: "local" | "remote" | undefined;
  let output = "sync-schema.draft.json";
  const tables: string[] = [];
  for (let index = 0; index < args.length; index++) {
    const argument = args[index];
    if (["generate", "discover", "types"].includes(argument ?? "") && index === 0) { command = argument!; continue; }
    if (argument === "--check") mode = "check";
    else if (argument === "--dry-run") mode = "dry-run";
    else if (argument === "--local" || argument === "--remote") {
      if (location !== undefined) throw new TypeError("Choose exactly one of --local or --remote.");
      location = argument === "--local" ? "local" : "remote";
    }
    else if (["--root", "--config", "--wrangler", "--binding", "--env", "--table", "--out"].includes(argument ?? "") && args[index + 1] && !args[index + 1]!.startsWith("--")) {
      const value = args[++index]!;
      if (argument === "--root") root = resolve(value);
      else if (argument === "--config") configPath = value;
      else if (argument === "--wrangler") wrangler = value;
      else if (argument === "--binding") binding = value;
      else if (argument === "--env") environment = value;
      else if (argument === "--table") tables.push(value);
      else output = value;
    } else if (argument === "--help") { console.log("sync-engine-vinext generate [--root path] [--config sync-engine.config.ts|.json|.jsonc] [--check|--dry-run]\nsync-engine-vinext discover --binding DB --table notes --local|--remote [--wrangler wrangler.jsonc] [--env staging] [--out sync-schema.draft.json]\nsync-engine-vinext types [--wrangler wrangler.jsonc] [--env staging]"); return 0; }
    else throw new TypeError(`Unsupported argument: ${argument}`);
  }
  if (command === "discover") {
    if (location === undefined) throw new TypeError("Discovery requires an explicit --local or --remote choice.");
    if (mode !== "write") throw new TypeError("Discovery writes only a new draft file; --check and --dry-run apply to generate.");
    relativeFile(output);
    if (output.includes("/")) throw new TypeError("Draft output must be a filename in the application root.");
    const draft = await discoverConfiguredD1({ root, wrangler, binding, ...(environment === undefined ? {} : { environment }), location, tables });
    await writeFile(resolve(root, output), JSON.stringify(draft, null, 2) + "\n", { flag: "wx" });
    console.log(`Created ${output}; review warnings and unresolved fields before updating your sync configuration. No rows were imported.`);
    return 0;
  }
  if (command === "types") {
    console.log(await generateWranglerTypes({ root, wrangler, ...(environment === undefined ? {} : { environment }) }));
    return 0;
  }
  const result = await generateSyncVinext({ root, ...(configPath === undefined ? {} : { configPath }), mode });
  for (const file of result.files) console.log(`${file.status} ${file.path}${file.reason ? `: ${file.reason}` : ""}`);
  return result.ok ? 0 : 1;
}
try { process.exitCode = await runCli(process.argv.slice(2)); }
catch (error) { console.error(error instanceof Error ? error.message : "Sync generation failed."); process.exitCode = 1; }
