"use client";

import { useMemo, useSyncExternalStore } from "react";
import type { CrudModel, CrudModelDefinition } from "@mintcd/sync-engine/records";
import { createVinextSyncEngine, logoutVinextSync } from "./client.js";
import type { VinextClientOptions, VinextRuntimeConfig } from "./client.js";
import { assertSyncClientConfig, createSyncConfig } from "./client-config.js";
import type { SyncClientConfig } from "./client-config.js";
import { createVinextSyncStore, idleVinextSyncState, openingVinextSyncState } from "./react-store.js";
import type { VinextSyncState } from "./react-store.js";
export type { VinextSyncState } from "./react-store.js";

export type VinextSyncEngine<D extends CrudModelDefinition> = Awaited<ReturnType<typeof createVinextSyncEngine<D>>>;

const emptyStore = { subscribe: (_listener: () => void) => () => undefined, getSnapshot: () => idleVinextSyncState };

/** The generated browser entry calls this once with its literal application model. */
export function createVinextSyncClient<D extends CrudModelDefinition>(model: CrudModel<D>, input: VinextRuntimeConfig) {
  const runtime = Object.freeze({ ...input, replicaKeys: Object.freeze([...input.replicaKeys]) });
  type Store = ReturnType<typeof createVinextSyncStore<VinextSyncEngine<D>>>;
  const stores = new Map<string, { readonly options: VinextClientOptions; readonly reference: WeakRef<Store> }>();
  const activeStores = new Map<string, Store>();
  const configurations = new WeakMap<SyncClientConfig, Store>();
  const loggingOut = new Map<string, { readonly reason: Error; readonly stores: Set<Store>; readonly cleanup: Promise<void>[]; deleteData: boolean; promise: Promise<void> }>();
  const finalized = new FinalizationRegistry<string>(key => { if (!stores.get(key)?.reference.deref()) stores.delete(key); });

  function storeFor(config: SyncClientConfig): Store {
    assertSyncClientConfig(config);
    const replicaKey = config.replicaKey ?? "main";
    if (!runtime.replicaKeys.includes(replicaKey)) throw new TypeError("Replica key is not declared by this application.");
    const bound = configurations.get(config);
    if (bound) return bound;
    const key = JSON.stringify(config);
    let store = activeStores.get(key) ?? stores.get(key)?.reference.deref();
    if (!store) {
      const session = createVinextSyncStore(() => createVinextSyncEngine(model, runtime, config));
      let consumers = 0;
      let terminal: VinextSyncState<VinextSyncEngine<D>> | undefined;
      let stopping: Promise<void> | undefined;
      const shared: Store = {
        ...session,
        getSnapshot: () => terminal ?? session.getSnapshot(),
        subscribe(listener: () => void) {
          if (terminal) return () => undefined;
          ++consumers;
          activeStores.set(key, shared);
          const unsubscribe = session.subscribe(listener);
          let subscribed = true;
          return () => {
            if (!subscribed) return;
            subscribed = false;
            unsubscribe();
            if (--consumers === 0 && activeStores.get(key) === shared) activeStores.delete(key);
          };
        },
        stop(reason: unknown) {
          if (!stopping) {
            stopping = session.stop(reason);
            // Old configs stay logged out even after their final subscriber leaves.
            terminal = session.getSnapshot();
          }
          return stopping;
        },
      };
      store = shared;
      stores.set(key, { options: config, reference: new WeakRef(store) });
      finalized.register(store, key);
    }
    configurations.set(config, store);
    const pending = loggingOut.get(replicaKey);
    if (pending && !pending.stores.has(store)) {
      pending.stores.add(store);
      const cleanup = store.stop(pending.reason);
      pending.cleanup.push(cleanup);
      void cleanup.catch(() => undefined);
    }
    return store;
  }
  function logoutSync(options: Parameters<typeof logoutVinextSync>[1] = {}): Promise<void> {
    const replicaKey = options.replicaKey ?? "main";
    const existing = loggingOut.get(replicaKey);
    if (existing) {
      existing.deleteData ||= options.deleteData ?? false;
      return existing.promise;
    }
    const pending = {
      reason: new Error("The sync session was logged out. Sign in again to open a new session."),
      stores: new Set<Store>(), cleanup: [] as Promise<void>[], deleteData: options.deleteData ?? false, promise: Promise.resolve(),
    };
    loggingOut.set(replicaKey, pending);
    for (const entry of stores.values()) {
      const store = entry.reference.deref();
      if (entry.options.replicaKey !== replicaKey || !store) continue;
      pending.stores.add(store);
      const cleanup = store.stop(pending.reason);
      pending.cleanup.push(cleanup);
      void cleanup.catch(() => undefined);
    }
    pending.promise = (async () => {
      try {
        await Promise.allSettled(pending.cleanup);
        let deleted: boolean;
        let results: PromiseSettledResult<void>[];
        do {
          deleted = pending.deleteData;
          await logoutVinextSync(runtime, { replicaKey, deleteData: deleted });
          results = await Promise.allSettled(pending.cleanup);
        } while (pending.deleteData && !deleted);
        const errors = results.filter((result): result is PromiseRejectedResult => result.status === "rejected").map(result => result.reason);
        // A new authenticated config may now open, while observed old configs retain
        // their terminal stores. A replaced store must survive old cleanup callbacks.
        for (const [key, entry] of stores) {
          const store = entry.reference.deref();
          if (!store || !pending.stores.has(store)) continue;
          if (stores.get(key)?.reference.deref() === store) stores.delete(key);
          if (activeStores.get(key) === store) activeStores.delete(key);
        }
        if (errors.length) throw new AggregateError(errors, "Closing the sync session failed.");
      } finally { if (loggingOut.get(replicaKey) === pending) loggingOut.delete(replicaKey); }
    })();
    return pending.promise;
  }
  function useSyncEngine(config: SyncClientConfig | null) {
    const store = config === null ? emptyStore : storeFor(config);
    const snapshot = useSyncExternalStore(store.subscribe, store.getSnapshot, config === null ? emptyStore.getSnapshot : () => openingVinextSyncState);
    const replicaKey = config?.replicaKey ?? "main";
    const logout = useMemo(() => (options: { readonly deleteData?: boolean } = {}) => logoutSync({ ...options, replicaKey }), [replicaKey]);
    return useMemo(() => Object.freeze({ ...snapshot, logoutSync: logout }), [snapshot, logout]);
  }
  return {
    useSyncEngine,
    createSyncEngine: (options: VinextClientOptions) => createVinextSyncEngine(model, runtime, createSyncConfig(options)),
    logoutSync,
  };
}
