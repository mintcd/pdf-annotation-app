import { crudCollections } from "@mintcd/sync-engine/records";
import type { CrudModel, CrudModelDefinition, CrudSchema, CrudIntent, CrudOperation, CrudRejection, CrudCollections } from "@mintcd/sync-engine/records";
import { createPwaSyncEngine } from "@mintcd/sync-engine/pwa/client";
import type { PwaSyncEngine } from "@mintcd/sync-engine/pwa/client";
import { initializeVinextReplica, openRegistry, openVinextSession, registryName } from "./session.js";
import type { VinextClientOptions, VinextRuntimeConfig } from "./session.js";
export type { VinextClientOptions, VinextRuntimeConfig } from "./session.js";
export { createSyncConfig } from "./client-config.js";
export type { SyncClientConfig } from "./client-config.js";
export type VinextSyncEngine<D extends CrudModelDefinition> = PwaSyncEngine<CrudSchema<D>, CrudIntent<D>, CrudOperation<D>, CrudRejection, CrudCollections<D>>;

/** Application-specialized factories are generated with the literal model type. */
export async function createVinextSyncEngine<D extends CrudModelDefinition>(model: CrudModel<D>, config: VinextRuntimeConfig, options: VinextClientOptions): Promise<VinextSyncEngine<D>> {
  const registry = await openRegistry(config);
  let closeSession: (() => Promise<void>) | undefined;
  try {
    await initializeVinextReplica(model, config, registry, options);
    const session = await openVinextSession(model, config, registry, options.replicaKey ?? "main", undefined, options);
    closeSession = session.close;
    if (session.lease.descriptor.accountId !== options.accountId || session.lease.descriptor.streamId !== options.streamId) throw new TypeError("The active account or stream changed while opening the client.");
    const engine = await createPwaSyncEngine({
      replica: session.replica, transport: session.transport, collections: crudCollections(model),
      autoSync: options.autoSync ?? true,
      ...(options.syncOptions === undefined ? {} : { syncOptions: options.syncOptions }),
      worker: { replicaKey: options.replicaKey ?? "main", contractVersion: model.contractVersion,
        ...(config.pwa ? {} : { getRegistration: () => undefined }),
      },
      lifecycle: { signal: session.lease.signal, assertEnabled: () => session.lease.assertEnabled() },
      subscribeChanges: listener => session.database.subscribe(listener),
    });
    let closing: Promise<void> | undefined;
    const abort = () => { void close().catch(() => undefined); };
    const close = () => closing ??= (async () => {
      session.lease.signal.removeEventListener("abort", abort);
      try { await engine.close(); }
      finally { try { await session.close(); } finally { registry.close(); } }
    })();
    session.lease.signal.addEventListener("abort", abort, { once: true });
    if (session.lease.signal.aborted) { await close(); throw session.lease.signal.reason; }
    return { ...engine, close };
  } catch (error) { try { await closeSession?.(); } finally { registry.close(); } throw error; }
}

export async function logoutVinextSync(config: VinextRuntimeConfig, options: { readonly replicaKey?: string; readonly deleteData?: boolean } = {}) {
  const registry = await openRegistry(config);
  try {
    const locks = globalThis.navigator?.locks;
    if (!locks) throw new TypeError("Generated PWA sessions require Web Locks.");
    await locks.request(`${registryName(config)}:bootstrap`, async () => {
      await registry.disable(options.replicaKey ?? "main", options.deleteData ? {
        cleanup: descriptor => new Promise<void>((resolve, reject) => {
          const deletion = indexedDB.deleteDatabase(descriptor.databaseName);
          deletion.onsuccess = () => resolve();
          deletion.onerror = () => reject(deletion.error);
          deletion.onblocked = () => reject(new Error("Database deletion is blocked by an unrelated connection."));
        }),
      } : {});
    });
  } finally { registry.close(); }
}
