import type { Plugin } from "vite";
import { resolve } from "node:path";
import { syncEnginePwa } from "@mintcd/sync-engine/integrations/vinext/pwa";
import { legacyConfig } from "./config.js";
import { generateSyncVinext, loadSyncVinextConfigWithDependencies } from "./node.js";
import { vinextPwaSources } from "./sources.js";

/** Configure before vinext(). Generation runs before Vinext discovers routes. */
export function syncEngineVinext(options: { readonly config?: string; readonly root?: string } = {}): Plugin[] {
  let pwa: Plugin | undefined;
  let watched: readonly string[] = [];
  return [{ name: "sync-engine-vinext:generate", enforce: "pre",
    async config(config, environment) {
      const root = options.root ?? config.root ?? process.cwd();
      const loaded = await loadSyncVinextConfigWithDependencies(root, options.config, environment);
      const input = loaded.config;
      watched = [...new Set([loaded.path, ...loaded.dependencies, resolve(root, input.wrangler.config ?? "wrangler.jsonc"),
        ...(options.config === undefined ? ["sync-engine.config.ts", "sync-engine.config.json", "sync-engine.config.jsonc"].map(file => resolve(root, file)) : []),
      ])];
      pwa = undefined;
      const result = await generateSyncVinext({ root, config: input });
      if (!result.ok) throw new Error(`Sync generation conflicts: ${result.files.filter(file => file.status === "conflict").map(file => file.path).join(", ")}`);
      if (input.pwa) pwa = syncEnginePwa({ config: legacyConfig(input), sources: vinextPwaSources(input) });
    },
    configureServer(server) {
      server.watcher.add(watched);
      const changed = (file: string) => { if (watched.includes(resolve(file))) void server.restart().catch(error => server.config.logger.error(String(error))); };
      server.watcher.on("change", changed);
      server.watcher.on("add", changed);
      server.watcher.on("unlink", changed);
      server.httpServer?.once("close", () => { server.watcher.off("change", changed); server.watcher.off("add", changed); server.watcher.off("unlink", changed); });
    },
  }, {
    name: "sync-engine-vinext:pwa", enforce: "post",
    async configResolved(config) { const hook = pwa?.configResolved; if (typeof hook === "function") await hook.call(this, config); },
    resolveId(source, importer, options) { const hook = pwa?.resolveId; if (typeof hook === "function") return hook.call(this, source, importer, options); },
    load(id, options) { const hook = pwa?.load; if (typeof hook === "function") return hook.call(this, id, options); },
    transform(code, id, options) { const hook = pwa?.transform; if (typeof hook === "function") return hook.call(this, code, id, options); },
    generateBundle: { order: "pre", async handler(options, bundle, isWrite) {
      const hook = pwa?.generateBundle;
      if (typeof hook === "function") await hook.call(this, options, bundle, isWrite);
      else if (hook) await hook.handler.call(this, options, bundle, isWrite);
    } },
  }];
}
