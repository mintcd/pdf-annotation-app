/** JSON with line/block comments and trailing commas; never evaluates code. */
export function parseJsonc(source: string): unknown {
  source = source.replace(/^\uFEFF/, "");
  let text = "";
  let quoted = false;
  for (let index = 0; index < source.length; index++) {
    const character = source[index]!;
    if (quoted) {
      text += character;
      if (character === "\\") text += source[++index] ?? "";
      else if (character === '"') quoted = false;
    } else if (character === '"') { quoted = true; text += character; }
    else if (character === "/" && source[index + 1] === "/") {
      while (index < source.length && source[index] !== "\n") index++;
      text += "\n";
    } else if (character === "/" && source[index + 1] === "*") {
      index += 2;
      while (index < source.length && !(source[index] === "*" && source[index + 1] === "/")) index++;
      if (index >= source.length) throw new TypeError("Unterminated JSONC comment.");
      index++;
      text += " ";
    } else text += character;
  }
  let result = "";
  quoted = false;
  for (let index = 0; index < text.length; index++) {
    const character = text[index]!;
    if (quoted) {
      result += character;
      if (character === "\\") result += text[++index] ?? "";
      else if (character === '"') quoted = false;
    } else if (character === '"') { quoted = true; result += character; }
    else if (character === "," && /^[\s]*[}\]]/.test(text.slice(index + 1))) continue;
    else result += character;
  }
  return JSON.parse(result);
}
