import { readFile, realpath, stat } from "node:fs/promises";
import { extname, isAbsolute, relative, resolve } from "node:path";
import { relativeFile } from "./config.js";
import { parseJsonc } from "./jsonc.js";

export const SYNC_CONFIG_FILENAMES = Object.freeze([
  "sync-engine.config.ts", "sync-engine.config.json", "sync-engine.config.jsonc",
] as const);

export interface SyncConfigEnvironment {
  readonly command: "serve" | "build";
  readonly mode: string;
}

export interface LoadedSyncConfigFile {
  readonly value: unknown;
  readonly path: string;
  /** Absolute files bundled into the configuration, including the entry itself. */
  readonly dependencies: readonly string[];
}

async function exists(file: string): Promise<boolean> {
  try { await stat(file); return true; }
  catch (error) {
    if (error && typeof error === "object" && "code" in error && error.code === "ENOENT") return false;
    throw error;
  }
}

/** TypeScript is trusted build-time code; JSON/JSONC never loads a code evaluator. */
export async function loadSyncConfigFile(
  root: string,
  configPath?: string,
  environment: SyncConfigEnvironment = { command: "build", mode: "production" },
): Promise<LoadedSyncConfigFile> {
  const absoluteRoot = resolve(root);
  if (!environment || !["serve", "build"].includes(environment.command) || typeof environment.mode !== "string" || !environment.mode) {
    throw new TypeError("Configuration environment requires command serve/build and a nonempty mode.");
  }
  let selected = configPath;
  if (selected === undefined) {
    const found = (await Promise.all(SYNC_CONFIG_FILENAMES.map(async name => await exists(resolve(absoluteRoot, name)) ? name : undefined)))
      .filter((name): name is typeof SYNC_CONFIG_FILENAMES[number] => name !== undefined);
    if (found.length === 0) throw new TypeError(`Sync configuration not found. Create one of ${SYNC_CONFIG_FILENAMES.join(", ")}.`);
    if (found.length > 1) throw new TypeError(`Multiple sync configuration files found (${found.join(", ")}). Keep one or select an explicit config path.`);
    selected = found[0]!;
  }
  relativeFile(selected);
  const extension = extname(selected);
  if (![".ts", ".json", ".jsonc"].includes(extension)) throw new TypeError("Sync configuration must be a .ts, .json, or .jsonc file.");
  const absolutePath = resolve(absoluteRoot, selected);
  const [actualRoot, actualPath, details] = await Promise.all([realpath(absoluteRoot), realpath(absolutePath), stat(absolutePath)]);
  const within = relative(actualRoot, actualPath);
  if (within === ".." || within.startsWith("../") || within.startsWith("..\\") || isAbsolute(within)) throw new TypeError("Sync configuration must stay inside the application root.");
  if (!details.isFile()) throw new TypeError("Sync configuration must be a regular file.");
  if (details.size > 1024 * 1024) throw new TypeError("Configuration exceeds 1 MiB.");
  if (extension !== ".ts") {
    const text = await readFile(absolutePath, "utf8");
    if (Buffer.byteLength(text) > 1024 * 1024) throw new TypeError("Configuration exceeds 1 MiB.");
    return Object.freeze({ value: parseJsonc(text), path: absolutePath, dependencies: Object.freeze([absolutePath]) });
  }

  let vite: typeof import("vite");
  try { vite = await import("vite"); }
  catch (error) {
    throw new TypeError("TypeScript sync configuration requires Vite >=8.3.4 <9. Install the application's Vite peer dependency, or use JSON/JSONC configuration.", { cause: error });
  }
  const version = /^(\d+)\.(\d+)\.(\d+)(?:\+.*)?$/.exec(vite.version);
  if (!version || Number(version[1]) !== 8 || Number(version[2]) < 3 || Number(version[2]) === 3 && Number(version[3]) < 4) {
    throw new TypeError(`TypeScript sync configuration requires Vite >=8.3.4 <9; found ${vite.version}.`);
  }
  // Explicit bundling keeps .ts support independent of Node's native type stripping.
  const loaded = await vite.loadConfigFromFile({ command: environment.command, mode: environment.mode }, absolutePath, absoluteRoot, "silent", undefined, "bundle");
  if (!loaded) throw new TypeError(`Sync configuration could not be loaded: ${selected}.`);
  return Object.freeze({
    value: loaded.config as unknown,
    path: absolutePath,
    dependencies: Object.freeze([...new Set([absolutePath, ...loaded.dependencies.map(file => resolve(file))])]),
  });
}
