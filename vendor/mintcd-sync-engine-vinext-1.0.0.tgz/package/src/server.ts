import { openD1RecordDatabase } from "@mintcd/sync-engine/adapters/d1";
import type { D1Binding, D1CollectionMappings } from "@mintcd/sync-engine/adapters/d1";
import { createRecordSyncAuthority } from "@mintcd/sync-engine/server";
import { SyncError } from "@mintcd/sync-engine";
import { SyncHttpError, createSyncHandler } from "@mintcd/sync-engine/transport/http-server";
import type { SyncHandlerOptions } from "@mintcd/sync-engine/transport/http-server";
import { createCrudPolicy, exportRecordBootstrap } from "@mintcd/sync-engine/records";
import type { CrudModel, CrudModelDefinition, CrudIntent, CrudOperation, CrudRejection, CrudSchema, RecordDecisionPolicy, RecordBootstrapLimits } from "@mintcd/sync-engine/records";
export { createVinextD1Mappings } from "./mapping.js";

export interface VinextServerOptions<D extends CrudModelDefinition, Context> {
  readonly model: CrudModel<D>;
  readonly database: () => D1Binding;
  readonly collections: D1CollectionMappings<CrudSchema<D>>;
  readonly tablePrefix?: string;
  /** Limits apply to both the materialized snapshot and its encoded response. */
  readonly bootstrapLimits?: Partial<RecordBootstrapLimits>;
  readonly resolveContext: SyncHandlerOptions<CrudIntent<D>, CrudOperation<D>, CrudRejection, Context>["resolveContext"];
  readonly policy?: RecordDecisionPolicy<CrudSchema<D>, CrudIntent<D>, CrudOperation<D>, CrudRejection, Context>;
}

const bootstrapHeaders = () => ({ "content-type": "application/json; charset=utf-8", "cache-control": "no-store", "x-content-type-options": "nosniff" });

export function createVinextSyncHandler<D extends CrudModelDefinition, Context>(options: VinextServerOptions<D, Context>) {
  const openDatabase = (streamId: string) => openD1RecordDatabase({ database: options.database(), streamId, model: options.model, collections: options.collections,
    ...(options.tablePrefix === undefined ? {} : { tablePrefix: options.tablePrefix }),
  });
  const sync = createSyncHandler({ model: options.model, resolveContext: options.resolveContext,
    async getAuthority(_context, streamId) {
      const database = await openDatabase(streamId);
      return createRecordSyncAuthority({ database, model: options.model, policy: options.policy ?? createCrudPolicy(options.model) });
    },
  });
  return async (request: Request): Promise<Response> => {
    if (request.method !== "GET") return sync(request);
    try {
      request.signal.throwIfAborted();
      const parameters = new URL(request.url).searchParams;
      const fields = ["bootstrap", "protocolVersion", "contractVersion", "streamId"];
      if ([...parameters.keys()].some(key => !fields.includes(key)) || fields.some(key => parameters.getAll(key).length !== 1)
        || parameters.get("bootstrap") !== "1" || parameters.get("protocolVersion") !== "1") throw new SyncHttpError(400, "invalid-input", "Invalid snapshot bootstrap request.");
      const contractVersion = parameters.get("contractVersion")!;
      if (contractVersion !== options.model.contractVersion) throw new SyncHttpError(409, "contract-mismatch", "Sync contract version does not match.");
      const streamId = parameters.get("streamId")!;
      if (!streamId.trim() || streamId.length > 1024) throw new SyncHttpError(400, "invalid-input", "Invalid sync stream.");
      const scope = Object.freeze({ protocolVersion: 1 as const, contractVersion, streamId });
      // GET uses the exact same authentication, stream authorization and Origin/
      // CSRF hook as POST, and never obtains a D1 binding before it succeeds.
      const resolved = await options.resolveContext(request, scope);
      if (!resolved || typeof resolved !== "object" || resolved.streamId !== streamId) throw new SyncHttpError(403, "access-denied", "The requested sync stream is not authorized.");
      request.signal.throwIfAborted();
      const database = await openDatabase(streamId);
      const authority = await createRecordSyncAuthority({ database, model: options.model, policy: options.policy ?? createCrudPolicy(options.model) });
      // An empty application's first bootstrap must initialize authority metadata
      // through the same validated path as incremental synchronization.
      const initialized = (await database.transaction("readonly", tx => tx.getInternal("meta", ["authority"]))).value;
      if (initialized === undefined) await authority.synchronize({ protocolVersion: 1, contractVersion, streamId, baseSequence: 0, maximumEntries: 1, proposals: [] }, resolved.context);
      request.signal.throwIfAborted();
      const snapshot = await exportRecordBootstrap({ database, model: options.model, ...(options.bootstrapLimits === undefined ? {} : { limits: options.bootstrapLimits }) });
      request.signal.throwIfAborted();
      return new Response(JSON.stringify(snapshot), { status: 200, headers: bootstrapHeaders() });
    } catch (cause) {
      const error = cause instanceof SyncHttpError ? cause
        : cause instanceof SyncError && ["invalid-input", "contract-mismatch", "stream-mismatch", "limit-exceeded", "commit-conflict"].includes(cause.code)
          ? new SyncHttpError(cause.code === "limit-exceeded" ? 413 : cause.code === "commit-conflict" ? 503 : cause.code === "invalid-input" ? 400 : 409, cause.code, "Snapshot bootstrap could not be completed.")
          : request.signal.aborted ? new SyncHttpError(408, "request-aborted", "Snapshot bootstrap request was aborted.")
            : new SyncHttpError(500, "internal-error", "The sync endpoint failed to export its snapshot.");
      return new Response(JSON.stringify({ protocolVersion: 1, error: { code: error.code, message: error.message, retryable: error.retryable } }), { status: error.status, headers: bootstrapHeaders() });
    }
  };
}
