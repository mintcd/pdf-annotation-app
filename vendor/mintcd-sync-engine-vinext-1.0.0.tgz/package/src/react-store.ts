import type { SyncEngineSnapshot } from "@mintcd/sync-engine/client";
import type { PwaWorkerSnapshot } from "@mintcd/sync-engine/pwa/client";

export type VinextSyncState<Engine> =
  | { readonly phase: "idle" | "opening"; readonly engine: undefined; readonly status: undefined; readonly error: undefined }
  | { readonly phase: "ready"; readonly engine: Engine; readonly status: SyncEngineSnapshot; readonly error: unknown }
  | { readonly phase: "error"; readonly engine: undefined; readonly status: undefined; readonly error: unknown };

export interface ObservableVinextEngine {
  getSnapshot(): SyncEngineSnapshot;
  subscribe(listener: (snapshot: SyncEngineSnapshot) => void): () => void;
  getWorkerSnapshot(): PwaWorkerSnapshot;
  subscribeWorker(listener: (snapshot: PwaWorkerSnapshot) => void): () => void;
  close(): Promise<void>;
}

export const idleVinextSyncState = Object.freeze({ phase: "idle", engine: undefined, status: undefined, error: undefined } as const);
export const openingVinextSyncState = Object.freeze({ phase: "opening", engine: undefined, status: undefined, error: undefined } as const);

/** Browser resources belong to subscriptions, never renders or configuration creation. */
export function createVinextSyncStore<Engine extends ObservableVinextEngine>(open: () => Promise<Engine>) {
  const listeners = new Set<() => void>();
  let snapshot: VinextSyncState<Engine> = openingVinextSyncState;
  let engine: Engine | undefined;
  let unsubscribeStatus: (() => void) | undefined;
  let unsubscribeWorker: (() => void) | undefined;
  let generation = 0;
  let cleanupTicket = 0;
  let started = false;
  // Opening and closing are serialized so a replacement never overlaps old cleanup.
  let work = Promise.resolve();

  function publish(value: VinextSyncState<Engine>): void {
    snapshot = Object.freeze(value);
    for (const listener of listeners) { try { listener(); } catch { /* React observers do not own the session lifecycle. */ } }
  }
  function detach(): void {
    unsubscribeStatus?.(); unsubscribeStatus = undefined;
    unsubscribeWorker?.(); unsubscribeWorker = undefined;
  }
  function enqueueClose(owned: Engine | undefined): Promise<void> {
    const cleanup = work.then(() => owned?.close());
    work = cleanup.catch(error => {
      if (listeners.size) publish({ phase: "error", engine: undefined, status: undefined, error });
    });
    return cleanup;
  }
  function stop(error: unknown): Promise<void> {
    ++generation;
    started = true;
    detach();
    const owned = engine; engine = undefined;
    publish({ phase: "error", engine: undefined, status: undefined, error });
    return enqueueClose(owned);
  }
  function observe(): void {
    if (!engine) return;
    const status = engine.getSnapshot();
    if (status.phase === "closed") {
      void stop(new Error("The sync session was closed. Sign in again to open a new session.")).catch(() => undefined);
      return;
    }
    const worker = engine.getWorkerSnapshot();
    publish({ phase: "ready", engine, status, error: worker.phase === "error" ? worker.lastError : status.lastError });
  }
  function start(): void {
    if (started) return;
    started = true;
    const current = ++generation;
    publish(openingVinextSyncState);
    work = work.then(async () => {
      if (current !== generation || !listeners.size) return;
      let opened: Engine | undefined;
      try {
        opened = await open();
        if (current !== generation || !listeners.size) { await opened.close(); return; }
        engine = opened;
        unsubscribeStatus = opened.subscribe(observe);
        unsubscribeWorker = opened.subscribeWorker(observe);
        observe();
      } catch (error) {
        if (engine === opened) { detach(); engine = undefined; }
        try { await opened?.close(); }
        catch (cause) { error = new AggregateError([error, cause], "Opening and cleaning up the sync session failed."); }
        if (current === generation) publish({ phase: "error", engine: undefined, status: undefined, error });
      }
    });
  }
  return {
    getSnapshot: () => snapshot,
    subscribe(listener: () => void) {
      ++cleanupTicket;
      listeners.add(listener);
      start();
      let subscribed = true;
      return () => {
        if (!subscribed) return;
        subscribed = false;
        listeners.delete(listener);
        if (listeners.size) return;
        const ticket = ++cleanupTicket;
        // React StrictMode immediately subscribes again after its cleanup probe.
        queueMicrotask(() => {
          if (ticket !== cleanupTicket || listeners.size) return;
          ++generation;
          started = false;
          detach();
          const owned = engine; engine = undefined;
          snapshot = openingVinextSyncState;
          void enqueueClose(owned).catch(() => undefined);
        });
      };
    },
    stop,
  };
}
