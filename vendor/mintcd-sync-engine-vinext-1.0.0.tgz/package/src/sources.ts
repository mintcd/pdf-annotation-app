import { planVinextGeneration } from "@mintcd/sync-engine/integrations/vinext";
import { legacyConfig } from "./config.js";
import type { SyncVinextConfig } from "./config.js";

export const sourceLiteral = (value: unknown): string => JSON.stringify(value, null, 2).replace(/</g, "\\u003c").replace(/\u2028/g, "\\u2028").replace(/\u2029/g, "\\u2029");

export function modelSource(config: SyncVinextConfig): string {
  const definition = { contractVersion: config.contractVersion, ...(config.schemaVersion ? { schemaVersion: config.schemaVersion } : {}), collections: config.collections };
  return `const model = defineCrudModel(${sourceLiteral(definition)} as const);\n`;
}

export function runtimeSource(config: SyncVinextConfig): string {
  return `const runtime = ${sourceLiteral({ appId: config.appId, ...(config.deploymentVersion === undefined ? {} : { deploymentVersion: config.deploymentVersion }), endpoint: config.endpoint ?? "/api/sync", contractVersion: config.contractVersion, replicaKeys: config.replicaKeys, pwa: Boolean(config.pwa) })} as const;\n`;
}

/** Build inputs stay virtual; neither worker nor server imports the React facade. */
export function vinextPwaSources(config: SyncVinextConfig): { readonly worker: string; readonly registration: string } {
  const plan = planVinextGeneration(legacyConfig(config));
  const worker = plan.files.find(file => file.path === "sync/worker.generated.ts")!.content;
  const registration = plan.files.find(file => file.path === "sync/register.generated.ts")!.content;
  return {
    worker: worker.replace(/import \{ syncWorkerOptions \} from [^\n]+\n/, () => `import { defineCrudModel } from "@mintcd/sync-engine/records";\nimport { createVinextWorkerOptions } from "@mintcd/sync-engine-vinext/worker";\n${modelSource(config)}${runtimeSource(config)}const syncWorkerOptions = createVinextWorkerOptions(model, runtime);\n`),
    registration,
  };
}
