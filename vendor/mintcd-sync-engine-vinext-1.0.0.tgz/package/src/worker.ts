import { createSyncEngine } from "@mintcd/sync-engine/client";
import { crudCollections } from "@mintcd/sync-engine/records";
import type { CrudModel, CrudModelDefinition } from "@mintcd/sync-engine/records";
import type { CreateSyncWorkerHostOptions } from "@mintcd/sync-engine/pwa/worker";
import { openRegistry, openVinextSession } from "./session.js";
import type { VinextRuntimeConfig } from "./session.js";

export function createVinextWorkerOptions<D extends CrudModelDefinition>(model: CrudModel<D>, config: VinextRuntimeConfig): CreateSyncWorkerHostOptions {
  return {
    contractVersion: model.contractVersion, replicaKeys: config.replicaKeys,
    async openSession(key, { signal }) {
      const registry = await openRegistry(config);
      let closeSession: (() => Promise<void>) | undefined;
      try {
        const session = await openVinextSession(model, config, registry, key, signal);
        closeSession = session.close;
        const engine = await createSyncEngine({ replica: session.replica, transport: session.transport, collections: crudCollections(model), autoSync: false });
        return { engine, signal: session.lease.signal, assertEnabled: () => session.lease.assertEnabled(),
          async close() { try { await session.close(); } finally { registry.close(); } },
        };
      } catch (error) { try { await closeSession?.(); } finally { registry.close(); } throw error; }
    },
  };
}
