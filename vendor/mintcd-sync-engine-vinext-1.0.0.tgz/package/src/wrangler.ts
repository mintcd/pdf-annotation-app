import { execFile } from "node:child_process";
import { createRequire } from "node:module";
import { readFile } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { pathToFileURL } from "node:url";
import { promisify } from "node:util";
import { discoverD1Schema } from "./discovery.js";
import { parseJsonc } from "./jsonc.js";
import { relativeFile } from "./config.js";

const execute = promisify(execFile);
async function projectWrangler(root: string, args: readonly string[]): Promise<string> {
  const require = createRequire(pathToFileURL(resolve(root, "package.json")));
  let manifestPath: string;
  try { manifestPath = require.resolve("wrangler/package.json"); }
  catch { throw new Error("Install Wrangler in the application first: npm install --save-dev wrangler."); }
  const manifest = JSON.parse(await readFile(manifestPath, "utf8")) as { bin: string | Record<string, string> };
  const bin = typeof manifest.bin === "string" ? manifest.bin : manifest.bin.wrangler;
  if (!bin) throw new Error("The installed Wrangler package has no CLI entry.");
  try {
    const result = await execute(process.execPath, [resolve(dirname(manifestPath), bin), ...args], {
      cwd: root, maxBuffer: 8 * 1024 * 1024, timeout: 120_000,
      env: { ...process.env, WRANGLER_SEND_METRICS: "false", NO_COLOR: "1" },
    });
    return result.stdout;
  } catch { throw new Error("Wrangler could not complete the requested command. Check the selected environment and your local Wrangler authentication."); }
}
export interface DiscoverConfiguredD1Options {
  readonly root: string;
  readonly wrangler?: string;
  readonly binding: string;
  readonly environment?: string;
  readonly location: "local" | "remote";
  readonly tables: readonly string[];
}
/** Explicit read-only discovery. Normal generation/build never invokes Wrangler. */
export async function discoverConfiguredD1(options: DiscoverConfiguredD1Options) {
  const configPath = options.wrangler ?? "wrangler.jsonc";
  relativeFile(configPath);
  if (!["local", "remote"].includes(options.location)) throw new TypeError("Select --local or --remote explicitly.");
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(options.binding) || options.environment !== undefined && !/^[A-Za-z0-9_-]+$/.test(options.environment)) throw new TypeError("Invalid binding or environment name.");
  const platform = parseJsonc(await readFile(resolve(options.root, configPath), "utf8")) as { d1_databases?: { binding?: string }[]; env?: Record<string, { d1_databases?: { binding?: string }[] }> };
  const selected = options.environment === undefined ? platform : platform.env?.[options.environment];
  if (selected?.d1_databases?.filter(value => value.binding === options.binding).length !== 1) throw new TypeError("Selected Wrangler environment must declare exactly one matching D1 binding.");
  return discoverD1Schema({ tables: options.tables, async query(sql) {
    const output = await projectWrangler(options.root, ["d1", "execute", options.binding, `--${options.location}`, "--config", configPath,
      ...(options.environment === undefined ? [] : ["--env", options.environment]), "--command", sql, "--json"]);
    const result = JSON.parse(output) as { success: boolean; results: Record<string, unknown>[] }[];
    if (!Array.isArray(result) || result.length !== 1 || !result[0]?.success || !Array.isArray(result[0].results)) throw new Error("Wrangler returned invalid schema metadata.");
    return result[0].results;
  } });
}

export async function generateWranglerTypes(options: { readonly root: string; readonly wrangler?: string; readonly environment?: string }) {
  const configPath = options.wrangler ?? "wrangler.jsonc";
  relativeFile(configPath);
  if (options.environment !== undefined && !/^[A-Za-z0-9_-]+$/.test(options.environment)) throw new TypeError("Invalid Wrangler environment.");
  return projectWrangler(options.root, ["types", "--config", configPath, ...(options.environment === undefined ? [] : ["--env", options.environment])]);
}
