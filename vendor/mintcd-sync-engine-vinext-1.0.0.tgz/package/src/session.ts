import { openIndexedDbRecordDatabase } from "@mintcd/sync-engine/adapters/indexeddb";
import type { IndexedDbRecordDatabase } from "@mintcd/sync-engine/adapters/indexeddb";
import { installRecordBootstrap, openRecordReplica } from "@mintcd/sync-engine/records";
import type { CrudModel, CrudModelDefinition, CrudSchema, CrudIntent, CrudOperation, CrudRejection, RecordReplica } from "@mintcd/sync-engine/records";
import { openPwaReplicaRegistry } from "@mintcd/sync-engine/pwa/registry";
import type { PwaReplicaDescriptor, PwaReplicaRegistration, PwaReplicaRegistry, PwaReplicaLease } from "@mintcd/sync-engine/pwa/registry";
import { createHttpSyncTransport } from "@mintcd/sync-engine/transport/http-client";
import type { SyncRunOptions } from "@mintcd/sync-engine/client";
import type { SyncTransport } from "@mintcd/sync-engine";

export interface VinextRuntimeConfig {
  readonly appId: string;
  /** Optional fallback deployment marker; a client option takes precedence. */
  readonly deploymentVersion?: string;
  readonly endpoint: string;
  readonly contractVersion: string;
  readonly replicaKeys: readonly string[];
  readonly pwa: boolean;
}
export interface VinextClientOptions {
  readonly accountId: string;
  readonly streamId: string;
  /** Change this for every app deployment to rebuild from the authenticated D1 snapshot. */
  readonly deploymentVersion?: string;
  readonly replicaKey?: string;
  /** Explicit authenticated bootstrap/sign-in. Recovery never recreates lost state. */
  readonly initialize?: boolean;
  /** Explicitly start a new replica instead of resuming retained local work. */
  readonly freshStart?: boolean;
  readonly autoSync?: boolean;
  readonly syncOptions?: SyncRunOptions;
}
export interface VinextSession<D extends CrudModelDefinition> {
  readonly database: IndexedDbRecordDatabase<CrudSchema<D>>;
  readonly replica: RecordReplica<CrudSchema<D>, CrudIntent<D>, CrudOperation<D>, CrudRejection>;
  readonly transport: SyncTransport<CrudIntent<D>, CrudOperation<D>, CrudRejection>;
  readonly lease: PwaReplicaLease;
  close(): Promise<void>;
}
export const registryName = (config: VinextRuntimeConfig) => `sync-engine:${config.appId}:registry`;
export const openRegistry = (config: VinextRuntimeConfig) => openPwaReplicaRegistry({ name: registryName(config) });
function assertKey(config: VinextRuntimeConfig, key: string) {
  if (!config.replicaKeys.includes(key)) throw new TypeError("Replica key is not declared by this application.");
}

const maximumBootstrapBytes = 8 * 1024 * 1024;
function deploymentVersion(config: VinextRuntimeConfig, options?: Pick<VinextClientOptions, "deploymentVersion">): string | undefined {
  const value = options?.deploymentVersion ?? config.deploymentVersion;
  if (value !== undefined && (typeof value !== "string" || !/^[A-Za-z0-9_.:/-]{1,128}$/.test(value))) throw new TypeError("Invalid deploymentVersion.");
  return value;
}
async function deleteReplicaDatabase(name: string): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const deletion = indexedDB.deleteDatabase(name);
    deletion.onsuccess = () => resolve();
    deletion.onerror = () => reject(deletion.error);
    deletion.onblocked = () => reject(new Error("Bootstrap candidate database is still open."));
  });
}
async function fetchBootstrap(config: VinextRuntimeConfig, streamId: string, contractVersion: string): Promise<unknown> {
  const url = new URL(config.endpoint, globalThis.location.origin);
  if (url.origin !== globalThis.location.origin) throw new TypeError("Deployment bootstrap requires a same-origin sync endpoint.");
  url.search = new URLSearchParams({ bootstrap: "1", protocolVersion: "1", contractVersion, streamId }).toString();
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(new Error("Deployment bootstrap timed out. Retry when connected.")), 30_000);
  try {
    const response = await fetch(url.href, { method: "GET", credentials: "same-origin", redirect: "error", cache: "no-store", headers: { accept: "application/json" }, signal: controller.signal });
    if (response.redirected || response.type === "opaqueredirect") { await response.body?.cancel(); throw new TypeError("Deployment bootstrap redirects are not allowed."); }
    if (!response.ok) {
      await response.body?.cancel();
      throw new Error(`Deployment bootstrap failed (HTTP ${response.status}). Sign in and retry; the previous local replica is retained.`);
    }
    if (!/^application\/json(?:\s*;|$)/i.test(response.headers.get("content-type") ?? "")) { await response.body?.cancel(); throw new TypeError("Deployment bootstrap returned a non-JSON snapshot."); }
    const length = response.headers.get("content-length");
    if (length !== null && (!/^\d+$/.test(length) || Number(length) > maximumBootstrapBytes)) { await response.body?.cancel(); throw new TypeError("Deployment bootstrap snapshot exceeds the supported size."); }
    if (!response.body) throw new TypeError("Deployment bootstrap snapshot is empty.");
    const reader = response.body.getReader();
    const decoder = new TextDecoder("utf-8", { fatal: true });
    let bytes = 0, text = "";
    try {
      while (true) {
        const chunk = await reader.read();
        if (chunk.done) break;
        bytes += chunk.value.byteLength;
        if (bytes > maximumBootstrapBytes) throw new TypeError("Deployment bootstrap snapshot exceeds the supported size.");
        text += decoder.decode(chunk.value, { stream: true });
      }
      text += decoder.decode();
      return JSON.parse(text) as unknown;
    } catch (error) { await reader.cancel().catch(() => undefined); throw error; }
    finally { reader.releaseLock(); }
  } finally { clearTimeout(timeout); }
}
async function assertRetainedWorkIsSettled(retained: PwaReplicaRegistration): Promise<void> {
  // Inspect only the retained adapter's versioned bookkeeping. Opening it with
  // the new model would reject a safe rebuild whenever the schema has changed.
  const database = await new Promise<IDBDatabase>((resolve, reject) => {
    const opening = indexedDB.open(retained.databaseName);
    let failure: Error | undefined;
    opening.onupgradeneeded = () => {
      failure = new Error("Retained local replica storage is missing; its descriptor was preserved. An explicit reset is required.");
      opening.transaction!.abort();
    };
    opening.onerror = () => reject(failure ?? opening.error);
    opening.onsuccess = () => resolve(opening.result);
  });
  let drained: Promise<void> | undefined;
  const object = (value: unknown): Record<string, unknown> => {
    if (!value || typeof value !== "object" || Array.isArray(value)) throw new TypeError("Retained replica metadata is invalid; its local data was preserved.");
    return value as Record<string, unknown>;
  };
  const count = (value: unknown): value is number => typeof value === "number" && Number.isSafeInteger(value) && value >= 0;
  try {
    const transaction = database.transaction(["__sync_metadata", "internal:meta", "internal:pending", "internal:outbox"], "readonly");
    drained = new Promise<void>((resolve, reject) => {
      transaction.oncomplete = () => resolve();
      transaction.onabort = () => reject(transaction.error ?? new Error("Retained replica inspection was aborted."));
    });
    void drained.catch(() => undefined);
    const read = <Value>(request: IDBRequest<Value>) => new Promise<Value>((resolve, reject) => {
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
    const metadata = transaction.objectStore("__sync_metadata");
    const streamRange = IDBKeyRange.bound([retained.streamId], [retained.streamId, [[]]], false, true);
    const values = await Promise.all([
      read(metadata.get(["schema"])), read(metadata.get(["stream", retained.streamId])),
      read(transaction.objectStore("internal:meta").get([retained.streamId, ["replica"]])),
      read(transaction.objectStore("internal:pending").count(streamRange)),
      read(transaction.objectStore("internal:outbox").count(streamRange)),
    ]);
    await drained;
    const schema = object(values[0]), stream = object(values[1]), envelope = object(values[2]);
    const meta = object(envelope.value);
    if (schema.format !== "record-indexeddb-v1" || typeof schema.schemaIdentity !== "string" || !schema.schemaIdentity
      || stream.schemaIdentity !== schema.schemaIdentity || !count(stream.revision)
      || envelope.streamId !== retained.streamId || !Array.isArray(envelope.key) || envelope.key.length !== 1 || envelope.key[0] !== "replica"
      || meta.kind !== "record-replica-v1" || meta.clientId !== retained.clientId || meta.contractVersion !== retained.contractVersion
      || meta.schemaIdentity !== schema.schemaIdentity || typeof meta.schemaVersion !== "string" || !meta.schemaVersion
      || !count(meta.pendingCount) || !count(meta.acceptedAwaitingCount)
      || !count(meta.confirmedSequence) || !count(meta.headSequence) || meta.headSequence < meta.confirmedSequence
      || !count(meta.nextClientSequence) || meta.nextClientSequence < 1
      || meta.pendingCount !== values[3] || meta.pendingCount + meta.acceptedAwaitingCount !== values[4]) throw new TypeError("Retained replica metadata is invalid; its local data was preserved.");
    if (meta.pendingCount || meta.acceptedAwaitingCount) throw new Error("Replica replacement is paused because the previous local replica has unsynced edits. Sign into its previous account and app version, finish syncing those edits, and retry. Its database and client identity are retained.");
  } finally { await drained?.catch(() => undefined); database.close(); }
}

export async function initializeVinextReplica<D extends CrudModelDefinition>(model: CrudModel<D>, config: VinextRuntimeConfig, registry: PwaReplicaRegistry, options: VinextClientOptions) {
  const key = options.replicaKey ?? "main";
  assertKey(config, key);
  const version = deploymentVersion(config, options);
  if (typeof options.accountId !== "string" || !options.accountId || typeof options.streamId !== "string" || !options.streamId) throw new TypeError("accountId and streamId are required.");
  const locks = globalThis.navigator?.locks;
  if (!locks) throw new TypeError("Generated PWA sessions require Web Locks.");
  await locks.request(`${registryName(config)}:bootstrap`, async () => {
    const present = await registry.get(key);
    const sameScope = present?.accountId === options.accountId && present.streamId === options.streamId;
    if (present?.enabled && !sameScope) throw new TypeError("Close and log out the existing replica before switching accounts or streams.");
    const rebuild = version !== undefined && (!sameScope || present?.deploymentVersion !== version);
    if (present?.enabled && !rebuild) return;
    if (!present?.enabled && !options.initialize) throw new TypeError("Replica is not initialized. Pass initialize: true after authenticating the account.");
    if (present && !options.freshStart && sameScope && !rebuild) {
      // Explicit sign-in resumes preserved work; eviction must surface as recovery failure.
      const database = await openIndexedDbRecordDatabase({ name: present.databaseName, streamId: present.streamId, schema: model.schema, requireExisting: true });
      try {
        const replica = await openRecordReplica({ database, clientId: present.clientId, model, requireExisting: true });
        await replica.close();
      } finally { await database.closeAndDrain(); }
      const { enabled: _enabled, generation: _generation, ...descriptor } = present;
      await registry.enable(descriptor);
      return;
    }
    const descriptor: PwaReplicaDescriptor = {
      replicaKey: key, accountId: options.accountId, streamId: options.streamId,
      databaseName: `sync-engine:${config.appId}:${crypto.randomUUID()}`,
      clientId: crypto.randomUUID(), contractVersion: model.contractVersion, modelKey: config.appId,
      ...(version === undefined ? {} : { deploymentVersion: version }),
    };
    let published = false;
    let publicationAttempted = false;
    try {
      // Finish the authenticated, bounded snapshot before changing registration.
      const snapshot = version === undefined ? undefined : await fetchBootstrap(config, options.streamId, model.contractVersion);
      const database = await openIndexedDbRecordDatabase({ name: descriptor.databaseName, streamId: descriptor.streamId, schema: model.schema });
      try {
        if (version !== undefined) await installRecordBootstrap({ database, clientId: descriptor.clientId, model, snapshot });
        const replica = await openRecordReplica({ database, clientId: descriptor.clientId, model, ...(version === undefined ? {} : { requireExisting: true }) });
        await replica.close();
      } finally { await database.closeAndDrain(); }
      publicationAttempted = true;
      if (present) {
        await registry.replace(key, async retained => {
          if (retained.databaseName !== present.databaseName || retained.clientId !== present.clientId || retained.generation !== present.generation) throw new TypeError("The retained replica changed while preparing its replacement. Retry.");
          // All cooperating pages/workers have drained before this final barrier.
          if (!options.freshStart) await assertRetainedWorkIsSettled(retained);
          return descriptor;
        });
      } else await registry.enable(descriptor);
      published = true;
    } finally {
      if (!published) {
        // A storage error after commit can make publication ambiguous. Never
        // remove a candidate that may already be the durable active replica.
        const disposable = !publicationAttempted || await registry.get(key).then(current => current?.databaseName !== descriptor.databaseName, () => false);
        if (disposable) await deleteReplicaDatabase(descriptor.databaseName).catch(() => undefined);
      }
    }
  });
}

/** Shared page/worker recovery. Hold the lease until native database writes drain. */
export async function openVinextSession<D extends CrudModelDefinition>(model: CrudModel<D>, config: VinextRuntimeConfig, registry: PwaReplicaRegistry, key: string, signal?: AbortSignal, expected?: { readonly accountId: string; readonly streamId: string; readonly deploymentVersion?: string }): Promise<VinextSession<D>> {
  assertKey(config, key);
  const lease = await registry.acquire(key, signal === undefined ? {} : { signal });
  let database: Awaited<ReturnType<typeof openIndexedDbRecordDatabase<typeof model.schema>>> | undefined;
  let replica: Awaited<ReturnType<typeof openRecordReplica<typeof model.schema, Parameters<typeof model.intent.encode>[0], Parameters<typeof model.operation.encode>[0], Parameters<typeof model.rejection.encode>[0]>>> | undefined;
  try {
    await lease.assertEnabled();
    const descriptor = lease.descriptor;
    if (expected && (descriptor.accountId !== expected.accountId || descriptor.streamId !== expected.streamId)) throw new TypeError("The active account or stream changed while opening the client.");
    const expectedVersion = deploymentVersion(config, expected);
    if (expectedVersion !== undefined && descriptor.deploymentVersion !== expectedVersion) throw new TypeError("The app deployment changed while opening the client. Retry bootstrap.");
    if (descriptor.contractVersion !== model.contractVersion || descriptor.modelKey !== config.appId) throw new TypeError("Replica model version does not match. An explicit migration is required.");
    database = await openIndexedDbRecordDatabase({ name: descriptor.databaseName, streamId: descriptor.streamId, schema: model.schema, requireExisting: true });
    replica = await openRecordReplica({ database, clientId: descriptor.clientId, model, requireExisting: true });
    await lease.assertEnabled();
    const transport = createHttpSyncTransport({
      url: new URL(config.endpoint, globalThis.location.origin).href,
      streamId: descriptor.streamId, model,
      headers: async () => { await lease.assertEnabled(); return {}; },
      fetch: (input, init) => fetch(input, { ...init, credentials: "same-origin" }),
    });
    const ownedDatabase = database;
    const ownedReplica = replica;
    let closing: Promise<void> | undefined;
    const close = () => closing ??= (async () => {
      try { await ownedReplica.close(); }
      finally { try { await ownedDatabase.closeAndDrain(); } finally { await lease.release(); } }
    })();
    return { database: ownedDatabase, replica: ownedReplica, transport, lease, close };
  } catch (error) {
    try { await replica?.close(); }
    finally { try { await database?.closeAndDrain(); } finally { await lease.release(); } }
    throw error;
  }
}
