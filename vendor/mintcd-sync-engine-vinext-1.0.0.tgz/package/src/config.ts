import { defineCrudModel } from "@mintcd/sync-engine/records";
import type { CrudCollectionDefinition, CrudFieldDefinition, CrudModelDefinition } from "@mintcd/sync-engine/records";
import { parseVinextGeneratorConfig } from "@mintcd/sync-engine/integrations/vinext";
import type { VinextPwaConfig, VinextGeneratorConfig } from "@mintcd/sync-engine/integrations/vinext";

export interface SyncVinextConfig extends CrudModelDefinition {
  readonly version: 1;
  readonly appId: string;
  /** Optional fixed deployment marker; a client option can override it at runtime. */
  readonly deploymentVersion?: string;
  readonly wrangler: { readonly config?: string; readonly binding: string; readonly environment?: string };
  readonly appDirectory?: "app" | "src/app";
  readonly endpoint?: string;
  readonly serverModule?: string;
  readonly replicaKeys?: readonly string[];
  readonly pwa?: Omit<VinextPwaConfig, "appId" | "workerModule">;
}

type KnownProperties<Value, Shape> = {
  readonly [Property in Exclude<keyof Value, keyof Shape>]: never;
};
type KeyField<Collection extends CrudCollectionDefinition, Primary extends boolean> = {
  readonly [Field in keyof Collection["fields"] & string]:
    Exclude<Collection["fields"][Field]["type"], "boolean"> extends never ? never
      : Primary extends true
        ? Collection["fields"][Field] extends { readonly optional: true } | { readonly nullable: true } ? never : Field
        : Field;
}[keyof Collection["fields"] & string];
type CheckedCollection<Collection extends CrudCollectionDefinition> =
  KnownProperties<Collection, CrudCollectionDefinition> & {
    readonly fields: {
      readonly [Field in keyof Collection["fields"]]: KnownProperties<Collection["fields"][Field], CrudFieldDefinition>;
    };
    readonly primaryKey: readonly KeyField<Collection, true>[];
    readonly indexes?: Readonly<Record<string, readonly KeyField<Collection, false>[]>>;
  };
type CheckedConfig<Config extends SyncVinextConfig> =
  KnownProperties<Config, SyncVinextConfig> & {
    readonly wrangler: KnownProperties<Config["wrangler"], SyncVinextConfig["wrangler"]>;
    readonly collections: {
      readonly [Collection in keyof Config["collections"]]: CheckedCollection<Config["collections"][Collection]>;
    };
  };

/** Validate a TypeScript configuration while preserving its literal schema types.
 * Returns the same normalized, frozen representation as the JSON parser.
 * This helper does not read files, load modules or contact a database.
 */
export function defineSyncConfig<const Config extends SyncVinextConfig>(config: Config & CheckedConfig<Config>): Config {
  return parseSyncVinextConfig(config) as Config;
}

export function relativeFile(value: unknown): asserts value is string {
  if (typeof value !== "string" || value.length > 512 || !/^[A-Za-z0-9_.-]+(?:\/[A-Za-z0-9_.-]+)*$/.test(value)
    || value.split("/").some(part => part === "." || part === ".." || /^(?:node_modules|\.git|\.sync-engine)$/i.test(part))) throw new TypeError("Expected a portable file path inside the application.");
}
function plain(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value) || ![null, Object.prototype].includes(Object.getPrototypeOf(value))) throw new TypeError("Expected a JSON configuration object.");
  if (Object.getOwnPropertySymbols(value).length || Object.values(Object.getOwnPropertyDescriptors(value)).some(descriptor => !descriptor.enumerable || !("value" in descriptor))) throw new TypeError("Configuration must contain ordinary JSON properties.");
  return value as Record<string, unknown>;
}
export function parseSyncVinextConfig(value: unknown): SyncVinextConfig {
  const input = plain(value);
  const allowed = ["version", "appId", "deploymentVersion", "contractVersion", "schemaVersion", "collections", "wrangler", "appDirectory", "endpoint", "serverModule", "replicaKeys", "pwa"];
  if (Object.keys(input).some(field => !allowed.includes(field)) || input.version !== 1) throw new TypeError("Unsupported sync-engine-vinext configuration.");
  if (typeof input.appId !== "string" || !/^[a-z][a-z0-9_]{0,31}$/.test(input.appId)) throw new TypeError("appId must use 1 to 32 lowercase letters, digits or underscores.");
  if (input.deploymentVersion !== undefined && (typeof input.deploymentVersion !== "string" || !/^[A-Za-z0-9_.:/-]{1,128}$/.test(input.deploymentVersion))) throw new TypeError("Invalid deploymentVersion.");
  const wrangler = plain(input.wrangler);
  if (Object.keys(wrangler).some(field => !["config", "binding", "environment"].includes(field)) || typeof wrangler.binding !== "string" || !/^[A-Za-z_][A-Za-z0-9_]*$/.test(wrangler.binding)) throw new TypeError("A D1 binding name is required.");
  relativeFile(wrangler.config ?? "wrangler.jsonc");
  relativeFile(input.serverModule ?? "sync/server.ts");
  if (typeof input.serverModule === "string" && input.serverModule.toLowerCase() === "sync/generated.ts") throw new TypeError("serverModule must be an application-owned .ts file.");
  if (wrangler.environment !== undefined && (typeof wrangler.environment !== "string" || !/^[A-Za-z0-9_-]+$/.test(wrangler.environment))) throw new TypeError("Invalid Wrangler environment.");
  const definition = { contractVersion: input.contractVersion, ...(input.schemaVersion === undefined ? {} : { schemaVersion: input.schemaVersion }), collections: input.collections } as CrudModelDefinition;
  const model = defineCrudModel(definition);
  for (const [name, collection] of Object.entries(model.definition.collections)) {
    if (!/^[A-Za-z_][A-Za-z0-9_]{0,39}$/.test(name)) throw new TypeError("Collection names must be short SQL identifiers.");
    for (const field of Object.keys(collection.fields)) if (!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(field) || field.toLowerCase().startsWith("__sync_")) throw new TypeError("Fields must be ordinary SQL identifiers.");
  }
  const keys = input.replicaKeys ?? ["main"];
  if (!Array.isArray(keys) || !keys.length || keys.length > 256 || new Set(keys).size !== keys.length || keys.some(key => typeof key !== "string" || !/^[A-Za-z0-9_-]{1,128}$/.test(key))) throw new TypeError("replicaKeys must contain distinct portable names.");
  const config = { ...input, ...model.definition, replicaKeys: Object.freeze([...keys]), wrangler: Object.freeze({ ...wrangler, config: wrangler.config ?? "wrangler.jsonc" }) } as unknown as SyncVinextConfig;
  const validated = legacyConfig(config); // Reuse the endpoint, source path and PWA validation contract.
  return Object.freeze({ ...config, ...(validated.pwa ? { pwa: validated.pwa } : {}) });
}

export function legacyConfig(config: SyncVinextConfig): VinextGeneratorConfig {
  return parseVinextGeneratorConfig({ version: 1, contractVersion: config.contractVersion,
    appDirectory: config.appDirectory ?? "app", endpoint: config.endpoint ?? "/api/sync",
    serverModule: config.serverModule ?? "sync/server.ts", clientModule: "sync/generated.ts",
    ...(config.pwa ? { pwa: { ...config.pwa, appId: config.appId, workerModule: "sync/worker-options.generated.ts" } } : {}),
  });
}
