import type { CrudCollectionDefinition, CrudFieldDefinition } from "@mintcd/sync-engine/records";

export interface D1SchemaDiscoveryOptions {
  /** An explicit application table allowlist; discovery never enumerates the database. */
  readonly tables: readonly string[];
  /** Caller-owned local or remote connection. Only metadata-reading PRAGMAs are issued. */
  readonly query: (sql: string) => Promise<readonly Record<string, unknown>[]>;
}
export interface D1SchemaDiscoveryWarning {
  readonly code: string;
  readonly table: string;
  readonly column?: string;
  readonly index?: string;
  readonly message: string;
}
export interface D1SchemaDiscoveryDraft {
  readonly sourceTables: readonly string[];
  /** Draft declarations only. Unresolved fields may be omitted and primaryKey may be empty. */
  readonly collections: Readonly<Record<string, CrudCollectionDefinition>>;
  readonly warnings: readonly D1SchemaDiscoveryWarning[];
  readonly unresolved: readonly D1SchemaDiscoveryWarning[];
  readonly metadata: {
    readonly kind: "d1-schema-draft";
    readonly version: 1;
    readonly reviewRequired: true;
    readonly rowsRead: false;
    readonly writesPerformed: false;
  };
}

const identifierPattern = /^[A-Za-z_][A-Za-z0-9_]{0,127}$/;
function identifier(value: unknown): value is string { return typeof value === "string" && identifierPattern.test(value); }
function quote(value: string): string {
  if (!identifier(value)) throw new TypeError("Schema discovery requires ordinary SQL identifiers of at most 128 characters.");
  return `"${value.replaceAll('"', '""')}"`;
}
function reservedTable(name: string): boolean { return /^(sqlite_|sync_|__sync_|_cf_|cloudflare_)/i.test(name) || name.toLowerCase() === "d1_migrations"; }
function integer(value: unknown): value is number { return typeof value === "number" && Number.isSafeInteger(value); }
function scalar(type: string): CrudFieldDefinition["type"] | undefined {
  // Declared affinities provide a starting point, not a guarantee about stored values.
  const name = type.trim().toUpperCase();
  if (/BOOL|DATE|TIME|JSON/.test(name)) return undefined;
  if (/INT/.test(name)) return "number";
  if (/CHAR|CLOB|TEXT/.test(name)) return "string";
  if (/REAL|FLOA|DOUB/.test(name)) return "number";
  return undefined;
}

/** Inspect only explicitly selected tables and return a draft requiring application review. */
export async function discoverD1Schema(options: D1SchemaDiscoveryOptions): Promise<D1SchemaDiscoveryDraft> {
  if (!options || typeof options.query !== "function" || !Array.isArray(options.tables) || options.tables.length === 0) throw new TypeError("Discovery requires a read-only query port and an explicit nonempty table allowlist.");
  const tables = [...options.tables];
  if (tables.some(table => !identifier(table) || reservedTable(table)) || new Set(tables.map(table => table.toLowerCase())).size !== tables.length) throw new TypeError("Discovery table names must be distinct application identifiers; engine and system tables are excluded.");
  const warnings: D1SchemaDiscoveryWarning[] = [];
  const unresolved: D1SchemaDiscoveryWarning[] = [];
  const collections: Record<string, CrudCollectionDefinition> = Object.create(null) as Record<string, CrudCollectionDefinition>;
  const report = (warning: D1SchemaDiscoveryWarning, blocksField = false): void => { warnings.push(Object.freeze(warning)); if (blocksField) unresolved.push(warning); };
  const query = async (pragma: "table_xinfo" | "table_info" | "index_list" | "index_xinfo" | "index_info" | "foreign_key_list", name: string) => {
    const result = await options.query(`PRAGMA ${pragma}(${quote(name)});`);
    if (!Array.isArray(result) || result.some(row => row === null || typeof row !== "object" || Array.isArray(row))) throw new TypeError("Discovery query results must be metadata row objects.");
    return result;
  };
  for (const table of tables) {
    let columns: readonly Record<string, unknown>[];
    let extended = true;
    try { columns = await query("table_xinfo", table); }
    catch { columns = []; }
    if (columns.length === 0) {
      extended = false;
      columns = await query("table_info", table);
      if (columns.length > 0) report({ code: "column-metadata-incomplete", table, message: "table_xinfo was unavailable; hidden and generated column metadata needs review." });
    }
    if (columns.length === 0) {
      report({ code: "table-not-found", table, message: "The selected table was not found or exposes no ordinary columns." }, true);
      continue;
    }
    if (columns.some(column => typeof column.name === "string" && column.name.toLowerCase().startsWith("__sync_"))) {
      report({ code: "engine-table-excluded", table, message: "This table contains reserved sync storage columns and was excluded." }, true);
      continue;
    }
    const fields: Record<string, CrudFieldDefinition> = Object.create(null) as Record<string, CrudFieldDefinition>;
    const primaryColumns: { field: string; position: number }[] = [];
    for (const column of [...columns].sort((left, right) => Number(left.cid) - Number(right.cid))) {
      if (!identifier(column.name)) {
        report({ code: "unsupported-column-name", table, message: "A column needs an explicit application field mapping because its name is unsupported." }, true);
        continue;
      }
      const name = column.name;
      if (!integer(column.pk) || ![0, 1].includes(column.notnull as number) || (extended && !integer(column.hidden))) throw new TypeError(`Invalid column metadata for ${table}.${name}.`);
      if (column.pk > 0) primaryColumns.push({ field: name, position: column.pk });
      if (extended && column.hidden !== 0) {
        report({ code: "generated-column-unsupported", table, column: name, message: "Hidden or generated columns are not imported as writable CRUD fields." }, true);
        continue;
      }
      if (typeof column.type !== "string") throw new TypeError(`Invalid declared type for ${table}.${name}.`);
      const type = scalar(column.type);
      if (type === undefined) {
        report({ code: "ambiguous-column-type", table, column: name, message: `Declared type ${column.type || "(none)"} needs an explicit JSON scalar codec; boolean, date, JSON, blob and decimal semantics are not inferred.` }, true);
        continue;
      }
      const nullable = column.notnull !== 1;
      fields[name] = Object.freeze({ type, ...(nullable ? { nullable: true } : {}) });
      if (column.pk > 0 && nullable) report({ code: "primary-key-nullability-review", table, column: name, message: "PRAGMA metadata does not prove this primary key nonnullable. Review rowid, STRICT and WITHOUT ROWID semantics before declaring the required nonnullable sync key." }, true);
      if (type === "number") report({ code: "numeric-semantics-review", table, column: name, message: "Review integer precision, boolean encodings and numeric domain constraints before using JavaScript numbers." });
      if (column.dflt_value !== null && column.dflt_value !== undefined) report({ code: "database-default-not-imported", table, column: name, message: "SQL defaults are not reproduced by offline inserts; provide application values explicitly." });
    }
    const primaryKey = primaryColumns.sort((left, right) => left.position - right.position).map(column => column.field);
    if (primaryKey.length === 0) report({ code: "primary-key-required", table, message: "A sync collection needs an explicit stable primary key; no key is inferred from rowid or uniqueness." }, true);
    if (primaryKey.length > 32) report({ code: "primary-key-too-wide", table, message: "Portable sync keys support at most 32 components." }, true);
    if (primaryKey.some(field => !Object.hasOwn(fields, field))) report({ code: "primary-key-field-unresolved", table, message: "A primary-key column has no supported field declaration and must be resolved before generation." }, true);
    const indexes: Record<string, readonly string[]> = Object.create(null) as Record<string, readonly string[]>;
    for (const index of await query("index_list", table)) {
      if (!identifier(index.name)) { report({ code: "unsupported-index-name", table, message: "An index name needs an explicit application mapping." }); continue; }
      const name = index.name;
      if (index.origin === "pk") {
        let details: readonly Record<string, unknown>[];
        try { details = await query("index_xinfo", name); } catch { details = []; }
        const keys = details.filter(part => part.key === 1);
        if (keys.length === 0 || keys.some(part => part.desc !== 0 || typeof part.coll !== "string" || part.coll.toUpperCase() !== "BINARY")) report({ code: "primary-key-order-review", table, index: name, message: "Primary-key collation and ordering are unknown or differ from portable ascending BINARY keys; review identity semantics explicitly." }, true);
        continue;
      }
      if (index.unique !== 0) { report({ code: "unique-index-not-imported", table, index: name, message: "Unique constraints require authority validation and are not converted to nonunique sync indexes." }); continue; }
      if (index.partial !== 0) { report({ code: "partial-index-not-imported", table, index: name, message: "Partial index predicates cannot be reproduced by the portable index declaration." }); continue; }
      let details: readonly Record<string, unknown>[];
      try { details = await query("index_xinfo", name); }
      catch { details = []; }
      if (details.length === 0 || details.some(part => part.key !== 0 && part.key !== 1)) {
        // index_info alone cannot establish collation or direction, so it never
        // authorizes an apparently equivalent portable index.
        await query("index_info", name);
        report({ code: "index-metadata-incomplete", table, index: name, message: "Collation and direction metadata is unavailable; review this index manually." });
        continue;
      }
      const parts = details.filter(part => part.key === 1).sort((left, right) => Number(left.seqno) - Number(right.seqno));
      if (parts.length === 0 || parts.length > 32 || parts.some(part => !integer(part.cid) || part.cid < 0 || !identifier(part.name))) { report({ code: "expression-index-not-imported", table, index: name, message: "Expression, rowid and oversized indexes are not converted to portable field tuples." }); continue; }
      if (parts.some(part => part.desc !== 0 || typeof part.coll !== "string" || part.coll.toUpperCase() !== "BINARY")) { report({ code: "index-order-not-imported", table, index: name, message: "Only ascending indexes with BINARY collation have portable field-tuple semantics." }); continue; }
      const names = parts.map(part => part.name as string);
      if (new Set(names).size !== names.length || names.some(field => !Object.hasOwn(fields, field))) { report({ code: "index-fields-unresolved", table, index: name, message: "The index references repeated or unresolved fields and needs manual review." }); continue; }
      indexes[name] = Object.freeze(names);
    }
    const foreignKeys = await query("foreign_key_list", table);
    if (foreignKeys.length > 0) report({ code: "foreign-keys-not-imported", table, message: "Foreign keys and cascade actions require application-level sync and authority rules; relationships are not inferred." });
    report({ code: "application-review-required", table, message: "Review stored value types, constraints, account and stream boundaries, authorization and merge rules. Discovery does not inspect rows or adopt this table as engine storage." });
    collections[table] = Object.freeze({ fields: Object.freeze(fields), primaryKey: Object.freeze(primaryKey), indexes: Object.freeze(indexes) });
  }
  return Object.freeze({ sourceTables: Object.freeze(tables), collections: Object.freeze(collections), warnings: Object.freeze(warnings), unresolved: Object.freeze(unresolved), metadata: Object.freeze({ kind: "d1-schema-draft", version: 1, reviewRequired: true, rowsRead: false, writesPerformed: false }) });
}
