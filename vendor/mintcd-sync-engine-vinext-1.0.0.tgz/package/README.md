# @mintcd/sync-engine-vinext

Generate one typed hook module and a Vinext route from `wrangler.jsonc` and
a shared logical schema. Package helpers compose the Cloudflare D1 authority
and optional PWA worker, public shell build and registration.

This guide describes Vinext package 1.0.0 with core `@mintcd/sync-engine` 2.2.0.
Install the integration; it includes the core engine as a dependency:

```sh
npm install @mintcd/sync-engine-vinext
```

Create `sync-engine.config.ts` in the application root for configuration
completion and literal schema inference:

```ts
import { defineSyncConfig } from "@mintcd/sync-engine-vinext/config";

export default defineSyncConfig({
  version: 1,
  appId: "notes",
  contractVersion: "notes/1",
  wrangler: { config: "wrangler.jsonc", binding: "DB" },
  collections: {
    notes: {
      fields: {
        id: { type: "string" },
        title: { type: "string" },
        folderId: { type: "string" },
        archived: { type: "boolean" }
      },
      primaryKey: ["id"],
      indexes: { byFolder: ["folderId"] }
    }
  }
});
```

`sync-engine.config.json` remains supported as plain JSON/JSONC data. The CLI
and Vite plugin discover a single default TS or JSON file automatically; if both
exist, select one with `--config` or the plugin's `config` option. TypeScript
configuration and its imports execute as trusted build-time code; JSON does not.

Keep your existing Vinext Cloudflare deployment plugins and add generation
before `vinext()`:

```ts
import { syncEngineVinext } from "@mintcd/sync-engine-vinext/vite";

// Within your existing Vite configuration:
plugins: [syncEngineVinext(), vinext(), /* existing platform plugins */]
```

The installed CLI also supports explicit generation and drift checks:

```sh
npx sync-engine-vinext generate
npx sync-engine-vinext generate --check
npx sync-engine-vinext types --wrangler wrangler.jsonc
```

The generated `sync/server.ts` scaffold is application-owned and rejects
requests until you implement authentication, stream authorization and your
Origin/CSRF policy. Apply the generated initial SQL migration through your
normal deployment workflow. Generation never applies it or changes Wrangler.

Generation produces `sync/generated.ts` and `app/api/sync/route.ts`, plus the
create-once authentication/policy scaffold and initial SQL migration. PWA
worker and registration entries stay inside the build integration as virtual
modules. The browser never imports the authored build configuration.

Client Components use a stable typed configuration and hook:

```tsx
"use client";
import { createSyncConfig } from "@mintcd/sync-engine-vinext";
import { useSyncEngine } from "./sync/generated";

// After authentication; initialize only at trusted bootstrap.
const config = createSyncConfig({
  accountId: "alice", streamId: "alice/notes", initialize: true,
});

export function Notes() {
  const { engine, error, logoutSync } = useSyncEngine(config);
  if (error) return <p>{String(error)}</p>;
  if (!engine) return <p>Opening local notes...</p>;
  return <>
    <button onClick={() => void engine.sync()}>Sync notes</button>
    <button onClick={() => void logoutSync()}>Disconnect sync</button>
  </>;
}
```

The generated module exports only `useSyncEngine`. The hook returns
`{ engine, status, error, phase, logoutSync }`, opens after hydration,
shares the engine between consumers of the same hook/config and cleans up
after the last consumer.
Pass `null` while awaiting authentication. Keep the config in a module constant
or `useMemo`; `createSyncConfig` configures the client at runtime, while
`defineSyncConfig` declares the build-time schema.

Once the hook returns an engine, UI handlers use its typed collection API:

```ts
await engine.from("notes").insert({
  id: "note-1", title: "Offline draft", folderId: "inbox", archived: false,
});
await engine.from("notes").update(["note-1"], { title: "Updated draft" });

const page = await engine.from("notes")
  .select("id", "title")
  .where("folderId", "eq", "inbox")
  .limit(50)
  .execute();

await engine.sync();
const status = await engine.status();
```

The generated hook supplies TypeScript inference for table names, columns,
predicate values, primary keys, mutations and selected results. Queries read
local optimistic records;
writes return after durable local enqueue. Server policy makes the final
decision. Only supported declared index intervals are accepted by `.where()`.

The hook's `logoutSync()` method disables the replica and retains local work.
After awaiting logout, sign in with a fresh `createSyncConfig(...)` value;
previously observed configurations remain revoked, even for the same account.
Signing back into the same retained account/stream with `initialize: true`
resumes its identity and pending work. After intentional deletion with
`logoutSync({ deleteData: true })`, explicitly use `initialize: true,
freshStart: true`. Lost storage is otherwise reported as a recovery failure.
Generated sessions require IndexedDB and Web Locks, including when PWA support
is disabled. The portable core remains available for custom composition.

To rebuild local state from D1 after **every app deployment**, inject one unique
build/release ID and pass it as a runtime client option:

```ts
const config = createSyncConfig({
  accountId: "alice", streamId: "alice/notes", initialize: true,
  deploymentVersion: BUILD_RELEASE_ID,
});
```

Use the same ID throughout that deployed asset set. The first versioned session
and every changed ID fetch the authenticated generated GET snapshot, install its
materialized rows at the real canonical watermark in a fresh local replica, then
continue incremental POST sync. The same ID resumes its local database/client
identity without another snapshot. Keep `appId` and the D1 namespace stable.

A complete valid snapshot is prepared before replacing the registry entry.
Existing owners drain their writes; retained pending edits block replacement
with a clear error and stay reachable in the old database, including when
switching accounts after logout. Sign into the previous account/session to sync
its queue before replacing that slot. Offline/auth/invalid snapshots
preserve the existing registration. Snapshot requests and responses use
`no-store`; the same application auth/stream/Origin hook protects GET and POST.
Omitting the option disables deployment rebuilds; pending-work protection also
applies to ordinary account/stream replacement. See
[`docs/vinext-package.md`](../../docs/vinext-package.md#rebuild-the-local-replica-after-every-app-deployment)
for bounds, recovery, retention and deployment integration details.

Explicit schema discovery can reduce initial schema entry:

```sh
npx sync-engine-vinext discover --wrangler wrangler.jsonc --binding DB --table notes --local --out sync-schema.draft.json
```

Install Wrangler in the application first. Add `--env staging` for a named
environment, and explicitly select `--remote` instead of `--local` to inspect
its remote database. Discovery reads only allowlisted table metadata and returns
a draft requiring review. It does not adopt existing tables/data, infer
authentication, or run during generation/build. SQLite affinities need logical
overrides for ambiguous values and constraints.

PWA setup requires an application-owned browser entry, manifest and public
icons. A browser-only offline entry can mount the same hook-based components:

```tsx
import { createRoot } from "react-dom/client";
import { Notes } from "../components/Notes";

createRoot(document.getElementById("root")!).render(<Notes />);
```

The Vite integration builds the worker and public assets, registers the
worker in production, and retains foreground synchronization as a fallback.
Background scheduling is best effort. Full setup and API documentation live in
the repository's `docs/vinext-package.md` and `docs/pwa-api.md`.

Runtime exports: `.`, `/client`, `/worker`, `/server` and `/discovery`.
The package root and `/client` export `createSyncConfig` without importing React.
`/react` supplies the shared hook lifecycle used by the generated module.
`/config` supplies the typed configuration helper; `/node` and `/vite` provide
build tooling. Vinext tooling requires Node `^20.19.0 || >=22.12.0`; the tested
PWA build range is Vite `>=8.3.4 <9` with Vinext 1.2.1. Loading TS configuration
requires the application's Vite installation; JSON generation does not load Vite.

For existing applications, regenerate and replace `sync/client.generated`
imports with `sync/generated`. Unchanged obsolete generated files are removed
under the ownership checks. Update the preserved application-owned server hook
to export `createPolicy(model)` instead of `policy`; use a type-only `SyncModel`
import from the generated route instead of importing `model.generated`.
Import `createSyncConfig` from the package; the generated module exports only
`useSyncEngine`. Logout is available on the hook's returned state.
